# Promoter14 and Figure 7 amendment — 2026-09-09

This amendment updates Figure 5 and promoter Tables S9, S10, S27 and S29 to **14 patterns** and
provides the current Figure 7 author PDF/PNG with the grey-point label **Non-DE**. It supplements
the fixed revision-20260909 release and the preceding reader-label amendment. It does not rewrite
their archived files.

## Analysis boundary

The historical custom BACGTG (ACGTG_flank_B) entry is excluded on provenance and interpretability
grounds: no independent exact-pattern database record was established, and it is nested within
existing ACGT-core categories. B is C/G/T; CACGTG equals G-box and the three expansions contain
the ABRE-associated ACGTG core. Remaining categories may still overlap and are not independent
functional sites or pathways. Deletion is not based on significance.

All 21,798 by 14 retained counts and all 42 raw one-sided Fisher P values are unchanged. Existing
73-sequence caches reproduce all 1,022 target counts. BH correction is recalculated across **14
tests per scenario** and **42 tests jointly**. Minimum within-scenario adjusted P values are
0.913466881888829 (73/21,695), 0.5939052148989911 (69/19,957), and 0.7193580168031927
(53/19,144). Joint BH42 values are all 1.0. No pattern is significantly enriched at BH FDR < 0.05.

There is no new sequencing or genome extraction, no change to promoter boundaries/cohorts, and
no new expression analysis or functional validation. Figure 7 changes presentation only.

## Reproduce and verify

```sh
python verify_patch.py
cd promoter14
python run_all14.py
```

Python plotting dependencies are numpy, matplotlib and PyMuPDF. The independent rebuild entry
point verifies frozen historical inputs, recalculates Fisher/BH, checks the existing 73 cached
sequences and redraws Figure 5. The 15-pattern inputs/results are retained under
promoter14/historical15/ **for audit only**. Current results/ and replacement_tables/ use 14 patterns;
the joint column is bh_all_42_p. S28 is a historical byte-exact reference copy only, not a replacement
for subsequent reader-label corrections to the current S28.

Use the outer MANIFEST_SHA256.tsv for the distributed bytes. The promoter14 manifest verifies
its independent analysis delivery. PUBLICATION_TRANSFORMS.tsv lists input/distributed hashes;
the source already uses relative paths or explicit CLI arguments. No local usernames, private
execution directories, manuscript files or reviewer correspondence are included.
