"""Single entry point for the current 14-pattern tables, figure and verification."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for script in ['rebuild_14_patterns.py','plot_promoters14_compact.py','finalize_analysis14.py']:
    subprocess.run([sys.executable,'-X','utf8',str(root/script)],cwd=root,check=True)
