# Current 14-pattern promoter analysis

Run from this directory:

```sh
python run_all14.py
```

Requirements: Python 3.8 or later; numpy, matplotlib, PyMuPDF (fitz).
The entry point validates frozen historical counts/audits, excludes the unsupported custom pattern,
recomputes 42 unchanged raw Fisher P values, applies within-scenario BH to 14 tests and joint BH to
42 tests, rescans the existing 73 cached proxy sequences for 1,022 retained counts, and regenerates
the Figure 5 PDF/SVG/PNG. No genome extraction, new sequencing, expression analysis, or wet-lab
validation is performed. The original backgrounds and sequence boundaries are retained.

Current replacement tables are S9, S10, S27 and S29. S28 is a byte-exact historical reference only;
do not overwrite a later editorial correction to the current S28 with that reference copy.
The historical15 directory is explicitly excluded from active interpretation and contains old 15/45
test results solely for auditability. See IMPACT_REPORT_14模式.md and BH_change_audit.tsv.

The historical motif source records establish the sequence pattern provenance, not binding or
regulatory activity in R. soongarica. Excluding a custom pattern does not make the remaining
categories independent. No enrichment passes BH FDR < 0.05 in this revision.
