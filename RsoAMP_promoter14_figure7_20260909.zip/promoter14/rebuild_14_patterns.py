#!/usr/bin/env python3
"""Rebuild the 14-pattern tables from frozen cached 15-pattern counts.

This does not extract a genome, sequence new material, or infer a regulatory function.
The excluded legacy custom pattern is documented in historical15/, not tested here.
"""
import argparse, csv, hashlib, json, math, re, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED = 'ACGTG_flank_B'
SCENARIOS = ('primary_full_length', 'S1_clean', 'S2_clean_utr')
VERSION = 'promoter14_20260909'

def read(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f, delimiter='\t'))

def write(path, rows):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    assert rows, str(path)
    with path.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter='\t')
        w.writeheader(); w.writerows(rows)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def bh(ps):
    order = sorted(range(len(ps)), key=ps.__getitem__)
    out = [1.0] * len(ps); v = 1.0
    for j in range(len(order)-1, -1, -1):
        i = order[j]; v = min(v, ps[i] * len(ps)/(j+1)); out[i] = v
    return out

def fisher(a, n, c, m):
    """Exact integer hypergeometric upper tail, same test as the frozen analysis."""
    k = a+c; N = n+m; den = math.comb(N, n)
    return sum(math.comb(k, x) * math.comb(N-k, n-x)
               for x in range(max(a, 0, n-(N-k)), min(n, k)+1)) / den

def bh_independent(ps):
    """Direct definition, independent of the reverse-pass implementation above."""
    order = sorted(range(len(ps)), key=ps.__getitem__)
    qs = [1.0] * len(ps)
    for rank, i in enumerate(order):
        qs[i] = min([1.0] + [ps[order[k]] * len(ps)/(k+1) for k in range(rank, len(ps))])
    return qs

def initialize(source):
    """One-time byte-exact snapshot. A repeat refuses changed frozen inputs."""
    files = [
        'results/all_gene_motif_counts.tsv', 'results/all_gene_upstream_audit.tsv',
        'results/cis_element_full_results.tsv', 'results/cis_element_enrichment.tsv',
        'results/cis_element_sensitivity.tsv', 'results/promoter_extraction_audit.tsv',
        'results/summary.json', 'motif_sources.tsv',
        'primary73_promoter_catalogue.tsv', 'primary73_upstream_proxies.fa',
        'background_cohort_membership.tsv', 'replacement_tables/S28_PromoterQC.tsv',
        'audit_promoters_primary73.py', 'plot_promoters_primary73.py',
        'figures/figure5_qa.json',
        'execution_provenance.json', 'MOTIF_PROVENANCE.md', 'REPRODUCE.md',
    ]
    checks = []
    for rel in files:
        src = source/rel; dest = ROOT/'historical15'/rel
        before = sha(src); dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            assert sha(dest) == before, ('Refuse changed frozen input', rel)
        else:
            shutil.copyfile(src, dest)
        after = sha(src); copied = sha(dest)
        assert before == after == copied
        checks.append({'relative_path':rel, 'source_sha256_before':before,
                       'source_sha256_after':after, 'snapshot_sha256':copied,
                       'status':'PASS'})
    write(ROOT/'historical15/SOURCE_SNAPSHOT_SHA256.tsv', checks)
    (ROOT/'historical15/README_HISTORICAL.md').write_text(
        '# Frozen 15-pattern inputs — historical only\n\n'
        'Byte-exact snapshots of the prior published module S8/analysis/启动子_F5.\n'
        'These records retain the excluded custom pattern and old 15/45-test BH values '
        'for auditability. They are not the active Figure 5 analysis.\n'
        'The old workflow and provenance document prior computation; do not run the '
        'historical scripts to regenerate current 14-pattern outputs.\n', encoding='utf-8')

def rebuild():
    frozen = ROOT/'historical15'; result = ROOT/'results'; result.mkdir(exist_ok=True)
    replacements = ROOT/'replacement_tables'; replacements.mkdir(exist_ok=True)
    manifest = read(frozen/'SOURCE_SNAPSHOT_SHA256.tsv')
    assert all(sha(frozen/r['relative_path']) == r['snapshot_sha256'] for r in manifest)
    original_summary = json.loads((frozen/'results/summary.json').read_text(encoding='utf-8'))
    original_sources = read(frozen/'motif_sources.tsv')
    sources = [r.copy() for r in original_sources if r['element'] != EXCLUDED]
    elements = [r['element'] for r in sources]; assert len(elements) == 14
    for r in sources:
        r['selection_reason'] = ('Retained documented sequence from the historical panel; '
            'reverse-complement TGACG/CGTCA aliases merged; unsupported custom legacy entry '
            'excluded from the 14-pattern revision before recalculating multiple testing')
    write(ROOT/'motif_sources.tsv', sources)
    old_counts = read(frozen/'results/all_gene_motif_counts.tsv')
    counts = {r['gene_id']:{key:int(r[key]) for key in elements} for r in old_counts}
    assert len(counts) == 21798
    write(result/'all_gene_motif_counts.tsv',
          [{'gene_id':r['gene_id'], **{e:r[e] for e in elements}} for r in old_counts])
    old_long = read(frozen/'results/cis_element_full_results.tsv')
    long = [r for r in old_long if r['element'] != EXCLUDED]
    assert len(long) == 73*14
    assert all(int(r['nonredundant_genomic_site_count']) == counts[r['gene_id']][r['element']] for r in long)
    write(result/'cis_element_full_results.tsv', long)
    audit = read(frozen/'results/all_gene_upstream_audit.tsv')
    by_gene = {r['gene_id']:r for r in audit}; assert set(by_gene) == set(counts)
    for rel in ['results/all_gene_upstream_audit.tsv', 'results/promoter_extraction_audit.tsv',
                'primary73_promoter_catalogue.tsv', 'primary73_upstream_proxies.fa',
                'background_cohort_membership.tsv', 'replacement_tables/S28_PromoterQC.tsv']:
        shutil.copyfile(frozen/rel, ROOT/rel)
        assert sha(frozen/rel) == sha(ROOT/rel)
    old_tests = {(r['scenario'], r['element']):r for r in read(frozen/'results/cis_element_sensitivity.tsv')}
    enrichment = []; summaries = []
    for scenario in SCENARIOS:
        target = [r['gene_id'] for r in audit if r['target']=='1' and r[scenario]=='1']
        background = [r['gene_id'] for r in audit if r['target']=='0' and r[scenario]=='1']
        n, m = len(target), len(background); rows = []
        for s in sources:
            name = s['element']; a = sum(counts[k][name]>0 for k in target)
            c = sum(counts[k][name]>0 for k in background); b=n-a; d=m-c
            original = old_tests[(scenario, name)]
            expected = {'target_full_length_promoters':n,'target_with_motif':a,
                        'non_target_background_full_length_promoters':m,'background_with_motif':c}
            assert all(int(original[k]) == v for k,v in expected.items()), (scenario, name)
            p = fisher(a,n,c,m)
            assert p == float(original['fisher_greater_p']), (scenario, name, p, original['fisher_greater_p'])
            rows.append({'scenario':scenario, 'element':name, 'iupac_consensus':s['iupac_consensus'],
                'annotation_category':s['annotation_category'], 'target_full_length_promoters':n,
                'target_with_motif':a, 'target_fraction':a/n,
                'non_target_background_full_length_promoters':m, 'background_with_motif':c,
                'background_fraction':c/m, 'prevalence_difference':a/n-c/m,
                'odds_ratio':(a*d)/(b*c) if b*c else ('inf' if a*d else 'undefined'),
                'fisher_greater_p':p, 'bh_adjusted_p':'', 'bh_all_42_p':'',
                'enriched_at_bh_fdr_0.05':''})
        qs = bh([r['fisher_greater_p'] for r in rows])
        assert qs == bh_independent([r['fisher_greater_p'] for r in rows])
        for row,q in zip(rows,qs):
            row['bh_adjusted_p']=q; row['enriched_at_bh_fdr_0.05']='YES' if q<.05 else 'NO'
        enrichment.extend(rows)
        historical_scenario=next(r for r in original_summary['scenarios'] if r['scenario']==scenario)
        assert math.isclose(sum(float(by_gene[k]['gc_fraction']) for k in target)/n,
                            historical_scenario['mean_target_gc'], rel_tol=1e-12)
        assert math.isclose(sum(float(by_gene[k]['gc_fraction']) for k in background)/m,
                            historical_scenario['mean_background_gc'], rel_tol=1e-12)
        summaries.append({'scenario':scenario,'target_n':n,'background_n':m,'tested_patterns':14,
            'minimum_p':min(r['fisher_greater_p'] for r in rows), 'minimum_bh_q':min(qs),
            'significant':[r['element'] for r in rows if r['bh_adjusted_p']<.05],
            'mean_target_gc':historical_scenario['mean_target_gc'],
            'mean_background_gc':historical_scenario['mean_background_gc']})
    allq=bh([r['fisher_greater_p'] for r in enrichment])
    assert allq == bh_independent([r['fisher_greater_p'] for r in enrichment])
    for row,q in zip(enrichment,allq):row['bh_all_42_p']=q
    write(result/'cis_element_enrichment.tsv',[r for r in enrichment if r['scenario']==SCENARIOS[0]])
    write(result/'cis_element_sensitivity.tsv', enrichment)
    impacts=[]
    for r in enrichment:
        old=old_tests[(r['scenario'],r['element'])]
        impacts.append({'scenario':r['scenario'],'element':r['element'],
            'old_fisher_greater_p':old['fisher_greater_p'],'new_fisher_greater_p':r['fisher_greater_p'],
            'raw_p_exactly_unchanged':True, 'old_BH15':old['bh_adjusted_p'],
            'new_BH14':r['bh_adjusted_p'],'delta_BH14_minus_BH15':r['bh_adjusted_p']-float(old['bh_adjusted_p']),
            'old_BH45':old['bh_all_45_p'],'new_BH42':r['bh_all_42_p'],
            'delta_BH42_minus_BH45':r['bh_all_42_p']-float(old['bh_all_45_p'])})
    write(ROOT/'BH_change_audit.tsv', impacts)
    family_order={'Defensin':0,'Snakin_GASA':1,'nsLTP':2}
    member_family={r['member_id']:r['family'] for r in long}
    members=sorted(member_family, key=lambda k:(family_order[member_family[k]],int(re.search(r'(\d+)$',k).group())))
    member_rank={name:i for i,name in enumerate(members)}; element_rank={name:i for i,name in enumerate(elements)}
    ordered=sorted(long,key=lambda r:(member_rank[r['member_id']],element_rank[r['element']]))
    write(replacements/'S9_PromoterOccur.tsv',ordered)
    shutil.copyfile(result/'cis_element_enrichment.tsv', replacements/'S10_PromoterEnrich.tsv')
    shutil.copyfile(ROOT/'motif_sources.tsv', replacements/'S27_MotifSources.tsv')
    shutil.copyfile(result/'cis_element_sensitivity.tsv', replacements/'S29_PromoterSensitivity.tsv')
    mapping=[]
    for name in ['S9_PromoterOccur','S10_PromoterEnrich','S27_MotifSources','S28_PromoterQC','S29_PromoterSensitivity']:
        rows=read(replacements/(name+'.tsv'))
        mapping.append({'sheet_name':name,'tsv_file':'replacement_tables/'+name+'.tsv',
            'data_rows':len(rows),'columns':len(rows[0]),
            'status':('UNCHANGED_BYTE_EXACT_REFERENCE_ONLY_DO_NOT_REPLACE_CURRENT_S28' if name.startswith('S28') else VERSION)})
    write(ROOT/'table_replacement_map.tsv', mapping)
    summary={k:original_summary[k] for k in ['genome_sha256','gff_sha256','catalogue_sha256',
        'gene_n','official_gene_n','novel_target_models','official_target_models',
        'non_target_official_genes_before_filters','background_includes_novel_models',
        'target_n','unlinked_utr_features','target_no_utr','target_overlaps']}
    summary.update({'analysis_version':VERSION, 'python':sys.version, 'patterns':14,
        'tests_per_scenario':14,'tests_across_three_scenarios':42,'excluded_historical_pattern':EXCLUDED,
        'operation':'Filter unsupported custom pattern from cached counts and recompute Fisher and BH',
        'genome_extraction_rerun':False,'new_sequence_data':False,'cached_primary73_sequences_recounted':False,
        'historical_genome_and_gff_hashes_above_are_inherited_provenance':True,
        'all_14_retained_counts_exactly_preserved_genes':len(counts),
        'retained_raw_fisher_p_values_exactly_reproduced':len(enrichment),
        'BH_calculated_from_14_and_42_tests':True,'scenarios':summaries,
        'minimum_bh_all_42_q':min(allq), 'significant_joint42':[r['element'] for r in enrichment if r['bh_all_42_p']<.05],
        'script_sha256':sha(Path(__file__))})
    # Directly rescan existing 73 frozen proxy sequences, without genome extraction.
    iupac=dict(zip('ACGTRYSWKMBDHVN',['A','C','G','T','[AG]','[CT]','[GC]','[AT]','[GT]','[AC]','[CGT]','[AGT]','[ACT]','[ACG]','[ACGT]']))
    comp=str.maketrans('ACGTRYSWKMBDHVN','TGCAYRSWMKVHDBN')
    patterns={s['element']:[re.compile('(?=('+''.join(iupac[x] for x in sequence)+'))')
        for sequence in {s['iupac_consensus'],s['iupac_consensus'].translate(comp)[::-1]}] for s in sources}
    fasta=(ROOT/'primary73_upstream_proxies.fa').read_text(encoding='utf-8').splitlines(); checked=0
    for i in range(0,len(fasta),2):
        head,seq=fasta[i:i+2]; gid=head.split('gene_id=')[1]; assert len(seq)==2000
        for element,pats in patterns.items():
            sites={(hit.start(),hit.end(1)) for pat in pats for hit in pat.finditer(seq)}
            assert len(sites)==counts[gid][element],(gid,element)
            checked+=1
    summary['cached_primary73_sequences_recounted']=True
    summary['cached_primary73_site_counts_verified']=checked
    save(result/'summary.json',summary)
    save(ROOT/'execution_provenance.json',{'analysis_version':VERSION,
        'entry_point':'python rebuild_14_patterns.py', 'inputs':'historical15/SOURCE_SNAPSHOT_SHA256.tsv',
        'no_new_genome_extraction_or_sequencing':True,'filter_and_statistical_recalculation_only':True,
        'source_module':'published revision-20260909: modules/S8/analysis/启动子_F5',
        'frozen_historical_source_verification':'PASS', 'script_sha256':sha(Path(__file__))})
    save(ROOT/'independent_qa.json',{'status':'PASS','retained_gene_pattern_count_values':len(counts)*14,
        'raw_Fisher_P_values_verified_exactly':42,'BH_recomputed_by_two_implementations':True,
        'primary73_cached_sequence_count_checks':checked,'S28_bytes_unchanged':True,
        'cohort_audit_and_background_membership_bytes_unchanged':True,
        'sequence_fasta_bytes_unchanged':True,'all_adjusted_tests_nonsignificant':not any(q<.05 for q in allq)
            and not any(r['bh_adjusted_p']<.05 for r in enrichment)})
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--initialize-from',type=Path,help='One-time frozen snapshot of prior module')
    args=parser.parse_args()
    if args.initialize_from:initialize(args.initialize_from)
    rebuild()
