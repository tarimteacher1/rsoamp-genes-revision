# Frozen 15-pattern inputs — historical only

Byte-exact snapshots of the prior published module S8/analysis/启动子_F5.
These records retain the excluded custom pattern and old 15/45-test BH values for auditability. They are not the active Figure 5 analysis.
The old workflow and provenance document prior computation; do not run the historical scripts to regenerate current 14-pattern outputs.
