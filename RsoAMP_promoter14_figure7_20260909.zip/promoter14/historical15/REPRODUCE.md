# Reproduce the primary73 promoter analysis

The analysis was executed on Python 3.8.10 using only the standard library. Plotting used Python 3.13, matplotlib 3.10.8 and numpy 2.4.3. The audit requires the original R. soongarica genome FASTA and official GFF, whose SHA-256 values are recorded in `results/summary.json`; these large source files are referenced, not redistributed here. The public genome/annotation source is Figshare DOI `10.6084/m9.figshare.25533064.v2`. Seven new model spans and the exact target membership are included locally.

The `baseline_verification_inputs/` directory contains only the three previously verified official-gene outputs required to assert that all original sequence hashes/counts were reproduced. These files do not supply the new statistical results. The audit rescans every official plus new-model interval directly from the genome.

From this directory, run the following commands, setting the two source paths to your copies. The output directory must not already exist:

```bash
python audit_promoters_primary73.py \
  --genome /path/to/genome.fa --gff /path/to/genome.gff \
  --catalogue primary73_promoter_catalogue.tsv \
  --novel-models novel7_model_spans.json \
  --baseline-results baseline_verification_inputs \
  --outdir rebuilt_results

python verify_promoters_primary73.py \
  --results rebuilt_results --sources motif_sources.tsv \
  --baseline-results baseline_verification_inputs \
  --catalogue primary73_promoter_catalogue.tsv \
  --out rebuilt_independent_qa.json

python verify_new7_genome.py \
  --genome /path/to/genome.fa --models novel7_model_spans.json \
  --sequences rebuilt_results/upstream_sequences.fa.gz \
  --out rebuilt_new7_genome_qa.json

python plot_promoters_primary73.py --results rebuilt_results --outdir rebuilt_figures
```

The raw gzip file can contain a creation timestamp, so compressed-file byte hashes need not reproduce across runs. Biological sequence SHA-256 values, coordinates, motif counts, cohort membership and statistical values must reproduce. Figure-file binary hashes can vary with software/font versions; fixed row/column order, counts and natural-log scale are documented in `figure5_qa.json`.

`package_tables_and_qa.py` packages the delivered `results/` and `figures/` into the five replacement TSVs, background membership and primary FASTA, and checks the captured remote-to-local transfer hashes. It is a delivery QA script, not a requirement for recalculating the biology. Its preview-review status describes the delivered figure, which was visually inspected.

All windows are upstream proxies. The new M6 spans describe modeled transcript extents and lack independently established TSSs or separate 5′UTR annotations. The 15-pattern panel is unchanged, finite and sequence-based; no inference of binding or treatment-specific activation is made.
