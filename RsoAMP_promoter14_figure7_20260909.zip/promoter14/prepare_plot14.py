"""One-time, audited extraction of the current Figure 5 renderer only."""
from pathlib import Path
import argparse,hashlib,json
p=argparse.ArgumentParser();p.add_argument('compact_source',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parent
source=a.compact_source.read_text(encoding='utf-8')
snapshot=root/'historical15/plot_compact_F5_F6.py'
snapshot.write_bytes(a.compact_source.read_bytes())
assert hashlib.sha256(snapshot.read_bytes()).digest()==hashlib.sha256(a.compact_source.read_bytes()).digest()
body=source[:source.index('def figure6():')]
body=body.replace('"""Layout-only split heatmaps from frozen tables; no expression re-normalization."""',
    '"""Figure 5 only: 14-pattern count heatmap; plotting does not recalculate statistics."""')
body=body.replace("O=Path(__file__).resolve().parent; R=O.parent\nP=R/'启动子_F5'; E=R/'表达_F6_F7'",
    "P=Path(__file__).resolve().parent\nO=P/'figures'; O.mkdir(exist_ok=True)")
body=body.replace("old=json.loads((P/'figures/figure5_qa.json').read_text(encoding='utf-8'));ids=old['row_order'];names=old['column_order']",
    "old=json.loads((P/'historical15/figures/figure5_qa.json').read_text(encoding='utf-8'));ids=old['row_order'];names=[r['element'] for r in read(P/'motif_sources.tsv')]")
body=body.replace('len(names)==15 and len(lookup)==1095','len(names)==14 and len(lookup)==1022')
body=body.replace(",'ACGTG_flank_B':'BACGTG (custom)'",'')
body=body.replace('15 double-stranded patterns','14 double-stranded patterns')
body=body.replace('np.arange(15)+.5','np.arange(14)+.5')
body=body.replace('len(cells)==1095','len(cells)==1022')
body=body.replace('Proxies use 66 annotated and 7 new-model boundaries; no independently mapped TSSs.',
    'Proxies use 66 annotated + 7 reconstructed-model boundaries; no mapped TSSs.')
body=body.replace("'no_statistical_recalculation':True", "'plot_recalculates_statistics':False,'source_statistics_recalculated_for_14_patterns':True,'tests_per_scenario':14,'joint_tests':42")
body += "\nif __name__=='__main__':\n report=figure5()\n print(json.dumps(report,ensure_ascii=False,indent=2))\n"
assert 'def figure6' not in body and 'BACGTG' not in body and 'ACGTG_flank_B' not in body
(root/'plot_promoters14_compact.py').write_text(body,encoding='utf-8')
(root/'plot_adaptation_provenance.json').write_text(json.dumps({
    'historical_renderer':'historical15/plot_compact_F5_F6.py',
    'historical_renderer_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),
    'source_original_unchanged':True,'Figure6_function_excluded':True,
    'adaptation':'Use current14 tables; preserve split layout, row ordering, flags, cividis and original global ln1p scale; change 15 to14 and update reconstructed-model wording',
    'adapted_renderer_sha256':hashlib.sha256(body.encode()).hexdigest()},indent=2)+'\n',encoding='utf-8')
