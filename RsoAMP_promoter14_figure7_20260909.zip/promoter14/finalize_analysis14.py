"""Finalize documented 14-pattern delivery and byte manifests after plot inspection."""
from pathlib import Path
import csv,hashlib,json,re,shutil
import fitz
from rebuild_14_patterns import read,write,sha,save
root=Path(__file__).resolve().parent
summary=json.loads((root/'results/summary.json').read_text(encoding='utf-8'))
qa=json.loads((root/'figures/Figure5_primary73_compact_QA.json').read_text(encoding='utf-8'))
oldqa=json.loads((root/'historical15/figures/figure5_qa.json').read_text(encoding='utf-8'))
pdf=fitz.open(root/'figures/Figure5_primary73_compact.pdf')
text=pdf[0].get_text()
assert 'BACGTG' not in text and 'custom' not in text
assert '14 double-stranded patterns' in text and '15 double-stranded patterns' not in text
assert all(re.search(r'\b'+re.escape(m)+r'\b',text) for m in oldqa['row_order'])
assert qa['scale']==[0,oldqa['scale_max']] and qa['cell_count']==1022
assert qa['positive_overlap_flags']==4 and qa['positive_no_UTR_flags']==16
for ext in ['pdf','png','svg']:
    shutil.copyfile(root/'figures'/('Figure5_primary73_compact.'+ext),root/'figures'/('Figure5_promoter_motif_occurrence.'+ext))
shutil.copyfile(root/'figures/Figure5_primary73_compact_preview.png',root/'figures/Figure5_preview.png')
qa.update({'rows':73,'column_order':qa['columns'],'row_order':oldqa['row_order'],
           'scale_min':0,'scale_max':oldqa['scale_max'],'preview_visually_reviewed':True,
           'removed_custom_pattern_absent_in_current_figure':True})
save(root/'figures/figure5_qa.json',qa)
impacts=read(root/'BH_change_audit.tsv')
changed_within=sum(float(r['old_BH15'])!=float(r['new_BH14']) for r in impacts)
changed_joint=sum(float(r['old_BH45'])!=float(r['new_BH42']) for r in impacts)
oldsummary=json.loads((root/'historical15/results/summary.json').read_text(encoding='utf-8'))
report=['# Figure 5：删除自定义模式后的影响核验','',
    '版本：`promoter14_20260909`。当前分析由15项改为14项；历史15项输入及统计表保存在 `historical15/`，不作为当前结果。','',
    '## 删除依据','',
    '移除项目沿用的 `ACGTG_flank_B`（BACGTG），因为来源审计没有建立该精确模式的独立数据库依据，且它与已有 ACGT 核心类别嵌套。B 为 C/G/T，因此 BACGTG 展开为 CACGTG、GACGTG、TACGTG；其中 CACGTG 就是现有 G-box，而三者均包含现有 ABRE 搜索核心 ACGTG。反向互补搜索不改变这种嵌套关系。','',
    '该删减基于来源和可解释性，不是依据显著性筛选模式。剩余14类也并非完全独立，图和文字仍不能把它们相加解释成独立调控位点或通路。','',
    '## 实际完成的计算','',
    '- 没有重新提取基因组、测序或改变上游边界。采用冻结的全基因计数和原有cohort条件。',
    '- 21,798个基因 × 14项 = 305,172个保留计数逐项保持相同。',
    '- 另直接复核已有73条上游FASTA的14类序列匹配，1,022个计数全部重现。',
    '- 三个场景的42个单侧Fisher检验由同一列联表重新计算，原始P值与历史保留项逐项完全相同。',
    '- 每场景BH从15项改为14项，联合BH从45项改为42项；两种BH实现结果完全一致。',
    f'- 保留检验中，场景内BH值有{changed_within}/42项变化；联合BH值有{changed_joint}/42项变化。具体旧值、新值和差值见 `BH_change_audit.tsv`。','',
    '| 场景 | 目标/背景 | 原最低BH15 q | 新最低BH14 q | 新显著项 |',
    '|---|---:|---:|---:|---:|']
for s in summary['scenarios']:
    old=next(r for r in oldsummary['scenarios'] if r['scenario']==s['scenario'])
    report.append(f"| {s['scenario']} | {s['target_n']}/{s['background_n']} | {old['minimum_bh_q']:.12g} | {s['minimum_bh_q']:.12g} | 0 |")
report.extend(['','联合42项检验的BH校正值均为1.0。**没有检测到显著富集的结论保持不变。**','',
    '## 图表同步','',
    '- Figure 5的14列、1,022个格子；73个成员顺序、家族组成15/18/40、ln(1+count)、cividis以及全局色阶0–3.5553480614894135保留。',
    '- 4个O标记、16个U标记和146个标记格均保留。图注将7个边界描述为reconstructed-model，而非把重构模型称为新发现基因。',
    '- 当前TSV：S9=1,022行；S10=14行；S27=14行；S29=42行，联合字段名为 `bh_all_42_p`。',
    '- S28仅附原始字节一致副本用于对照，不应覆盖其他线程已校订的当前S28文字；本轮不改变它的数值、边界、UTR或重叠注释。',
    '- PDF单页含全部73个名称；无文字相撞或出界；SVG文字可编辑；PNG为600 dpi。','',
    '## 复核入口','',
    '在本目录运行 `python run_all14.py`。脚本先核查冻结输入SHA-256，再复算表和图及最终清单。依赖Python标准库、numpy、matplotlib、PyMuPDF。',
    '源文件保持只读；来源校验见 `historical15/SOURCE_SNAPSHOT_SHA256.tsv` 和 `plot_adaptation_provenance.json`。'])
(root/'IMPACT_REPORT_14模式.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
(root/'REPRODUCE.md').write_text('''# Current 14-pattern promoter analysis

Run from this directory:

```sh
python run_all14.py
```

Requirements: Python 3.8 or later; numpy, matplotlib, PyMuPDF (fitz).
The entry point validates frozen historical counts/audits, excludes the unsupported custom pattern,
recomputes 42 unchanged raw Fisher P values, applies within-scenario BH to 14 tests and joint BH to
42 tests, rescans the existing 73 cached proxy sequences for 1,022 retained counts, and regenerates
the Figure 5 PDF/SVG/PNG. No genome extraction, new sequencing, expression analysis, or wet-lab
validation is performed. The original backgrounds and sequence boundaries are retained.

Current replacement tables are S9, S10, S27 and S29. S28 is a byte-exact historical reference only;
do not overwrite a later editorial correction to the current S28 with that reference copy.
The historical15 directory is explicitly excluded from active interpretation and contains old 15/45
test results solely for auditability. See IMPACT_REPORT_14模式.md and BH_change_audit.tsv.

The historical motif source records establish the sequence pattern provenance, not binding or
regulatory activity in R. soongarica. Excluding a custom pattern does not make the remaining
categories independent. No enrichment passes BH FDR < 0.05 in this revision.
''',encoding='utf-8')
(root/'MOTIF_PROVENANCE.md').write_text('''# Active motif selection: 14 patterns

The active source catalogue is motif_sources.tsv (14 rows). It retains documented sequence patterns
from the previous catalogue, merges reverse-complement TGACG/CGTCA aliases, and excludes the
unsupported custom legacy ACGTG_flank_B entry from all active counts and tests.
Exclusion is based on provenance and interpretability, rather than statistical significance. The
old catalogue and its rationale remain available in historical15/; historical results are not active.

BACGTG expands to CACGTG, GACGTG and TACGTG. The first equals G-box and all contain the
ABRE-associated ACGTG core. Consequently the custom category did not supply an independent
functional motif class. Remaining categories can still overlap and must not be summed as
independent sites/pathways. Source annotations do not validate R. soongarica binding or regulation.
''',encoding='utf-8')
files=[]
for p in sorted(root.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts or p.name in ['MANIFEST_SHA256.tsv','DELIVERY_QA.json']:continue
    files.append({'relative_path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
write(root/'MANIFEST_SHA256.tsv',files)
assert all(sha(root/r['relative_path'])==r['sha256'] for r in files)
save(root/'DELIVERY_QA.json',{'status':'PASS','version':'promoter14_20260909',
    'manifest_files':len(files),'manifest_sha256':sha(root/'MANIFEST_SHA256.tsv'),
    'historical_inputs_sha256_verified':True,'source_files_changed':False,
    'figure_pdf_text_and_layout_verified':True,'figure_preview_visually_reviewed':True,
    'counts_retained_exactly':305172,'raw_p_retained_exactly':42,
    'updated_within_scenario_BH_values':changed_within,'updated_joint_BH_values':changed_joint,
    'adjusted_significant_patterns':0,'S28_reference_bytes_unchanged':True})
print(json.dumps({'status':'PASS','manifest_files':len(files),'within_BH_changed':changed_within,
                  'joint_BH_changed':changed_joint,'new_significant_patterns':0}))
