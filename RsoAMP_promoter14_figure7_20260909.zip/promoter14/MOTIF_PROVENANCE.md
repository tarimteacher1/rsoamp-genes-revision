# Active motif selection: 14 patterns

The active source catalogue is motif_sources.tsv (14 rows). It retains documented sequence patterns
from the previous catalogue, merges reverse-complement TGACG/CGTCA aliases, and excludes the
unsupported custom legacy ACGTG_flank_B entry from all active counts and tests.
Exclusion is based on provenance and interpretability, rather than statistical significance. The
old catalogue and its rationale remain available in historical15/; historical results are not active.

BACGTG expands to CACGTG, GACGTG and TACGTG. The first equals G-box and all contain the
ABRE-associated ACGTG core. Consequently the custom category did not supply an independent
functional motif class. Remaining categories can still overlap and must not be summed as
independent sites/pathways. Source annotations do not validate R. soongarica binding or regulation.
