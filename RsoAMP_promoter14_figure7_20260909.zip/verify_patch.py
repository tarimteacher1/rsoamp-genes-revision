from pathlib import Path
import csv,hashlib
root=Path(__file__).resolve().parent
with (root/'MANIFEST_SHA256.tsv').open(encoding='utf-8-sig',newline='') as f:
 rows=list(csv.DictReader(f,delimiter='\t'))
for row in rows:
 p=root/row['path']
 assert p.is_file() and p.stat().st_size==int(row['bytes'])
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
print('PASS:',len(rows),'distributed files')
