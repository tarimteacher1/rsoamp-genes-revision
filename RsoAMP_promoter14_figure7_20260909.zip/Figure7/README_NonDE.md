# Figure 7: current author presentation

The PDF and PNG carry the concise grey-point label **Non-DE**. The accompanying current legend
defines this as failure to satisfy the joint differential-expression criteria: BH-adjusted P (FDR)
< 0.05 and absolute unshrunken maximum-likelihood log2 fold change > 1.
The label does not mean unexpressed, missing, unquantified or below the count filter. Those states
remain separate. The two panels contain 49 and 52 finite plotted members and 8 and 18 DE members,
respectively. The gene-level statistics, thresholds, membership and DE calls are unchanged.

This PDF/PNG supersedes the Figure 7 display in the preceding reader-label amendment. The
older editable SVG currently carries a different long label and is intentionally not included as
the final author figure. No unsupported equivalence between the SVG and this author PDF is claimed.
The base analytical code and data remain available in the fixed revision-20260909 release.
