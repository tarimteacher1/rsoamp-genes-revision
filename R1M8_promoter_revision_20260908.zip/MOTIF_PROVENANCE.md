# Motif provenance and interpretation

This is a custom, finite IUPAC sequence panel inherited from the original analysis. It is not an execution of the PlantCARE web service, a complete PlantCARE/PLACE database scan, or a PWM/FIMO analysis. Sources below document exact sequences or their background context; they do not establish why the historical author originally selected them. All retained choices and their limits are explicit in motif_sources.tsv.

The original 16 entries give 15 double-stranded patterns after merging TGACG/CGTCA. Other nested patterns remain separate sequence queries and are not independent regulatory pathways. No counts were added across categories. A single TGACG core is not a complete as-1 element. BACGTG is explicitly a custom legacy pattern with no independently established exact database record; B means C/G/T. STRE-like carries yeast-context evidence only, without a plant-function claim.

Sources:

- [RcGPX promoter survey, Table 2](https://doi.org/10.3389/fpls.2021.707127): published sequence annotations for ABRE, LTR, MBS, ARE, TGACG/CGTCA, P-box and TC-rich patterns. This table supplies sequence provenance, not functional validation of our sites.
- [DREB binding specificity](https://doi.org/10.1006/bbrc.2001.6299): Arabidopsis DREB recognition of A/GCCGAC.
- [Cotton MYB212 study](https://doi.org/10.1111/nph.15620): MYBCORE context; not a drought-specific signature.
- [ICE1 study](https://genesdev.cshlp.org/content/17/8/1043.full): CANNTG consensus and factor-specific experiments.
- [Rice cis-element study](https://doi.org/10.1186/s12284-018-0243-0): explicit TTGACY W-box sequence.
- [Archived PLACE GT1GMSCAM4 record](https://togodb.biosciencedbc.jp/togodb/show/place_main/GT1GMSCAM4): GAAAAA and its soybean context.
- [Yeast RGD1 study](https://www.sciencedirect.com/science/article/abs/pii/S0378111905001812): STRE sequence context; not transferable functional validation in plants.

No sequence in this table is experimentally validated in R. soongarica by this study.
