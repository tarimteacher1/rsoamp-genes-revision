# R1.M8 bounded promoter reanalysis

Plan fixed before this reanalysis. Date: 2026-09-08.

The primary question remains greater motif prevalence in the existing primary AMP catalogue versus non-target annotated genes. No new motifs, gene-family subgroups, expression-based subsets, or window-length search will be introduced. The current catalogue is versioned by SHA-256; later M2/M6 catalogue changes require rerunning this module.

1. Retain the strand-aware 2,000-bp interval upstream of the annotated gene 5-prime boundary as a putative promoter proxy. Do not infer experimentally determined TSSs.
2. Preserve all 16 legacy sequences but merge TGACG and its reverse complement CGTCA into one double-stranded pattern. This gives 15 tests. Rename ambiguous historical labels and record all aliases, exact IUPAC patterns, provenance, and evidence limits. Nested patterns remain distinguishable sequence queries, not independent pathways.
3. Reread every target and background interval from the genome; count overlapping matches on both strands and deduplicate identical coordinates within a pattern.
4. Primary scenario: all intervals exactly 2,000 bp, matching the historical length rule.
5. Sensitivity S1: apply the same rule to targets and background: exactly 2,000 bp, only A/C/G/T, and no overlap with any other annotated gene body on either strand. Excluded AMP genes never become background.
6. Sensitivity S2: S1 plus at least one annotated five_prime_UTR feature linked to that gene, applied to both groups. This is annotation support, not independent TSS validation.
7. For all three scenarios, use one-sided Fisher exact tests for greater prevalence, BH over 15 patterns within each scenario, and also report a conservative BH across all 45 scenario-pattern comparisons. Report all outcomes, denominators, prevalence differences and odds ratios. Do not choose the scenario based on significance.
8. Retain full per-gene counts, coordinates, ambiguity/overlap/UTR flags, sequence hashes and cohort membership. Verify the primary counts against the historical tables and independently recompute the tests.
9. GC content is reported descriptively; the cohorts are not claimed to be fully matched for GC content, expression, family relatedness, or chromatin state. These remain limits.
10. Stop after these predefined analyses. Preserve non-significant results. No new wet-laboratory work is part of this revision.
