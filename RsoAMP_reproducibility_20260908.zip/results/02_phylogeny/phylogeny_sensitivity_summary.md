# Phylogenetic sensitivity summary

Status: PASS

Each family was analyzed under four pre-specified strategies: full precursor or mature/core region, each with an untrimmed or trimAl `gappyout` alignment. IQ-TREE model selection used the same candidate model set, and branch support was evaluated with 1,000 SH-aLRT and 1,000 ultrafast bootstrap replicates.

A branch was jointly supported only when SH-aLRT was at least 80 and UFBoot was at least 95. A sensitivity-stable R. soongarica group required the same multi-member bipartition in at least three of four strategies.

The four-strategy analyses identified 1, 2, and 7 multi-member groups stable in all four strategies for Defensin, Snakin/GASA, and nsLTP, respectively; nsLTP additionally contained 1 group stable in three strategies.

These groups are reported as sensitivity-qualified supported clades rather than formal subfamilies. Members without a stable multi-member placement remain unresolved. Because the proteins are short and often highly divergent, unresolved backbone relationships are treated as a data limitation rather than manually forced into bifurcating groups.

Complete, uncollapsed trees and the branch-level support table are retained for reproducibility; low-support nodes may be collapsed only in the display copy to show unresolved polytomies.
