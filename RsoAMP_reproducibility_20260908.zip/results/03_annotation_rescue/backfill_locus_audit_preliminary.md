# Six historical tblastn backfills - preliminary audit

Status: **PARTIAL; no locus is accepted as a final gene model at this stage**

The six hardcoded peptide sequences were tested against the reported genomic loci and strands. Exact genomic encoding was found for 6/6 peptides, and 0/6 had an upstream in-frame methionine within the local stop-delimited interval. The matrix also records GFF overlap, nearest genes and assembly-gap screening.

The old workflow used tblastn-HSP spans and absence of overlap with a GFF gene feature, then assumed a single exon. That procedure does not establish an intact gene model. Final calls require explicit ORF boundaries, splice/read evidence, domain and secretion evidence, and a genome-wide rescue search under the frozen family rules.
