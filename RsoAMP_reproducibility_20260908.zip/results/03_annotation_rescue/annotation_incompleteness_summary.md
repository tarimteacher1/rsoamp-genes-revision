# Genome-wide targeted rescue audit

Status: PASS

The historical rescue was a whole-genome screen, not a search limited to six preselected loci.
It used 128 family-labelled reference peptides, produced 1003 tblastn HSPs, and collapsed them into 37 loci.
Thirty-one loci overlap frozen gene models; the remaining 6 are the six loci evaluated with ORF, short-read, Iso-Seq, domain, and secretion evidence.
No additional unannotated cluster exists in the frozen screen.

## Final locus classes

- ANNOTATED_GENE_OVERLAP: 31
- KNOWN_UNANNOTATED_LOCUS_PENDING_FINAL_EVIDENCE: 6

The screen itself is sensitive rather than gene-defining: a tblastn cluster is not counted as a gene without a complete model and transcript support.
