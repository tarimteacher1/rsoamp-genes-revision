# Final AMP catalogue completeness report

Status: PASS

The primary gene catalogue contains 63 complete annotated or fully rescued gene models: Defensin=9, Snakin_GASA=18, nsLTP=36.
All 6 historical tblastn backfills were assessed against exact genomic encoding, local start/stop context, frozen GFF overlap, nine-sample short-read support, and public Iso-Seq support.
Backfill candidates retained in the primary gene count: 0.
Excluded backfill sequences remain reported as genomic AMP-like ORF candidates and are not silently discarded, but they are not used for gene-family counts, expression, synteny, promoter, or duplication analyses.
The catalogue is evidence-defined; historical totals were not used as retention targets.
