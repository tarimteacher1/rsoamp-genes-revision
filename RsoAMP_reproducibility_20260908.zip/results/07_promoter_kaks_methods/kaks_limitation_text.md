# Ka/Ks reliability audit

Status: PASS

The historical analysis used protein-guided MAFFT alignment, complete deletion of codons containing alignment gaps, and the YN method in KaKs_Calculator. All 23 nominated duplicate pairs were retained in the audit, including pairs without a finite result or no longer applicable to the final catalogue.

After final-catalogue membership, source-CDS translation, alignment length, substitution count, finite dS, and dS-saturation checks, 19 pairs were classified as usable with short-peptide caution. Of these, 16 had Ka/Ks < 1 with Fisher P < 0.05 and can be described as *consistent with* purifying selection. Other ratios are descriptive only.

AMP coding sequences are short, so dN and dS estimates can have high sampling variance. dS > 2 was treated as potential saturation, and complete deletion of gap-containing codons can remove structurally variable regions. Ka/Ks therefore does not prove functional constraint or identify the biological source of selection.
