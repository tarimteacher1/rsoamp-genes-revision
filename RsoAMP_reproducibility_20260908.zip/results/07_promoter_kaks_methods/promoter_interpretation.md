# Promoter motif audit

Status: PASS

Promoters were defined as the 2000-bp interval immediately upstream of each annotated gene in transcript orientation.
Overlapping IUPAC matches were allowed, while forward- and reverse-complement matches at the same genomic coordinates were counted once.
Scaffold-truncated promoters were retained in the occurrence table but excluded from enrichment testing.
The enrichment background comprised 21,698 complete promoters from non-target annotated genes; 63 complete target promoters were tested.
One-sided Fisher exact tests evaluated greater motif presence in target promoters, with Benjamini-Hochberg correction across the 16 tested motifs.

Significant enriched motifs at BH FDR < 0.05: none

Motif occurrence or enrichment is a sequence-level association and does not establish transcription-factor binding, treatment-specific activation, or a regulatory mechanism.
