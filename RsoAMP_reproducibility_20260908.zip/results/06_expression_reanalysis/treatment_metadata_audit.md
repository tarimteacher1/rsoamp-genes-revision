# RNA-seq treatment metadata audit

Status: **PARTIAL - biological design resolved; one printed unit and one accession-range error require transparent handling**

## Verified design

The primary source reports leaf RNA-seq samples from 8-week-old *Reaumuria soongorica* seedlings treated for one week with Hoagland solution containing 0, 200, or 400 mmol/L Na2SO4. Each treatment has three biological replicates, and each biological replicate comprises eight seedlings. Growth and sampling details are recorded field by field in `source_treatment_metadata.tsv`.

The source explicitly says that the cultivation, stress treatment, and sampling strategy described in Methods 1.6 was the same as that used to prepare the earlier transcriptome samples. These details can therefore be reported for the public RNA-seq dataset with a citation to the primary source.

## Source discrepancies that must not be hidden

1. The article prints the RNA-seq range as SRR27540875-SRR27540881, although the same paragraph reports a 3 treatment x 3 replicate design. ENA metadata resolves the nine RNA-seq runs as SRR27540875-SRR27540881 plus SRR27540883-SRR27540884; the latter two are S400-3 and S400-2, respectively.
2. The article prints light intensity as approximately `600 mmol m-2 s-1`. This may be a unit typo, but the revision must not silently replace it with `micromol m-2 s-1`. The manuscript should either quote the source exactly and flag the unit, omit this numerical detail, or use a value confirmed by the authors' experimental record.
3. The old project provenance file labels the treatment as NaCl. The primary source and ENA group labels support Na2SO4, so NaCl is treated as a historical documentation error.

## Writing boundary

The RNA-seq design supports differential-expression analysis at the biological-replicate level. Eight seedlings pooled within a replicate do not constitute eight independent RNA-seq replicates. Reanalysis cannot replace the independent RT-qPCR validation requested by both reviewers; until validation is supplied, the Results and Discussion must use bounded terms such as `salt-responsive transcriptome-supported candidates`.
