# Reproducible nsLTP decision rules

Status: PASS

The 54-sequence re-screening pool contains the 40 previously reported members plus 14 rejected boundary controls. Protein length is never used as an independent inclusion rule.

1. **R1, canonical core/type-specific nsLTP:** the sequence must be secretory by DeepSig and/or TMbed, carry an nsLTP-specific InterPro entry, and have either a compatible 8CM or strong curated positive homology. Competing specific architectures override this rule.
2. **R2, predicted LTPg:** for members lacking a specific InterPro entry, inclusion requires a secretion signal, complete 8CM, PredGPI support, a curated-positive similarity margin of at least 50 bits, and no repeated association with negative/ambiguous references in the four phylogenetic sensitivity analyses.
3. **R3, RsLTP20 boundary case:** broad prolamin similarity is 89.1 bits stronger than the best reviewed nsLTP match, with no nsLTP-specific InterPro or PredGPI support. It is excluded from the primary nsLTP count.
4. **R4, excluded HyPRP/pEARLI1/prolamin boundary controls:** sequences from the rejected pool with pEARLI1-like, hydrophobic-seed, proline-rich/extensin, or long multidomain architecture and no nsLTP-specific InterPro evidence remain excluded.
5. **R5/R6, partial or ambiguous:** a sequence failing secretion/framework gates, or retaining only broad prolamin-superfamily compatibility, is not counted as canonical.

Phylogenetic placement is used as concordance evidence, not as a mechanism to override contradictory domain architecture. Formal subfamilies are not assigned when the four alignment strategies do not recover a stable jointly supported split.
