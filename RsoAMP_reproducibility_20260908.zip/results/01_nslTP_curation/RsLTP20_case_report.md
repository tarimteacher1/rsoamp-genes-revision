# RsLTP20 final case report

Final classification: **B_AMBIGUOUS_NSLTP_PROLAMIN_BOUNDARY**  
Primary nsLTP catalogue inclusion: **NO**  
Confidence: **HIGH**

RsLTP20 has a predicted N-terminal signal peptide and an eight-cysteine framework, but it lacks an nsLTP-specific InterPro entry and a predicted GPI anchor. Its best reviewed nsLTP similarity score is 32.9, whereas its strongest broad prolamin-umbrella reference score is 122.0; the positive-minus-alternative margin is -89.1 bits. Across four phylogenetic sensitivity analyses, its labeled-reference interpretation was `REPEATED_EXPLICIT_2S_ASSOCIATION`.

The previous canonical assignment arose from an OR rule that accepted any seed BLAST hit despite contradictory broad-superfamily evidence. Under the revised rules, RsLTP20 is retained in the evidence matrix as a boundary case but removed from canonical counts, expression-family summaries, and primary evolutionary conclusions.
