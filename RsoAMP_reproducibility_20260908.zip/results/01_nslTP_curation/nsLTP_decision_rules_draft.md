# nsLTP decision rules - pre-analysis draft

Status: preregistered draft; final calls have not been made.

## Candidate universe

The audit includes every protein retrieved by the historical PF00234 HMM or nsLTP-seed similarity search, including current catalogue members and previously rejected borderline candidates. Catalogue membership is not used as evidence for acceptance.

## Evidence layers

1. **Sequence integrity:** complete precursor, no unexplained internal stop, and annotation-fragmentation check.
2. **Secretory architecture:** reproducible N-terminal signal peptide prediction. Absence is treated as partial/non-secretory evidence unless the gene model is demonstrably N-terminally incomplete.
3. **Cysteine framework:** an alignable plant nsLTP 8CM and its spacing. Protein length alone is never decisive.
4. **Domain competition:** PF00234 is a discovery model, not proof. nsLTP-specific InterPro/CDD evidence supports inclusion; 2S albumin, alpha-amylase/trypsin inhibitor, seed-storage or other competing annotations count against a canonical call.
5. **Curated homology:** reciprocal similarity to a versioned, manually curated nsLTP/prolamin reference set. A one-way best BLAST hit is insufficient.
6. **Topology:** transmembrane and GPI-anchor predictions distinguish soluble nsLTPs, plausible LTPg proteins and unrelated multi-pass proteins. A C-terminal hydrophobic signal is not automatically an exclusion because bona fide LTPg proteins are GPI anchored.
7. **Phylogenetic sensitivity:** the call must be compatible with supported placement across full-precursor and mature-region alignments. Unsupported placement is reported, not manually corrected.

## Final states

- **A. canonical nsLTP:** coherent signal peptide, 8CM, no stronger competing-family evidence, curated homology and compatible phylogenetic placement.
- **B. nsLTP-like / ambiguous prolamin-superfamily member:** some nsLTP evidence but unresolved domain competition, topology, or phylogenetic placement.
- **C. excluded non-nsLTP prolamin-family protein:** stronger competing-family evidence and failure of the preregistered nsLTP evidence combination.
- **D. partial or pseudogene-like candidate:** incomplete model or sequence prevents a defensible family call.

## Conflict handling

- No candidate is retained to preserve the historical count of 40 or total count of 73.
- BLAST identity, length, expression and visual tree position cannot independently promote a candidate to state A.
- GPI-anchored LTPg candidates are recorded separately from soluble nsLTPs rather than mislabeled as generic “nsLTP-like”.
- Every final state requires a textual reason and evidence links in the matrix.
- Any threshold or rule change after viewing the outcomes must be versioned and justified; it cannot be tuned to recover an expected number of genes.

