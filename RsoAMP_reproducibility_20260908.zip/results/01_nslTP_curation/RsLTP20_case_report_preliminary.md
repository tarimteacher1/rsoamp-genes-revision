# RsLTP20 case report - preliminary evidence stage

Status: **OPEN; no final reclassification yet**

## Historical inconsistency

The old InterPro filtering file rejected `gmmChr04G004380.1` as having no AMP-specific domain, while the later script classified it as canonical whenever either an nsLTP-specific InterPro term **or any nsLTP-seed BLAST hit** was present. RsLTP20 was therefore restored solely through the BLAST branch of an overly permissive OR rule.

## Evidence currently observed

- Precursor length: 109 aa.
- DeepSig N-terminal signal peptide: YES; cleavage after residue 26.
- Candidate mature-region 8CM: YES; spacing `9,16,0,9,1,12,6`.
- nsLTP-specific InterPro terms: `none`.
- Broad/other InterPro terms: `IPR016140;IPR036312`.
- Best historical nsLTP-seed BLAST: `nsLTP|Q29QA0`, identity 53.659%, E-value 2.38e-26.
- C-terminal hydrophobic screening flag: NO.
- PredGPI GPI-anchor prediction: NO.
- TMbed post-signal transmembrane helix: NO (none).
- Best reviewed Arabidopsis nsLTP reference: `gnl|POS|Q8VYI9` (bitscore 32.9).
- Best broad prolamin-umbrella reference: `AMBPRO|Q9LTK4` (bitscore 122.0).
- Positive-minus-strongest-alternative bitscore: -89.1.
- Labeled-reference interpretation: `broad_prolamin_umbrella_reference_preferred`.

## Decision still required

The signal peptide and cysteine framework are compatible with an nsLTP hypothesis, but the old best hit was an ambiguous protease-inhibitor/seed-storage/LTP-superfamily sequence rather than a curated nsLTP. In the labeled-reference comparison, broad prolamin similarity strongly exceeded the best reviewed nsLTP match, and PredGPI did not support an LTPg interpretation. RsLTP20 is therefore removed from the provisional canonical set and treated as an ambiguous nsLTP/prolamin-boundary candidate. A final exclusion decision still requires stable placement in the revised positive/negative-control phylogeny and an explicit post-signal-peptide TM assessment.
