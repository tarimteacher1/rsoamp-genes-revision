# Close-species comparative genomics summary

Status: PASS

Tamarix austromongolica was selected as the close comparator because it is a chromosome-level genome from the same family (Tamaricaceae), with a similarly sized predicted proteome and public sequence/GFF provenance. The same HMM, InterPro, secretion, cysteine-framework, PredGPI, TMbed, and labeled-reference gates were applied to nsLTP candidates before counts were compared.

Observed high-confidence counts were R. soongarica: Defensin=9, Snakin/GASA=18, nsLTP=36; and T. austromongolica: Defensin=5, Snakin/GASA=7, nsLTP=24. Counts are also reported per 10,000 predicted proteins.

Pairwise DIAMOND screening identified 31 reciprocal-best-hit groups involving at least one final AMP, including 28 groups in which both partners were final AMPs of the same family. MCScanX yielded 5 AMP-involving interspecies anchors, of which 4 directly paired final AMP candidates in both species.

These results support discussion of higher or lower *observed* family representation and conserved candidates. They do not by themselves prove lineage-specific expansion or loss; such claims require concordant phylogeny, duplication and synteny evidence and remain sensitive to the five Tamarix defensin homology models that were absent from the official annotation.
