# Species selection report

Tamarix austromongolica was chosen before examining AMP family counts. It is a same-family Tamaricaceae comparator with a chromosome-level assembly (GCA_039764185.1), 22,374 longest-protein models, public GFF/proteome/genome files, checksums, and a primary genome report (doi:10.1093/dnares/dsae021). Arabidopsis thaliana is retained only as a distant reference for continuity with the submitted analysis.

The comparator is suitable for family composition, reciprocal homology and chromosome-scale synteny. Annotation sensitivity is reported explicitly: five complete defensin homology models were recovered from intergenic genome sequence and are not represented as official annotated genes.
