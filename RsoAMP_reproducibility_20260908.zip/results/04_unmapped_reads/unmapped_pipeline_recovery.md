# Unmapped-read pipeline recovery log

This note records implementation failures encountered during the major-revision audit. None was treated as biological evidence.

1. **Java not visible to non-interactive SSH execution.** BBMap was present, but the non-interactive PATH omitted its Java runtime. The workflow now prepends the explicit `busco/bin` runtime path.
2. **Unsupported BBduk parameter combination.** BBMap 39.52 rejected `mink` because no `ktrim` mode was active. The parameter was removed. The subsequently tested one-mismatch screen was later superseded by the exact 27-mer rule documented below.
3. **Inefficient per-sample SILVA loading.** Loading the 48-GB expanded SILVA reference separately for each of nine runs would dominate runtime. Quality-passing reads are therefore processed as one batch, with sample assignments recovered from SRR-prefixed read identifiers.
4. **Reference-neighborhood expansion exceeded a 64-GB Java heap.** `hdist=1` expands reference k-mers and triggered `OutOfMemoryError`. A query-side `qhdist=1` test reduced the reference table to approximately 6 GB, but was also superseded because its read-processing rate was impractical.
5. **Directly concatenated gzip members were not accepted by BBMap's threaded reader.** Although concatenated gzip is valid for many tools, the BBMap reader stopped at a member boundary. The workflow now decompresses each sample and recompresses the batch as one gzip stream per mate, with `pigz -t` validation before classification.

The final PASS markers and category tables are written only after the mutually exclusive assignment count for every sample equals the number of Salmon unmapped-name records.
## 6. SILVA query-distance expansion was computationally inefficient

- **Observed issue:** The batched SILVA screen with `k=31 qhdist=1` used approximately one CPU core during read processing and produced only about 46 MB of non-rRNA output after nearly 50 minutes from a 4 GB compressed paired input.
- **Diagnosis:** `qhdist=1` expands every query k-mer and is poorly suited to this audit-scale classification pass.
- **Recovery:** The incomplete batch was discarded and the SILVA screen was restarted with exact `k=27 hdist=0` matching. Plastid and mitochondrial-proxy screens retain `k=31 hdist=1` because their reference sets are small.
- **Interpretation boundary:** This stage estimates broad rRNA-derived content; it is not a taxonomic or transcript-discovery analysis. Exact 27-mer matching is therefore reported as a conservative classification rule.

## 7. fastp `--failed_out` did not contain every filtered fragment

- **Observed issue:** The first conservation failure was 4,231,756 category assignments for 4,231,757 Salmon-unassigned fragments in SRR27540881. A global set-difference audit then found eight omitted fragments across five runs and no extra assignments.
- **Diagnosis:** The first missing fragment, `SRR27540881.1976529`, was present in both fastp inputs. Its R1 sequence was almost entirely poly-G and it was absent from both passing outputs and `--failed_out`. The same explicit set-difference rule was applied to all nine runs rather than assuming the other seven omissions had an identical sequence pattern.
- **Recovery:** The workflow now defines filtered fragments as the union of explicit `--failed_out` IDs and the set difference between non-decoy input IDs and all fastp-accounted IDs. This keeps the low-quality/low-complexity category exhaustive without changing the biological classification hierarchy.
- **Gate:** The final per-sample partition must still contain one unique assignment for every Salmon-unassigned fragment.

## 8. Python 3.8 lacked `str.removesuffix`

- **Observed issue:** The final FASTQ-to-labeled-FASTA conversion stopped before DIAMOND search with `AttributeError: 'str' object has no attribute 'removesuffix'`.
- **Recovery:** The suffix removal was replaced by an explicit `/1` or `/2` ending test compatible with Python 3.8. Classification outputs and their PASS marker were unaffected; only the not-yet-started targeted AMP search was rerun.
