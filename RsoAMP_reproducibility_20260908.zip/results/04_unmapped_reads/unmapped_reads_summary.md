# Transcriptome-unassigned read audit

Status: PASS

Unmapped is defined relative to the decoy-aware Salmon transcript index. Each Salmon-unassigned fragment was assigned exactly once, in this order: genome decoy, quality/complexity failure, rRNA, same-species plastid, same-family mitochondrial proxy, residual genome-mapped, or residual genome-unmapped.

The mitochondrial category is a conservative proxy screen against Myricaria laxiflora MW971331 because a species-specific R. soongarica mitochondrial reference was not available; it is not interpreted as a complete mitochondrial read count.

Across all samples, Salmon wrote 41,770,434 transcriptome-unassigned fragment records for classification. The per-sample table separately reports any difference between this record count and num_processed minus num_mapped rather than forcing the two quantities to agree.
- genome_decoy_assigned: 5,863,532 (14.04%)
- low_quality_or_low_complexity: 149 (0.00%)
- rRNA_derived: 104,313 (0.25%)
- plastid_derived: 15,094 (0.04%)
- mitochondrial_like_same_family_proxy: 0 (0.00%)
- genome_mapped_but_transcriptome_unassigned: 26,234,614 (62.81%)
- genome_unmapped_residual: 9,552,732 (22.87%)
