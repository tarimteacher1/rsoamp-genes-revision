"""Optional backup export; the supplied author PDF is the authoritative layout."""
from pathlib import Path
import argparse,json
import fitz
p=argparse.ArgumentParser();p.add_argument('pdf',type=Path);p.add_argument('--outdir',type=Path,required=True)
p.add_argument('--dpi',type=int,default=600);a=p.parse_args();a.outdir.mkdir(parents=True,exist_ok=True)
d=fitz.open(a.pdf);assert len(d)==1
d[0].get_pixmap(dpi=a.dpi,alpha=False).save(a.outdir/(a.pdf.stem+'.png'))
(a.outdir/(a.pdf.stem+'.svg')).write_text(d[0].get_svg_image(text_as_path=True),encoding='utf-8')
print(json.dumps({'tool':'PyMuPDF','version':fitz.VersionBind,'dpi':a.dpi,
 'source':'supplied author PDF','SVG_text_outlined':True,'data_or_layout_reconstructed':False}))
