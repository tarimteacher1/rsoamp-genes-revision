from pathlib import Path
import csv,hashlib
r=Path(__file__).resolve().parent
with (r/'MANIFEST_SHA256.tsv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f,delimiter='\t'))
for x in rows:
 p=r/x['path'];assert p.stat().st_size==int(x['bytes']) and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'],x['path']
print('PASS:',len(rows),'files')
