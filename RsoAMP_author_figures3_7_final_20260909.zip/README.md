# Final author Figure 3 and Figure 7 — 2026-09-09

These PDF/PNG/SVG files match the final current author figures used for submission. They supersede
the earlier Figure 3 layout and the older Figure 7 SVG in the reader-label amendment. The final
Figure 7 PDF/PNG is unchanged from the promoter14 amendment; this package adds its matching
outline SVG so the three formats now show the same current author presentation.

The PDFs are the authoritative author layouts. This distribution does not claim that the hand-edited
layouts can be rebuilt from biological input tables. The included optional PDF export utility converts
the supplied PDFs to 600-dpi PNG and outlined SVG; it does not recreate the manual layout or alter
scientific data. SVG text is converted to paths to preserve appearance, so it is not editable text.
The backup converter was tested with PyMuPDF 1.27.2. The supplied author exports are preserved
byte-for-byte; fresh conversions can differ in encoding, glyph identifiers, metadata or rendering.
No byte-identical regeneration of the supplied SVG/PNG is promised.

Figure 3 keeps all 73 members and the existing model geometry, coordinates and evidence states;
A/R identifies reference annotation/reconstructed model source. S/M/NR retains the UTR evidence
meaning. The accompanying legend explains independent model-span normalization and why missing
UTR annotation is not biological absence. Figure 7 retains the same data, 8/18 DE calls, thresholds,
and Non-DE grey-point meaning. No new biological analysis, numerical revision, or validation occurs.

This author-figure package leaves the 14-pattern promoter analysis, its 14/42-test BH correction,
all old ZIP files and the fixed revision-20260909 release unchanged. The promoter14 amendment
remains required for current Figure 5/Tables S9, S10, S27 and S29.

Verify the downloaded files first:

```sh
python verify_files.py
```

Optional format backup (requires PyMuPDF):

```sh
python export_from_author_pdf.py Figure3/Figure3_catalogue_synced_20260909.pdf --outdir exported_figure3
python export_from_author_pdf.py Figure7/Figure7_catalogue_synced_20260909.pdf --outdir exported_figure7
```

The package contains figures, scientific legends and source/checksum records only. It contains no
manuscript, reviewer correspondence, account data, or private local paths.
