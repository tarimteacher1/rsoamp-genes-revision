from pathlib import Path
import csv,hashlib,json
root=Path(__file__).resolve().parent
count=0
with (root/'MANIFEST_SHA256_PUBLIC.tsv').open(encoding='utf-8',newline='') as f:
 for row in csv.DictReader(f,delimiter='\t'):
  p=root/row['path']
  assert p.stat().st_size==int(row['bytes']),row['path']
  assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
  count+=1
print(json.dumps({'verification':'PASS','files':count}))
