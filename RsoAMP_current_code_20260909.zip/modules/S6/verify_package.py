from pathlib import Path
import csv,hashlib
r=Path(__file__).resolve().parent
rows=list(csv.DictReader((r/'MANIFEST_SHA256.tsv').open(encoding='utf-8-sig'),delimiter='\t'))
for row in rows:
 p=r/row['path']
 assert p.is_file(),row['path']
 assert p.stat().st_size==int(row['bytes']),row['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
print('PASS',len(rows),'payloads')
