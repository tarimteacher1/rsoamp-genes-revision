from pathlib import Path
import csv, hashlib, json, zipfile
R=Path(__file__).resolve().parents[1]
J=Path(__file__).resolve().parent
OUT=J/'staged/File_S6_unified_catalogue_expression_20260909.zip'
payload={}
def add(p):
    p=Path(p)
    if not p.is_file() or '__pycache__' in p.parts:return
    rel=p.relative_to(R).as_posix()
    payload['Workspace/'+rel]=p.read_bytes()
for sub in ['tables','规则核验','敏感性']:
    for p in (J/sub).rglob('*'):add(p)
for name in ['统一判定与报告规则_v3.md','stage_integration.py','finish_stage.py','package_file_s6.py','install_and_deliver.py','reply_scope_fixes.json']:
    add(J/name)
for p in (R/'成员判定收尾_20260909/统一目录').glob('*'):add(p)
for p in (R/'成员判定收尾_20260909/审核_M6').glob('*.tsv'):add(p)
for name in ['M6_核对计数与验证.json','M6_合并审核说明.md']:
    add(R/'成员判定收尾_20260909/审核_M6'/name)
for name in ['M2_all99_tiered_evidence.tsv','M2_audit_validation.json','M2_specific_domain_signature_audit.tsv']:
    add(R/'成员判定收尾_20260909/审核_M2'/name)
with (J/'规则核验/input_and_script_SHA256.tsv').open(encoding='utf-8-sig') as f:
    for row in csv.DictReader(f,delimiter='\t'):
        p=R/row['path_relative_to_workspace']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
        add(p)
readme="""# File S6: unified catalogue, expression reconciliation and sensitivity

This package accompanies Tables S30-S38. File S4 remains the earlier M6 model-evidence package; File S5 is the separate localization audit.

Primary resource: 73 R. soongarica (15 defensin,18 Snakin/GASA,40 nsLTP) and38 Tamarix(5,7,26).
Extended resource:74/39, adding the two Q6ZFW0-dependent C4-like candidates.
Annotation-derived expression:66 primary Rso members,52 passing prefilter,DE8/18/13.
Seven reconstructed Rso models have NOT_QUANTIFIED status rather than zero expression.

Contents retain Workspace-relative paths. The authoritative sequence/GFF catalogue is under
Workspace/成员判定收尾_20260909/统一目录; additional explicit flags and analysis membership are in
Workspace/M2_M6_落实核验_20260909/tables. Current operational rules are 统一判定与报告规则_v3.md.
Historical READMEs in source evidence remain versioned provenance; current expression reconciliation
supersedes their statements that restored annotation-derived members have not yet been checked.

Reproduce the filtering audit from frozen inputs:
python Workspace/M2_M6_落实核验_20260909/敏感性/run_boundary_sensitivity.py
python Workspace/M2_M6_落实核验_20260909/敏感性/add_profile_edge_scenario.py
See the directory README for actual script filenames and scenario scope.
Reproduce signature/core coordinate validation:
python Workspace/M2_M6_落实核验_20260909/规则核验/verify_core_signature_coordinates.py

Python3,openpyxl andBiopython are required for expression/tree input parsing; the coordinate audit uses
the standard library. No new HMM/BLAST search,RBH selection,MCScanX,RNA-seq quantification,DESeq2 fitting
or tree inference is claimed. Filtered edges are existing outputs,not recomputed nearest counterparts.
The first four scenarios retain existing highlighted group membership; excluding profile-edge cases
changes L3/L5* membership and no support value is re-estimated.

The document-integration scripts are provenance,not a standalone manuscript build: they require
the versioned formal DOCX/workbook and translation sources outside this scientific data package.
Verify all archive payloads with verify_package.py before reuse.
"""
# Name the actual fifth-scenario script rather than guessing a reproducibility command.
scripts=[p.name for p in (J/'敏感性').glob('*.py') if p.name!='run_boundary_sensitivity.py']
assert len(scripts)==1,scripts
readme=readme.replace('add_profile_edge_scenario.py',scripts[0])
payload['README.md']=readme.encode('utf8')
verifier="""from pathlib import Path
import csv,hashlib
r=Path(__file__).resolve().parent
rows=list(csv.DictReader((r/'MANIFEST_SHA256.tsv').open(encoding='utf-8-sig'),delimiter='\\t'))
for row in rows:
 p=r/row['path']
 assert p.is_file(),row['path']
 assert p.stat().st_size==int(row['bytes']),row['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
print('PASS',len(rows),'payloads')
"""
payload['verify_package.py']=verifier.encode()
manifest='path\tbytes\tsha256\n'+''.join(f'{k}\t{len(v)}\t{hashlib.sha256(v).hexdigest()}\n' for k,v in sorted(payload.items()))
payload['MANIFEST_SHA256.tsv']=b'\xef\xbb\xbf'+manifest.encode()
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED) as z:
    for name,b in sorted(payload.items()):z.writestr(name,b)
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    for name,b in payload.items():assert z.read(name)==b,name
result={'status':'PASS','payloads':len(payload)-1,'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'path':str(OUT)}
(J/'staged/File_S6_validation.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result))
