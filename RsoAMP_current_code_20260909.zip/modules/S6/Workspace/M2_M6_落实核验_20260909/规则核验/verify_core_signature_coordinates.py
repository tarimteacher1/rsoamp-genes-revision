"""Independently audit nsLTP signature/core coordinates without changing admission.

Python >= 3.9, standard library only. Run from any directory; all inputs are
resolved relative to this script's workspace. Only this script's directory is
written. Coordinate containment is not residue alignment or functional proof.
"""
from pathlib import Path
from collections import Counter, defaultdict
import csv
import hashlib
import json
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
M2 = ROOT / '成员判定收尾_20260909' / '审核_M2'
OLD = ROOT / 'nsLTP_统一审核_20260908' / 'analysis'
M6 = ROOT / 'R1M6_深入分类_20260908'
SPEC = {'IPR000528', 'IPR033872', 'IPR039265', 'IPR044741'}
PROFILE_APPS = {'CDD', 'PANTHER', 'Pfam', 'SMART', 'ProSiteProfiles'}
LOCAL_APPS = {'PRINTS', 'ProSitePatterns'}
input_hashes = {}
errors = []
signatures = []
broad_excluded = []


def digest_bytes(b):
    return hashlib.sha256(b).hexdigest()


def read(path):
    b = path.read_bytes()
    input_hashes[path] = (len(b), digest_bytes(b))
    return b.decode('utf-8-sig')


def table(path):
    return list(csv.DictReader(read(path).splitlines(), delimiter='\t'))


def load(path):
    return json.loads(read(path))


def fasta(path):
    result = {}
    key = None
    for line in read(path).splitlines():
        if line.startswith('>'):
            key = line[1:].split()[0]
            assert key not in result, (path, key)
            result[key] = ''
        elif key:
            result[key] += line.strip()
    return result


def write_table(name, rows, empty_fields=()):
    fields = list(rows[0]) if rows else list(empty_fields)
    with (OUT / name).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter='\t')
        w.writeheader()
        w.writerows(rows)


def check(condition, message, candidate=''):
    if not condition:
        errors.append({'candidate_id': candidate, 'problem': message})


def interval_set(intervals):
    return {i for a, b in intervals for i in range(a, b + 1)}


def signature_kind(app):
    if app == 'PANTHER':
        return 'FAMILY_PROFILE'
    if app in PROFILE_APPS:
        return 'DOMAIN_PROFILE'
    if app == 'PRINTS':
        return 'SHORT_FINGERPRINT_COMPONENT'
    if app == 'ProSitePatterns':
        return 'SHORT_SEQUENCE_PATTERN'
    return 'UNCLASSIFIED_REVIEW'


def make_raw(row, source, source_line):
    return {'protein_id': row[0], 'md5': row[1], 'length': int(row[2]),
            'application': row[3], 'signature': row[4], 'description': row[5],
            'start': int(row[6]), 'end': int(row[7]), 'score': row[8],
            'interpro': row[11] if len(row) > 11 else '-',
            'source': source, 'source_line': source_line}


raw_by_id = defaultdict(list)
live = load(M2 / 'all99_live_source_extract.json')
for sp, data in live.items():
    for i, line in enumerate(data['interpro_rows'], 1):
        f = line.split('\t')
        raw_by_id[(sp, f[0])].append(make_raw(f, 'all99_live_source_extract.json:' + sp, i))
for name in ('new_candidates.interpro.tsv', 'new_candidates.additional_interpro.tsv',
             'new_candidates.signature_interpro.tsv'):
    for i, line in enumerate(read(OLD / name).splitlines(), 1):
        if not line:
            continue
        f = line.split('\t')
        f[0] = f[0].removeprefix('TAU__')
        raw_by_id[('tau', f[0])].append(make_raw(f, str((OLD/name).relative_to(ROOT)), i))

rows = table(M2 / 'M2_all99_tiered_evidence.tsv')
provided_signatures = table(M2 / 'M2_specific_domain_signature_audit.tsv')
provided_by_id = defaultdict(list)
for r in provided_signatures:
    provided_by_id[r['id']].append(r)
assert len(rows) == 99 and len({r['id'] for r in rows}) == 99
candidates = []

for r in rows:
    seq = r['full_sequence']
    q = r['id']
    check(seq == live[r['species']]['sequences'][r['protein_id']].replace('*', ''),
          'Sequence differs from source snapshot', q)
    check(digest_bytes(seq.encode()) == r['protein_sha256'], 'Protein SHA256 mismatch', q)
    core = r['core_sequence']
    start = int(r['core_start']) if r['core_start'] else None
    end = int(r['core_end']) if r['core_end'] else None
    cps = [int(x) for x in r['core_cysteine_positions'].split(';') if x]
    candidate = {'scope': 'M2', 'id': q, 'member': r['member_id'] or r['protein_id'],
                 'sequence': seq, 'core': core, 'start': start, 'end': end, 'cps': cps,
                 'class': r['new_class'], 'tier': r['decision_layer'],
                 'include_primary': r['include_primary'],
                 'include_extended': r['include_extended'], 'route': r['identity_route'],
                 'qualifying_positive_count': r['qualified_positive_reference_count'],
                 'qualifying_positive': r['best_qualified_positive'],
                 'omega': int(r['gpi_omega']) if r['gpi_omega'] else None,
                 'signal_cut': int(r['signal_cut']), 'raw': raw_by_id[(r['species'], r['protein_id'])]}
    candidates.append(candidate)
    raw_specific = [x for x in candidate['raw'] if x['interpro'] in SPEC]
    # Compare multisets, retaining separate PRINTS fingerprint components.
    expected = Counter((x['application'], x['signature'], x['interpro'],
                        int(x['start_aa']), int(x['end_aa']), x['score'])
                       for x in provided_by_id[q])
    observed = Counter((x['application'], x['signature'], x['interpro'],
                        x['start'], x['end'], x['score']) for x in raw_specific)
    check(expected == observed, 'Specific signature table differs from raw source rows', q)
    check(set(x['interpro'] for x in raw_specific) == set(filter(None, r['specific_ipr'].split(';'))),
          'Specific InterPro set differs from candidate matrix', q)

facts = load(M6 / 'evidence_summary.json')
fact = next(r for r in facts if r['id'] == 'R1M6_CAND03')
seq = fasta(M6 / '交付' / '候选序列与模型' / 'high_confidence.protein.faa')['R1M6_CAND03']
check(seq == fact['model']['protein_sequence'], 'M6 exported sequence differs from evidence_summary', 'R1M6_CAND03')
mf = fact['framework']
start, end = map(int, mf['nsLTP_8CM_span'].split('-'))
raw_m6 = []
for i, line in enumerate(read(M6 / 'interpro' / 'queries.tsv').splitlines(), 1):
    f = line.split('\t')
    if f[0] == 'R1M6_CAND03':
        raw_m6.append(make_raw(f, str((M6/'interpro'/'queries.tsv').relative_to(ROOT)), i))
candidates.append({'scope': 'M6', 'id': 'R1M6_CAND03', 'member': 'RsLTP41 (CAND03)',
                   'sequence': seq, 'core': seq[start-1:end], 'start': start, 'end': end,
                   'cps': list(map(int, mf['mature_cysteine_positions_precursor'].split(','))),
                   'class': 'COMPUTATIONAL_NSLTP_CANDIDATE', 'tier': 'M6_PRIMARY_MODEL',
                   'include_primary': 'True', 'include_extended': 'True',
                   'qualifying_positive_count': '', 'qualifying_positive': '',
                   'route': 'SPECIFIC_LOCAL_FINGERPRINT', 'omega': fact['PredGPI'][0]['begin'],
                   'signal_cut': int(mf['DeepSig_cut']), 'raw': raw_m6})

candidate_results = []
for c in candidates:
    q = c['id']; seq = c['sequence']; a = c['start']; b = c['end']
    cp = set(c['cps']); core_sites = set(range(a, b+1)) if a and b else set()
    if c['core']:
        check(1 <= a <= b <= len(seq), 'Invalid core coordinates', q)
        check(seq[a-1:b] == c['core'], 'Core differs from full-sequence slice', q)
        actual = {a+i for i, aa in enumerate(c['core']) if aa == 'C'}
        check(actual == cp and len(cp) == 8, 'Eight cysteine coordinates disagree with sequence', q)
        check(a > c['signal_cut'], 'Selected core overlaps predicted signal peptide', q)
    else:
        check(not cp and a is None and b is None, 'Empty core has nonempty coordinates', q)
    specific = []
    for r in c['raw']:
        check(r['length'] == len(seq) and r['md5'] == hashlib.md5(seq.encode()).hexdigest(),
              'Raw predictor sequence MD5/length mismatch', q)
        check(1 <= r['start'] <= r['end'] <= len(seq), 'Signature interval outside protein', q)
        entry = {'scope': c['scope'], 'candidate_id': q, 'member_id': c['member'],
                 'application': r['application'], 'signature': r['signature'],
                 'interpro': r['interpro'], 'description': r['description'],
                 'signature_kind': signature_kind(r['application']),
                 'start_aa': r['start'], 'end_aa': r['end'], 'reported_score': r['score'],
                 'core_start_aa': a or '', 'core_end_aa': b or '',
                 'source': r['source'], 'source_line': r['source_line']}
        positions = set(range(r['start'], r['end']+1))
        overlap = core_sites & positions
        outside_c = sorted(cp - positions)
        prefix = sorted(p for p in cp if p < r['start'])
        suffix = sorted(p for p in cp if p > r['end'])
        entry.update(core_overlap_aa=len(overlap), core_length_aa=len(core_sites),
                     core_coverage_fraction=round(len(overlap)/len(core_sites), 6) if core_sites else '',
                     core_cysteines_inside=len(cp & positions) if core_sites else '',
                     core_cysteines_outside=';'.join(map(str, outside_c)),
                     N_edge_cysteines_outside=';'.join(map(str, prefix)),
                     C_edge_cysteines_outside=';'.join(map(str, suffix)),
                     contains_complete_core=bool(core_sites and core_sites <= positions),
                     interval_semantics='1-based inclusive; coordinate containment, not residue-alignment coverage')
        if r['interpro'] not in SPEC:
            entry['exclusion_reason'] = 'Not in audited nsLTP-specific IPR set; broad/other evidence does not count as specific profile coverage'
            broad_excluded.append(entry)
            continue
        if r['application'] not in PROFILE_APPS | LOCAL_APPS:
            check(False, 'Unclassified specific-signature application', q)
        if not core_sites:
            status = 'NO_SELECTED_CANONICAL_CORE'
        elif r['application'] in LOCAL_APPS:
            status = 'LOCAL_SIGNATURE_INTERSECTS_CORE' if overlap else 'LOCAL_SIGNATURE_OUTSIDE_SELECTED_CORE_REVIEW'
        elif core_sites <= positions:
            status = 'PROFILE_CONTAINS_COMPLETE_CORE'
        elif overlap:
            status = 'PROFILE_BOUNDARY_PARTIAL_REVIEW'
        else:
            status = 'PROFILE_DISJOINT_FROM_CORE_REVIEW'
        entry['coordinate_status'] = status
        signatures.append(entry)
        specific.append((r, entry))

    profiles = [(r,e) for r,e in specific if r['application'] in PROFILE_APPS]
    domains = [(r,e) for r,e in specific if e['signature_kind'] == 'DOMAIN_PROFILE']
    local = [(r,e) for r,e in specific if r['application'] in LOCAL_APPS]
    def merged(items):
        return interval_set((r['start'],r['end']) for r,e in items)
    profile_union = merged(profiles); domain_union = merged(domains)
    all_union = merged(specific); local_union = merged(local)
    any_profile_full = any(e['contains_complete_core'] for r,e in profiles)
    any_domain_full = any(e['contains_complete_core'] for r,e in domains)
    review = []
    if not core_sites:
        status = 'NO_SELECTED_CANONICAL_CORE'
        if specific: review.append('Specific signature present but selected classical eight-cysteine core is absent; retain current boundary/model distinction')
    elif not specific:
        status = 'NO_SPECIFIC_SIGNATURE_PATH'
    elif any_profile_full:
        status = 'SPECIFIC_PROFILE_CONTAINS_COMPLETE_CORE'
    elif profiles and core_sites <= profile_union:
        status = 'SPECIFIC_PROFILE_UNION_COVERS_CORE_REVIEW'
        review.append('Profile union covers core but no individual profile contains it; do not equate union with one complete domain')
    elif profiles and core_sites & profile_union:
        status = 'SPECIFIC_PROFILE_BOUNDARY_PARTIAL_REVIEW'
        review.append('No individual or union specific profile fully contains core; inspect missing edge cysteines without automatic reclassification')
    elif profiles:
        status = 'SPECIFIC_PROFILE_DISJOINT_REVIEW'
        review.append('Specific profile intervals are disjoint from selected core')
    elif core_sites & local_union:
        status = 'LOCAL_SIGNATURES_ONLY_COMPATIBLE_REGION'
    else:
        status = 'LOCAL_SIGNATURES_DISJOINT_REVIEW'
        review.append('Only local specific signatures, all outside the selected core')
    partial_profiles = [f"{r['application']}:{r['signature']}:{r['start']}-{r['end']}({e['core_cysteines_inside']}/8C)"
                        for r,e in profiles if core_sites and not e['contains_complete_core']]
    outside_local = [f"{r['application']}:{r['signature']}:{r['start']}-{r['end']}"
                     for r,e in local if core_sites and not e['core_overlap_aa']]
    if partial_profiles and any_profile_full:
        review.append('Some profile boundaries omit core residues, but another specific profile contains the full core; per-signature rows preserve the differences')
    if outside_local:
        review.append('A local fingerprint/pattern component lies outside first-to-eighth C span; terminal mature-peptide motifs may do so and are not automatically invalid')
    retained_c = len({p for p in cp if p <= c['omega']}) if c['omega'] and cp else ''
    if retained_c != '' and retained_c < 8:
        review.append('Predicted GPI omega retains fewer than eight selected-core cysteines; topology conflict remains separate from family evidence')
    result = {'scope': c['scope'], 'candidate_id': q, 'member_id': c['member'],
              'unchanged_classification': c['class'], 'unchanged_tier': c['tier'],
              'include_primary': c['include_primary'], 'include_extended': c['include_extended'],
              'unchanged_identity_route': c['route'], 'core_start_aa': a or '', 'core_end_aa': b or '',
              'archived_qualifying_positive_reference_count': c['qualifying_positive_count'],
              'archived_best_qualifying_positive_reference': c['qualifying_positive'],
              'core_length_aa': len(core_sites), 'core_cysteine_positions': ';'.join(map(str, sorted(cp))),
              'specific_signature_rows': len(specific), 'specific_full_profile_rows': len(profiles),
              'specific_domain_profile_rows': len(domains), 'specific_local_signature_rows': len(local),
              'any_specific_full_profile_contains_complete_core': any_profile_full,
              'any_specific_domain_profile_contains_complete_core': any_domain_full,
              'maximum_single_full_profile_core_coverage_fraction': max((e['core_coverage_fraction'] for r,e in profiles),default=0) if core_sites else '',
              'maximum_single_full_profile_cysteines_inside': max((e['core_cysteines_inside'] for r,e in profiles),default=0) if core_sites else '',
              'maximum_single_domain_profile_core_coverage_fraction': max((e['core_coverage_fraction'] for r,e in domains),default=0) if core_sites else '',
              'maximum_single_domain_profile_cysteines_inside': max((e['core_cysteines_inside'] for r,e in domains),default=0) if core_sites else '',
              'full_profile_union_core_coverage_fraction': round(len(core_sites & profile_union)/len(core_sites),6) if core_sites else '',
              'full_profile_union_cysteines_inside': len(cp & profile_union) if core_sites else '',
              'full_profile_union_cysteines_outside': ';'.join(map(str,sorted(cp-profile_union))) if core_sites else '',
              'domain_profile_union_core_coverage_fraction': round(len(core_sites & domain_union)/len(core_sites),6) if core_sites else '',
              'domain_profile_union_cysteines_inside': len(cp & domain_union) if core_sites else '',
              'all_specific_signature_union_core_coverage_fraction': round(len(core_sites & all_union)/len(core_sites),6) if core_sites else '',
              'all_specific_signature_union_cysteines_inside': len(cp & all_union) if core_sites else '',
              'local_signature_union_core_coverage_fraction': round(len(core_sites & local_union)/len(core_sites),6) if core_sites else '',
              'local_signature_union_cysteines_inside': len(cp & local_union) if core_sites else '',
              'coordinate_status': status, 'partial_specific_profile_rows': ';'.join(partial_profiles),
              'local_components_outside_core': ';'.join(outside_local),
              'predicted_GPI_omega': c['omega'] or '', 'core_cysteines_retained_at_omega': retained_c,
              'requires_candidate_level_coordinate_explanation': status.endswith('_REVIEW'),
              'notes': ' | '.join(review), 'protein_sha256': digest_bytes(seq.encode()),
              'core_sha256': digest_bytes(c['core'].encode()) if c['core'] else ''}
    candidate_results.append(result)

by_id = {r['candidate_id']:r for r in candidate_results}
target_assertions = []
for q in ('RSO__gmmChr07G009240.1', 'TAU__evm.model.Chr05.234'):
    matches = [s for s in signatures if s['candidate_id']==q and s['interpro']=='IPR044741' and s['signature']=='cd04660']
    ok = bool(matches) and any(s['contains_complete_core'] and s['core_cysteines_inside']==8 for s in matches)
    check(ok, 'IPR044741-only identity path does not cover complete core with cd04660', q)
    target_assertions.append({'id':q,'cd04660_contains_full_core_and_all8C':ok})

write_table('candidate_core_signature_compatibility.tsv', candidate_results)
write_table('specific_signature_coordinate_details.tsv', signatures)
write_table('broad_or_other_signatures_excluded_from_specific_coverage.tsv', broad_excluded)
review_rows = [r for r in candidate_results if r['requires_candidate_level_coordinate_explanation'] or r['partial_specific_profile_rows'] or r['local_components_outside_core'] or (not r['core_length_aa'] and r['specific_signature_rows']) or (r['core_cysteines_retained_at_omega']!='' and r['core_cysteines_retained_at_omega']<8)]
write_table('coordinate_exceptions_and_explanations.tsv', review_rows, ['candidate_id','notes'])
write_table('validation_errors.tsv', errors, ['candidate_id','problem'])
# Detect input drift during the run before declaring reproducibility.
for p,(size,sha) in input_hashes.items():
    check(p.stat().st_size==size and digest_bytes(p.read_bytes())==sha, 'Input changed during audit', str(p.relative_to(ROOT)))
manifest = [{'path_relative_to_workspace':str(p.relative_to(ROOT)), 'bytes':size, 'sha256':sha}
            for p,(size,sha) in sorted(input_hashes.items())]
manifest.append({'path_relative_to_workspace':str(Path(__file__).relative_to(ROOT)),
                 'bytes':Path(__file__).stat().st_size, 'sha256':digest_bytes(Path(__file__).read_bytes())})
write_table('input_and_script_SHA256.tsv', manifest)

status = {
    'status':'PASS_WITH_EXPLICIT_COORDINATE_LIMITS' if not errors else 'FAIL',
    'candidate_count':len(candidate_results), 'M2_candidates':99, 'M6_candidates':['R1M6_CAND03'],
    'signature_source_rows_match_original_table':not any('table differs' in e['problem'] for e in errors),
    'sequence_MD5_and_core_coordinate_validation_errors':len(errors), 'errors':errors,
    'coordinate_status_counts':dict(Counter(r['coordinate_status'] for r in candidate_results)),
    'M2_status_counts':dict(Counter(r['coordinate_status'] for r in candidate_results if r['scope']=='M2')),
    'specific_signature_rows':len(signatures), 'broad_other_rows_not_counted_as_specific':len(broad_excluded),
    'IPR044741_single_path_assertions':target_assertions,
    'candidate_level_coordinate_review_ids':[r['candidate_id'] for r in candidate_results if r['requires_candidate_level_coordinate_explanation']],
    'M6_CAND03_result':by_id['R1M6_CAND03'],
    'classifications_changed':False,
    'methods':{'coordinates':'1-based inclusive precursor amino-acid positions',
               'specific_IPR_set':sorted(SPEC),'full_profile_applications':sorted(PROFILE_APPS),
               'short_local_signature_applications':sorted(LOCAL_APPS),
               'union':'Exact union of reported intervals; intervening gaps not filled by bounding boxes',
               'core':'Previously selected first-to-eighth core, verified against exact protein sequence and supplied C positions',
               'profile_edges':'Partial boundaries and all missing core-C positions retained; no arbitrary percent cutoff changes family membership'},
    'limitations':[
        'Coordinate inclusion does not show residue-level profile alignment, disulfide pairing, domain fold, or biological function.',
        'PANTHER family-profile spans are distinguished from CDD domain spans; either may have approximate edges.',
        'PRINTS/PROSITE patterns are local motifs; they are not required to cover the whole core or all eight cysteines.',
        'Broad Pfam/InterPro/other matches are retained separately and never count toward specific-profile coverage.',
        'A selected canonical core may be absent despite a specific profile; this preserves the existing boundary classification.',
        'No BLAST, HMM, predictor, tree, sequence-model reconstruction or membership decision was rerun or changed.'
    ], 'inputs_checked_for_drift':len(input_hashes),
}
(OUT/'coordinate_validation.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
write_table('validation_errors.tsv', errors, ['candidate_id','problem'])
partial = [r for r in candidate_results if r['coordinate_status']=='SPECIFIC_PROFILE_BOUNDARY_PARTIAL_REVIEW']
partial_table = '\n'.join(f"| {r['member_id']} | {r['core_start_aa']}–{r['core_end_aa']} | {100*r['full_profile_union_core_coverage_fraction']:.3f}% | {r['full_profile_union_cysteines_inside']}/8 | {r['full_profile_union_cysteines_outside']} | {r['archived_qualifying_positive_reference_count']} |" for r in partial)
report = f'''# 8CM 与家族签名坐标独立核验

本核验只读取既有输入、只向本目录写文件；不修改候选分类、主集数量或正式稿。

已审核 M2 全部 99 个候选及 M6 CAND03。输入蛋白 SHA256、原始 InterProScan 序列 MD5/长度、核心序列及八个 C 的坐标、原始签名与已有审核表的多重行集合均通过核对。输入在运行前后哈希相同。状态为 `{status['status']}`，不表示所有候选都有完整域覆盖。

## 如何计算

- 全部坐标为前体蛋白的 1-based inclusive 氨基酸位置。
- CDD 等域 profile 与 PANTHER 家族 profile 分列；两者合并指标名为 full profile。PRINTS 的指纹组件、PROSITE 的短模式单独计量，不能要求单个短模式覆盖八个 C 或整个核心。
- IPR000528/IPR033872/IPR039265/IPR044741 为本次沿用的特定家族证据集合。其他匹配（包括 PF00234/PF14368 及广义 prolamin）另表保留，不贡献特异域覆盖。
- 覆盖率=核心中被已报告匹配区间覆盖的氨基酸位置数/核心长度。并集只合并真正覆盖的位置，不用首尾包围框填补组件之间的空隙。
- “C 在区间内”只是位置包含关系，不证明该 C 与 profile 保守位点同列，也不证明二硫键、真实折叠或生物学功能。

## 结果

M2：39 个有至少一个特异完整 profile 区间覆盖整个已选核心；13 个仅有相容区域内的局部特异指纹/模式；4 个整域 profile 边缘未包含整个核心；41 个没有特异签名路径（按原同源路径或原边界/范围外分类解释）；2 个虽有特异签名，但没有可识别的已选经典 8CM，原本就属于 B。

两个单独依赖 IPR044741 的个案已设置严格断言：RsLTP29 的 cd04660 与核心均为30–103，Tamarix Chr05.234 均为31–105，完整覆盖8 C。断言结果见 JSON。

以下4个候选必须保留边缘说明，不能写成“全部家族域完全覆盖8CM”：

| 候选 | 核心区间 | 特异 profile 并集覆盖 | 区间内 C | 区间外 C 坐标 | 既有合格正参考数 |
|---|---|---:|---:|---:|---:|
{partial_table}

前三例 PANTHER 边界距离末端 C8 为2 aa，最后一例距离C8为3 aa。它们是profile边缘差异，需要解释；没有凭此新设95%阈值，也没有自动纳入或排除。前三例还有既有合格核心同源证据；最后一例没有该额外路径，应明确保留域边缘的不确定性。精确逐签名位置及遗漏C见TSV。部分候选的一种profile遗漏末端C、另一种覆盖完整核心，亦逐行保留，没有隐藏差异。

RsLTP8另有一个PRINTS组件109–120在其C1–C8核心33–104之后；其其他profile覆盖整个核心。指纹组件可对应核心以外的成熟蛋白残基，此情况单列，不等同于整个域位于远端。

M6 CAND03：3个PRINTS PR00382组件为24–40、44–58、78–95，整合到IPR000528；与28–101核心交集的精确并集为46/74 aa（62.162%）、包含5/8 C。这是局部指纹，不能写成“IPR000528整域覆盖8 C”。核心本身完整、与分泌及omega125相容。其广义Pfam/SMART/SUPERFAMILY/PANTHER匹配已单列，不冒充特异域。核验保留既有家族结论，不重新评分该指纹。

## 正式稿可用的方法表述

We independently mapped the original family-specific signature intervals to the selected eight-cysteine cores for all 99 annotation-derived candidates and the reconstructed nsLTP candidate CAND03. Full domain/family profiles were distinguished from local PRINTS/PROSITE signatures, and exact interval-union coverage and the number of core cysteines within each match were tabulated. Broad prolamin matches did not count toward specific-profile coverage. The two candidates relying solely on IPR044741 had cd04660 matches spanning their complete cores. Four other candidates had specific-profile boundaries that excluded the terminal core cysteine; these boundary differences were retained explicitly rather than used to impose a new arbitrary exclusion threshold. Coordinate containment was not interpreted as residue-level alignment or experimental validation.

## 文件与复现

- `candidate_core_signature_compatibility.tsv`：100项逐候选结论，包含同源路径上下文、最大单profile覆盖及并集覆盖。
- `specific_signature_coordinate_details.tsv`：249行特异签名，逐行核心覆盖和遗漏C。
- `broad_or_other_signatures_excluded_from_specific_coverage.tsv`：645行不计作特异覆盖的匹配。
- `coordinate_exceptions_and_explanations.tsv`：边缘差异、无经典核心、局部末端组件和GPI核心冲突。
- `coordinate_validation.json`、`validation_errors.tsv`：核验范围、断言和错误。零错误指数据一致性及上述断言通过，不等于不存在边缘限制。
- `input_and_script_SHA256.tsv`：9个输入及脚本哈希，路径相对工作区。

在另一台电脑将整个工作区保持相同相对结构后执行：

```powershell
python .\\M2_M6_落实核验_20260909\\规则核验\\verify_core_signature_coordinates.py
```

仅依赖Python标准库，无需网络、R、Biopython或重新调用预测器。
'''
(OUT/'README_核验结果与解释.md').write_text(report,encoding='utf-8')
print(json.dumps(status,ensure_ascii=False,indent=2))
if errors:
    raise SystemExit(1)
