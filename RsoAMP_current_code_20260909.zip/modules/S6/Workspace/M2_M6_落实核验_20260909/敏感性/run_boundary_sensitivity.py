"""Filter archived results by candidate membership. Does NOT rerun inference.

First use: python run_boundary_sensitivity.py --snapshot --snapshot-global --snapshot-m6
Reproduce from frozen local inputs: python run_boundary_sensitivity.py
Requires Python 3.10+, openpyxl and biopython.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from Bio import Phylo
from openpyxl import load_workbook

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
M2 = ROOT / "成员判定收尾_20260909/审核_M2"
S3 = ROOT / "跨物种比较_正式同步_20260909/File_S3"
FORMAL = ROOT / "Genes_lab_handoff_20260908/01_Current_Editing"
EXPR_BASE = ROOT / "Genes_lab_handoff_20260908/02_Workspace/9_2_major_revision"
EXPR = EXPR_BASE / "revision_R1_20260902/06_expression_reanalysis"
INPUTS = {
    "M2_all99_tiered_evidence.tsv": M2 / "M2_all99_tiered_evidence.tsv",
    "M2_primary_39_26.tsv": M2 / "M2_primary_39_26.tsv",
    "M2_extended_40_27.tsv": M2 / "M2_extended_40_27.tsv",
    "M2_reference_dependent_1_1.tsv": M2 / "M2_reference_dependent_1_1.tsv",
    "M2_IPR044741_admission_dependent_1_1.tsv": M2 / "M2_IPR044741_admission_dependent_1_1.tsv",
    "S19_Roster.tsv": S3 / "audit/results/S19_Roster.tsv",
    "S19_Counts.tsv": S3 / "audit/results/S19_Counts.tsv",
    "S20_RBH_pairs.tsv": S3 / "audit/results/S20_RBH_pairs.tsv",
    "S21_Collinear_pairs.tsv": S3 / "audit/results/S21_Collinear_pairs.tsv",
    "Supplementary_snapshot.xlsx": FORMAL / "03_Supplementary/Genes_RsoAMP_Supplementary_Tables_expression_status_20260904.xlsx",
    "key_branch_evidence.tsv": FORMAL / "05_Newick_iTOL/key_branch_evidence.tsv",
    "Figure2C_nsLTP_key_clades.nwk": FORMAL / "05_Newick_iTOL/Figure2C_nsLTP_key_clades.nwk",
}
GLOBAL_INPUTS = {
    "all_gene_DE_results.csv": EXPR / "results/all_gene_DE_results.csv",
    "gene_TPM.csv": EXPR / "results/gene_TPM.csv",
    "gene_normalized_counts.csv": EXPR / "results/gene_normalized_counts.csv",
    "all_gene_prefilter_audit.tsv": EXPR_BASE / "expression_status_audit_20260904/all_gene_prefilter_audit.tsv",
    "all_gene_prefilter_counts.tsv": EXPR_BASE / "expression_status_audit_20260904/all_gene_prefilter_counts.tsv",
    "transcript_to_gene.tsv": EXPR / "transcript_to_gene.tsv",
    "run_expression_deseq2.R": EXPR / "run_expression_deseq2.R",
}
SCENARIOS = [
    ("extended", "扩展候选集", set()),
    ("primary_without_C4", "主集：去除C4参考依赖对", {"C4_reference"}),
    ("without_IPR044741_route", "去除IPR044741单路径依赖对", {"IPR044741_route"}),
    ("without_both", "两类依赖对均去除", {"C4_reference", "IPR044741_route"}),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump_tsv(name, rows, fields=None):
    rows = list(rows)
    if fields is None:
        fields = list(dict.fromkeys(k for r in rows for k in r))
    with (HERE / name).open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, delimiter="\t", extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def read_tsv(name):
    with (HERE / "inputs" / name).open(encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def truth(v):
    return str(v).lower() in ("true", "yes", "1")

def finite(v):
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def read_csv(name):
    with (HERE / "inputs" / name).open(encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def workbook_rows(workbook, sheet):
    it = iter(workbook[sheet].values)
    header = next(it)
    return [dict(zip(header, v)) for v in it if any(x is not None for x in v)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", action="store_true",
                        help="Capture current inputs once; refuses an existing input manifest.")
    parser.add_argument("--snapshot-global", action="store_true",
                        help="Append the previously uncaptured genome-wide expression sources once.")
    parser.add_argument("--snapshot-m6", action="store_true",
                        help="Append M6 accepted-model metadata to create explicit unquantified placeholders.")
    args = parser.parse_args()
    manifest_path = HERE / "input_manifest.json"
    if args.snapshot:
        if manifest_path.exists():
            raise RuntimeError("Refusing to replace existing input snapshot.")
        (HERE / "inputs").mkdir(parents=True, exist_ok=True)
        manifest = []
        for name, source in INPUTS.items():
            data = source.read_bytes()
            before = sha(data)
            if sha(source.read_bytes()) != before:
                raise RuntimeError(f"Source changed during capture: {source}")
            (HERE / "inputs" / name).write_bytes(data)
            manifest.append({
                "snapshot_name": name, "source_absolute_path": str(source),
                "source_relative_path": str(source.relative_to(ROOT)),
                "size_bytes": len(data), "sha256": before,
            })
        manifest_path.write_text(json.dumps({
            "captured_at_utc": datetime.now(timezone.utc).isoformat(),
            "inputs": manifest,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if args.snapshot_global:
        existing = {r["snapshot_name"] for r in manifest["inputs"]}
        if existing & set(GLOBAL_INPUTS):
            raise RuntimeError("Refusing to replace existing genome-wide expression snapshot.")
        for name, source in GLOBAL_INPUTS.items():
            data = source.read_bytes()
            checksum = sha(data)
            if sha(source.read_bytes()) != checksum:
                raise RuntimeError(f"Source changed during capture: {source}")
            (HERE / "inputs" / name).write_bytes(data)
            manifest["inputs"].append({
                "snapshot_name": name, "source_absolute_path": str(source),
                "source_relative_path": str(source.relative_to(ROOT)),
                "size_bytes": len(data), "sha256": checksum,
            })
        manifest["genome_expression_added_at_utc"] = datetime.now(timezone.utc).isoformat()
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.snapshot_m6:
        name = "M6_七个可合并成员.tsv"
        source = ROOT / "成员判定收尾_20260909/审核_M6" / name
        if name in {r["snapshot_name"] for r in manifest["inputs"]}:
            raise RuntimeError("Refusing to replace existing M6 metadata snapshot.")
        data = source.read_bytes()
        checksum = sha(data)
        assert sha(source.read_bytes()) == checksum
        (HERE / "inputs" / name).write_bytes(data)
        manifest["inputs"].append({
            "snapshot_name": name, "source_absolute_path": str(source),
            "source_relative_path": str(source.relative_to(ROOT)),
            "size_bytes": len(data), "sha256": checksum,
        })
        manifest["M6_metadata_added_at_utc"] = datetime.now(timezone.utc).isoformat()
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    for row in manifest["inputs"]:
        data = (HERE / "inputs" / row["snapshot_name"]).read_bytes()
        assert sha(data) == row["sha256"], row["snapshot_name"]
        assert len(data) == row["size_bytes"], row["snapshot_name"]
    dump_tsv("输入_SHA256.tsv", manifest["inputs"])

    roster = read_tsv("S19_Roster.tsv")
    extended = read_tsv("M2_extended_40_27.tsv")
    primary = read_tsv("M2_primary_39_26.tsv")
    references = read_tsv("M2_reference_dependent_1_1.tsv")
    iprs = read_tsv("M2_IPR044741_admission_dependent_1_1.tsv")
    all99 = read_tsv("M2_all99_tiered_evidence.tsv")
    assert len({r["id"] for r in roster}) == len(roster)
    assert {r["id"] for r in roster if r["family"] == "nsLTP"} == {r["id"] for r in extended}
    assert {r["id"] for r in extended} - {r["id"] for r in references} == {r["id"] for r in primary}
    assert len(references) == len(iprs) == 2
    dependent = {r["id"]: "C4_reference" for r in references}
    dependent.update({r["id"]: "IPR044741_route" for r in iprs})
    target_rows = [r for r in all99 if r["id"] in dependent]
    assert len(target_rows) == 4
    rbhs = read_tsv("S20_RBH_pairs.tsv")
    colls = read_tsv("S21_Collinear_pairs.tsv")
    assert len(rbhs) == 27 and len(colls) == 31
    assert sum(truth(r["both_retained"]) for r in colls) == 26

    # Freeze and filter existing edges only. New best hits or new blocks are not inferred.
    counts = []
    family_counts = []
    pair_impacts = []
    all_filtered_rbhs = []
    all_filtered_colls = []
    for key, label, omit_categories in SCENARIOS:
        omitted = {i for i, cat in dependent.items() if cat in omit_categories}
        kept = [r for r in roster if r["id"] not in omitted]
        kr = [r for r in rbhs if r["query_id"] not in omitted and r["best_other_id"] not in omitted]
        kc = [r for r in colls if r["rso_gene"] not in omitted and r["tamarix_gene"] not in omitted]
        both = [r for r in kc if truth(r["both_retained"])]
        concordant = [r for r in both if truth(r["family_concordant"])]
        count_by = Counter((r["species"], r["family"]) for r in kept)
        for (species, family), value in sorted(count_by.items()):
            family_counts.append(dict(scenario=key, species=species, family=family,
                                      count_existing_catalogue=value, M6_models_included=False))
        rso_n = count_by[("rso", "nsLTP")]
        tau_n = count_by[("tau", "nsLTP")]
        counts.append(dict(
            scenario=key, scenario_label=label,
            rso_nsLTP=rso_n, tau_nsLTP=tau_n,
            rso_minus_tau_nsLTP=rso_n-tau_n,
            rso_to_tau_nsLTP_ratio=round(rso_n/tau_n, 6),
            rso_total_existing_candidates=sum(r["species"] == "rso" for r in kept),
            tau_total_existing_candidates=sum(r["species"] == "tau" for r in kept),
            existing_RBH_pairs=len(kr),
            existing_nsLTP_RBH_pairs=sum(r["query_family"] == "nsLTP" for r in kr),
            existing_collinear_links_all=len(kc),
            existing_collinear_links_both_retained=len(both),
            existing_collinear_links_family_concordant=len(concordant),
            existing_nsLTP_collinear_both_retained=sum(r["rso_family"] == "nsLTP" for r in both),
            removed_ids=";".join(sorted(omitted)),
            method="filter_fixed_existing_results; no inference rerun; M6 not included",
        ))
        all_filtered_rbhs.extend(dict(scenario=key, **r) for r in kr)
        all_filtered_colls.extend(dict(scenario=key, **r) for r in kc)
        for kind, rows, left, right in [
            ("RBH", rbhs, "query_id", "best_other_id"),
            ("Collinearity", colls, "rso_gene", "tamarix_gene"),
        ]:
            for r in rows:
                if {r[left], r[right]} & omitted:
                    pair_impacts.append(dict(
                        scenario=key, evidence_type=kind,
                        left_id=r[left], right_id=r[right],
                        original_both_retained=r["both_retained"],
                        original_family_concordant=r["family_concordant"],
                        removed_by=";".join(sorted({r[left], r[right]} & omitted)),
                        block=r.get("mcscanx_block", ""),
                    ))
    dump_tsv("四情景_现有结果过滤汇总.tsv", counts)
    dump_tsv("四情景_现有成员家族数量.tsv", family_counts)
    dump_tsv("四情景_移出既有配对.tsv", pair_impacts)
    dump_tsv("四情景_保留既有RBH.tsv", all_filtered_rbhs)
    dump_tsv("四情景_保留既有共线性.tsv", all_filtered_colls)

    w = load_workbook(HERE / "inputs/Supplementary_snapshot.xlsx", read_only=True, data_only=True)
    old = workbook_rows(w, "S1_Catalogue")
    old_members = {r["member_id"] for r in old}
    tpm = workbook_rows(w, "S12_AMP_TPM")
    de = workbook_rows(w, "S14_AMP_DE")
    original_summary = workbook_rows(w, "S15_DE_Summary")
    filters = workbook_rows(w, "S26_ExpressionFilter")
    mappability = workbook_rows(w, "S23_Mappability")
    qr = workbook_rows(w, "S22_qPCR_Candidates")
    assert len(old_members) == 63 and len(de) == 189
    rso_targets = {r["member_id"] for r in target_rows if r["species"] == "rso"}
    status = []
    for row in target_rows:
        member = row["member_id"]
        existing_tpm = [r for r in tpm if r["member_id"] == member] if member else []
        existing_de = [r for r in de if r["member_id"] == member] if member else []
        existing_filters = [r for r in filters if r["member_id"] == member] if member else []
        status.append(dict(
            id=row["id"], member_id=member, dependency=dependent[row["id"]],
            old_expression_catalogue_member=member in old_members,
            TPM_rows=len(existing_tpm), DE_rows=len(existing_de),
            prefilter_status=existing_filters[0]["prefilter_status"] if existing_filters else "",
            total_estimated_counts=existing_filters[0]["tximport_estimated_count_sum"] if existing_filters else "",
            positive_DE_contrasts=sum(truth(r["DE_call_FDR_lt_0.05_abs_log2FC_gt_1"]) for r in existing_de),
            interpretation=(
                "Tamarix expression not assayed in the current Rso RNA-seq data"
                if row["species"] == "tau" else
                "Absent from the archived 63-member expression subset; inclusion impact not evaluable by filtering"
                if not existing_tpm else
                "All-zero counts and TPM in all nine samples; already prefiltered; removal changes denominators only"
            ),
        ))
    dump_tsv("依赖成员_既有表达覆盖.tsv", status)
    dump_tsv("依赖成员_既有TPM条目.tsv", [r for r in tpm if r["member_id"] in rso_targets])
    dump_tsv("依赖成员_既有DE条目.tsv", [r for r in de if r["member_id"] in rso_targets])
    dump_tsv("依赖成员_既有预过滤条目.tsv", [r for r in filters if r["member_id"] in rso_targets])
    dump_tsv("依赖成员_既有可比对性条目.tsv", [r for r in mappability if r["member_id"] in rso_targets])

    expr_counts = []
    contrasts = list(dict.fromkeys(r["contrast"] for r in de))
    for key, label, cats in SCENARIOS:
        omitted_members = {
            r["member_id"] for r in target_rows
            if r["species"] == "rso" and dependent[r["id"]] in cats
        }
        kept_de = [r for r in de if r["member_id"] not in omitted_members]
        for contrast in contrasts:
            for family in ("ALL", "Defensin", "Snakin_GASA", "nsLTP"):
                rows = [r for r in kept_de if r["contrast"] == contrast
                        and (family == "ALL" or r["family"] == family)]
                positive = [r for r in rows if truth(r["DE_call_FDR_lt_0.05_abs_log2FC_gt_1"])]
                summary = dict(
                    scenario=key, contrast=contrast, family=family,
                    archived_expression_subset_members=len(rows),
                    retained_for_DE_members=sum(r["prefilter_status"] == "RETAINED_TOTAL_COUNT_GE_10" for r in rows),
                    filtered_all_zero_members=sum(r["prefilter_status"] == "FILTERED_ALL_ZERO_COUNTS" for r in rows),
                    filtered_low_total_count_members=sum(r["prefilter_status"] == "FILTERED_TOTAL_COUNT_LT_10" for r in rows),
                    members_with_adjusted_P=sum(finite(r["padj_BH"]) for r in rows),
                    DE_members=len(positive),
                    upregulated=sum(float(r["log2FoldChange"]) > 0 for r in positive),
                    downregulated=sum(float(r["log2FoldChange"]) < 0 for r in positive),
                    method="subset existing DE rows; preserve original genome-wide adjusted P; no refit",
                )
                expr_counts.append(summary)
                if key == "extended":
                    expected = next(r for r in original_summary if r["contrast"] == contrast and r["family"] == family)
                    assert len(rows) == expected["primary_catalogue_members"]
                    for field in ["retained_for_DE_members", "filtered_all_zero_members",
                                  "filtered_low_total_count_members", "members_with_adjusted_P",
                                  "DE_members", "upregulated", "downregulated"]:
                        assert summary[field] == expected[field], (contrast, family, field)
    dump_tsv("四情景_旧表达子集统计.tsv", expr_counts)
    missing = []
    for key, label, cats in SCENARIOS:
        omitted = {i for i, cat in dependent.items() if cat in cats}
        for r in roster:
            if r["species"] == "rso" and r["id"] not in omitted and r["member_id"] not in old_members:
                missing.append(dict(scenario=key, id=r["id"], member_id=r["member_id"],
                                    family=r["family"],
                                    status="Not present in archived S12-S15; quantitative effect not evaluated"))
    dump_tsv("各情景_目录中缺旧表达结果成员.tsv", missing)

    # Recover existing genome-wide results for all annotated Rso candidates.
    # This extends the reported subset, but neither quantification nor tests are rerun.
    all_de = {(r["gene_id"], r["contrast"]): r for r in read_csv("all_gene_DE_results.csv")}
    all_tpm = {r["gene_id"]: r for r in read_csv("gene_TPM.csv")}
    all_norm = {r["gene_id"]: r for r in read_csv("gene_normalized_counts.csv")}
    all_prefilter = {r["gene_id"]: r for r in read_tsv("all_gene_prefilter_audit.tsv")}
    all_counts = {r["gene_id"]: r for r in read_tsv("all_gene_prefilter_counts.tsv")}
    txmap_rows = read_tsv("transcript_to_gene.tsv")
    txmap = {list(r.values())[0]: list(r.values())[1] for r in txmap_rows}
    gene_map = {r["member_id"]: r["gene_id"] for r in old}
    gene_map.update({r["member_id"]: r["gene_id"] for r in all99 if r["species"] == "rso"})
    # Verify the full-genome table is the same statistical source as current S14.
    equality_checks = 0
    for r in de:
        if r["prefilter_status"] != "RETAINED_TOTAL_COUNT_GE_10":
            continue
        full = all_de[(r["gene_id"], r["contrast"])]
        for old_f, full_f in [("baseMean", "baseMean"), ("log2FoldChange", "log2FoldChange"),
                              ("padj_BH", "padj"), ("pvalue", "pvalue")]:
            if finite(r[old_f]):
                assert finite(full[full_f])
                assert math.isclose(float(r[old_f]), float(full[full_f]), rel_tol=1e-10, abs_tol=1e-12)
            else:
                assert not finite(full[full_f])
            equality_checks += 1
        assert truth(r["DE_call_FDR_lt_0.05_abs_log2FC_gt_1"]) == truth(full["DE_call"])
    unified_de, unified_tpm, unified_norm, unified_counts, unified_filter = [], [], [], [], []
    provenance_rows = []
    for r in roster:
        if r["species"] != "rso":
            continue
        member = r["member_id"]
        gene = gene_map[member]
        assert gene in all_prefilter and gene in all_tpm and gene in all_counts
        prefix = dict(member_id=member, family=r["family"], id=r["id"], protein_id=r["protein_id"])
        pf = all_prefilter[gene]
        unified_filter.append(dict(**prefix, **pf))
        unified_tpm.append(dict(**prefix, **all_tpm[gene]))
        unified_counts.append(dict(**prefix, **all_counts[gene]))
        if gene in all_norm:
            unified_norm.append(dict(**prefix, **all_norm[gene]))
        else:
            unified_norm.append(dict(**prefix, gene_id=gene,
                                     **{k: "NA" for k in next(iter(all_norm.values())) if k != "gene_id"}))
        tx_match = txmap.get(r["protein_id"])
        if tx_match is None:
            # Protein identifiers may have an ORF suffix which is absent from tximport input.
            tid = r["protein_id"]
            if ".p" in tid:
                tid = tid.rsplit(".p", 1)[0]
            tx_match = txmap.get(tid)
        assert tx_match == gene, (member, r["protein_id"], gene, tx_match)
        provenance_rows.append(dict(**prefix, gene_id=gene,
                                    in_old_63=member in old_members,
                                    transcript_gene_mapping_verified=True,
                                    prefilter_status=pf["prefilter_status"],
                                    evidence="recovered from frozen whole-transcriptome analysis; no requantification"))
        for contrast in contrasts:
            original = all_de.get((gene, contrast))
            retained = truth(pf["retained_for_DE"])
            assert (original is not None) == retained, (member, contrast)
            full = original or {
                "gene_id": gene, "contrast": contrast, "baseMean": "NA",
                "log2FoldChange": "NA", "log2FC_apeglm": "NA", "lfcSE": "NA",
                "stat": "NA", "pvalue": "NA", "padj": "NA", "DE_call": "NA",
            }
            test_status = (
                "TESTED_WITH_ADJUSTED_P" if original and finite(original["padj"]) else
                "INDEPENDENTLY_FILTERED_PADJ_UNAVAILABLE" if original else
                "NOT_TESTED_ALL_ZERO_COUNTS" if pf["prefilter_status"] == "FILTERED_ALL_ZERO_COUNTS"
                else "NOT_TESTED_LOW_TOTAL_COUNT"
            )
            unified_de.append(dict(**prefix, **full, prefilter_status=pf["prefilter_status"],
                                   DE_test_status=test_status,
                                   source="frozen genome-wide DE results and prefilter audit"))
    dump_tsv("现有注释67成员_全转录组提取DE.tsv", unified_de)
    dump_tsv("现有注释67成员_全转录组提取TPM.tsv", unified_tpm)
    dump_tsv("现有注释67成员_全转录组提取NormalizedCounts.tsv", unified_norm)
    dump_tsv("现有注释67成员_全转录组提取Counts.tsv", unified_counts)
    dump_tsv("现有注释67成员_全转录组预过滤.tsv", unified_filter)
    dump_tsv("现有注释67成员_表达来源对应.tsv", provenance_rows)
    primary_ids = {r["id"] for r in roster
                   if r["id"] not in {x["id"] for x in references}}
    for suffix, rows in [
        ("DE", unified_de), ("TPM", unified_tpm), ("NormalizedCounts", unified_norm),
        ("Counts", unified_counts), ("预过滤", unified_filter),
    ]:
        dump_tsv(f"现有注释主集66成员_{suffix}.tsv",
                 [r for r in rows if r["id"] in primary_ids])
    m6 = read_tsv("M6_七个可合并成员.tsv")
    assert len(m6) == 7
    m6_de, m6_tpm, m6_filter = [], [], []
    samples = [k for k in unified_tpm[0] if k.startswith("SRR")]
    for r in m6:
        base = dict(member_id=r["suggested_stable_gene_name"], family=r["family"],
                    id=r["candidate_id"], protein_id=r["original_orf_id"],
                    gene_id=r["original_model_id"], name_status="suggested_stable_gene_name",
                    quantification_status="NOT_QUANTIFIED_NEW_MODEL",
                    source="M6 model metadata only; not present in frozen quantification reference")
        m6_tpm.append(dict(**base, **{s: "NA" for s in samples}))
        m6_filter.append(dict(**base, retained_for_DE="NA",
                              prefilter_status="NOT_ASSESSED_NEW_MODEL",
                              **{k: "NA" for k in all_prefilter[next(iter(all_prefilter))]
                                 if k not in ("gene_id", "retained_for_DE", "prefilter_status")}))
        for contrast in contrasts:
            m6_de.append(dict(**base, contrast=contrast,
                              **{k: "NA" for k in (
                                  "baseMean", "log2FoldChange", "log2FC_apeglm",
                                  "lfcSE", "stat", "pvalue", "padj", "DE_call")},
                              prefilter_status="NOT_ASSESSED_NEW_MODEL",
                              DE_test_status="NOT_TESTED_NEW_MODEL_NOT_QUANTIFIED"))
    dump_tsv("M6七模型_表达未定量_DE.tsv", m6_de)
    dump_tsv("M6七模型_表达未定量_TPM.tsv", m6_tpm)
    dump_tsv("M6七模型_表达未定量_预过滤.tsv", m6_filter)
    new_members = {r["member_id"] for r in unified_de} - old_members
    dump_tsv("补齐4成员_既有全转录组DE.tsv", [r for r in unified_de if r["member_id"] in new_members])
    dump_tsv("依赖成员_全转录组表达状态.tsv",
             [r for r in unified_filter if r["member_id"] in rso_targets])
    unified_summary = []
    for key, label, cats in SCENARIOS:
        omitted = {i for i, cat in dependent.items() if cat in cats}
        for contrast in contrasts:
            for family in ("ALL", "Defensin", "Snakin_GASA", "nsLTP"):
                rows = [r for r in unified_de if r["id"] not in omitted
                        and r["contrast"] == contrast and (family == "ALL" or r["family"] == family)]
                positive = [r for r in rows if truth(r["DE_call"])]
                unified_summary.append(dict(
                    scenario=key, contrast=contrast, family=family,
                    annotated_subset_members=len(rows),
                    retained_for_DE_members=sum(r["prefilter_status"] == "RETAINED_TOTAL_COUNT_GE_10" for r in rows),
                    filtered_all_zero_members=sum(r["prefilter_status"] == "FILTERED_ALL_ZERO_COUNTS" for r in rows),
                    filtered_low_total_count_members=sum(r["prefilter_status"] == "FILTERED_TOTAL_COUNT_LT_10" for r in rows),
                    members_with_adjusted_P=sum(finite(r["padj"]) for r in rows),
                    DE_members=len(positive),
                    upregulated=sum(float(r["log2FoldChange"]) > 0 for r in positive),
                    downregulated=sum(float(r["log2FoldChange"]) < 0 for r in positive),
                    method="reselect from original whole-transcriptome DE; no requantification/refit/BH recomputation",
                    M6_models="not quantified or evaluated",
                ))
    dump_tsv("四情景_现有注释集全转录组提取统计.tsv", unified_summary)

    tree = Phylo.read(HERE / "inputs/Figure2C_nsLTP_key_clades.nwk", "newick")
    tips = {t.name for t in tree.get_terminals()}
    branches = read_tsv("key_branch_evidence.tsv")
    target_tips = {
        r["id"]: ("RSO_" + r["member_id"] if r["species"] == "rso" else "TAU_" + r["protein_id"])
        for r in target_rows
    }
    fig_presence = []
    for r in target_rows:
        tip = target_tips[r["id"]]
        matching = [b["group_label"] for b in branches if tip in b["all_taxon_ids"].split(";")]
        highlighted = [b["group_label"] for b in branches
                       if truth(b["highlight_in_main"]) and tip in b["all_taxon_ids"].split(";")]
        fig_presence.append(dict(
            id=r["id"], tip_id=tip, in_existing_Figure2C=tip in tips,
            key_branch_groups=";".join(matching), highlighted_groups=";".join(highlighted),
            role="unhighlighted_tip" if tip in tips else "not_present_in_existing_tree",
            inference_limit="membership overlap only; support/topology were not re-estimated",
        ))
    dump_tsv("Figure2C_依赖成员位置.tsv", fig_presence)
    clade_impacts = []
    for key, label, cats in SCENARIOS:
        omit_tips = {target_tips[i] for i, cat in dependent.items() if cat in cats}
        for b in branches:
            members = set(b["all_taxon_ids"].split(";"))
            affected = members & omit_tips
            clade_impacts.append(dict(
                scenario=key, family=b["family"], group_label=b["group_label"],
                highlighted_in_main=b["highlight_in_main"],
                original_key_group_members=len(members),
                remaining_key_group_members=len(members - omit_tips),
                removed_group_tips=";".join(sorted(affected)),
                original_source_support=b["source_support"],
                interpretation="original membership definition unchanged" if not affected
                               else "membership definition affected",
                inferential_status="No tree/alignment/bootstrap rerun; unchanged membership does not establish new support",
            ))
    dump_tsv("Figure2_关键分支成员影响.tsv", clade_impacts)
    assert not any(r["removed_group_tips"] for r in clade_impacts)
    w.close()

    validation = {
        "input_hashes_verified": len(manifest["inputs"]),
        "extended_M2_matches_archived_comparison_nsLTP_roster": True,
        "primary_equals_extended_minus_reference_dependents": True,
        "old_expression_summary_reproduced_exactly": True,
        "whole_transcriptome_stat_values_equal_archived_S14_cells": equality_checks,
        "all_67_annotated_candidates_joined_to_existing_quantification": True,
        "all_67_transcript_to_gene_mappings_verified": True,
        "first_four_scenarios_all_7_highlighted_key_groups_membership_unchanged": True,
        "fifth_scenario_changed_groups": ["L3", "L5*"],
        "not_reestimated": True,
        "Figure2C_original_tip_count": len(tips),
        "M6_new_models_quantification_and_comparison": "NOT_EVALUATED",
        "analysis_executed": "deterministic row filtering, descriptive recounting, existing tree-tip membership audit",
        "not_executed": ["BLAST/RBH search rerun", "MCScanX rerun", "RNA-seq requantification",
                         "DESeq2 model refit or BH recomputation", "alignment/tree/bootstrap re-estimation",
                         "functional validation", "formal manuscript/table/figure edits"],
        "dependencies": {"python": __import__("sys").version,
                         "openpyxl": __import__("openpyxl").__version__,
                         "biopython": __import__("Bio").__version__},
    }
    (HERE / "validation.json").write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding="utf-8")
    results = "\n".join(
        f"| {r['scenario_label']} | {r['rso_nsLTP']}/{r['tau_nsLTP']} | "
        f"{r['existing_RBH_pairs']} | {r['existing_collinear_links_all']}/"
        f"{r['existing_collinear_links_both_retained']} |" for r in counts
    )
    expression_results = "\n".join(
        f"| {r['scenario']} | {r['contrast']} | {r['annotated_subset_members']} | "
        f"{r['DE_members']} | {r['upregulated']}/{r['downregulated']} |"
        for r in unified_summary if r["family"] == "ALL"
    )
    readme = f"""# 边界候选纳入与否：既有结果过滤核验

本目录只读取冻结输入，过滤已有结果并重计数量。没有重跑 BLAST/RBH、MCScanX、RNA-seq 定量、DESeq2 或系统树；没有改正式稿件、正式补表或作者图片。此结果不等同于用新目录重跑全流程。

## 已有比较结果

| 情景 | 红砂/柽柳 nsLTP | 既有 RBH 对 | 既有共线性连线/两端均为保留成员 |
|---|---:|---:|---:|
{results}

- 四种情景红砂 nsLTP 数量都比柽柳多 13 个；“本次候选目录的红砂数量较多”这个描述方向保持。但不能据此认定进化扩张，也不能排除两物种注释完整性差异。
- C4 依赖成员 RsLTP20 与 Chr10.1284 构成 1 对既有 RBH 和 1 对共线性（block 283）；移出它们各减少 1 对。
- IPR044741 单路径依赖成员 RsLTP29 与 Chr05.234 构成 1 对既有 RBH，未出现在既有共线性对表；移出它们仅减少 1 对既有 RBH。
- 主集 39/26 的既有 RBH 为 26 对，共线性为 30 条，其中 25 条两端均为保留成员。扩展集 40/27 的 27 对 RBH 与 31/26 条共线性仍作为扩展集描述，不能直接标成主集结果。
- 这些计数未纳入 M6 新模型。它们在冻结比较数据中没有对应结果；纳入后的匹配数和共线性不能靠直接加法得出。
- RBH 是过滤原有配对：删除成员后可能产生的新最佳匹配未计算。共线性是过滤已有块中的连线，未重新估计块结构。

## 表达：已从全转录组结果补齐现有注释成员

- 冻结正式 S12–S15 仍为原 63 成员（9 defensin + 18 Snakin/GASA + 36 nsLTP），并非新的完整成员目录。
- RsLTP20 不在这份旧表达子集中；继续查找后，已从本地冻结全转录组结果和预过滤审计恢复它的状态。9 个样本合计估计计数为 1，仅 1 样本非零，max TPM 为 0.462609，原流程已因总计数小于 10 过滤。其纳入不增加已有差异检验阳性数。不能把“未检验”写成“确定不差异”。柽柳两条依赖成员没有本项目红砂 RNA-seq 的表达结果。
- RsLTP29 的 9 个样本计数与 TPM 均为 0，原先已过滤、3 个比较都未进行差异检验。移出后旧表达子集从 63 变为 62（nsLTP 从 36 变为 35）；全零成员从 11 变为 10。既有 DE 阳性数保持 7、17、12（S200 vs CK、S400 vs CK、S400 vs S200），对应 nsLTP 为 3、9、7。
- 扩展集比旧表达子集新增的 4 个现有注释成员是 RsLTP2、RsLTP18、RsLTP20、RsLTP30；本次已从全转录组结果提取，并核验所有 67 成员的 transcript-to-gene 对应和原 S14 已检验数值的一致性。RsLTP2 在三个比较都显著上调；RsLTP18/30 的绝对 log2FC 都未达到大于 1 的门槛。
- 因此旧正式稿 7/17/12 个 DE 成员不适用于新的完整注释目录。四种敏感性情景的 DE 阳性总数均为 **8/18/13**；nsLTP 对应 **4/10/8**。C4 与 IPR044741 依赖成员均已预过滤，去留只改变目录分母及预过滤数量。这个变化来自补回 RsLTP2，而非重跑统计。
- 67/66/65 指已有注释成员的情景数，尚未纳入 M6。`四情景_现有注释集全转录组提取统计.tsv` 是当前用于主集/扩展集比较的表达结果；`四情景_旧表达子集统计.tsv` 仅用于追溯旧正式表。
- M6 新模型未重定量，表达影响未评估。所有表中原始 FDR/P 值均保留，未重拟合模型或重新多重校正。

| 情景 | 比较 | 已有注释成员数 | DE 成员数 | 上调/下调 |
|---|---|---:|---:|---:|
{expression_results}

## Figure 2：定义关键分支的成员未受这四条影响

- 现有 Figure2C 树有 {len(tips)} 个末端，包含 RsLTP20、RsLTP29、Chr05.234，缺少 Chr10.1284。
- 四条都不在已有着色 L1–L4 定义成员中，也不在未着色 L5* 定义成员中；七个主图着色分支的原成员定义在本次过滤情景下不变。
- 这里仅核对已存在树的成员集合，不能将原四策略 bootstrap/支持值说成已在新成员集上重新验证。现有 Figure 2 不包含完整扩展目录，尤其尚无 M6 模型；主图若继续使用，需明确其分析集合和候选标记。

## 重现与输入范围

运行 `python run_boundary_sensitivity.py` 从本目录 `inputs` 快照重建结果。全新运行目录使用 `python run_boundary_sensitivity.py --snapshot --snapshot-global --snapshot-m6` 一次性捕获目录、全转录组输入与 M6 模型元数据；已有输入拒绝覆盖。本次输入先后发现，已分别捕获并记录时间。另有直接可用的主注释集 66 成员全行 DE/TPM/计数/预过滤表，以及 M6 七模型全为 NA 的未定量占位表；M6 表中的 Rs 名称来自来源文件的建议稳定命名。

输入相对原路径、大小及 SHA-256 见 `输入_SHA256.tsv` / `input_manifest.json`。输出均带情景；`validation.json` 记录核验边界。冻结快照保留了本次读取时的正式补表，而不追随后续正式文件改动。
"""
    (HERE / "先看这一页.md").write_text(readme, encoding="utf-8")
    print(json.dumps({"counts": counts, "validation": validation}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
