"""Fifth, narrower sensitivity scenario on top of the primary annotated set.

Run base script first. First capture: python run_profile_edge_sensitivity.py --snapshot
Reproduce: python run_profile_edge_sensitivity.py
Only filters archived tables, never reruns statistical or phylogenetic inference.
"""
import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from collections import Counter

import run_boundary_sensitivity as base


def out_rows(name):
    with (base.HERE / name).open(encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--snapshot", action="store_true")
    args = ap.parse_args()
    source = base.ROOT / "M2_M6_落实核验_20260909/规则核验/coordinate_exceptions_and_explanations.tsv"
    name = "coordinate_exceptions_and_explanations.tsv"
    dest = base.HERE / "inputs" / name
    manifest_path = base.HERE / "profile_edge_input_manifest.json"
    if args.snapshot:
        if dest.exists() or manifest_path.exists():
            raise RuntimeError("Refusing to replace frozen profile-edge source.")
        data = source.read_bytes()
        checksum = base.sha(data)
        assert base.sha(source.read_bytes()) == checksum
        dest.write_bytes(data)
        manifest_path.write_text(json.dumps({
            "source_absolute_path": str(source),
            "source_relative_path": str(source.relative_to(base.ROOT)),
            "snapshot_name": name, "size_bytes": len(data), "sha256": checksum,
            "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert base.sha(dest.read_bytes()) == manifest["sha256"]
    expected = {
        "RSO__gmmChr07G003680.1", "RSO__gmmChr08G009900.1",
        "RSO__gmmChr08G009930.1", "TAU__novel_model_206_643946eb",
    }
    edges = [
        r for r in base.read_tsv(name)
        if r["scope"] == "M2" and
        r["coordinate_status"] == "SPECIFIC_PROFILE_BOUNDARY_PARTIAL_REVIEW"
    ]
    assert {r["candidate_id"] for r in edges} == expected
    references = {r["id"] for r in base.read_tsv("M2_reference_dependent_1_1.tsv")}
    omitted = expected | references
    key = "primary_without_profile_edge_cases"
    roster = base.read_tsv("S19_Roster.tsv")
    rbhs = base.read_tsv("S20_RBH_pairs.tsv")
    colls = base.read_tsv("S21_Collinear_pairs.tsv")
    kept = [r for r in roster if r["id"] not in omitted]
    kr = [r for r in rbhs if r["query_id"] not in omitted and r["best_other_id"] not in omitted]
    kc = [r for r in colls if r["rso_gene"] not in omitted and r["tamarix_gene"] not in omitted]
    both = [r for r in kc if base.truth(r["both_retained"])]
    count_by = Counter((r["species"], r["family"]) for r in kept)
    summary = dict(
        scenario=key, scenario_label="主注释集再去除4条profile边缘案例",
        rso_nsLTP=count_by[("rso", "nsLTP")], tau_nsLTP=count_by[("tau", "nsLTP")],
        rso_minus_tau_nsLTP=count_by[("rso", "nsLTP")] - count_by[("tau", "nsLTP")],
        rso_to_tau_nsLTP_ratio=round(count_by[("rso", "nsLTP")]/count_by[("tau", "nsLTP")], 6),
        rso_total_existing_candidates=sum(r["species"] == "rso" for r in kept),
        tau_total_existing_candidates=sum(r["species"] == "tau" for r in kept),
        existing_RBH_pairs=len(kr),
        existing_nsLTP_RBH_pairs=sum(r["query_family"] == "nsLTP" for r in kr),
        existing_collinear_links_all=len(kc),
        existing_collinear_links_both_retained=len(both),
        existing_collinear_links_family_concordant=sum(base.truth(r["family_concordant"]) for r in both),
        existing_nsLTP_collinear_both_retained=sum(r["rso_family"] == "nsLTP" for r in both),
        removed_ids=";".join(sorted(omitted)),
        method="filter primary existing results after additional profile-edge omissions; no inference rerun; M6 excluded",
    )
    assert (summary["rso_nsLTP"], summary["tau_nsLTP"], len(kr), len(kc), len(both)) == (36, 25, 25, 29, 24)
    base.dump_tsv("第五情景_现有结果过滤汇总.tsv", [summary])
    base.dump_tsv("五情景_现有结果过滤汇总.tsv",
                  out_rows("四情景_现有结果过滤汇总.tsv") + [summary])
    base.dump_tsv("第五情景_profile边缘原始证据.tsv", edges)
    base.dump_tsv("第五情景_保留既有RBH.tsv", kr)
    base.dump_tsv("第五情景_保留既有共线性.tsv", kc)
    impact = []
    for kind, rows, left, right in [
        ("RBH", rbhs, "query_id", "best_other_id"),
        ("Collinearity", colls, "rso_gene", "tamarix_gene"),
    ]:
        for r in rows:
            if {r[left], r[right]} & expected:
                impact.append(dict(evidence_type=kind, left_id=r[left], right_id=r[right],
                                   removed_by=";".join(sorted({r[left], r[right]} & expected)),
                                   block=r.get("mcscanx_block", "")))
    base.dump_tsv("第五情景_相对主集新增移出配对.tsv", impact)
    de = out_rows("现有注释67成员_全转录组提取DE.tsv")
    filtered = [r for r in de if r["id"] not in omitted]
    base.dump_tsv("第五情景_63注释成员既有DE.tsv", filtered)
    expr_summary = []
    for contrast in dict.fromkeys(r["contrast"] for r in de):
        for family in ("ALL", "Defensin", "Snakin_GASA", "nsLTP"):
            rows = [r for r in filtered if r["contrast"] == contrast
                    and (family == "ALL" or r["family"] == family)]
            positive = [r for r in rows if base.truth(r["DE_call"])]
            expr_summary.append(dict(
                scenario=key, contrast=contrast, family=family,
                annotated_subset_members=len(rows),
                retained_for_DE_members=sum(r["prefilter_status"] == "RETAINED_TOTAL_COUNT_GE_10" for r in rows),
                filtered_all_zero_members=sum(r["prefilter_status"] == "FILTERED_ALL_ZERO_COUNTS" for r in rows),
                filtered_low_total_count_members=sum(r["prefilter_status"] == "FILTERED_TOTAL_COUNT_LT_10" for r in rows),
                members_with_adjusted_P=sum(base.finite(r["padj"]) for r in rows),
                DE_members=len(positive),
                upregulated=sum(float(r["log2FoldChange"]) > 0 for r in positive),
                downregulated=sum(float(r["log2FoldChange"]) < 0 for r in positive),
                method="reselect from original whole-transcriptome DE; no requantification/refit/BH recomputation",
                M6_models="not quantified or evaluated",
            ))
    assert [r["DE_members"] for r in expr_summary if r["family"] == "ALL"] == [8, 18, 13]
    base.dump_tsv("第五情景_既有注释集表达统计.tsv", expr_summary)
    base.dump_tsv("五情景_既有注释集表达统计.tsv",
                  out_rows("四情景_现有注释集全转录组提取统计.tsv") + expr_summary)
    base.dump_tsv("第五情景_移出profile边缘成员既有DE.tsv",
                  [r for r in de if r["id"] in expected])
    branches = base.read_tsv("key_branch_evidence.tsv")
    omitted_tips = {"RSO_RsLTP20", "TAU_evm.model.Chr10.1284",
                    "RSO_RsLTP28", "RSO_RsLTP32", "RSO_RsLTP33",
                    "TAU_novel_model_206_643946eb"}
    clade_rows = []
    for b in branches:
        members = set(b["all_taxon_ids"].split(";"))
        removed = members & omitted_tips
        clade_rows.append(dict(
            group_label=b["group_label"], highlighted_in_main=b["highlight_in_main"],
            original_key_group_members=len(members),
            remaining_key_group_members=len(members - removed),
            removed_group_tips=";".join(sorted(removed)),
            original_source_support=b["source_support"],
            interpretation="membership definition affected" if removed else "original membership definition unchanged",
            inference_limit="original support is not re-estimated; pruning membership is not a new tree analysis",
        ))
    base.dump_tsv("第五情景_Figure2关键分支影响.tsv", clade_rows)
    assert {r["group_label"] for r in clade_rows if r["removed_group_tips"]} == {"L3", "L5*"}
    (base.HERE / "第五情景_先看这一页.md").write_text(
        """# 主集再去除 profile 边缘案例的敏感性

本情景以主注释集 66 个红砂成员（39 nsLTP）与 26 个柽柳 nsLTP 为起点，额外移出 RsLTP28、RsLTP32、RsLTP33 和柽柳 novel_model_206_643946eb。这是比前四情景更窄的范围检查，不代表上述成员判定错误，不改当前分类。

三条红砂序列的特异 profile 末端比第八个半胱氨酸短 2 aa，并分别有 12、9、11 条合格正参考；柽柳案例短 3 aa，缺少其他合格正参考。完整候选序列本身的 8C 框架并未因为 profile 边缘而消失。

过滤现成结果后：

- nsLTP 数量为红砂 36 / 柽柳 25，差值 11；“本次目录红砂候选数较多”的描述方向保持，仍不等同于证实进化扩张。
- 红砂已有注释总成员 63，柽柳已有候选总数 37（包括另行标记的 5 个 defensin 同源模型）。
- 既有 RBH 25 对；既有共线性 29 条，其中 24 条两端均为保留成员。相对主集各再少 1，对应 RsLTP40 与柽柳 novel_model_206_643946eb。
- 三条移出红砂成员全部通过原 DE 预过滤，但三比较均未达到 FDR < 0.05 且 |log2FC| > 1。移出后通过过滤人数从 52 降至 49；DE 阳性总数仍为 8/18/13，上下调分别为 6/2、12/6、9/4；nsLTP 为 4/10/8。
- Figure2 着色 L3 的原定义由 RsLTP39/RsLTP40/柽柳 novel_model_206_643946eb 三叶变成两条红砂叶。未着色 L5* 的原成员定义也改变（移出 RsLTP28/32/33）。不能声称本情景全部关键分支成员不变，不能把原支持值当作重新建树后的支持值。

没有重跑 BLAST/RBH、MCScanX、RNA-seq 定量、DESeq2、比对或树。所有 P 值来自既有全转录组结果；M6 未定量、未计入该情景。

复现顺序：先运行 `run_boundary_sensitivity.py`，再运行 `run_profile_edge_sensitivity.py`。首次新的坐标输入用后者 `--snapshot` 捕获；该单独输入及 SHA-256 记录于 `profile_edge_input_manifest.json`。合并对照表为 `五情景_现有结果过滤汇总.tsv` 和 `五情景_既有注释集表达统计.tsv`。
""", encoding="utf-8")
    (base.HERE / "profile_edge_validation.json").write_text(json.dumps({
        "coordinate_source_sha256_verified": True,
        "exact_four_profile_edge_cases_verified": True,
        "M2_classification_modified": False,
        "profile_scenario_summary": summary,
        "DE_totals_unchanged_from_primary": [8, 18, 13],
        "existing_key_group_definitions_affected": ["L3", "L5*"],
        "scope": "fixed result filtering only; no full-pipeline robustness claim",
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
