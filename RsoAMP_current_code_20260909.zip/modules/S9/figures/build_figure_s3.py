"""Plot audited, existing expression results; performs no sequence inference.

Usage: python build_figure_s3.py [--source path/to/restored_status.tsv]
Outputs are confined to this script's directory.
"""
from pathlib import Path
import argparse
import hashlib
import json
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.text import Text

OUT = Path(__file__).resolve().parent
DEFAULT_SOURCE = OUT.parent / "02_核查与汇总/independent_table_audit/paired_expression_restored_status.tsv"
COLORS = {"nsLTP": "#326B9B", "Snakin_GASA": "#168579"}
MARKERS = {"nsLTP": "o", "Snakin_GASA": "^"}
LABELS = {
    "S200_vs_CK": {
        "RsLTP15": (-1.26, 0.48), "RsLTP34": (1.24, 0.22),
        "RsLTP37": (-1.29, -0.08), "RsLTP25": (-1.26, -0.62),
        "RsSNA3": (1.81, -0.52), "RsLTP36": (-1.82, -1.21),
        "RsSNA14": (1.53, -1.48), "RsSNA17": (-3.22, 1.04),
        "RsLTP16": (-0.50, 1.77), "RsSNA10": (2.68, 1.58),
        "RsLTP3": (2.84, 0.94), "RsLTP17": (2.64, 2.41),
    },
    "S400_vs_CK": {
        "RsLTP15": (-0.92, 0.64), "RsLTP34": (1.69, 0.25),
        "RsLTP37": (-1.07, 0.04), "RsLTP25": (1.39, -0.68),
        "RsSNA3": (-1.66, -0.47), "RsLTP36": (-3.20, -1.48),
        "RsSNA14": (-1.22, -1.56), "RsSNA17": (-3.26, 1.24),
        "RsLTP16": (2.89, 1.81), "RsSNA10": (1.26, 1.41),
        "RsLTP3": (3.00, 0.82), "RsLTP17": (2.29, 2.46),
    },
}


def boolean(s):
    return s.astype(str).str.casefold().isin(["true", "yes", "1"])


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    args = parser.parse_args()
    df = pd.read_csv(args.source, sep="\t", keep_default_na=False)
    subset = df[boolean(df.strict_RBH_and_synteny)].copy()
    for col in ["rso_log2FC", "tchin_log2FC", "rso_padj", "tchin_padj"]:
        subset[col] = pd.to_numeric(subset[col], errors="coerce")
    subset["plotted_in_Figure_S3"] = np.isfinite(subset.rso_log2FC) & np.isfinite(subset.tchin_log2FC)
    subset["DE_both_species_for_plot"] = (
        (subset.rso_padj < 0.05) & (subset.tchin_padj < 0.05)
        & (subset.rso_log2FC.abs() > 1) & (subset.tchin_log2FC.abs() > 1)
    )
    subset["same_sign_for_plot"] = np.where(
        subset.plotted_in_Figure_S3,
        np.sign(subset.rso_log2FC).eq(np.sign(subset.tchin_log2FC)).astype(str),
        "NOT_AVAILABLE",
    )
    subset["display_label"] = subset.member_id + np.where(subset.member_id.eq("RsLTP17"), "†", "")
    subset["omission_reason"] = np.where(subset.plotted_in_Figure_S3, "PLOTTED", "TCHIN_ESTIMATE_UNAVAILABLE")
    subset["label_x"] = [LABELS.get(c, {}).get(m, (np.nan, np.nan))[0]
                           for c, m in zip(subset.rso_contrast, subset.member_id)]
    subset["label_y"] = [LABELS.get(c, {}).get(m, (np.nan, np.nan))[1]
                           for c, m in zip(subset.rso_contrast, subset.member_id)]
    assert len(subset) == 32
    assert subset[["member_id", "tchin_gene"]].drop_duplicates().shape[0] == 16
    subset.to_csv(OUT / "Figure_S3_eligible_pairs_source.tsv", sep="\t", index=False, na_rep="NA", encoding="utf-8-sig")
    plotted = subset[subset.plotted_in_Figure_S3].copy()
    plotted.to_csv(OUT / "Figure_S3_plotted_points.tsv", sep="\t", index=False, na_rep="NA", encoding="utf-8-sig")

    plt.rcParams.update({
        "font.family": ["Arial", "DejaVu Sans"], "font.size": 8, "axes.labelsize": 8,
        "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
        "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
        "axes.linewidth": 0.65, "savefig.facecolor": "white",
        "mathtext.fontset": "dejavusans", "axes.unicode_minus": True,
    })
    fig, axes = plt.subplots(1, 2, figsize=(180 / 25.4, 150 / 25.4), sharex=True, sharey=True)
    fig.subplots_adjust(left=0.115, right=0.983, bottom=0.355, top=0.887, wspace=0.16)
    stats, annotations = [], []
    for i, (ax, contrast, dose) in enumerate(zip(axes, ["S200_vs_CK", "S400_vs_CK"], [200, 400])):
        allrows = subset[subset.rso_contrast.eq(contrast)]
        d = allrows[allrows.plotted_in_Figure_S3]
        assert len(d) == 12
        assert d.both_tested_with_FDR.map(str).str.casefold().eq("true").all()
        n_both = int(d.DE_both_species_for_plot.sum())
        n_sign = int(np.sign(d.rso_log2FC).eq(np.sign(d.tchin_log2FC)).sum())
        assert n_both == [3, 4][i] and n_sign == [6, 9][i]
        ax.set_xlim(-4.5, 4.05)
        ax.set_ylim(-1.98, 2.86)
        ax.set_xticks([-4, -2, 0, 2, 4])
        ax.set_yticks([-1, 0, 1, 2])
        ax.axhline(0, color="#B5BDC4", lw=0.7, ls=(0, (3, 3)), zorder=0)
        ax.axvline(0, color="#B5BDC4", lw=0.7, ls=(0, (3, 3)), zorder=0)
        ax.spines[["top", "right"]].set_visible(False)
        ax.spines[["bottom", "left"]].set_color("#68737B")
        ax.tick_params(length=3, width=0.65, color="#68737B")
        ax.text(-0.03, 1.14, "ab"[i], transform=ax.transAxes,
                weight="bold", fontsize=11, va="bottom", ha="left")
        ax.set_title(f"{dose} mM Na₂SO₄ vs CK", fontsize=9, pad=23)
        ax.text(0.5, 1.026, "R. soongarica · tender leaves", transform=ax.transAxes,
                fontsize=7.5, color="#58636C", ha="center", va="bottom", style="italic")
        for row in d.itertuples():
            color = COLORS[row.family]
            both = row.DE_both_species_for_plot
            ax.scatter(row.rso_log2FC, row.tchin_log2FC,
                       marker=MARKERS[row.family], s=44 if both else 33,
                       linewidth=1.05, edgecolor=color,
                       facecolor=color if both else "white", zorder=4)
            t = ax.annotate(row.display_label,
                            xy=(row.rso_log2FC, row.tchin_log2FC),
                            xytext=(row.label_x, row.label_y),
                            ha="center", va="center", fontsize=7.1,
                            color="#202D36", weight="bold" if both else "normal",
                            arrowprops={"arrowstyle": "-", "color": "#8D989F", "lw": 0.55,
                                        "shrinkA": 2.8, "shrinkB": 4.2,
                                        "connectionstyle": "arc3,rad=0"},
                            zorder=5,
                            bbox={"facecolor": "white", "edgecolor": "none", "pad": 0.35})
            annotations.append(t)
        ax.text(0.5, -0.165, f"Both DE: {n_both}/12 pairs (all up)",
                transform=ax.transAxes, ha="center", fontsize=7.7, color="#26333B")
        ax.text(0.5, -0.225, f"Same sign across all plotted pairs: {n_sign}/12",
                transform=ax.transAxes, ha="center", fontsize=7.0, color="#59656D")
        stats.append({"contrast": contrast, "eligible_pairs": len(allrows), "plotted_pairs": len(d),
                      "unavailable_pairs": len(allrows) - len(d), "both_DE_pairs": n_both,
                      "both_DE_pair_labels": d.loc[d.DE_both_species_for_plot, "member_id"].tolist(),
                      "same_sign_all_plotted_pairs": n_sign})
    axes[0].set_ylabel("T. chinensis shoots | log₂ fold change\n300 mM NaCl vs matched control", labelpad=7)
    fig.text(0.555, 0.293, "R. soongarica tender leaves | log₂ fold change", ha="center", fontsize=8)
    handles = [
        Line2D([], [], color=COLORS["nsLTP"], marker="o", linestyle="None", markerfacecolor="white",
               markersize=5.8, label="nsLTP"),
        Line2D([], [], color=COLORS["Snakin_GASA"], marker="^", linestyle="None", markerfacecolor="white",
               markersize=6.3, label="Snakin/GASA"),
        Line2D([], [], color="#52616D", marker="o", linestyle="None", markerfacecolor="#52616D",
               markersize=5.8, label="DE in both species"),
        Line2D([], [], color="#52616D", marker="o", linestyle="None", markerfacecolor="white",
               markersize=5.8, label="Not DE in both species"),
    ]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.55, 0.140), frameon=False,
               ncol=2, handletextpad=0.5, columnspacing=1.8, labelspacing=0.65, fontsize=7.5)
    fig.text(0.55, 0.110, "Each panel: 16 eligible pairs · 12 plotted · 4 without T. chinensis estimates",
             ha="center", fontsize=7.3, color="#3E4B55")
    fig.text(0.55, 0.073, "Filled symbols: FDR < 0.05 and |log₂FC| > 1 in each species.",
             ha="center", fontsize=7.1, color="#58636C")
    fig.text(0.55, 0.035, "† RsLTP17 does not pass the additional reverse-coverage sensitivity filter.",
             ha="center", fontsize=7.0, color="#58636C")
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    boxes = [(a.get_text(), Text.get_window_extent(a, renderer)) for a in annotations]
    overlaps = []
    for k, (name_a, box_a) in enumerate(boxes):
        for name_b, box_b in boxes[k + 1:]:
            if box_a.overlaps(box_b):
                overlaps.append([name_a, name_b])
    for ext in ["pdf", "svg"]:
        fig.savefig(OUT / f"Figure_S3.{ext}")
    fig.savefig(OUT / "Figure_S3.png", dpi=600)
    fig.savefig(OUT / "Figure_S3_preview.png", dpi=180)
    plt.close(fig)

    english = """Figure S3. Directional comparison of salt-responsive expression among homolog candidates supported by reciprocal hits and synteny in R. soongarica and T. chinensis.

Panels a and b show R. soongarica tender-leaf responses to 200 and 400 mM Na₂SO₄, respectively, relative to CK. The vertical axis shows the same T. chinensis shoot response to 300 mM NaCl versus the matched control in both panels. T. chinensis plants received a 2-h pretreatment with 200 mM NaCl followed by 7 days at 300 mM NaCl. Each within-species comparison used three biological replicates per group. Fold changes were estimated within each species; the different salt treatments and tissues preclude interpreting relative cross-species response magnitudes. No regression, cross-species correlation test, or common-effect estimate is fitted.

The display subset comprises 16 unique Rso–Tchi candidate pairs with a reproduced reciprocal-best-hit relationship, a unique highest-bit-score target in each direction among retained BLAST outputs, at least 50% coordinate coverage of both proteins in the forward Rso-to-Tchi high-scoring segment pair (HSP), and an existing interspecies MCScanX anchor. Twelve pairs have finite expression estimates and adjusted P values in both species and are plotted in each panel. The same four pairs (RsLTP13–TC02G2374, RsLTP31–TC05G1434, RsLTP40–TC03G0075 and RsSNA8–TC09G0140) lack T. chinensis expression estimates and are omitted rather than assigned zero or classed as nonsignificant. The homolog search used the historical 63-member Rso query subset, not the full current 73-member primary catalogue; this figure does not establish exhaustive family coverage or one-to-one orthology.

Blue circles denote nsLTP candidates and green triangles denote Snakin/GASA candidates. Filled symbols indicate adjusted P < 0.05 and |log₂ fold change| > 1 in both species; open symbols indicate that both-species DE criterion is not met. Labels give Rso member names, and thin guide lines link labels to points. Three pairs (RsLTP3–TC01G0837, RsLTP17–TC12G1360 and RsSNA10–TC12G1896) meet both-species DE criteria in panel a; those three plus RsLTP16–TC12G1359 meet them in panel b. All seven qualifying comparison rows, representing four unique pairs, are upregulated in both species. Across all 12 plotted pairs, including those not DE in both species, fold-change signs agree for 6 pairs in panel a and 9 pairs in panel b. The two panels reuse the same T. chinensis contrast and are not independent replication of a cross-species effect.

† RsLTP17 passes the stated main forward-coverage rule, but its reverse HSP spans only 44.5% of the T. chinensis query and 45.5% of the Rso target. Requiring at least 50% coverage of both proteins in both search directions excludes this pair (and RsLTP34), leaving 14 pairs with synteny support, 10 plotted pairs per contrast, and two/three both-species DE pairs in panels a/b, respectively. Thus the RsLTP17 correspondence remains sensitive to the coverage definition. These results provide comparative expression context and candidate correspondence rather than functional validation.
"""
    chinese = """图 S3. 红砂与中华柽柳中获互为最佳命中及共线性支持的同源候选对，其盐处理表达变化方向比较。

a、b 分别显示红砂嫩叶在 200、400 mM Na₂SO₄ 处理相对 CK 的表达变化。两幅图的纵轴均为中华柽柳地上部在 300 mM NaCl 处理相对同期对照的同一表达比较。中华柽柳先接受 200 mM NaCl 预处理 2 h，再接受 300 mM NaCl 处理 7 d。各物种的每个处理组和对照组均有 3 个生物学重复。各物种的倍数变化分别估计；组织和盐处理不一致，因此不能用横纵坐标的大小比较两个物种响应强弱。图中不拟合回归、跨物种相关检验或共同效应量。

展示集合包含 16 个唯一候选配对：原始结果可复现互为最佳命中、在已保留的 BLAST 输出中两个方向均只有一个最高 bit score 对象、红砂至中华柽柳正向高分片段（HSP）对两侧蛋白的坐标覆盖率均不低于 50%，且有已有 MCScanX 跨物种共线性锚定支持。每个面板中，12 对在两个物种均具有有限的表达估计和校正 P 值，可用于绘图。同样的 4 对——RsLTP13–TC02G2374、RsLTP31–TC05G1434、RsLTP40–TC03G0075、RsSNA8–TC09G0140——缺少中华柽柳表达估计，故不画点；不将其补零或归为不显著。该检索使用历史 63 成员红砂查询子集，而非当前 73 成员主目录全体，因此本图不构成家族全覆盖或一对一直系同源关系的证明。

蓝色圆形表示 nsLTP 候选，绿色三角形表示 Snakin/GASA 候选。实心点表示两侧均满足校正 P < 0.05 且 |log₂FC| > 1；空心点表示未同时满足两侧差异表达条件。标签为红砂成员名称，细引导线连接标签与对应点。a 中，RsLTP3–TC01G0837、RsLTP17–TC12G1360、RsSNA10–TC12G1896 共 3 对达到两侧 DE；b 中这 3 对加上 RsLTP16–TC12G1359，共 4 对达到两侧 DE。合计 7 条比较行、4 个唯一配对均为两侧上调。对于每个面板全部 12 个可绘制配对（包含未达到两侧 DE 的配对），a 中 6 对、b 中 9 对符号一致。两幅图复用同一中华柽柳比较，不能算作跨物种效应的独立重复。

† RsLTP17 满足主分析采用的正向覆盖规则，但反向 HSP 仅覆盖中华柽柳查询蛋白的 44.5% 和红砂目标蛋白的 45.5%。若进一步要求两个检索方向对两侧蛋白的覆盖均达到 50%，将排除该配对及 RsLTP34；届时获共线性支持的配对为 14 对，每个面板可绘制 10 对，a/b 的两侧 DE 分别为 2/3 对。因此，RsLTP17 的配对对覆盖判定方式敏感。本结果提供跨物种表达背景和候选对应关系，不等于功能验证。
"""
    (OUT / "Figure_S3_legend_EN.txt").write_text(english, encoding="utf-8")
    (OUT / "Figure_S3_legend_ZH.txt").write_text(chinese, encoding="utf-8")
    qc = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source": str(args.source.resolve()), "source_sha256": sha(args.source),
        "matplotlib_version": matplotlib.__version__, "pandas_version": pd.__version__,
        "figure_mm": [180, 150], "png_dpi": 600,
        "statistics": stats, "text_label_overlap_pairs": overlaps,
        "all_points_labelled": True, "missing_values_imputed": False,
        "new_sequence_analysis_performed": False,
        "main_rule": "unique reciprocal top bit-score target; forward HSP coordinate coverage >=50% of both proteins; MCScanX anchor",
        "coverage_sensitivity_note": "RsLTP17 and RsLTP34 are excluded by requiring >=50% of both proteins in both directions",
    }
    import fitz
    from PIL import Image
    pdf = fitz.open(OUT / "Figure_S3.pdf")
    png = Image.open(OUT / "Figure_S3.png")
    qc.update({
        "pdf_pages": len(pdf),
        "pdf_page_mm": [round(v * 25.4 / 72, 3) for v in (pdf[0].rect.width, pdf[0].rect.height)],
        "pdf_embedded_fonts": [{"name": f[3], "type": f[2], "extension": f[1],
                                "embedded_bytes": len(pdf.extract_font(f[0])[3])}
                               for f in pdf[0].get_fonts()],
        "png_pixels": png.size, "png_dpi_metadata": png.info.get("dpi"),
    })
    pdf[0].get_pixmap(matrix=fitz.Matrix(1.7, 1.7)).save(OUT / "Figure_S3_PDF_render_check.png")
    pdf.close()
    png.close()
    (OUT / "Figure_S3_QC.json").write_text(json.dumps(qc, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(qc, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
