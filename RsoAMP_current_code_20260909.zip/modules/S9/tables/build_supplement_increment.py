"""Append audited S47-S50 to a stage copy; never install or edit the formal source."""
from pathlib import Path
from collections import Counter
from copy import copy
import csv, json, hashlib, math, re, zipfile, posixpath
from xml.etree import ElementTree as ET
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

T = Path(__file__).resolve().parent
R = T.parent.parent
W = R.parent
A = R/'02_核查与汇总/independent_table_audit'
J = W/'跨物种表达_实施_20260909'
F = W/'Genes_lab_handoff_20260908/01_Current_Editing/03_Supplementary/Genes_RsoAMP_Supplementary_Tables_expression_status_20260904.xlsx'
D = R/'stage/03_Supplementary'/F.name
D.parent.mkdir(parents=True,exist_ok=True)

def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def istrue(v):return v is True or v=='True' or v=='TRUE'
def num(v):
    try:
        x=float(v)
        return x if math.isfinite(x) else None
    except (ValueError,TypeError):return None
def equal_num(x,y):
    a,b=num(x),num(y)
    return (a is None and b is None) or (a is not None and b is not None and math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-12))
def write(name,rows):
    with (T/(name+'.tsv')).open('w',encoding='utf-8-sig',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');wr.writeheader();wr.writerows(rows)

catalogue=[x for x in read(W/'成员判定收尾_20260909/统一目录/统一成员目录_主分析111.tsv') if x['species']=='rso']
assert len(catalogue)==73
byid={x['member_id']:x for x in catalogue}
evidence=read(A/'pairing_evidence_audit.tsv')
ev={x['member_id']:x for x in evidence}
paired=read(A/'paired_expression_restored_status.tsv')
pairedmap={(x['member_id'],x['rso_contrast']):x for x in paired}
rso={(x['member_id'],x['contrast']):x for x in read(J/'rso_inputs/Rso_primary66_existing_DE.tsv')}
scope=[]
for c in catalogue:
    m=c['member_id'];p=ev.get(m);inref=(m,'S200_vs_CK') in rso
    if p:status='QUERIED_HISTORICAL63';reason='Included in the supplied v2 historical 63-member search cohort.'
    elif inref:status='NOT_QUERIED_RESTORED_ANNOTATED';reason='Restored primary member with existing original-reference expression; not included in this 63-query search.'
    else:status='NOT_QUERIED_NEW_RECONSTRUCTED_MODEL';reason='New reconstructed primary model; absent from this search cohort and original quantification reference.'
    scope.append(dict(member_id=m,current_primary_catalogue='Rso73_20260909',family=c['family'],rso_combined_id=c['id'],rso_protein_id=c['protein_id'],rso_gene_id=c['original_gene_parent'] or c['source_gene_feature_ID'],source_model_id=c['source_model_id'],source_candidate_id=c['source_candidate_id'],in_current_primary=True,queried_in_supplied_v2=bool(p),query_scope_status=status,scope_reason=reason,rso_original_quant_reference='PRESENT' if inref else 'NOT_IN_QUANT_REFERENCE',rso_DE_source_availability='EXISTING_GENOME_WIDE_DE_FITS' if inref else 'NOT_IN_QUANT_REFERENCE',tchin_best_hit_status=('ASSIGNED_BEST_HIT' if p['tchin_gene'] else 'NO_HIT_IN_SUPPLIED_OUTPUT') if p else 'NOT_QUERIED',tchin_gene=p['tchin_gene'] if p and p['tchin_gene'] else 'NA',supplied_RBH=p['reciprocal'] if p else 'NOT_QUERIED',synteny_supported=p['synteny_supported'] if p else 'NOT_ASSESSED_IN_THIS_COHORT',main_sequence_rule=istrue(p['strict_existing_RBH']) if p else False,main_RBH_synteny_subset=istrue(p['strict_RBH_and_synteny']) if p else False,fourway_RBH_synteny_sensitivity=istrue(p['fourway_RBH_and_synteny']) if p else False,protein_sha256=c['protein_sha256'],catalogue_source='S30_UnifiedPrimary; unified primary catalogue 20260909',pairing_source='File S9 supplied v2 tables/rso_tchin_pairing.tsv',expression_source='Rso_primary66_existing_DE.tsv' if inref else 'No original-reference DE result'))
sc={x['member_id']:x for x in scope}
assert Counter(x['query_scope_status'] for x in scope)==Counter(QUERIED_HISTORICAL63=63,NOT_QUERIED_RESTORED_ANNOTATED=3,NOT_QUERIED_NEW_RECONSTRUCTED_MODEL=7)

S48=[]
for e in evidence:
    c=sc[e['member_id']]
    assert e['rso_protein_id']==c['rso_protein_id']
    a=dict(e)
    a.update(current_primary_catalogue='Rso73_20260909',query_scope_status=c['query_scope_status'],provided_assignment_status='ASSIGNED_BEST_HIT' if e['tchin_gene'] else 'NO_HIT_IN_SUPPLIED_OUTPUT',unique_best_scope='Unique highest bit score among retained opposite-species BLAST output; recovered invocation specifies forward/reverse max_target_seqs 20/5',main_sequence_rule_definition='Unique reciprocal highest-bit matches in retained output; inclusive forward HSP coordinate coverage >=0.5 on each protein',main_writing_subset_definition='Main sequence rule AND supplied cross-species collinear support',fourway_sensitivity_definition='Main sequence rule plus >=0.5 coordinate coverage on both proteins in the reverse HSP; synteny retained separately',evidence_source='File S9 supplied v2 BLAST outputs and mcscanx_official/rso_tch.collinearity')
    S48.append(a)

S49=[]
new_columns=['current_primary_catalogue','query_scope_status','pair_assignment_status','row_scope_note','rso_baseMean','rso_pvalue','rso_log2FC_apeglm','rso_original_quant_reference','rso_source','tchin_source','pairing_evidence_source']
for c in catalogue:
    m=c['member_id'];ss=sc[m]
    for contrast in ['S200_vs_CK','S400_vs_CK']:
        key=(m,contrast);rr=rso.get(key)
        if key in pairedmap:
            a=dict(pairedmap[key])
            assignment='ASSIGNED_BEST_HIT'
            note='Existing supplied v2 pairing; original expression values retained and untested DE states restored as NA.'
        else:
            assignment='NO_HIT_IN_SUPPLIED_OUTPUT' if m in ev else 'NOT_QUERIED'
            note='This query had no retained BLAST hit; no cross-species expression pairing is available.' if m in ev else ss['scope_reason']
            a={k:'NA' for k in paired[0]}
            a.update(member_id=m,family=c['family'],rso_protein_id=c['protein_id'],rso_gene_id=ss['rso_gene_id'],tchin_gene='NA',pair_tier=assignment,pident='NA',rso_contrast=contrast,rso_quant_status='QUANTIFIED' if rr else 'NOT_IN_QUANT_REFERENCE',rso_log2FC=rr['log2FoldChange'] if rr else 'NA',rso_padj=rr['padj'] if rr else 'NA',rso_DE=rr['DE_call'] if rr and rr['DE_call'] in ['TRUE','FALSE'] else 'NA',tchin_prefilter_pass='NA',tchin_log2FC='NA',tchin_padj='NA',tchin_DE='NA',same_direction='NA',both_DE_same_direction='NA',rso_prefilter_status=rr['prefilter_status'] if rr else 'NOT_IN_QUANT_REFERENCE',rso_DE_test_status=rr['DE_test_status'] if rr else 'NOT_IN_QUANT_REFERENCE',tchin_inference_status='NO_COUNTERPART_ASSIGNED',supplied_RBH='NO_HIT' if m in ev else 'NOT_QUERIED',synteny_supported='NOT_ASSESSED_WITHOUT_ASSIGNED_COUNTERPART',strict_existing_RBH=False,strict_RBH_and_synteny=False,fourway_RBH=False,fourway_RBH_and_synteny=False,both_signed_estimates=False,both_tested_with_FDR=False)
        a.update(current_primary_catalogue='Rso73_20260909',query_scope_status=ss['query_scope_status'],pair_assignment_status=assignment,row_scope_note=note,rso_baseMean=rr['baseMean'] if rr else 'NA',rso_pvalue=rr['pvalue'] if rr else 'NA',rso_log2FC_apeglm=rr['log2FC_apeglm'] if rr else 'NA',rso_original_quant_reference=ss['rso_original_quant_reference'],rso_source='Unchanged frozen genome-wide DE fits: Rso_primary66_existing_DE.tsv' if rr else 'NOT_IN_QUANT_REFERENCE',tchin_source='Tchinensis_all_gene_DE_results.tsv; six-library Salt_vs_CK DESeq2 fit' if assignment=='ASSIGNED_BEST_HIT' else 'NO_COUNTERPART_ASSIGNED',pairing_evidence_source='S48_TchiPairEvidence; supplied v2 outputs' if m in ev else 'NOT_QUERIED_IN_SUPPLIED_V2')
        if rr:
            assert equal_num(a['rso_log2FC'],rr['log2FoldChange']) and equal_num(a['rso_padj'],rr['padj'])
        S49.append(a)
assert len(S49)==146 and len({(x['member_id'],x['rso_contrast']) for x in S49})==146
assert sum(x['pair_assignment_status']=='ASSIGNED_BEST_HIT' for x in S49)==98
assert sum(x['pair_assignment_status']=='NO_HIT_IN_SUPPLIED_OUTPUT' for x in S49)==28
assert sum(x['pair_assignment_status']=='NOT_QUERIED' for x in S49)==20
assert sum(istrue(x['strict_RBH_and_synteny']) for x in S49)==32
assert sum(istrue(x['strict_RBH_and_synteny']) and istrue(x['both_tested_with_FDR']) for x in S49)==24
assert sum(x['rso_original_quant_reference']=='NOT_IN_QUANT_REFERENCE' for x in S49)==14
for row in S49:
    if row['rso_original_quant_reference']=='NOT_IN_QUANT_REFERENCE':
        assert row['rso_log2FC']==row['rso_padj']==row['rso_DE']=='NA'

S50=[]
for s in read(A/'stratified_expression_counts.tsv'):
    a=dict(s)
    a.update(comparison_row_unit='One Rso member-target pair x one Rso contrast; the same Tchin Salt_vs_CK contrast is reused',unique_pair_unit='Distinct Rso member_id + Tchin gene_id within the named subset; not independent experiments',both_tested_definition='Finite adjusted P values are available in both species; not equivalent to both DE',both_signed_definition='Both log2FC estimates are finite and nonzero; excludes missing estimates',both_DE_definition='Within-species adjusted P <0.05 and absolute unshrunken log2FC >1 in both species',same_direction_denominator='Use both_signed_rows for overall directional agreement, or both_DE_rows only for conditional double-DE agreement',main_writing_subset=s['subset'].startswith('Strict_unique_RBH_50pct_and_synteny'),sensitivity_subset=s['subset'].startswith('Sensitivity_fourway'),repeated_contrast_caution='S200 and S400 reuse the same Tchin contrast; pooled rows are not independent cross-species replications',scope='Supplied historical 63-query cohort; omitted current members and no-hit rows do not enter paired denominators')
    S50.append(a)

tables={'S47_TchiPairScope':scope,'S48_TchiPairEvidence':S48,'S49_TchiPairedExpression':S49,'S50_TchiPairSummary':S50}
for k,rows in tables.items():write(k,rows)

source_hash=sha(F)
book=openpyxl.load_workbook(F)
old_sheet_names=list(book.sheetnames)
assert not any(k in book for k in tables)
header_style=copy(book['S46_StructureFeatures'].cell(1,1)._style)
base_style=copy(book['S46_StructureFeatures'].cell(2,1)._style)
float_columns={'pident','evalue','bitscore','reverse_pident','forward_identity_unrounded','reverse_identity_unrounded','forward_query_coverage','forward_target_coverage','reverse_query_coverage','reverse_target_coverage','rso_log2FC','rso_padj','tchin_log2FC','tchin_padj','rso_baseMean','rso_pvalue','rso_log2FC_apeglm'}
int_columns={'query_length','target_length','forward_target_count','reverse_target_count','forward_qstart','forward_qend','forward_sstart','forward_send','reverse_qstart','reverse_qend','reverse_sstart','reverse_send','comparison_rows','unique_member_gene_pairs','unique_Tchin_genes','both_tested_rows','both_signed_rows','same_direction_signed_rows','both_DE_rows','both_DE_unique_pairs','both_DE_unique_Tchin_genes','both_DE_same_direction_rows','both_DE_opposite_rows'}
boolean_columns={'in_current_primary','queried_in_supplied_v2','main_sequence_rule','main_RBH_synteny_subset','fourway_RBH_synteny_sensitivity','forward_unique_top_bits','reverse_unique_top_bits','raw_RBH_reproduced','four_way_coordinate_coverage_ge50','forward_coordinate_coverage_ge50','strict_existing_RBH','strict_RBH_and_synteny','fourway_RBH','fourway_RBH_and_synteny','both_signed_estimates','both_tested_with_FDR','main_writing_subset','sensitivity_subset'}
insert_at=book.sheetnames.index('S46_StructureFeatures')+1
for offset,(name,rows) in enumerate(tables.items()):
    ws=book.create_sheet(name,insert_at+offset)
    headers=list(rows[0]);ws.append(headers)
    for cell in ws[1]:cell._style=copy(header_style);cell.alignment=Alignment(wrap_text=True,vertical='center')
    for rr in rows:
        values=[]
        for k in headers:
            v=rr[k]
            if k in boolean_columns:v=istrue(v)
            elif k in float_columns and num(v) is not None:v=float(v)
            elif k in int_columns and num(v) is not None:v=int(v)
            values.append(v)
        ws.append(values)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell._style=copy(base_style)
            cell.alignment=Alignment(vertical='top',wrap_text=True)
    for i,k in enumerate(headers,1):
        ws.column_dimensions[get_column_letter(i)].width=55 if any(t in k for t in ['definition','note','source','scope','caution','reason','denominator']) else (26 if len(k)>20 else 20)
    ws.row_dimensions[1].height=55
    ws.freeze_panes='C2';ws.auto_filter.ref=ws.dimensions
    ws.sheet_view.zoomScale=80
    ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_setup.orientation='landscape';ws.page_setup.paperSize=ws.PAPERSIZE_A3;ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0
    ws.print_title_rows='1:1'

rd=book['README']
for row in rd.iter_rows():
    if row[0].value=='public_scope':row[1].value='File S8 retains the current catalogue/figure update; File S9 adds audited T. chinensis paired-expression evidence. Both are separate from the earlier public GitHub snapshot.'
notes=[
('S47_TchiPairScope','73 current Rso primary members. Supplied v2 queried historical63; three restored annotated members have existing Rso DE but were not queried; seven reconstructed models were neither queried nor present in the original quantification reference.'),
('S48_TchiPairEvidence','63 queried members:49 supplied best-hit assignments and14 no-hit records. Both-direction retained highest-bit evidence, inclusive HSP coordinate coverages, main and four-direction sensitivity flags are explicit. No alternative pairs were inferred.'),
('S49_TchiPairedExpression','146 rows=current73 members x S200/S400.98 paired rows,28 no-hit rows,20 not-queried rows. Existing Rso values are retained for66 reference members;14 new-model contrast rows are NOT_IN_QUANT_REFERENCE with numerical NA. Untested is not non-significant.'),
('S50_TchiPairSummary','24 strata including per-contrast rows, exact unique-pair and comparison-row denominators, raw assignments,20 sequence-filtered reciprocal pairs,16 main reciprocal+synteny pairs,18/14 four-direction sensitivity sets. Main paired-response result is7 double-DE rows/4 pairs; sensitivity5 rows/3 pairs.'),
('Tchi_reference_scope','Official CDS-derived representatives cover26,426 genes from46,080 retained transcripts. The original self-parent orphan transcript is excluded. Reference QC is in File S9; S47 is a73-member Rso scope table, not the entire Tchi proteome.'),
('Tchi_main_pair_rule','Unique reciprocal highest-bit matches among retained opposite-species BLAST outputs, forward highest-bit HSP coordinate coverage>=50% on each protein, and MCScanX collinearity.20 sequence-rule pairs;16 also collinear. Tchi targets are not a uniformly curated family census.'),
('Tchi_coverage_sensitivity','Requiring >=50% coverage on both proteins also in the reverse HSP removes RsLTP17 and RsLTP34:18 sequence pairs and14 collinear pairs. RsLTP17 is retained under the primary forward-coverage rule but explicitly sensitive to this stricter criterion.'),
('Tchi_missingness_and_units','Recover original NA DE calls; no hit/not queried/not in quantification reference are separate states. Two Rso contrasts reuse one Tchi contrast; comparison rows are not independent cross-species replicates. Directional agreement in the double-DE subset is not overall agreement or functional conservation.'),
('Tchi_study_boundary','Rso leaf Na2SO4 responses and Tchi shoot NaCl responses are heterogeneous published designs. These analyses do not provide independent Rso qRT-PCR validation, experimental antimicrobial function, or causal salt-tolerance proof.'),
]
for k,v in notes:
    rd.append([k,v])
    for cell in rd[rd.max_row]:cell._style=copy(rd.cell(2,cell.column)._style);cell.alignment=Alignment(wrap_text=True,vertical='top')
book.save(D)
assert sha(F)==source_hash

# openpyxl serializes floats to 16 significant digits; preserve literal numeric
# cell XML in every old scientific/history sheet before comparing exact values.
# This changes only the staged archive and avoids rounding a pre-existing QC cell.
ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def sheet_parts(z):
    rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    targets={x.attrib['Id']:x.attrib['Target'] for x in rel}
    out={}
    for x in ET.fromstring(z.read('xl/workbook.xml')).find('s:sheets',ns):
        target=targets[x.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']]
        out[x.attrib['name']]=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join('xl',target))
    return out
cell_re=re.compile(r'<c\b[^>]*\br="([^"]+)"[^>]*>.*?</c>',re.S)
patches={};literal_restorations=0
with zipfile.ZipFile(F) as za,zipfile.ZipFile(D) as zb:
    sa,sb=sheet_parts(za),sheet_parts(zb)
    for name in old_sheet_names:
        if name=='README':continue
        old_xml=za.read(sa[name]).decode('utf8');new_xml=zb.read(sb[name]).decode('utf8')
        numeric={}
        for mm in cell_re.finditer(old_xml):
            cell=mm.group(0);head=cell.split('>',1)[0]
            if (' t=' not in head or 't="n"' in head) and re.search(r'<v>[-+0-9.eE]+</v>',cell):numeric[mm.group(1)]=cell
        def restore(mm):
            global literal_restorations
            old=numeric.get(mm.group(1))
            if old is not None and old!=mm.group(0):
                literal_restorations+=1
                return old
            return mm.group(0)
        updated=cell_re.sub(restore,new_xml)
        if updated!=new_xml:patches[sb[name]]=updated.encode('utf8')
    staged_entries=[(x,zb.read(x.filename)) for x in zb.infolist()]
if patches:
    tmp=D.with_suffix('.numeric-preserved.xlsx')
    with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED) as zz:
        for info,data in staged_entries:zz.writestr(info,patches.get(info.filename,data))
    tmp.replace(D)

# Reopen both files and compare every pre-existing scientific/history cell.
source=openpyxl.load_workbook(F)
stage=openpyxl.load_workbook(D)
value_mismatches=[];style_mismatches=[];shape_mismatches=[];compared=0
for name in old_sheet_names:
    if name=='README':continue
    x,y=source[name],stage[name]
    if (x.max_row,x.max_column)!=(y.max_row,y.max_column):shape_mismatches.append(name)
    for row in x:
        for old in row:
            new=y.cell(old.row,old.column);compared+=1
            if old.value!=new.value or old.data_type!=new.data_type:value_mismatches.append((name,old.coordinate))
            if old._style!=new._style:style_mismatches.append((name,old.coordinate))
if value_mismatches or style_mismatches or shape_mismatches:
    print(json.dumps(dict(value_mismatch_count=len(value_mismatches),style_mismatch_count=len(style_mismatches),shape_mismatches=shape_mismatches,value_examples=[dict(sheet=n,cell=c,old=source[n][c].value,new=stage[n][c].value,old_type=source[n][c].data_type,new_type=stage[n][c].data_type) for n,c in value_mismatches[:12]],style_examples=style_mismatches[:12]),ensure_ascii=False,indent=2))
assert not value_mismatches and not style_mismatches and not shape_mismatches
assert set(stage.sheetnames)-set(source.sheetnames)==set(tables)
check_rows=list(stage['S49_TchiPairedExpression'].values)
checks=[dict(zip(check_rows[0],r)) for r in check_rows[1:]]
assert len(checks)==146 and len({(x['member_id'],x['rso_contrast']) for x in checks})==146
assert sum(x['strict_RBH_and_synteny'] is True for x in checks)==32
assert sum(x['strict_RBH_and_synteny'] is True and x['both_tested_with_FDR'] is True for x in checks)==24
validation=dict(source=str(F),source_sha256=source_hash,staged_workbook=str(D),staged_sha256=sha(D),source_unchanged=sha(F)==source_hash,old_scientific_and_history_sheets_checked=len(old_sheet_names)-1,old_cells_compared=compared,old_numeric_XML_literals_preserved=literal_restorations,old_value_and_type_mismatches=value_mismatches,old_style_mismatches=style_mismatches,old_shape_mismatches=shape_mismatches,new_tables={k:len(v) for k,v in tables.items()},S49_unique_member_contrast_keys=146,S49_paired_rows=98,S49_no_hit_rows=28,S49_not_queried_rows=20,S49_main_subset_rows=32,S49_main_both_FDR_available_rows=24,S49_NOT_IN_QUANT_REFERENCE_rows=14,installed_formal_files=False)
(T/'supplement_increment_validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf8')
manifest=[dict(table=name,rows=len(rows),columns=len(rows[0]),file=name+'.tsv',bytes=(T/(name+'.tsv')).stat().st_size,sha256=sha(T/(name+'.tsv'))) for name,rows in tables.items()]
write('TABLE_MANIFEST',manifest)
print(json.dumps(validation,ensure_ascii=False,indent=2))
