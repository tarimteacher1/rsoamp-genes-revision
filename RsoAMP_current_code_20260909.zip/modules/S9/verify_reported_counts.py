"""Verify this submission snapshot and recount existing expression rows; no sequence analysis."""
from pathlib import Path
import csv, hashlib, json, math

ROOT=Path(__file__).resolve().parent
def truth(x): return str(x).lower() in {'true','yes','1'}
def number(x):
    try: return float(x)
    except (ValueError,TypeError): return float('nan')
def main():
    manifest=ROOT/'CHECKSUMS_SHA256.tsv'
    if manifest.exists():
        with manifest.open(encoding='utf-8-sig',newline='') as f:
            for row in csv.DictReader(f,delimiter='\t'):
                p=ROOT/row['relative_path']
                assert p.stat().st_size==int(row['bytes']),row['relative_path']
                assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['relative_path']
    with (ROOT/'tables/paired_expression_restored_status.tsv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f,delimiter='\t'))
    provenance=json.loads((ROOT/'reference_audit/REFERENCE_AND_SOFTWARE_PROVENANCE.json').read_text(encoding='utf8'))
    scope=provenance['retained_BLAST_output_scope']
    assert scope['full_original_invocation_available'] is True
    assert scope['max_target_seqs_setting_verified'] is True
    assert (scope['configured_max_target_seqs_forward'],scope['configured_max_target_seqs_reverse'])==(20,5)
    assert scope['historical_call_exit_codes']==[0,0]
    evidence=json.loads((ROOT/'reference_audit/PUBLIC_EXECUTION_PROVENANCE_RECOVERED_20260909.json').read_text(encoding='utf8'))
    calls={x['source_line']:x for x in evidence['historical_calls']}
    assert '-max_target_seqs 20' in calls[224]['command'] and calls[224]['result']['exit_code']==0
    assert '-max_target_seqs 5' in calls[226]['command'] and calls[226]['result']['exit_code']==0
    assert 'completed with exit code 0' in evidence['MCScanX_completion_notice']['content']
    results=[]
    for contrast,expected_de,expected_same in [('S200_vs_CK',3,6),('S400_vs_CK',4,9)]:
        eligible=[r for r in rows if r['rso_contrast']==contrast and truth(r['strict_RBH_and_synteny'])]
        usable=[r for r in eligible if all(math.isfinite(number(r[c])) for c in ['rso_log2FC','tchin_log2FC','rso_padj','tchin_padj'])]
        both=[r for r in usable if truth(r['rso_DE']) and truth(r['tchin_DE'])]
        same=[r for r in usable if number(r['rso_log2FC'])*number(r['tchin_log2FC'])>0]
        assert (len(eligible),len(usable),len(both),len(same))==(16,12,expected_de,expected_same)
        results.append({'contrast':contrast,'eligible':16,'usable':12,'both_DE':len(both),'same_sign':len(same)})
    print(json.dumps({'verification':'PASS','comparison_counts':results},indent=2))
if __name__=='__main__':main()
