"""Read-only audit of supplied v2 outputs; no searches or new alignments.

Retains supplied member-to-target assignments and evaluates their existing HSP
coordinates and tied highest bit scores. Never creates alternative pairs.
"""
from pathlib import Path
from collections import defaultdict, Counter
import csv, json, math, re, hashlib

O = Path(__file__).resolve().parent
B = O.parent.parent
S = B / '01_原始结果快照'
W = B.parent
J = W / '跨物种表达_实施_20260909'

def read(p):
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f, delimiter='\t'))

def write(name, rows):
    if not rows: return
    with (O/name).open('w', encoding='utf-8-sig', newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)

def fasta(p):
    seq={};key=None;chunks=[]
    for l in p.read_text().splitlines():
        if l.startswith('>'):
            if key is not None: seq[key]=''.join(chunks)
            key=l[1:].split()[0];chunks=[]
        else: chunks.append(l.strip())
    if key is not None: seq[key]=''.join(chunks)
    return seq

def num(x):
    try:
        f=float(x)
        return f if math.isfinite(f) else None
    except (ValueError,TypeError):return None

def equal_num(a,b):
    x,y=num(a),num(b)
    return (x is None and y is None) or (x is not None and y is not None and math.isclose(x,y,rel_tol=1e-10,abs_tol=1e-12))

def blast(p):
    out=defaultdict(list)
    for l in p.read_text().splitlines():
        q,s,pi,al,mi,ga,qs,qe,ss,se,ev,bs=l.split('\t')
        out[q].append(dict(q=q,s=s,pident=float(pi),length=int(al),qs=int(qs),qe=int(qe),ss=int(ss),se=int(se),evalue=float(ev),bits=float(bs)))
    return out

def best_by_subject(hits):
    groups=defaultdict(list)
    for h in hits:groups[h['s']].append(h)
    # Highest-bit HSP per subject, not concatenated disjoint HSP coverage.
    return {s:min(v,key=lambda x:(-x['bits'],x['evalue'])) for s,v in groups.items()}

def top_bits(hits):
    d=best_by_subject(hits)
    m=max((h['bits'] for h in d.values()),default=None)
    return [h for h in d.values() if h['bits']==m]

cat=read(S/'tables/rso_primary_catalogue.tsv')
ps=read(S/'tables/rso_tchin_pairing.tsv')
official=read(S/'tables/rso_tchin_pairing_official.tsv')
assert len(ps)==len(official)==63
assert all(all(p[k]==o[k] for k in o) for p,o in zip(ps,official))
supplied_expr=read(S/'tables/paired_expression_official.tsv')
canonical_expr=read(S/'tables/paired_expression.tsv')
assert supplied_expr==canonical_expr
rso={(r['member_id'],r['contrast']):r for r in read(J/'rso_inputs/Rso_primary66_existing_DE.tsv')}
tch={r['gene_id']:r for r in read(J/'compute/verified_results/de_results/Tchinensis_all_gene_DE_results.tsv')}
qseq=fasta(S/'ref/rso_primary63_queries.faa')
tseq=fasta(S/'ref/Tchinensis.official_per_gene.faa')
qlens={k:len(v) for k,v in qseq.items()}
tlens={k:len(v) for k,v in tseq.items()}
full=fasta(S/'mcscanx_official/rso_tch.faa')
rlens={k.removeprefix('RSO__'):len(v) for k,v in full.items() if k.startswith('RSO__')}
reverse_queries=fasta(S/'blast/tchin_official_reverse_queries.faa')
assert all(qseq[x['member_id']]==full['RSO__'+x['protein_id']] for x in cat)
assert all(seq==tseq[k] for k,seq in reverse_queries.items())
fwd=blast(S/'blast/rso63_vs_tchin_official.tsv')
rev=blast(S/'blast/tchin_official_vs_rso.tsv')
audit=[]
for p in ps:
    q,t=p['member_id'],p['tchin_gene'];pid=p['rso_protein_id']
    a=dict(p)
    a.update(query_length=qlens[q],target_length=tlens.get(t,''),forward_target_count=len(best_by_subject(fwd[q])),reverse_target_count=len(best_by_subject(rev[t])),forward_top_bit_targets='',reverse_top_bit_targets='',forward_unique_top_bits=False,reverse_unique_top_bits=False,raw_RBH_reproduced=False,forward_qstart='',forward_qend='',forward_sstart='',forward_send='',reverse_qstart='',reverse_qend='',reverse_sstart='',reverse_send='',forward_identity_unrounded='',reverse_identity_unrounded='',forward_query_coverage='',forward_target_coverage='',reverse_query_coverage='',reverse_target_coverage='',four_way_coordinate_coverage_ge50=False,forward_coordinate_coverage_ge50=False,strict_existing_RBH=False,strict_RBH_and_synteny=False,fourway_RBH=False,fourway_RBH_and_synteny=False,strict_exclusion_reason='NO_HIT' if not t else '')
    if t:
        fs=best_by_subject(fwd[q]);rs=best_by_subject(rev[t])
        ftop=top_bits(fwd[q]);rtop=top_bits(rev[t]);h=fs[t];rh=rs.get(pid)
        raw_f=min(fwd[q],key=lambda x:(x['evalue'],-x['bits']))
        raw_r=min(rev[t],key=lambda x:(x['evalue'],-x['bits'])) if rev[t] else None
        assert raw_f['s']==t
        raw_recip=bool(raw_r and raw_r['s']==pid)
        assert raw_recip==(p['reciprocal']=='YES')
        a['raw_RBH_reproduced']=raw_recip
        a['forward_top_bit_targets']=';'.join(x['s'] for x in ftop)
        a['reverse_top_bit_targets']=';'.join(x['s'] for x in rtop)
        a['forward_unique_top_bits']=len(ftop)==1 and ftop[0]['s']==t
        a['reverse_unique_top_bits']=len(rtop)==1 and rtop[0]['s']==pid
        a['forward_query_coverage']=(abs(h['qe']-h['qs'])+1)/qlens[q]
        a['forward_target_coverage']=(abs(h['se']-h['ss'])+1)/tlens[t]
        a.update(forward_qstart=h['qs'],forward_qend=h['qe'],forward_sstart=h['ss'],forward_send=h['se'],forward_identity_unrounded=h['pident'])
        a['forward_coordinate_coverage_ge50']=min(a['forward_query_coverage'],a['forward_target_coverage'])>=.5
        if rh:
            a['reverse_query_coverage']=(abs(rh['qe']-rh['qs'])+1)/tlens[t]
            a['reverse_target_coverage']=(abs(rh['se']-rh['ss'])+1)/rlens[pid]
            a.update(reverse_qstart=rh['qs'],reverse_qend=rh['qe'],reverse_sstart=rh['ss'],reverse_send=rh['se'],reverse_identity_unrounded=rh['pident'])
            a['four_way_coordinate_coverage_ge50']=min(a['forward_query_coverage'],a['forward_target_coverage'],a['reverse_query_coverage'],a['reverse_target_coverage'])>=.5
        # Same publication filter as Figure 8, applied only to supplied pairs.
        a['strict_existing_RBH']=bool(raw_recip and a['forward_unique_top_bits'] and a['reverse_unique_top_bits'] and a['forward_coordinate_coverage_ge50'])
        a['strict_RBH_and_synteny']=bool(a['strict_existing_RBH'] and p['synteny_supported']=='YES')
        a['fourway_RBH']=a['strict_existing_RBH'] and a['four_way_coordinate_coverage_ge50']
        a['fourway_RBH_and_synteny']=a['strict_RBH_and_synteny'] and a['four_way_coordinate_coverage_ge50']
        reasons=[]
        if not raw_recip:reasons.append('NOT_SUPPLIED_RBH')
        if not a['forward_unique_top_bits']:reasons.append('FORWARD_NOT_UNIQUE_HIGHEST_BITS')
        if not a['reverse_unique_top_bits']:reasons.append('REVERSE_NOT_UNIQUE_HIGHEST_BITS')
        if not a['forward_coordinate_coverage_ge50']:reasons.append('FORWARD_COORDINATE_COVERAGE_LT50')
        a['strict_exclusion_reason']=';'.join(reasons)
    audit.append(a)
write('pairing_evidence_audit.tsv',audit)
ap={r['member_id']:r for r in audit}

errors=[];changes=[];expr=[]
for s in supplied_expr:
    rr=rso[(s['member_id'],s['rso_contrast'])];tt=tch[s['tchin_gene']];aa=ap[s['member_id']]
    for new,old in [('rso_log2FC','log2FoldChange'),('rso_padj','padj')]:
        if not equal_num(s[new],rr[old]):errors.append({'member':s['member_id'],'contrast':s['rso_contrast'],'field':new,'provided':s[new],'verified':rr[old]})
    for new,old in [('tchin_log2FC','log2FoldChange'),('tchin_padj','padj')]:
        if not equal_num(s[new],tt[old]):errors.append({'member':s['member_id'],'contrast':s['rso_contrast'],'field':new,'provided':s[new],'verified':tt[old]})
    rdc=rr['DE_call'] if rr['DE_call'] in ['TRUE','FALSE'] else 'NA'
    tdc=tt['DE_call_wald_padj_and_effect'] if tt['DE_call_wald_padj_and_effect'] in ['TRUE','FALSE'] else 'NA'
    for field,correct in [('rso_DE',rdc),('tchin_DE',tdc)]:
        if s[field]!=correct:changes.append(dict(member_id=s['member_id'],tchin_gene=s['tchin_gene'],contrast=s['rso_contrast'],field=field,supplied=s[field],restored=correct))
    a=dict(s)
    a.update(rso_DE=rdc,tchin_DE=tdc,rso_prefilter_status=rr['prefilter_status'],rso_DE_test_status=rr['DE_test_status'],tchin_inference_status=tt['inference_status'],supplied_RBH=aa['reciprocal'],synteny_supported=aa['synteny_supported'],strict_existing_RBH=aa['strict_existing_RBH'],strict_RBH_and_synteny=aa['strict_RBH_and_synteny'],fourway_RBH=aa['fourway_RBH'],fourway_RBH_and_synteny=aa['fourway_RBH_and_synteny'])
    x,y=num(rr['log2FoldChange']),num(tt['log2FoldChange'])
    signed=x is not None and y is not None and x!=0 and y!=0
    a['both_signed_estimates']=signed
    a['same_direction']='YES' if signed and x*y>0 else ('NO' if signed else 'NA')
    a['both_tested_with_FDR']=num(rr['padj']) is not None and num(tt['padj']) is not None
    a['both_DE_same_direction']=a['same_direction'] if rdc=='TRUE' and tdc=='TRUE' else 'NA'
    expr.append(a)
write('paired_expression_restored_status.tsv',expr)
write('NA_status_corrections.tsv',changes)
write('DE_numeric_mismatches.tsv',errors)
write('strict_RBH_pairs.tsv',[x for x in audit if x['strict_existing_RBH']])
write('strict_RBH_synteny_pairs.tsv',[x for x in audit if x['strict_RBH_and_synteny']])
write('both_DE_expression_rows.tsv',[x for x in expr if x['rso_DE']==x['tchin_DE']=='TRUE'])
focus=[]
for x in expr:
    if x['member_id'] not in ['RsLTP3','RsLTP16','RsLTP17','RsSNA10']:continue
    a=dict(x)
    for k in ['query_length','target_length','forward_qstart','forward_qend','forward_sstart','forward_send','reverse_qstart','reverse_qend','reverse_sstart','reverse_send','forward_identity_unrounded','reverse_identity_unrounded','forward_query_coverage','forward_target_coverage','reverse_query_coverage','reverse_target_coverage','four_way_coordinate_coverage_ge50']:
        a[k]=ap[x['member_id']][k]
    focus.append(a)
write('four_focus_pairs_expression_and_coordinates.tsv',focus)

def stats(label,subset):
    de=[x for x in subset if x['rso_DE']==x['tchin_DE']=='TRUE']
    signed=[x for x in subset if x['both_signed_estimates']]
    return dict(subset=label,comparison_rows=len(subset),unique_member_gene_pairs=len({(x['member_id'],x['tchin_gene']) for x in subset}),unique_Tchin_genes=len({x['tchin_gene'] for x in subset}),both_tested_rows=sum(x['both_tested_with_FDR'] for x in subset),both_signed_rows=len(signed),same_direction_signed_rows=sum(x['same_direction']=='YES' for x in signed),both_DE_rows=len(de),both_DE_unique_pairs=len({(x['member_id'],x['tchin_gene']) for x in de}),both_DE_unique_Tchin_genes=len({x['tchin_gene'] for x in de}),both_DE_same_direction_rows=sum(x['same_direction']=='YES' for x in de),both_DE_opposite_rows=sum(x['same_direction']=='NO' for x in de),both_DE_pair_labels=';'.join(sorted({x['member_id']+'--'+x['tchin_gene'] for x in de})))

summary=[]
filters=[('All_supplied_best_hit',lambda x:True),('Supplied_RBH',lambda x:x['supplied_RBH']=='YES'),('Supplied_synteny',lambda x:x['synteny_supported']=='YES'),('Supplied_RBH_and_synteny',lambda x:x['supplied_RBH']=='YES' and x['synteny_supported']=='YES'),('Strict_unique_RBH_50pct',lambda x:x['strict_existing_RBH']),('Strict_unique_RBH_50pct_and_synteny',lambda x:x['strict_RBH_and_synteny']),('Sensitivity_fourway_RBH',lambda x:x['fourway_RBH']),('Sensitivity_fourway_RBH_and_synteny',lambda x:x['fourway_RBH_and_synteny'])]
for label,fn in filters:
    sel=[x for x in expr if fn(x)]
    summary.append(stats(label,sel))
    for contrast in ['S200_vs_CK','S400_vs_CK']:
        summary.append(stats(label+'__'+contrast,[x for x in sel if x['rso_contrast']==contrast]))
write('stratified_expression_counts.tsv',summary)

# Independently parse existing MCScanX headers and anchors.
blocks=[];cur=None
for line in (S/'mcscanx_official/rso_tch.collinearity').read_text().splitlines():
    m=re.match(r'## Alignment (\d+): score=(\S+) e_value=(\S+) N=(\d+) (\S+)',line)
    if m:
        cur=dict(block=int(m[1]),expected=int(m[4]),chroms=m[5],pairs=[]);blocks.append(cur)
    elif cur and (m:=re.match(r'\s*\d+-\s*\d+:\s+(\S+)\s+(\S+)\s+(\S+)',line)):
        cur['pairs'].append((m[1],m[2],m[3]))
assert all(len(b['pairs'])==b['expected'] for b in blocks)
inter=[b for b in blocks if 'RSO_' in b['chroms'] and 'TCH_' in b['chroms']]
prot2m={r['protein_id']:r['member_id'] for r in cat}
anchors=[]
for b in inter:
    for g,h,e in b['pairs']:
        if h.startswith('RSO__'):g,h=h,g
        p=g.removeprefix('RSO__');t=h.removeprefix('TCH__')
        if p in prot2m:anchors.append(dict(block=b['block'],rso_amp=p,member_id=prot2m[p],tch_gene=t))
given=read(S/'tables/rso_tch_amp_synteny_official.tsv')
assert {(a['block'],a['rso_amp'],a['tch_gene']) for a in anchors}=={(int(a['block']),a['rso_amp'],a['tch_gene']) for a in given}
for a in audit:
    syn=any(g['member_id']==a['member_id'] and g['tch_gene']==a['tchin_gene'] for g in anchors)
    assert syn==(a['synteny_supported']=='YES')
write('independently_parsed_AMP_anchors.tsv',anchors)

result={
 'scope':'Audit existing v2 pair assignments and coordinate evidence only; no new sequence searches, alignments, family inference or pair assignments.',
 'provided_catalogue_by_family':dict(Counter(x['family'] for x in cat)),
 'missing_vs_current_primary66':sorted({k[0] for k in rso}-{x['member_id'] for x in cat}),
 'provided_pairs':len([x for x in audit if x['tchin_gene']]),
 'provided_RBH':sum(x['reciprocal']=='YES' for x in audit),
 'strict_RBH_count':sum(x['strict_existing_RBH'] for x in audit),
 'strict_RBH_by_family':dict(Counter(x['family'] for x in audit if x['strict_existing_RBH'])),
 'strict_RBH_synteny_count':sum(x['strict_RBH_and_synteny'] for x in audit),
 'strict_RBH_synteny_by_family':dict(Counter(x['family'] for x in audit if x['strict_RBH_and_synteny'])),
 'fourway_RBH_count':sum(x['fourway_RBH'] for x in audit),
 'fourway_RBH_synteny_count':sum(x['fourway_RBH_and_synteny'] for x in audit),
 'provided_query_sequences_vs_same_ID_background':{'Rso_query_exact_matches':len(qseq),'Tchin_reverse_query_exact_matches':len(reverse_queries)},
 'maximum_subjects_retained_per_query':{'forward':max(len(best_by_subject(x)) for x in fwd.values()),'reverse':max(len(best_by_subject(x)) for x in rev.values())},
 'supplied_RBH_failing_strict':[{k:x[k] for k in ['member_id','tchin_gene','strict_exclusion_reason','forward_query_coverage','forward_target_coverage','forward_top_bit_targets','reverse_top_bit_targets']} for x in audit if x['reciprocal']=='YES' and not x['strict_existing_RBH']],
 'strict_forward_pairs_failing_reverse_coverage':[x['member_id'] for x in audit if x['strict_existing_RBH'] and not x['four_way_coordinate_coverage_ge50']],
 'numeric_mismatches':errors,
 'NA_correction_cells':len(changes),
 'NA_corrections_by_field':dict(Counter(x['field'] for x in changes)),
 'restored_Rso_states':dict(Counter(x['rso_DE'] for x in expr)),
 'restored_Tchin_states':dict(Counter(x['tchin_DE'] for x in expr)),
 'MCScanX_total_blocks':len(blocks),'MCScanX_interspecies_blocks':len(inter),'AMP_anchor_rows':len(anchors),'unique_AMP_anchor_pairs':len({(x['member_id'],x['tch_gene']) for x in anchors}),
 'strata':[x for x in summary if '__' not in x['subset']],
 'limitations':['Historical 63-member queried cohort; RsLTP2/RsLTP18/RsLTP30 and seven reconstructed primary models were not queried.','Tchin family HMM screens are not curated family assignments.','Unique-best statements are conditional on retained BLAST output; original command/report lacks verifiable max_target_seqs invocation.','Two Rso contrasts reuse the same Tchin contrast, so comparison rows are not independent cross-species replications.','Concordant responses under different salts/tissues/time designs do not establish conserved causal salt-tolerance or antimicrobial function.']}
(O/'audit_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False,indent=2))
