"""Check identity and coverage of existing v2 protein files, without new sequence searches."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib, json, re
import pandas as pd
from Bio import SeqIO

ROOT = Path(__file__).resolve().parents[1]
W = ROOT.parent
SRC = ROOT / '01_原始结果快照'
J = W / '跨物种表达_实施_20260909'
OUT = ROOT / '02_核查与汇总/reference_audit'
OUT.mkdir(parents=True, exist_ok=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def fasta(p):
    records = list(SeqIO.parse(p, 'fasta'))
    assert len(records) == len({r.id for r in records}), p
    return {r.id:r for r in records}
def seq(r): return str(r.seq).upper().replace('.', '*').rstrip('*')
def save(rows, name): pd.DataFrame(rows).to_csv(OUT/name, sep='\t', index=False, encoding='utf-8-sig')
v2file = SRC/'ref/Tchinensis.official_per_gene.faa'
gfffile = ROOT/'03_核验依据/Tchinensis.protein_from_GFF.fa'
assert sha(gfffile) == '8d8e6aa03d858dd8689243732643ac7a94fb8057bcaac833477662c9a3025063'
v2, gff = fasta(v2file), fasta(gfffile)
published = fasta(J/'reference/Tchinensis_pep.fa')
published_rep = fasta(J/'reference/Tchinensis_longest_protein_per_gene.faa')
mapping = pd.read_csv(J/'reference/official_tx2gene.tsv', sep='\t', dtype=str)
tx2g = dict(zip(mapping.transcript_id, mapping.gene_id))
bygene = defaultdict(list)
for tx,r in gff.items():
    if tx in tx2g: bygene[tx2g[tx]].append(r)
rows=[]
for gene,r in v2.items():
    tx = re.search(r'transcript=(\S+)', r.description).group(1)
    rows.append({'gene_id':gene, 'transcript_id':tx, 'length_aa':len(seq(r)),
                 'gene_mapping_matches':tx2g.get(tx)==gene,
                 'equals_GFF_same_transcript': tx in gff and seq(r)==seq(gff[tx]),
                 'is_longest_GFF_protein_by_gene': len(r.seq)==max(len(x.seq) for x in bygene[gene]),
                 'equals_published_same_transcript':tx in published and seq(r)==seq(published[tx]),
                 'published_same_transcript_length_aa':len(seq(published[tx])) if tx in published else '',
                 'equals_published_longest_gene_sequence':gene in published_rep and seq(r)==seq(published_rep[gene]),
                 'internal_stop_count':seq(r).count('*'),
                 'sequence_sha256':hashlib.sha256(seq(r).encode()).hexdigest()})
save(rows,'gene_reference_identity.tsv')
genetable=pd.DataFrame(rows)
diffs=genetable[~genetable.equals_published_same_transcript]
save(diffs,'gene_reference_differences_from_released_peptides.tsv')
txrows=[]
for tx in sorted(set(gff)|set(published)):
    txrows.append({'transcript_id':tx,'gene_id':tx2g.get(tx,''),'GFF_present':tx in gff,'published_present':tx in published,
                   'GFF_length':len(seq(gff[tx])) if tx in gff else '',
                   'published_length':len(seq(published[tx])) if tx in published else '',
                   'identical':tx in gff and tx in published and seq(gff[tx])==seq(published[tx])})
save(txrows,'transcript_reference_identity.tsv')
txdf=pd.DataFrame(txrows)
pair = pd.read_csv(SRC/'tables/rso_tchin_pairing.tsv',sep='\t',keep_default_na=False)
pair=pair[pair.tchin_gene.ne('')].merge(genetable,left_on='tchin_gene',right_on='gene_id',validate='many_to_one')
save(pair,'paired_targets_reference_identity.tsv')
old=fasta(SRC/'ref/Tchinensis.fullmRNA_translated_DEPRECATED.faa')
old_diff=sum(seq(old[g])!=seq(v2[g]) for g in set(old)&set(v2))
old_exact_diff=sum(str(old[g].seq)!=str(v2[g].seq) for g in set(old)&set(v2))
summary={
 'v2_gene_proteins':len(v2),'GFF_derived_transcripts':len(gff),'official_map_transcripts':len(tx2g),
 'GFF_unmapped_transcripts':sorted(set(gff)-set(tx2g)),
 'map_transcripts_absent_from_GFF_proteins':sorted(set(tx2g)-set(gff)),
 'genes_missing_from_v2':sorted(set(tx2g.values())-set(v2)),
 'gene_mapping_disagreements':int((~genetable.gene_mapping_matches).sum()),
 'same_GFF_transcript_sequence_disagreements':int((~genetable.equals_GFF_same_transcript).sum()),
 'longest_GFF_selection_disagreements':int((~genetable.is_longest_GFF_protein_by_gene).sum()),
 'selected_proteins_different_from_released_same_transcript':len(diffs),
 'selected_proteins_different_from_released_gene_representative':int((~genetable.equals_published_longest_gene_sequence).sum()),
 'GFF_vs_released_transcripts_different_in_shared_IDs':int((txdf.GFF_present & txdf.published_present & ~txdf.identical).sum()),
 'v2_proteins_containing_internal_stop':int(genetable.internal_stop_count.gt(0).sum()),
 'paired_members':len(pair),'unique_target_genes':pair.tchin_gene.nunique(),
 'paired_targets_different_from_released_same_transcript':sorted(pair.loc[~pair.equals_published_same_transcript,'tchin_gene'].unique()),
 'v1_vs_v2_different_shared_gene_raw_sequences':old_exact_diff,
 'v1_vs_v2_different_shared_gene_stop_normalized_sequences':old_diff,
 'v2_gene_fasta_sha256':sha(v2file),'GFF_derived_protein_fasta_sha256':sha(gfffile),
 'normalization':'Uppercase; GFF stop symbol dot interpreted as asterisk; terminal stop removed for identity checks only',
 'new_sequence_search_executed':False,
}
(OUT/'reference_audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
print(diffs[['gene_id','transcript_id','length_aa','published_same_transcript_length_aa']].head(30).to_string(index=False))
