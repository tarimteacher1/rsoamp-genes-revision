#!/usr/bin/env python3
"""Prepare RSO + T. chinensis OFFICIAL combined inputs for MCScanX."""
from pathlib import Path
from Bio import SeqIO

HOM = Path("/path/to/rso_project/revision_20260909_cross_species_expression/homolog_pairing")
RSO_TAU = Path("/path/to/rso_project/revision_R1_20260902/05_comparative_genomics/mcscanx_rso_tamarix")
OUT = HOM / "mcscanx_official"
OUT.mkdir(parents=True, exist_ok=True)

rso_prots = []
for rec in SeqIO.parse(RSO_TAU / "rso_tau.faa", "fasta"):
    if rec.id.startswith("RSO__"):
        rso_prots.append(rec)
print("RSO proteins:", len(rso_prots))

rso_gff = []
with open(RSO_TAU / "rso_tau.gff") as fh:
    for line in fh:
        if line.startswith("RSO_"):
            rso_gff.append(line)
print("RSO gff rows:", len(rso_gff))

tch_prots = []
for rec in SeqIO.parse(HOM / "ref/Tchinensis.official_per_gene.faa", "fasta"):
    rec.id = "TCH__" + rec.id
    rec.description = ""
    tch_prots.append(rec)
print("TCH official proteins:", len(tch_prots))

# gff rows for TCH genes in protein set
prot_ids = {rec.id.replace("TCH__", "") for rec in tch_prots}
tch_gff = []
with open(Path("/path/to/rso_project/revision_20260909_cross_species_expression/reference/Tchinensis.gff3")) as fh:
    for line in fh:
        if line.startswith("#"):
            continue
        f = line.rstrip("\n").split("\t")
        if len(f) < 9 or f[2] != "gene":
            continue
        attrs = dict(kv.split("=", 1) for kv in f[8].split(";") if "=" in kv)
        gid = attrs.get("ID")
        if not gid or gid not in prot_ids:
            continue
        chrom = f[0].replace("chr", "TCH_Chr") if f[0].startswith("chr") else f"TCH_{f[0]}"
        tch_gff.append(f"{chrom}\tTCH__{gid}\t{int(f[3])}\t{int(f[4])}\n")
print("TCH gff rows:", len(tch_gff))

with open(OUT / "rso_tch.faa", "w") as fh:
    SeqIO.write(rso_prots + tch_prots, fh, "fasta")
with open(OUT / "rso_tch.gff", "w") as fh:
    fh.writelines(rso_gff)
    fh.writelines(tch_gff)
print("combined fasta/gff written")
