#!/usr/bin/env python3
"""Parse official RSO-TCH MCScanX collinearity, extract AMP anchors, add synteny flag."""
import csv
import re
from collections import defaultdict
from pathlib import Path

HOM = Path("/path/to/rso_project/revision_20260909_cross_species_expression/homolog_pairing")
COL = HOM / "mcscanx_official/rso_tch.collinearity"
PAIR_IN = HOM / "tables/rso_tchin_pairing_official.tsv"
ANCHOR_OUT = HOM / "tables/rso_tch_amp_synteny_official.tsv"
PAIR_OUT = HOM / "tables/rso_tchin_pairing.tsv"  # canonical corrected table

prot2member = {}
for r in csv.DictReader(open(HOM / "tables/rso_primary_catalogue.tsv"), delimiter="\t"):
    prot2member[r["protein_id"]] = r
amp_prots = set(prot2member)

blocks = []
cur = None
with open(COL) as fh:
    for line in fh:
        line = line.rstrip("\n")
        m = re.match(r"## Alignment (\d+): score=([\d.]+) e_value=(\S+) N=(\d+) (\S+)", line)
        if m:
            cur = {
                "id": int(m.group(1)), "score": float(m.group(2)),
                "evalue": m.group(3), "n": int(m.group(4)),
                "chroms": m.group(5).split("&"), "pairs": [],
            }
            blocks.append(cur)
            continue
        if cur is None:
            continue
        pm = re.match(r"\s*\d+-\s*\d+:\t(\S+)\t(\S+)\t", line)
        if pm:
            cur["pairs"].append((pm.group(1), pm.group(2)))

inter = [b for b in blocks if any(c.startswith("RSO_") for c in b["chroms"]) and any(c.startswith("TCH_") for c in b["chroms"])]
print(f"total blocks={len(blocks)} interspecies blocks={len(inter)}")

def strip(p):
    return p.replace("RSO__", "").replace("TCH__", "")

anchors = []
for b in inter:
    for a, c in b["pairs"]:
        a_amp = strip(a) in amp_prots
        c_amp = strip(c) in amp_prots
        if a_amp or c_amp:
            anchors.append({
                "block": b["id"], "score": b["score"], "evalue": b["evalue"],
                "chroms": "&".join(b["chroms"]),
                "gene1": a, "gene2": c,
                "rso_gene": a if a.startswith("RSO__") else c,
                "tch_gene": (c if a.startswith("RSO__") else a).replace("TCH__", ""),
                "rso_amp": (strip(a) if a_amp else strip(c)),
                "amp_side": "gene1" if a_amp else "gene2",
            })

print("AMP-involving interspecies anchors:", len(anchors))
with open(ANCHOR_OUT, "w", newline="") as fh:
    w = csv.DictWriter(fh, delimiter="\t", fieldnames=[
        "block", "score", "evalue", "chroms", "gene1", "gene2",
        "rso_gene", "tch_gene", "rso_amp", "amp_side"])
    w.writeheader()
    for a in sorted(anchors, key=lambda x: (x["block"], x["gene1"])):
        w.writerow(a)

synteny_supported = defaultdict(set)
for a in anchors:
    if a["rso_amp"] in prot2member:
        synteny_supported[prot2member[a["rso_amp"]]["member_id"]].add(a["tch_gene"])

rows = []
for r in csv.DictReader(open(PAIR_IN), delimiter="\t"):
    r["synteny_supported"] = "YES" if r["tchin_gene"] in synteny_supported.get(r["member_id"], set()) else "NO"
    rows.append(r)
cols = list(rows[0].keys())
with open(PAIR_OUT, "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=cols, delimiter="\t")
    w.writeheader()
    w.writerows(rows)

n_syn = sum(1 for r in rows if r["synteny_supported"] == "YES")
n_rbh_syn = sum(1 for r in rows if r["synteny_supported"] == "YES" and r["reciprocal"] == "YES")
print(f"members with synteny-supported best-hit partner: {n_syn}; of which RBH: {n_rbh_syn}")
print("wrote", PAIR_OUT)
