#!/usr/bin/env python3
"""Define RSO AMP <-> T. chinensis pairs with the OFFICIAL CDS-derived reference."""
import csv
from collections import defaultdict
from pathlib import Path

HOM = Path("/path/to/rso_project/revision_20260909_cross_species_expression/homolog_pairing")

member_info = {}
for r in csv.DictReader(open(HOM / "tables/rso_primary_catalogue.tsv"), delimiter="\t"):
    member_info[r["member_id"]] = r
protein2member = {r["protein_id"]: r["member_id"] for r in member_info.values()}

def read_blast(path):
    hits = defaultdict(list)
    with open(path) as fh:
        for line in fh:
            f = line.rstrip("\n").split("\t")
            hits[f[0]].append({
                "sseqid": f[1], "pident": float(f[2]), "length": int(f[3]),
                "evalue": float(f[10]), "bitscore": float(f[11]),
            })
    return hits

def best(h):
    return min(h, key=lambda x: (x["evalue"], -x["bitscore"])) if h else None

fwd = read_blast(HOM / "blast/rso63_vs_tchin_official.tsv")
rev = read_blast(HOM / "blast/tchin_official_vs_rso.tsv")
tchin_best_rso = {t: best(h) for t, h in rev.items()}

rows = []
n_recip = 0
for member, info in sorted(member_info.items()):
    pid = info["protein_id"]
    b = best(fwd.get(member, []))
    if b is None:
        rows.append({
            "member_id": member, "family": info["family"],
            "rso_protein_id": pid, "rso_gene_id": info["gene_id"],
            "tchin_gene": "", "pident": "", "evalue": "", "bitscore": "",
            "reciprocal": "NO_HIT", "reverse_best_rso": "", "reverse_pident": "",
        })
        continue
    rb = tchin_best_rso.get(b["sseqid"])
    reciprocal = "NO"
    rbr = ""
    rp = ""
    if rb:
        rbr = rb["sseqid"]
        rp = f"{rb['pident']:.1f}"
        if protein2member.get(rb["sseqid"]) == member:
            reciprocal = "YES"
            n_recip += 1
    rows.append({
        "member_id": member, "family": info["family"],
        "rso_protein_id": pid, "rso_gene_id": info["gene_id"],
        "tchin_gene": b["sseqid"], "pident": f"{b['pident']:.1f}",
        "evalue": f"{b['evalue']:.3g}", "bitscore": f"{b['bitscore']:.1f}",
        "reciprocal": reciprocal,
        "reverse_best_rso": rbr, "reverse_pident": rp,
    })

with open(HOM / "tables/rso_tchin_pairing_official.tsv", "w", newline="") as fh:
    cols = ["member_id", "family", "rso_protein_id", "rso_gene_id",
            "tchin_gene", "pident", "evalue", "bitscore",
            "reciprocal", "reverse_best_rso", "reverse_pident"]
    w = csv.DictWriter(fh, fieldnames=cols, delimiter="\t")
    w.writeheader()
    w.writerows(rows)

n_hit = sum(1 for r in rows if r["tchin_gene"])
print(f"members={len(rows)} with_hit={n_hit} RBH={n_recip}")
