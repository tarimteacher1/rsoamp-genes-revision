#!/usr/bin/env python3
"""Join RSO AMP member salt-response DE with T. chinensis homolog DE.

Inputs:
  tables/rso_tchin_pairing.tsv
  /path/to/rso_project/revision_R1_20260902/06_expression_reanalysis/results/final_AMP_DE_results.tsv
  /path/to/rso_project/revision_20260909_cross_species_expression/de_results/Tchinensis_all_gene_DE_results.tsv
Outputs:
  tables/paired_expression.tsv          one row per member x RSO contrast x Tchin best hit
  tables/paired_expression_summary.txt  concordance summary
"""
import csv
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path("/path/to/rso_project/revision_20260909_cross_species_expression/homolog_pairing")
RSO_DE = Path("/path/to/rso_project/revision_R1_20260902/06_expression_reanalysis/results/final_AMP_DE_results.tsv")
TCH_DE = Path("/path/to/rso_project/revision_20260909_cross_species_expression/de_results/Tchinensis_all_gene_DE_results.tsv")
PAIRING = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "tables/rso_tchin_pairing.tsv"
OUT = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "tables/paired_expression.tsv"
SUM = Path(sys.argv[3]) if len(sys.argv) > 3 else ROOT / "tables/paired_expression_summary.txt"

# load pairing
pairing = {}
with open(PAIRING) as fh:
    for r in csv.DictReader(fh, delimiter="\t"):
        pairing[r["member_id"]] = r

# RSO DE: member x contrast -> fields
rso_de = {}
with open(RSO_DE) as fh:
    for r in csv.DictReader(fh, delimiter="\t"):
        rso_de[(r["member_id"], r["contrast"])] = r

# Tchin DE: gene -> fields
tch_de = {}
with open(TCH_DE) as fh:
    for r in csv.DictReader(fh, delimiter="\t"):
        tch_de[r["gene_id"]] = r

def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None

def de_bool(x):
    return (x or "").strip().upper() == "TRUE"

def sign(x):
    x = num(x)
    if x is None:
        return ""
    return "UP" if x > 0 else ("DOWN" if x < 0 else "ZERO")

rows = []
for member, p in sorted(pairing.items()):
    if not p["tchin_gene"]:
        continue
    tch = tch_de.get(p["tchin_gene"])
    if tch is None:
        continue
    for contrast in ["S200_vs_CK", "S400_vs_CK"]:
        rso = rso_de.get((member, contrast))
        if rso is None:
            continue
        rso_q = rso.get("quantification_status", "")
        rso_lfc = rso.get("log2FoldChange", "")
        rso_padj = rso.get("padj_BH", "")
        rso_de_call = de_bool(rso.get("DE_call_FDR_lt_0.05_abs_log2FC_gt_1", ""))
        tch_lfc = tch.get("log2FoldChange", "")
        tch_padj = tch.get("padj", "")
        tch_de_call = de_bool(tch.get("DE_call_wald_padj_and_effect", ""))
        tch_pass = tch.get("prefilter_pass", "")

        # concordance among pairs where both have a point estimate
        rso_s = sign(rso_lfc)
        tch_s = sign(tch_lfc)
        same_dir = ""
        if rso_s and tch_s:
            same_dir = "YES" if rso_s == tch_s else "NO"
        both_de_same = ""
        if rso_de_call and tch_de_call and same_dir == "YES":
            both_de_same = "YES"
        elif rso_de_call and tch_de_call and same_dir == "NO":
            both_de_same = "NO"

        rows.append({
            "member_id": member,
            "family": p["family"],
            "rso_protein_id": p["rso_protein_id"],
            "rso_gene_id": p["rso_gene_id"],
            "tchin_gene": p["tchin_gene"],
            "pair_tier": "RBH" if p["reciprocal"] == "YES" else "BEST_HIT_ONLY",
            "pident": p["pident"],
            "rso_contrast": contrast,
            "rso_quant_status": rso_q,
            "rso_log2FC": rso_lfc,
            "rso_padj": rso_padj,
            "rso_DE": "TRUE" if rso_de_call else "FALSE",
            "tchin_prefilter_pass": tch_pass,
            "tchin_log2FC": tch_lfc,
            "tchin_padj": tch_padj,
            "tchin_DE": "TRUE" if tch_de_call else "FALSE",
            "same_direction": same_dir,
            "both_DE_same_direction": both_de_same,
        })

with open(OUT, "w", newline="") as fh:
    cols = list(rows[0].keys()) if rows else []
    w = csv.DictWriter(fh, fieldnames=cols, delimiter="\t")
    w.writeheader()
    w.writerows(rows)

# summaries
def summarize(subset, label, out):
    out.append(f"## {label}: n_pairs={len(subset)}")
    for key in ["rso_DE", "tchin_DE"]:
        c = defaultdict(int)
        for r in subset:
            c[r[key]] += 1
        out.append(f"  {key}: " + ", ".join(f"{k}={v}" for k, v in sorted(c.items())))
    for both in ["", "TRUE"]:
        sub2 = [r for r in subset if r["same_direction"] == "YES"]
        if both:
            sub2 = [r for r in sub2 if r["both_DE_same_direction"] == "YES"]
        out.append(f"  same_direction{(' and both_DE' if both else ' (any)')}: {len(sub2)}/{len(subset)}")
    # among pairs where both species DE-called: same direction?
    both_de = [r for r in subset if r["rso_DE"] == "TRUE" and r["tchin_DE"] == "TRUE"]
    same = [r for r in both_de if r["same_direction"] == "YES"]
    out.append(f"  pairs with both species DE-called: {len(both_de)}; same direction: {len(same)}; opposite: {len(both_de)-len(same)}")
    return out

out = [f"total paired rows: {len(rows)}"]
out = summarize(rows, "All best-hit pairs", out)
for tier in ["RBH", "BEST_HIT_ONLY"]:
    sub = [r for r in rows if r["pair_tier"] == tier]
    out = summarize(sub, tier, out)
for fam in ["Defensin", "Snakin_GASA", "nsLTP"]:
    sub = [r for r in rows if r["family"] == fam]
    out = summarize(sub, f"family {fam}", out)

with open(SUM, "w") as fh:
    fh.write("\n".join(out) + "\n")
print("\n".join(out))
