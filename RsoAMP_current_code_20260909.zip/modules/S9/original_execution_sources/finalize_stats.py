#!/usr/bin/env python3
"""Finalize comparison tables and stats for the homologous pairing report."""
import csv
from collections import defaultdict, Counter
from pathlib import Path

HOM = Path("/path/to/rso_project/revision_20260909_cross_species_expression/homolog_pairing")

# ---- three-species family composition ----
rows3 = [
    ("Reaumuria soongarica", "Defensin", 9, "curated (5 additional genome-rescued loci excluded from expression pairing)", 21791),
    ("Reaumuria soongarica", "Snakin_GASA", 18, "curated", 21791),
    ("Reaumuria soongarica", "nsLTP", 36, "curated", 21791),
    ("Tamarix austromongolica", "Defensin", 5, "curated; all five from genome rescue, 0 in official annotation", 22374),
    ("Tamarix austromongolica", "Snakin_GASA", 7, "curated", 22374),
    ("Tamarix austromongolica", "nsLTP", 24, "curated", 22374),
    ("Tamarix chinensis", "Defensin", 0, "HMM screening only, official annotation", 26426),
    ("Tamarix chinensis", "Snakin_GASA", 11, "HMM screening only, official annotation", 26426),
    ("Tamarix chinensis", "nsLTP", 38, "HMM screening only (PF00234 broad; uncured)", 26426),
    ("Tamarix chinensis", "Hevein_like_PF00187", 14, "HMM screening only; RSO/TAM workflow removes GH19 chitinases", 26426),
    ("Tamarix chinensis", "Thionin", 0, "HMM screening only", 26426),
    ("Tamarix chinensis", "Cyclotide", 0, "HMM screening only", 26426),
]
with open(HOM / "tables/family_composition_three_species.tsv", "w", newline="") as fh:
    w = csv.writer(fh, delimiter="\t")
    w.writerow(["species", "family", "count", "note", "protein_denominator"])
    w.writerows(rows3)

# ---- pairing + expression combined stats ----
pairing = {}
for r in csv.DictReader(open(HOM / "tables/rso_tchin_pairing.tsv"), delimiter="\t"):
    pairing[r["member_id"]] = r

pexp = list(csv.DictReader(open(HOM / "tables/paired_expression.tsv"), delimiter="\t"))
for r in pexp:
    r["synteny_supported"] = pairing[r["member_id"]].get("synteny_supported", "NO")

def stats(subset, label, out):
    out.append(f"## {label}: n_rows={len(subset)}")
    # unique member-gene pairs
    uniq = {(r["member_id"], r["tchin_gene"]) for r in subset}
    out.append(f"  unique member-gene pairs: {len(uniq)}")
    both = [r for r in subset if r["rso_DE"] == "TRUE" and r["tchin_DE"] == "TRUE"]
    same = [r for r in both if r["same_direction"] == "YES"]
    out.append(f"  rows both DE-called: {len(both)}; same direction: {len(same)}; opposite: {len(both)-len(same)}")
    uniq_both = {(r["member_id"], r["tchin_gene"]) for r in both}
    out.append(f"  unique pairs both DE-called: {len(uniq_both)}")
    out.append("  unique concordant pairs: " + ", ".join(sorted(f"{m}-{g}" for m, g in uniq_both if (m, g) in {(x['member_id'], x['tchin_gene']) for x in same})))
    # direction agreement among all rows with point estimates
    signed = [r for r in subset if r["same_direction"] in ("YES", "NO")]
    agree = [r for r in signed if r["same_direction"] == "YES"]
    out.append(f"  direction agreement among all signed rows: {len(agree)}/{len(signed)}")
    return out

out = []
for label, cond in [
    ("All best-hit pairs", lambda r: True),
    ("RBH pairs", lambda r: r["pair_tier"] == "RBH"),
    ("synteny-supported pairs", lambda r: r["synteny_supported"] == "YES"),
    ("RBH and synteny-supported", lambda r: r["pair_tier"] == "RBH" and r["synteny_supported"] == "YES"),
]:
    sub = [r for r in pexp if cond(r)]
    out = stats(sub, label, out)

with open(HOM / "tables/final_stats.txt", "w") as fh:
    fh.write("\n".join(out) + "\n")
print("\n".join(out))
