#!/usr/bin/env python3
"""Paired-expression scatter for S400 and S200 RSO contrasts vs T. chinensis Salt."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

HOM = Path("/path/to/rso_project/revision_20260909_cross_species_expression/homolog_pairing")

rows = []
with open(HOM / "tables/paired_expression.tsv") as fh:
    for r in csv.DictReader(fh, delimiter="\t"):
        rows.append(r)

# attach synteny support flag from pairing table
syn = {}
with open(HOM / "tables/rso_tchin_pairing.tsv") as fh:
    for r in csv.DictReader(fh, delimiter="\t"):
        syn[r["member_id"]] = r.get("synteny_supported", "NO")
for r in rows:
    r["synteny_supported"] = syn.get(r["member_id"], "NO")

def f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None

fam_color = {"nsLTP": "#1f77b4", "Snakin_GASA": "#d62728", "Defensin": "#7f7f7f"}

for contrast, tag in [("S400_vs_CK", "S400"), ("S200_vs_CK", "S200")]:
    sub = [r for r in rows if r["rso_contrast"] == contrast and r["rso_log2FC"] and r["tchin_log2FC"]]
    data = [(r, f(r["rso_log2FC"]), f(r["tchin_log2FC"])) for r in sub]
    data = [d for d in data if d[1] is not None and d[2] is not None]

    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    for r, x, y in data:
        fam = r["family"]
        tier = r["pair_tier"]
        synt = r.get("synteny_supported", "NO") == "YES"
        color = fam_color.get(fam, "gray")
        marker = "o" if tier == "RBH" else "^"
        size = 55 if tier == "RBH" else 40
        alpha = 0.85 if tier == "RBH" else 0.55
        edge = "#e6a817" if synt else "black"
        lw = 1.4 if synt else 0.4
        ax.scatter(x, y, c=color, marker=marker, s=size, alpha=alpha,
                   edgecolors=edge, linewidths=lw, zorder=3)

    for r, x, y in data:
        if r["both_DE_same_direction"] == "YES":
            ax.annotate(r["member_id"], (x, y), textcoords="offset points",
                        xytext=(5, 5), fontsize=7.5, color="black")

    lim = max(abs(v) for _, x, y in data for v in (x, y)) + 0.5
    ax.axhline(0, color="gray", lw=0.8)
    ax.axvline(0, color="gray", lw=0.8)
    ax.plot([-lim, lim], [-lim, lim], ls="--", color="gray", lw=0.8, alpha=0.6)
    ax.axhline(1, color="lightgray", lw=0.6, ls=":")
    ax.axhline(-1, color="lightgray", lw=0.6, ls=":")
    ax.axvline(1, color="lightgray", lw=0.6, ls=":")
    ax.axvline(-1, color="lightgray", lw=0.6, ls=":")
    ax.set_xlim(-lim, lim)
    ax.set_ylim(-lim, lim)
    ax.set_xlabel(f"R. soongorica log2FC ({tag} vs CK, MLE)")
    ax.set_ylabel("T. chinensis homolog log2FC (Salt vs CK, Wald)")
    ax.set_title(f"Paired homolog salt response ({tag}; 63-member catalogue; best-hit pairs)")

    handles = [
        Line2D([], [], marker="o", ls="", color="#1f77b4", label="nsLTP RBH"),
        Line2D([], [], marker="^", ls="", color="#1f77b4", label="nsLTP best-hit only", alpha=0.55),
        Line2D([], [], marker="o", ls="", color="#d62728", label="Snakin/GASA RBH"),
        Line2D([], [], marker="^", ls="", color="#d62728", label="Snakin/GASA best-hit only", alpha=0.55),
        Line2D([], [], marker="o", ls="", mfc="none", mec="#e6a817", mew=1.4,
               label="synteny-supported (MCScanX)"),
    ]
    ax.legend(handles=handles, fontsize=8, loc="upper left", framealpha=0.9)
    fig.tight_layout()
    for ext in ["png", "pdf"]:
        fig.savefig(HOM / f"figures/paired_expression_scatter_{tag}.{ext}", dpi=300)
    plt.close(fig)
    print(f"{tag}: saved {len(data)} points")
