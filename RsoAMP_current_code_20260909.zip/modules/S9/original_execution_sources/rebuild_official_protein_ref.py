#!/usr/bin/env python3
"""Rebuild T. chinensis protein reference from official CDS (gffread -y), longest per gene.

Also compares against the previous full-mRNA-translated reference to quantify the audit issues.
"""
from pathlib import Path
from Bio import SeqIO

ROOT = Path("/path/to/rso_project/revision_20260909_cross_species_expression")
HOM = ROOT / "homolog_pairing"
TX2GENE = ROOT / "reference/official_tx2gene.tsv"
NEW_PROT = ROOT / "reference/Tchinensis.protein_from_GFF.fa"
OLD_PROT = HOM / "ref/Tchinensis.longest_per_gene.faa"
OUT = HOM / "ref"
OUT.mkdir(parents=True, exist_ok=True)

# transcript -> gene
tx2gene = {}
with open(TX2GENE) as fh:
    header = fh.readline().strip("\ufeff").strip()
    assert header.split("\t")[0] == "transcript_id", header
    for line in fh:
        if not line.strip():
            continue
        tx, gene = line.rstrip("\n").split("\t")
        tx2gene[tx] = gene

# new official proteins
best = {}
n_new_tx = 0
n_orphan = 0
for rec in SeqIO.parse(NEW_PROT, "fasta"):
    tx = rec.id
    if tx not in tx2gene:
        n_orphan += 1
        continue
    n_new_tx += 1
    gene = tx2gene[tx]
    if gene not in best or len(rec.seq) > len(best[gene][0]):
        best[gene] = (rec.seq, tx, rec)

print(f"official protein transcripts mapped: {n_new_tx}; orphan/unmapped: {n_orphan}")
print(f"genes with official protein: {len(best)}")

with open(OUT / "Tchinensis.official_per_gene.faa", "w") as fh:
    for gene, (seq, tx, rec) in sorted(best.items()):
        out = rec[:]
        out.id = gene
        out.description = f"transcript={tx} length_aa={len(seq)}"
        fh.write(out.format("fasta"))

with open(OUT / "Tchinensis.official_per_gene.meta.tsv", "w") as fh:
    fh.write("gene_id\ttranscript_id\tprotein_length_aa\n")
    for gene, (seq, tx, rec) in sorted(best.items()):
        fh.write(f"{gene}\t{tx}\t{len(seq)}\n")

# compare with old reference
old = {}
for rec in SeqIO.parse(OLD_PROT, "fasta"):
    old[rec.id] = str(rec.seq)

diff_genes = []
only_old = []
only_new = []
same = 0
for gene in sorted(set(old) | set(best)):
    o = old.get(gene)
    n = str(best[gene][0]) if gene in best else None
    if o is None:
        only_new.append(gene)
    elif n is None:
        only_old.append(gene)
    elif o == n:
        same += 1
    else:
        diff_genes.append(gene)

print(f"old reference genes: {len(old)}; new official genes: {len(best)}")
print(f"identical: {same}; differing: {len(diff_genes)}; only_old(missed before): {len(only_old)}; only_new: {len(only_new)}")

with open(OUT / "reference_fix_audit.tsv", "w") as fh:
    fh.write("category\tcount\tgene_ids\n")
    fh.write(f"identical\t{same}\t\n")
    fh.write(f"differing\t{len(diff_genes)}\t{','.join(diff_genes)}\n")
    fh.write(f"only_old_missed_by_new\t{len(only_old)}\t{','.join(only_old)}\n")
    fh.write(f"only_new\t{len(only_new)}\t{','.join(only_new)}\n")
print("written:", OUT / "reference_fix_audit.tsv")
