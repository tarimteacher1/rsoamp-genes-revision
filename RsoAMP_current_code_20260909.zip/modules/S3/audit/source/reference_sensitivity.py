from pathlib import Path
import json
from classify_shared import classify
from prepare_analysis import write_tsv
W=Path(__file__).resolve().parent/'analysis'
rows=json.loads((W/'all_candidate_records.json').read_text());hs=json.loads((W/'all_candidate_core_hits.json').read_text())
tp=W/'final99_phylogenetic_evidence.json';trees=json.loads(tp.read_text()) if tp.exists() else {}
refs=json.loads((W/'reference_records.json').read_text());pos=[r['id'] for r in refs if r['label'].startswith('POS')]
baseline={r['id']:classify(r,hs.get(r['id'],[]),trees.get(r['id'])) for r in rows}
out=[];depend=[]
for ref in pos:
 results={r['id']:classify(r,[h for h in hs.get(r['id'],[]) if h['subject']!=ref],trees.get(r['id'])) for r in rows}
 changes=[r for r in rows if baseline[r['id']]['new_class'].startswith('A_')!=results[r['id']]['new_class'].startswith('A_')]
 out.append(dict(omitted_positive_reference=ref,RSO_A=sum(results[r['id']]['new_class'].startswith('A_') for r in rows if r['species']=='rso'),TAU_A=sum(results[r['id']]['new_class'].startswith('A_') for r in rows if r['species']=='tau'),changed_candidate_ids=';'.join(r['id'] for r in changes)))
 for r in changes:depend.append(dict(id=r['id'],member_id=r['member_id'] or r['protein_id'],omitted_reference=ref,original_class=baseline[r['id']]['new_class'],class_without_reference=results[r['id']]['new_class'],analysis_scope='Similarity-reference dependence only; BLAST database-size E-values and phylogenetic trees held fixed'))
write_tsv(W/'leave_one_positive_reference_out.tsv',out)
if depend:write_tsv(W/'single_reference_dependent_candidates.tsv',depend)
print('Reference omissions causing membership changes',[r for r in out if r['changed_candidate_ids']])
