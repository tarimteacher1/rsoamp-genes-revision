from pathlib import Path
import json,subprocess
W=Path(__file__).resolve().parent/'analysis'
script=r'''from pathlib import Path
import csv,re,json,hashlib
B=Path('/path/to/rso_project/revision_R1_20260902/05_comparative_genomics');P=B/'mcscanx_rso_tamarix/rso_tau.collinearity'
amp={r['combined_id'] for r in csv.DictReader((B/'mcscanx_rso_tamarix/amp_id_manifest.tsv').open(),delimiter='\t')}
old=[];fixed=[];block=''
for raw in P.open():
 l=raw.rstrip('\n')
 if l.startswith('## Alignment'):block=l;continue
 if 'RSO_' not in block or 'TAU_' not in block:continue
 if not re.match(r'^\s*\d+-\s*\d+:\s+',l):continue
 f=[x.strip() for x in l.split('\t')];assert len(f)==4
 if not (f[1] in amp or f[2] in amp):continue
 row={'block':block,'raw_line':l}
 fixed.append(row)
 if re.match(r'^\s+\d+-\s*\d+:\s+',l):old.append(row)
lost=[r for r in fixed if r not in old]
print(json.dumps({'same_archived_amp_manifest':True,'old_parser_rows':len(old),'corrected_parser_rows':len(fixed),'missed_rows':lost,'cause':'Leading whitespace was required. MCScanX three-digit block numbers have no leading padding.','parser_source':str(B/'prepare_rso_tamarix_mcscanx.py'),'source_sha256':hashlib.sha256((B/'prepare_rso_tamarix_mcscanx.py').read_bytes()).hexdigest()}))
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','dxy@example-host','python3 -'],input=script,text=True,encoding='utf-8',capture_output=True,check=True,timeout=60)
(W/'synteny_parser_regression_audit.json').write_text(r.stdout)
d=json.loads(r.stdout);print({k:v for k,v in d.items() if k!='missed_rows'})
assert d['old_parser_rows']==5 and d['corrected_parser_rows']>5
