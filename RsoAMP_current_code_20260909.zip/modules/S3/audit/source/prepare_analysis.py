from pathlib import Path
from collections import Counter
import csv,json,re,hashlib

ROOT=Path(__file__).resolve().parent
IN=ROOT/'inputs'; WORK=ROOT/'analysis';WORK.mkdir(exist_ok=True)

def fasta(p):
    d={};k=None
    for line in p.read_text(encoding='utf-8').splitlines():
        if line.startswith('>'):
            k=line[1:].split()[0]
            if k in d:raise ValueError('Duplicate FASTA ID '+k)
            d[k]=''
        elif k:d[k]+=line.strip()
    return d

def table(p):
    return list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter='\t'))

def write_tsv(p,rows):
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)

PAT=re.compile(r'(?=(C[^C]*C[^C]*CC[^C]*C[^C]C[^C]*C[^C]*C))')
def framework(seq):
    matches=[]
    for m in PAT.finditer(seq):
        s=m[1];pos=[m.start()+i+1 for i,a in enumerate(s) if a=='C']
        if len(pos)==8:
            matches.append({'start':m.start()+1,'end':m.start()+len(s),'sequence':s,'c_positions':pos,'spacing':[b-a-1 for a,b in zip(pos,pos[1:])]})
    return sorted(matches,key=lambda x:(len(x['sequence']),x['start']))

def annotated_boundary(record,kind):
    for f in record.get('features',[]):
        if f['type']==kind:
            loc=f.get('location',{});end=loc.get('end',{}).get('value')
            if end and loc.get('end',{}).get('modifier','EXACT')=='EXACT':return int(end)
    return None

def gpi_boundary(record):
    for f in record.get('features',[]):
        if f['type']=='Lipidation' and 'GPI' in f.get('description',''):
            return f['location']['start'].get('value')
    return None

if __name__=='__main__':
    refs=[];seen=set()
    for cat in ['positive_reviewed','negative_reviewed']:
        for v in json.loads((IN/(cat+'.json')).read_text(encoding='utf-8')):
            acc=v['primaryAccession'];name=v['proteinDescription'].get('recommendedName',{}).get('fullName',{}).get('value','')
            if acc in seen:continue
            ispos=cat=='positive_reviewed'
            seen.add(acc);seq=v['sequence']['value'];signal=annotated_boundary(v,'Signal') or 0;omega=gpi_boundary(v)
            gpi=('GPI-anchored' in name) or bool(omega)
            body=seq[signal:omega or len(seq)]
            fm=framework(body)
            ipr=[x['id'] for x in v.get('uniProtKBCrossReferences',[]) if x['database']=='InterPro']
            tax=v['organism']['scientificName'];fragment=v['proteinDescription'].get('flag','')=='Fragment'
            cls='POS_GPI' if ispos and gpi else 'POS_CORE' if ispos else 'NEG_EXPLICIT'
            refs.append(dict(id=acc,accession=acc,label=cls,name=name,species=tax,taxon_id=v['organism']['taxonId'],fragment=fragment,signal_cut=signal,gpi_omega=omega or '',interpro=';'.join(ipr),sequence=seq,processed_sequence=body,core_start=(signal+fm[0]['start']) if fm else '',core_end=(signal+fm[0]['end']) if fm else '',core_sequence=fm[0]['sequence'] if fm else '',framework_count=len(fm),source='UniProtKB reviewed; queried 2026-09-08'))
    for header,seq in fasta(IN/'ambiguous_reference.faa').items():
        acc=header.split('|')[-1]
        if acc in seen:continue
        seen.add(acc);fm=framework(seq)
        refs.append(dict(id=acc,accession=acc,label='AMB_UNRESOLVED',name='Historical broad prolamin reference; not a negative control',species='not_used_for_calibration',taxon_id='',fragment='',signal_cut=0,gpi_omega='',interpro='',sequence=seq,processed_sequence=seq,core_start=fm[0]['start'] if fm else '',core_end=fm[0]['end'] if fm else '',core_sequence=fm[0]['sequence'] if fm else '',framework_count=len(fm),source='Archived project AMB reference, provenance retained'))
    cand=[]
    for sp in ['rso','tau']:
        seqs=fasta(IN/(sp+'_candidates.faa'));rows=table(IN/(sp+'_evidence.tsv'));top={r['protein_id']:r for r in table(IN/(sp+'_topology.tsv'))}
        assert set(seqs)=={r['protein_id'] for r in rows}==set(top)
        for r in rows:
            pid=r['protein_id'];seq=seqs[pid];cut=int(r['effective_cleavage_after'] or 0);gpi=r['predgpi_GPI_anchor']=='YES';omega=int(r['predgpi_omega_site']) if gpi and r['predgpi_omega_site'] else None
            assert len(seq)==int(r['length_aa'])
            if omega:assert cut<omega<=len(seq)
            end=omega or len(seq);body=seq[cut:end];processed_fm=framework(body);before=framework(seq[cut:]);fm=before
            retained_tm=[]
            for a,b in re.findall(r'(\d+)-(\d+)',top[pid]['post_signal_tm_intervals']):
                if int(a)<=end and int(b)>cut:retained_tm.append(f'{a}-{b}')
            cand.append(dict(id=sp.upper()+'__'+pid,species=sp,protein_id=pid,member_id=r.get('member_id',''),old_class=r.get('final_classification',r.get('final_nsLTP_classification')),old_subtype=r.get('final_subtype',r.get('final_nsLTP_subtype')),signal_present=r['combined_signal_peptide'],signal_cut=cut,gpi_present=gpi,gpi_omega=omega or '',processed_cysteines=body.count('C'),processed_length=len(body),processed_framework_count=len(processed_fm),retained_tm_intervals=';'.join(retained_tm),specific_ipr=r['nsLTP_specific_IPR'],all_ipr=r.get('all_IPR',r.get('interpro_accessions','')),annotation_text=r.get('annotation_descriptions',r.get('interpro_descriptions','')),sequence=seq,processed_sequence=body,core_sequence=fm[0]['sequence'] if fm else '',core_start=cut+fm[0]['start'] if fm else '',core_end=cut+fm[0]['end'] if fm else '',core_spacing='-'.join(map(str,fm[0]['spacing'])) if fm else '',framework_count=len(fm),uncleaved_framework_count=len(before),old_phylogeny=r.get('phylogenetic_reference_interpretation','NOT_ASSESSED')))
    (WORK/'reference_records.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2),encoding='utf-8')
    (WORK/'candidate_records.json').write_text(json.dumps(cand,ensure_ascii=False,indent=2),encoding='utf-8')
    write_tsv(WORK/'reference_manifest.tsv',[{k:v for k,v in r.items() if k not in ['sequence','processed_sequence','core_sequence']} for r in refs])
    write_tsv(WORK/'candidate_processing_audit.tsv',[{k:v for k,v in r.items() if k not in ['sequence','processed_sequence','core_sequence']} for r in cand])
    for name,rows,key in [('references_full',refs,'sequence'),('references_core',[r for r in refs if r['core_sequence']],'core_sequence'),('candidates_full',cand,'sequence'),('candidates_processed',cand,'processed_sequence'),('candidates_core',[r for r in cand if r['core_sequence']],'core_sequence')]:
        (WORK/(name+'.faa')).write_text(''.join(f">{r['id']}\n{r[key]}\n" for r in rows),encoding='utf-8')
    print('References',Counter(r['label'] for r in refs),'core',Counter(r['label'] for r in refs if r['core_sequence']))
    print('Candidate sequence audit',Counter((r['species'],bool(r['core_sequence'])) for r in cand))
    print('No canonical framework',[(r['id'],r['processed_cysteines'],r['gpi_omega']) for r in cand if not r['core_sequence']])
    print('Remaining TM',[(r['id'],r['retained_tm_intervals']) for r in cand if r['retained_tm_intervals']])
