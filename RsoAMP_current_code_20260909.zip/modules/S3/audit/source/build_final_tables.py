from pathlib import Path
from collections import defaultdict,Counter
import json,re
from prepare_analysis import table,write_tsv
ROOT=Path(__file__).resolve().parent;W=ROOT/'analysis';O=ROOT/'核准结果';O.mkdir(exist_ok=True)
matrix=table(W/'shared_candidate_evidence_matrix.tsv');m={r['id']:r for r in matrix};counts=json.loads((W/'shared_family_counts.json').read_text())
extra=json.loads((W/'unchanged_other_family_roster.json').read_text())
roster=[dict(id=r['id'],species=r['species'],protein_id=r['protein_id'],member_id=r['member_id'] or r['protein_id'],family='nsLTP',source_tier='annotated_catalogue') for r in matrix if r['new_class'].startswith('A_')]+extra
ro={r['id']:r for r in roster};assert len(ro)==len(roster)
summary=[]
for sp in ['rso','tau']:
 for fam in ['Defensin','Snakin_GASA','nsLTP']:
  rr=[r for r in roster if r['species']==sp and r['family']==fam];n=next(r for r in counts if r['species']==sp)
  annot=sum(r['source_tier']=='annotated_catalogue' for r in rr);models=len(rr)-annot
  summary.append(dict(species='Reaumuria soongarica' if sp=='rso' else 'Tamarix austromongolica',family=fam,annotated_catalogue=annot,additional_homology_models=models,included_total=len(rr),B_boundary=n['B_boundary'] if fam=='nsLTP' else '',C_alternative_or_HyPRP=n['C_alternative'] if fam=='nsLTP' else '',audited_candidates=n['candidates'] if fam=='nsLTP' else '',reference_annotated_proteins=n['screened_proteins'],annotated_members_per_10000=round(annot/n['screened_proteins']*10000,4),classification_scope='Shared nsLTP audit completed' if fam=='nsLTP' else 'Prior catalogue preserved; classification not repeated in this audit'))
dep_path=W/'single_reference_dependent_candidates.tsv'
dependent=table(dep_path) if dep_path.exists() else []
dep_ids={r['id'] for r in dependent}
for r in summary:
 sp='rso' if r['species'].startswith('Reaumuria') else 'tau'
 ndep=sum(v['id'] in dep_ids for v in roster if v['species']==sp and v['family']=='nsLTP')
 r['reference_dependent_nsltp_subset']=ndep if r['family']=='nsLTP' else ''
 r['nsltp_without_reference_dependent_subset']=r['included_total']-ndep if r['family']=='nsLTP' else ''
hits=defaultdict(dict)
for l in (W/'all_family_cross_species.blast.tsv').read_text().splitlines():
 q,s,pi,al,ql,sl,qs,qe,ss,se,ev,bs=l.split('\t')
 if q.split('__')[0]==s.split('__')[0]:continue
 h=dict(query=q,subject=s,pident=float(pi),evalue=float(ev),bitscore=float(bs),query_coverage=(int(qe)-int(qs)+1)/int(ql),subject_coverage=(int(se)-int(ss)+1)/int(sl))
 if s not in hits[q] or h['bitscore']>hits[q][s]['bitscore']:hits[q][s]=h
best={}
for q,hs in hits.items():
 top=max(h['bitscore'] for h in hs.values());best[q]=[h for h in hs.values() if h['bitscore']==top]
audit=[];rbh=[]
for q in sorted(ro):
 for h in best.get(q,[]):
  s=h['subject'];qr=ro[q];sr=ro.get(s,{})
  reciprocal=len(best[q])==1 and len(best.get(s,[]))==1 and best[s][0]['subject']==q
  row=dict(query_id=q,query_display=qr['member_id'],query_family=qr['family'],query_source=qr['source_tier'],best_other_id=s,other_display=sr.get('member_id',s),other_family=sr.get('family',''),other_source=sr.get('source_tier','not_retained'),pident=h['pident'],evalue=h['evalue'],bitscore=h['bitscore'],query_coverage=h['query_coverage'],subject_coverage=h['subject_coverage'],ties=len(best[q]),unique_reciprocal_best_hit=reciprocal,minimum_half_length_both_sides=min(h['query_coverage'],h['subject_coverage'])>=.5,both_retained=bool(sr),family_concordant=qr['family']==sr.get('family',''))
  audit.append(row)
  if q.startswith('RSO__') and reciprocal and row['minimum_half_length_both_sides'] and row['both_retained']:rbh.append(row)
anchors=[]
for v in json.loads((W/'all_family_collinear_extract.json').read_text())['pairs']:
 r,t=v['rso_id'],v['tau_id'];rr=ro.get(r,{});tt=ro.get(t,{})
 if not rr and not tt:continue
 anchors.append(dict(mcscanx_block=re.search(r'Alignment (\d+)',v['block_header'])[1],rso_gene=r,rso_display=rr.get('member_id',r.removeprefix('RSO__')),rso_family=rr.get('family',''),rso_source=rr.get('source_tier','not_retained'),tamarix_gene=t,tamarix_display=tt.get('member_id',t.removeprefix('TAU__')),tamarix_family=tt.get('family',''),tamarix_source=tt.get('source_tier','not_retained'),pair_evalue=v['pair_evalue'],both_retained=bool(rr and tt),family_concordant=bool(rr and tt and rr['family']==tt['family'])))
tables={'S19_Counts':summary,'S19_Roster':roster,'S19_nsLTP_Audit':matrix,'Membership_changes':table(W/'membership_changes.tsv'),'S20_RBH_pairs':rbh,'S20_Best_hit_audit':audit,'S21_Collinear_pairs':anchors,'Threshold_sensitivity':table(W/'candidate_threshold_sensitivity.tsv'),'Control_calibration':table(W/'similarity_threshold_calibration.tsv'),'Phylogenetic_evidence':table(W/'final99_phylogenetic_evidence.tsv') if (W/'final99_phylogenetic_evidence.tsv').exists() else []}
tables['Reference_dependence']=dependent
tables['Reference_omission']=table(W/'leave_one_positive_reference_out.tsv')
for k,rows in tables.items():
 if rows:write_tsv(O/(k+'.tsv'),rows)
validation=json.loads((W/'classification_validation.json').read_text())
status='COUNTS_AUDIT_COMPLETE' if validation['tree_review_complete'] and validation['new_candidate_annotation_scope_complete'] else 'DRAFT_REVIEW_PENDING'
snapshot={'status':status,'counts':counts,'tables':tables,'validation':validation,'RBH_by_family':dict(Counter(r['query_family'] for r in rbh)),'collinear_pairs':len(anchors),'direct_collinear_pairs':sum(r['both_retained'] for r in anchors),'direct_pairs_by_family':dict(Counter(r['rso_family'] for r in anchors if r['both_retained'])),'direct_unique_rso_genes':len({r['rso_gene'] for r in anchors if r['both_retained']}),'whole_genome_MCScanX_rerun':False,'formal_manuscript_changed':False}
(O/'统一图表数据.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2),encoding='utf-8')
print({k:v for k,v in snapshot.items() if k not in ['tables','counts','validation']})
