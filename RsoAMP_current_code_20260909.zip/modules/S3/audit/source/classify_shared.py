from pathlib import Path
from collections import Counter
from itertools import product
import json,hashlib,random
from calibrate_similarity import qualifies
from prepare_analysis import write_tsv
W=Path(__file__).resolve().parent/'analysis'
SPEC={'IPR000528','IPR033872','IPR039265','IPR044741'}

def classify(e,hits,phylo=None,coverage=.8,identity=30,evalue=1e-5):
    """Pure evidence-only decision: no species, member name, or old membership use."""
    domain=bool(set(e['specific_ipr'].split(';'))&SPEC)
    good=[h for h in hits if qualifies(h,coverage,identity,evalue)]
    pos=next((h for h in good if h['label'].startswith('POS')),None)
    neg=next((h for h in good if h['label'].startswith('NEG')),None)
    rawpos=next((h for h in hits if h['label'].startswith('POS')),None)
    rawneg=next((h for h in hits if h['label'].startswith('NEG')),None)
    result={'new_class':'B_UNRESOLVED','identity_route':'','reason_code':'INSUFFICIENT_SPECIFIC_IDENTITY'}
    def done(cls,route,reason):
        result.update(new_class=cls,identity_route=route,reason_code=reason)
        if e['gpi_present'] and not e['processed_framework_count']:sub='GPI_PREDICTION_CORE_CONFLICT'
        elif e['gpi_present']:sub='GPI_SUPPORTED_PREDICTION'
        else:sub='GPI_NOT_PREDICTED'
        result['gpi_evidence_category']=sub
        result['best_qualified_positive']=pos['subject'] if pos else ''
        result['best_qualified_negative']=neg['subject'] if neg else ''
        return result
    if neg and (not rawpos or neg['bitscore']>rawpos['bitscore']):
        return done('B_UNRESOLVED' if domain else 'C_ALTERNATIVE_OR_HYPRP','', 'DOMAIN_ALTERNATIVE_CONFLICT' if domain else 'STRONG_EXPLICIT_ALTERNATIVE_CORE')
    if e['signal_present']!='YES':return done('B_UNRESOLVED','','NO_SIGNAL_SUPPORT')
    if not e['framework_count']:return done('B_UNRESOLVED','','NONCANONICAL_OR_INCOMPLETE_FRAMEWORK')
    if e['retained_tm_intervals']:return done('B_UNRESOLVED','','RETAINED_TRANSMEMBRANE_SEGMENT')
    if e['gpi_present'] and not e['processed_framework_count'] and not domain and not pos:
        return done('B_UNRESOLVED','','DISTAL_CYSTEINE_OR_GPI_CORE_CONFLICT')
    if not domain and rawneg and pos and rawneg['bitscore']>=pos['bitscore']:
        return done('B_UNRESOLVED','','COMPETING_ALTERNATIVE_SIMILARITY')
    if domain or pos:
        if phylo and all(phylo.get(m,{}).get('nearest_reference_side')=='NEG_ONLY' for m in ['aligned','gappyout']):
            return done('B_UNRESOLVED','','TWO_TREE_ALTERNATIVE_CONFLICT')
        return done('A_NSLTP_CANDIDATE','SPECIFIC_DOMAIN' if domain else 'REVIEWED_CORE_HOMOLOGY','SPECIFIC_IDENTITY_AND_FRAMEWORK_SUPPORTED')
    return done('B_UNRESOLVED','','INSUFFICIENT_SPECIFIC_IDENTITY')

def main():
    rows=json.loads((W/'all_candidate_records.json').read_text());hit=json.loads((W/'all_candidate_core_hits.json').read_text())
    pp=W/'final99_phylogenetic_evidence.json';trees=json.loads(pp.read_text()) if pp.exists() else {}
    coord={r['id']:r for r in json.loads((W/'candidate_gene_coordinates.json').read_text())}
    results=[];invariance=True
    for r in rows:
        hs=hit.get(r['id'],[]);d=classify(r,hs,trees.get(r['id']))
        renamed=dict(r,id='ARBITRARY',protein_id='UNKNOWN',member_id='NOT_A_REAL_NAME',species='BLINDED',old_class='BLINDED')
        assert d==classify(renamed,hs,trees.get(r['id']))
        bests={}
        for label in ['POS','NEG','AMB']:
            h=next((h for h in hs if h['label'].startswith(label)),{})
            for k in ['subject','bitscore','evalue','pident','query_coverage','subject_coverage','global_core_cys_matches']:bests[f'best_{label}_{k}']=h.get(k,'')
        rr={k:v for k,v in r.items() if k not in ['sequence','processed_sequence','core_sequence','annotation_text']}
        rr.update(coord[r['id']]);rr.update(d);rr.update(bests)
        rr['qualified_positive_reference_count']=len({h['subject'] for h in hs if h['label'].startswith('POS') and qualifies(h)})
        best_positive=d['best_qualified_positive']
        without_best=classify(r,[h for h in hs if h['subject']!=best_positive],trees.get(r['id'])) if best_positive else d
        rr['single_positive_reference_dependent']=d['new_class'].startswith('A_') and not without_best['new_class'].startswith('A_')
        for mode in ['aligned','gappyout']:rr['tree_'+mode]=trees.get(r['id'],{}).get(mode,{}).get('nearest_reference_side','PENDING')
        rr['membership_changed']=(r['old_class'].startswith('A_'))!=(d['new_class'].startswith('A_'))
        results.append(rr)
    write_tsv(W/'shared_candidate_evidence_matrix.tsv',results)
    changes=[r for r in results if r['membership_changed'] or r['old_class']=='NOT_RETRIEVED_PREVIOUSLY']
    write_tsv(W/'membership_changes.tsv',changes)
    summary=[]
    for sp in ['rso','tau']:
        rs=[r for r in results if r['species']==sp];a=[r for r in rs if r['new_class'].startswith('A_')]
        assert len({r['gene_id'] for r in a})==len(a)
        summary.append(dict(species=sp,screened_proteins=21791 if sp=='rso' else 22374,candidates=len(rs),old_primary=sum(r['old_class'].startswith('A_') for r in rs),A_primary=len(a),B_boundary=sum(r['new_class'].startswith('B_') for r in rs),C_alternative=sum(r['new_class'].startswith('C_') for r in rs),A_specific_domain=sum(r['identity_route']=='SPECIFIC_DOMAIN' for r in a),A_reference_core=sum(r['identity_route']=='REVIEWED_CORE_HOMOLOGY' for r in a),A_GPI_supported=sum(r['gpi_evidence_category']=='GPI_SUPPORTED_PREDICTION' for r in a),A_GPI_conflict=sum(r['gpi_evidence_category']=='GPI_PREDICTION_CORE_CONFLICT' for r in a),A_GPI_not_predicted=sum(r['gpi_evidence_category']=='GPI_NOT_PREDICTED' for r in a)))
    write_tsv(W/'shared_family_counts.tsv',summary)
    (W/'shared_family_counts.json').write_text(json.dumps(summary,indent=2))
    sens=[]
    primary={r['id']:r['new_class'] for r in results}
    for cov,ident,ev in product([.6,.7,.8,.9],[25,30,35],[1e-3,1e-5,1e-7]):
        classes={r['id']:classify(r,hit.get(r['id'],[]),trees.get(r['id']),cov,ident,ev)['new_class'] for r in rows}
        sens.append(dict(coverage=cov,identity=ident,evalue=ev,RSO_A=sum(classes[r['id']].startswith('A_') for r in rows if r['species']=='rso'),TAU_A=sum(classes[r['id']].startswith('A_') for r in rows if r['species']=='tau'),membership_change_ids=';'.join(k for k in classes if classes[k].startswith('A_')!=primary[k].startswith('A_')),any_class_change_ids=';'.join(k for k in classes if classes[k]!=primary[k])))
    write_tsv(W/'candidate_threshold_sensitivity.tsv',sens)
    tree_status=json.loads((W/'final99_v2_status.json').read_text()) if (W/'final99_v2_status.json').exists() else {}
    retrieval_ids={r['id'] for r in json.loads((W/'shared_retrieval_candidates.json').read_text())}
    archived_ids={r['id'] for r in json.loads((W/'candidate_records.json').read_text())}
    checks={'candidate_count':len(rows),'retrieval_recovers_all_old_candidates':archived_ids<=retrieval_ids,'unique_candidate_ids':len({r['id'] for r in rows})==len(rows),'unique_accepted_gene_ids':True,'name_species_old_status_invariance':invariance,'tree_review_complete':bool(trees) and len(trees)==len(rows) and all(tree_status.get(k)=='complete' for k in ['alignment','aligned','gappyout']),'classification_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    ps=json.loads((W/'new_prediction_status.json').read_text())
    extras=[json.loads((W/name).read_text()) for name in ['additional_domains_status.json','signature_domains_status.json']]
    checks['new_candidate_annotation_scope_complete']=all(ps.get(k)=='complete' for k in ['deepsig','predgpi','tmbed','interpro']) and all(v.get('state')=='complete' for v in extras)
    (W/'classification_validation.json').write_text(json.dumps(checks,indent=2))
    for sp in ['rso','tau']:
        aa={r['id'] for r in results if r['species']==sp and r['new_class'].startswith('A_')}
        (W/(sp+'_accepted_nsltp.faa')).write_text(''.join('>'+r['id']+'\n'+r['sequence']+'\n' for r in rows if r['id'] in aa))
    print('Tree review',checks['tree_review_complete']);print(summary)
    print('Changed',[(r['member_id'] or r['protein_id'],r['old_class'],r['new_class'],r['reason_code']) for r in changes])
    print('Sensitivity',Counter((r['RSO_A'],r['TAU_A']) for r in sens))

if __name__=='__main__':main()
