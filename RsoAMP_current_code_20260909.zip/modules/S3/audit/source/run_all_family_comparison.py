from pathlib import Path
import json,subprocess
ROOT=Path(__file__).resolve().parent;W=ROOT/'analysis'
old=json.loads((ROOT.parent/'R1M7_图表统一预览_20260908/unified_preview_data.json').read_text(encoding='utf-8'))['tables']['S19_RetainedSources']
extra=[]
for r in old:
 if r['family']=='nsLTP':continue
 sp='RSO' if r['species'].startswith('Reaumuria') else 'TAU'
 extra.append(dict(id=sp+'__'+r['candidate_id'],species=sp.lower(),protein_id=r['candidate_id'],member_id=r['display_id'],family=r['family'],source_tier=r['source_tier']))
(W/'unchanged_other_family_roster.json').write_text(json.dumps(extra,ensure_ascii=False,indent=2),encoding='utf-8')
ids=[r['id'] for r in extra]+[r['id'] for r in json.loads((W/'all_candidate_records.json').read_text())]
script=r'''from pathlib import Path
import subprocess,json,hashlib
B=Path('/path/to/rso_project/nsltp_shared_audit_20260908')
P=Path('/path/to/rso_project/revision_R1_20260902/05_comparative_genomics/mcscanx_rso_tamarix/rso_tau.faa')
ids=IDS_PLACEHOLDER
seqs={};k=None
for l in P.read_text().splitlines():
 if l.startswith('>'):k=l[1:].split()[0];seqs[k]=''
 elif k:seqs[k]+=l.strip()
assert set(ids)<=set(seqs)
retr={r['id']:r['sequence'] for r in json.loads((B/'shared_retrieval_candidates.json').read_text())}
assert all(seqs[k]==s for k,s in retr.items())
(B/'all_family_queries.faa').write_text(''.join('>'+k+'\n'+seqs[k]+'\n' for k in ids))
args=['/usr/bin/makeblastdb','-in',str(P),'-dbtype','prot','-out',str(B/'extended_genome_db')]
subprocess.run(args,check=True,stdout=subprocess.DEVNULL)
args2=['/usr/bin/blastp','-query',str(B/'all_family_queries.faa'),'-db',str(B/'extended_genome_db'),'-evalue','1e-5','-seg','yes','-comp_based_stats','2','-num_threads','4','-max_target_seqs','50000','-outfmt','6 qseqid sseqid pident length qlen slen qstart qend sstart send evalue bitscore','-out',str(B/'all_family_cross_species.blast.tsv')]
subprocess.run(args2,check=True)
(B/'all_family_comparison_provenance.json').write_text(json.dumps({'source':str(P),'sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'database_sequences':len(seqs),'query_sequences':len(ids),'extra_model_sequences':5,'retrieved_nsltp_sequences_identical':True,'commands':[args,args2]},indent=2))
P=P.with_suffix('.collinearity');rows=[];block=''
for l in P.open():
 if l.startswith('## Alignment'):block=l.strip();continue
 if l.startswith('#'):continue
 f=l.strip().split();genes=[v for v in f if v.startswith(('RSO__','TAU__'))]
 if len(genes)!=2 or genes[0].split('__')[0]==genes[1].split('__')[0]:continue
 if any(k in ids for k in genes):rows.append({'block_header':block,'rso_id':next(g for g in genes if g.startswith('RSO__')),'tau_id':next(g for g in genes if g.startswith('TAU__')),'pair_evalue':f[-1]})
(B/'all_family_collinear_extract.json').write_text(json.dumps({'source':str(P),'sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'pairs':rows},indent=2))
print('complete',len(ids),'queries',len(seqs),'database sequences')
'''.replace('IDS_PLACEHOLDER',repr(ids))
r=subprocess.run(['ssh','-o','BatchMode=yes','dxy@example-host','python3 -'],input=script,text=True,encoding='utf-8',capture_output=True,check=True,timeout=120)
print(r.stdout)
