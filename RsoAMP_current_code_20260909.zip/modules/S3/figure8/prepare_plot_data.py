from pathlib import Path
import collections
import csv
import hashlib
import json
import re
import shutil

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'

def read_tsv(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f,delimiter='\t'))

def write_tsv(path,rows):
    with path.open('w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)

genes={r['combined_id']:r for r in read_tsv(DATA/'combined_id_manifest.tsv')}
annotation={r['combined_id']:r for r in read_tsv(DATA/'annotation_mrna.tsv')}
model_source=BASE.parent/'Genes_lab_handoff_20260908/02_Workspace/9_2_major_revision/revision_R1_20260902/05_comparative_genomics/tamarix_defensin_miniprot_models.tsv'
if not (DATA/'tamarix_defensin_miniprot_models.tsv').exists():
    shutil.copy2(model_source,DATA/'tamarix_defensin_miniprot_models.tsv')
models=read_tsv(DATA/'tamarix_defensin_miniprot_models.tsv')
for r in models:
    annotation['TAU__'+r['candidate_id']]={**r,'feature_type':'additional_homology_model'}
for k,g in genes.items():
    g['start']=int(g['start']);g['end']=int(g['end']);g['species']=k[:3]
    a=annotation[k]
    assert (g['chrom'],g['start'],g['end'])==(a['chrom'],int(a['start']),int(a['end']))
    g['strand']=a['strand'];g['model_source']=a['feature_type']
roster=read_tsv(DATA/'S19_RetainedSources.tsv')
amp={('RSO__' if r['species'].startswith('Reaumuria') else 'TAU__')+r['candidate_id']:r for r in roster}
assert len(amp)==len(roster)==106 and set(amp)<=set(genes)
for k,r in amp.items():genes[k]['amp']=r

blocks=[];cur=None
for line in (DATA/'rso_tau.collinearity').read_text().splitlines():
    if line.startswith('## Alignment'):
        m=re.fullmatch(r'## Alignment (\d+): score=(\S+) e_value=(\S+) N=(\d+) (\S+)&(\S+) (plus|minus)',line)
        assert m,line
        cur=dict(id=int(m[1]),score=float(m[2]),evalue=m[3],n=int(m[4]),chr1=m[5],chr2=m[6],orientation=m[7],pairs=[])
        blocks.append(cur)
    elif cur and re.match(r'^\s*\d+-\s*\d+:',line):
        fields=[s.strip() for s in line.split('\t')]
        assert len(fields)==4,line
        a,b=fields[1:3]
        assert a in genes and b in genes
        cur['pairs'].append(dict(gene1=a,gene2=b,evalue=fields[3],old_reader_kept=bool(re.match(r'^\s+\d+-\s*\d+:',line))))
    elif line and not line.startswith('#'):
        raise ValueError('Unparsed data line: '+line)
assert all(b['n']==len(b['pairs']) for b in blocks)
inter=[b for b in blocks if b['chr1'][:3]!=b['chr2'][:3]]
rows=[]
for b in inter:
    for p in b['pairs']:
        assert p['gene1'].startswith('RSO__') and p['gene2'].startswith('TAU__')
        a,h=p['gene1'],p['gene2'];ra=amp.get(a,{});rb=amp.get(h,{})
        if not (ra or rb):continue
        direct=bool(ra and rb)
        if direct:assert ra['family']==rb['family']
        rows.append(dict(mcscanx_block=b['id'],rso_gene=a,rso_amp_id=ra.get('display_id',''),rso_amp_family=ra.get('family',''),tamarix_gene=h,tamarix_amp_id=rb.get('display_id',''),tamarix_amp_family=rb.get('family',''),pair_evalue=p['evalue'],direct_amp_to_amp_anchor='YES' if direct else 'NO',rso_source_tier=ra.get('source_tier','not_in_current_catalogue'),tamarix_source_tier=rb.get('source_tier','not_in_current_catalogue'),legacy_reader_kept='YES' if p['old_reader_kept'] else 'NO'))
legacy=read_tsv(DATA/'S21_CollinearPairs.tsv')
pairkey=lambda r:(int(r['mcscanx_block']),r['rso_gene'],r['tamarix_gene'])
assert {pairkey(r) for r in legacy}=={pairkey(r) for r in rows}
write_tsv(DATA/'S21_CollinearPairs_reparsed.tsv',rows)
direct=[r for r in rows if r['direct_amp_to_amp_anchor']=='YES']
summary=dict(status='shared_reference_proteome_comparison_audit',catalogue_snapshot='2026-09-08 shared nsLTP audit; other family membership retained',all_blocks=len(blocks),inter_species_blocks=len(inter),inter_species_anchor_records=sum(b['n'] for b in inter),unique_inter_species_gene_pairs=len({(p['gene1'],p['gene2']) for b in inter for p in b['pairs']}),amp_involving_pairs=len(rows),amp_involving_blocks=len({r['mcscanx_block'] for r in rows}),direct_amp_pairs=len(direct),direct_pairs_by_family=dict(collections.Counter(r['rso_amp_family'] for r in direct)),direct_unique_rso_genes=len({r['rso_gene'] for r in direct}),direct_unique_tamarix_genes=len({r['tamarix_gene'] for r in direct}),supplied_latest_pairs=len(legacy),newly_recovered_pairs=sum(r['legacy_reader_kept']=='NO' for r in rows),all_block_header_N_values_match=True,all_44170_gene_coordinates_and_strands_checked=True,latest_31_pairs_exactly_reproduced=True)
assert summary['amp_involving_pairs']==31 and summary['direct_amp_pairs']==26
counts=read_tsv(DATA/'S19_Counts.tsv')
for r in counts:
    found=[a for a in roster if a['species']==r['species'] and a['family']==r['family']]
    assert len(found)==int(r['current_included_total'])
    assert sum(a['source_tier']=='annotated_catalogue' for a in found)==int(r['annotated_catalogue_members'])

chroms={}
for sp,name in [('RSO','rso_genome.fai'),('TAU','tau_genome.fai')]:
    chroms[sp]=[dict(chrom=f[0],length=int(f[1])) for line in (DATA/name).read_text().splitlines() if re.fullmatch(r'Chr\d+', (f:=line.split('\t'))[0])]
    chroms[sp].sort(key=lambda a:int(a['chrom'][3:]))
bychrom=collections.defaultdict(list)
for k,g in genes.items():bychrom[(g['species'],g['chrom'])].append(k)
for ks in bychrom.values():ks.sort(key=lambda k:(genes[k]['start'],genes[k]['end'],k))
byblock={b['id']:b for b in inter}

def context(block_id,focus_pairs):
    b=byblock[block_id]
    focus_set={(r['rso_gene'],r['tamarix_gene']) for r in focus_pairs}
    ix=[i for i,p in enumerate(b['pairs']) if (p['gene1'],p['gene2']) in focus_set]
    assert ix
    anchors=b['pairs'][max(0,min(ix)-3):min(len(b['pairs']),max(ix)+4)]
    tracks=[]
    for side,sp,chrkey in [('gene1','RSO','chr1'),('gene2','TAU','chr2')]:
        chrom=b[chrkey].split('_',1)[1]
        lo=min(genes[p[side]]['start'] for p in anchors);hi=max(genes[p[side]]['end'] for p in anchors)
        # All actual annotation entries inside the selected genomic range, plus
        # two neighbouring models at each boundary. No fabricated neighbours.
        keys=bychrom[(sp,chrom)];inside=[i for i,k in enumerate(keys) if genes[k]['end']>=lo and genes[k]['start']<=hi]
        keys=keys[max(0,min(inside)-2):min(len(keys),max(inside)+3)]
        lo=min(genes[k]['start'] for k in keys);hi=max(genes[k]['end'] for k in keys)
        pad=max(100,(hi-lo)*0.025)
        tracks.append(dict(species=sp,chrom=chrom,start=max(1,lo-int(pad)),end=hi+int(pad),reverse=(sp=='TAU' and b['orientation']=='minus'),genes=keys))
    selected=[p for p in b['pairs'] if p['gene1'] in tracks[0]['genes'] and p['gene2'] in tracks[1]['genes']]
    return dict(block=block_id,tracks=tracks,pairs=selected,focus_pairs=focus_pairs,orientation=b['orientation'])

# Deterministic examples: first catalogue-to-catalogue anchor for each family;
# retain another focus anchor when it lies within 1 Mb in both species.
examples=[]
for family in ['Defensin','Snakin_GASA','nsLTP']:
    first=next(r for r in direct if r['rso_amp_family']==family)
    near=[r for r in direct if r['mcscanx_block']==first['mcscanx_block'] and all(abs(genes[r[side]]['start']-genes[first[side]]['start'])<=1_000_000 for side in ['rso_gene','tamarix_gene'])]
    ctx=context(first['mcscanx_block'],near);ctx['family']=family;examples.append(ctx)
all_contexts=[context(r['mcscanx_block'],[r]) for r in rows]
out=dict(summary=summary,genes=genes,chromosomes=chroms,blocks=inter,amp_pairs=rows,counts=counts,examples=examples,all_pair_contexts=all_contexts)
(DATA/'plot_data.json').write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')),encoding='utf8')
(DATA/'reader_validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
context_rows=[]
for i,c in enumerate(all_contexts,1):
    for t in c['tracks']:
        for k in t['genes']:
            g=genes[k];context_rows.append(dict(pair_index=i,block=c['block'],combined_id=k,species=g['species'],chrom=g['chrom'],start=g['start'],end=g['end'],strand=g['strand'],display_reversed=t['reverse'],amp_id=g.get('amp',{}).get('display_id',''),family=g.get('amp',{}).get('family',''),source=g['model_source']))
write_tsv(DATA/'all_pair_neighbourhood_genes.tsv',context_rows)
print(json.dumps(summary,ensure_ascii=False))
print(json.dumps([{'family':c['family'],'block':c['block'],'tracks':[(t['chrom'],len(t['genes']),t['end']-t['start']) for t in c['tracks']],'anchors':len(c['pairs'])} for c in examples],ensure_ascii=False))
