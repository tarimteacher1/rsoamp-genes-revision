from pathlib import Path
import csv,json,shutil,subprocess,sys,hashlib
R=Path(__file__).resolve().parents[1]
J=R/'跨物种比较_正式同步_20260909'
F=J/'figure8'
D=F/'data'
A=R/'nsLTP_统一审核_20260908/核准结果'
O=R/'Figure8_整体与局部共线性_20260908'
D.mkdir(parents=True,exist_ok=True)
def read(p):
    return list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter='\t'))
def write(p,rows):
    with p.open('w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
for n in ['combined_id_manifest.tsv','annotation_mrna.tsv','rso_genome.fai','tau_genome.fai','rso_tau.collinearity','tamarix_defensin_miniprot_models.tsv','source_manifest.json']:
    shutil.copy2(O/'data'/n,D/n)
roster=read(A/'S19_Roster.tsv')
write(D/'S19_RetainedSources.tsv',[dict(species='Reaumuria soongarica' if r['species']=='rso' else 'Tamarix austromongolica',candidate_id=r['protein_id'],display_id=r['member_id'],family=r['family'],source_tier=r['source_tier']) for r in roster])
counts=read(A/'S19_Counts.tsv')
write(D/'S19_Counts.tsv',[{**r,'annotated_catalogue_members':r['annotated_catalogue'],'current_included_total':r['included_total']} for r in counts])
shutil.copy2(A/'S21_Collinear_pairs.tsv',D/'S21_CollinearPairs.tsv')
code=(O/'prepare_plot_data.py').read_text(encoding='utf8')
code=code.replace('==99 and','==106 and')
code=code.replace("{pairkey(r) for r in rows if r['legacy_reader_kept']=='YES'}","{pairkey(r) for r in rows}")
code=code.replace("provisional_catalogue_snapshot_with_corrected_collinearity_reader","shared_reference_proteome_comparison_audit")
code=code.replace("2026-09-08 18:34; shared-rule re-audit pending","2026-09-08 shared nsLTP audit; other family membership retained")
code=code.replace("==28 and summary['direct_amp_pairs']==24","==31 and summary['direct_amp_pairs']==26")
code=code.replace('legacy_pairs=len(legacy)','supplied_latest_pairs=len(legacy)')
code=code.replace('old_five_pairs_exactly_reproduced=True','latest_31_pairs_exactly_reproduced=True')
(F/'prepare_plot_data.py').write_text(code,encoding='utf8')
code=(O/'redraw_figure8.py').read_text(encoding='utf8')
code=code.replace("str(n+m),ha=","(str(n+m)+'*' if r['family']=='nsLTP' else str(n+m)),ha=")
code=code.replace("ax.set_ylim(0,43)","ax.set_ylim(0,45)")
code=code.replace("fig.text(.962,.984,'DRAFT · catalogue classification pending',fontsize=7.5,ha='right',color='#986F46')","fig.text(.962,.984,'Reference-proteome comparison cohort',fontsize=7.5,ha='right',color='#586871')")
code=code.replace("Hatching: additional homology models (Tamarix defensins).","Hatching: additional models. *One reference-dependent nsLTP per species (39/26 without it).")
code=code.replace('(24 pairs); dashed: one end outside it (4 pairs).','(26 pairs); dashed: one end outside it (5 pairs).')
code=code.replace('Figure8_macro_micro_draft','Figure8_comparative_synced_20260909')
code=code.replace('全部28对','全部31对')
code=code.replace('Provisional catalogue · corrected reader · independent genomic scales per row','Shared comparison cohort · corrected reader · independent genomic scales per row')
code=code.replace("catalogue_counts_status='provisional; unchanged snapshot'","catalogue_counts_status='shared audit: Rso 9/18/40; Tamarix 5/7/27'")
(F/'redraw_figure8.py').write_text(code,encoding='utf8')
for script in ['prepare_plot_data.py','redraw_figure8.py']:
    subprocess.run([sys.executable,'-X','utf8',str(F/script)],check=True)
