from pathlib import Path
import csv,collections,re,hashlib,json
P=Path(__file__).resolve().parent
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter='\t'))
manifest=read(P/'MANIFEST_SHA256.tsv')
for r in manifest:
    f=P/r['path'];assert f.stat().st_size==int(r['bytes']) and hashlib.sha256(f.read_bytes()).hexdigest()==r['sha256'],r['path']
A=P/'audit/results'
roster=read(A/'S19_Roster.tsv');ro={r['id']:r for r in roster}
assert len(ro)==106
counts={(sp,f):sum(r['species']==sp and r['family']==f for r in roster) for sp in ['rso','tau'] for f in ['Defensin','Snakin_GASA','nsLTP']}
assert list(counts.values())==[9,18,40,5,7,27]
hits=collections.defaultdict(dict)
for line in (P/'audit/analysis/all_family_cross_species.blast.tsv').read_text().splitlines():
    q,s,pi,al,ql,sl,qs,qe,ss,se,ev,bs=line.split('\t')
    if q.split('__')[0]==s.split('__')[0]:continue
    assert float(ev)<=1e-5
    h=(float(bs),(int(qe)-int(qs)+1)/int(ql),(int(se)-int(ss)+1)/int(sl))
    if s not in hits[q] or h[0]>hits[q][s][0]:hits[q][s]=h
best={q:[s for s,h in hs.items() if h[0]==max(v[0] for v in hs.values())] for q,hs in hits.items()}
pairs=set()
for q in ro:
    if not q.startswith('RSO__') or len(best.get(q,[]))!=1:continue
    s=best[q][0]
    if s in ro and best.get(s)==[q] and min(hits[q][s][1:])>=.5:pairs.add((q,s))
expected={(r['query_id'],r['best_other_id']) for r in read(A/'S20_RBH_pairs.tsv')}
assert pairs==expected and len(pairs)==27
assert all(ro[q]['family']==ro[s]['family'] for q,s in pairs)
blocks=[];cur=None
for line in (P/'figure8/data/rso_tau.collinearity').read_text().splitlines():
    if line.startswith('## Alignment'):
        m=re.fullmatch(r'## Alignment (\d+): score=(\S+) e_value=(\S+) N=(\d+) (\S+)&(\S+) (plus|minus)',line)
        assert m
        cur={'id':m[1],'n':int(m[4]),'chr1':m[5],'chr2':m[6],'pairs':[]};blocks.append(cur)
    elif cur and re.match(r'^\s*\d+-\s*\d+:',line):
        fields=[s.strip() for s in line.split('\t')];cur['pairs'].append((fields[1],fields[2]))
assert len(blocks)==949 and all(b['n']==len(b['pairs']) for b in blocks)
inter=[b for b in blocks if b['chr1'][:3]!=b['chr2'][:3]]
assert len(inter)==588
anchors={(b['id'],q,s) for b in inter for q,s in b['pairs'] if q in ro or s in ro}
assert anchors=={(r['mcscanx_block'],r['rso_gene'],r['tamarix_gene']) for r in read(A/'S21_Collinear_pairs.tsv')}
direct={(b,q,s) for b,q,s in anchors if q in ro and s in ro}
assert len(anchors)==31 and len(direct)==26
assert len({q for b,q,s in direct})==23 and len({s for b,q,s in direct})==24
result={'status':'PASS','verified_payloads':len(manifest),'roster_members':106,'RBH_pairs':27,'interspecies_blocks':588,'candidate_involving_pairs':31,'direct_pairs':26,'distinct_Rso_genes_in_direct_pairs':23,'distinct_Tamarix_genes_in_direct_pairs':24,'MCScanX_rerun':False}
print(json.dumps(result,indent=2))
