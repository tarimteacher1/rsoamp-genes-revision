"""Extract existing author-written annotation text only; no sequence analysis."""
from pathlib import Path
import re, json, csv, hashlib
from collections import Counter
from datetime import datetime
import openpyxl
import pandas as pd

OUT=Path(__file__).parent
ROOT=OUT.parent
SOURCE=ROOT.parent/'跨物种表达_可行性核查_20260909'/'literature'/'giad053_supplemental_files'/'Supplementary_tables.xlsx'
OG=ROOT/'published_orthogroups'/'Orthogroups.tsv'
RULES={
    'defensin_wording':r'\bdefensin\b|gamma[- ]thionin',
    'snakin_gasa_wording':r'\bsnakin\b|\bGASA\d*\b|\bGAST\d*\b|gibberellin[- ]regulated protein',
    'lipid_transfer_wording':r'\blipid[- ]transfer\b|\b(?:nsLTP|LTPG|LTP)\d*\b',
}
regex={k:re.compile(v,re.I) for k,v in RULES.items()}
PRIMARY=['Table S14','Table S15','Table S16','Table S17']
DERIV=['Table S19','Table S20','Table S23','Table S27']
wb=openpyxl.load_workbook(SOURCE,read_only=False,data_only=True)
source_hash=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
records=[]; raw_records=[]; contrasts=[]; scope=[]
for name in PRIMARY+DERIV:
    sh=wb[name]
    max_col=sh.max_column
    max_row=sh.max_row
    start=3 if name in ['Table S19','Table S20'] else 4
    columns=[4,5] if start==3 else [18,19,20]
    annotated=0
    for ri in range(start,max_row+1):
        raw=[sh.cell(ri,c).value for c in range(1,max_col+1)]
        ident=raw[0]
        if not isinstance(ident,str) or not ident.startswith('TC'):
            continue
        cell_matches=[]
        for ci in columns:
            value=sh.cell(ri,ci).value
            if isinstance(value,str):
                for category,pat in regex.items():
                    hit=pat.search(value)
                    if hit:
                        cell_matches.append({'category':category,'cell':sh.cell(ri,ci).coordinate,'matched_text':hit.group(),'source_text':value})
        if not cell_matches:
            continue
        annotated+=1
        categories=sorted(set(x['category'] for x in cell_matches))
        protein=raw[3] if start==3 else raw[17]
        symbol=raw[4] if start==3 else raw[18]
        primary=raw[4] if start==3 else raw[19]
        row_record={'source_sheet':name,'source_excel_row':ri,'source_scope':'primary_DE_union_table' if name in PRIMARY else 'derived_DE_subset_table','TC_GeneID_verbatim':ident,'annotation_wording_matches':';'.join(categories),'protein_description_verbatim':protein,'gene_symbols_verbatim':symbol,'primary_name_verbatim':primary,'matched_cells':';'.join(x['cell'] for x in cell_matches),'matched_words':';'.join(x['matched_text'] for x in cell_matches),'source_workbook_sha256':source_hash}
        records.append(row_record)
        raw_records.append(dict(row_record,source_title=sh.cell(1,1).value,match_details=cell_matches,cells=[{'cell':sh.cell(ri,c).coordinate,'value':sh.cell(ri,c).value,'data_type':sh.cell(ri,c).data_type,'number_format':sh.cell(ri,c).number_format} for c in range(1,max_col+1)]))
        if start==4:
            for begin in [2,6,10,14]:
                values=[sh.cell(ri,c).value for c in range(begin,begin+4)]
                contrasts.append(dict(row_record,contrast_verbatim=sh.cell(2,begin).value,logFC_verbatim=values[0],pvalue_verbatim=values[1],padj_verbatim=values[2],regulation_verbatim=values[3],result_cells=f'{sh.cell(ri,begin).coordinate}:{sh.cell(ri,begin+3).coordinate}',result_state='published_numeric_result' if isinstance(values[0],(float,int)) else 'published_dash_or_blank_no_numeric_result',values_typed_json=json.dumps(values,ensure_ascii=False)))
        else:
            ends=10 if name=='Table S19' else 8
            for ci in range(6,ends):
                value=sh.cell(ri,ci).value
                contrasts.append(dict(row_record,contrast_verbatim=sh.cell(2,ci).value,logFC_verbatim=value,pvalue_verbatim=None,padj_verbatim=None,regulation_verbatim=None,result_cells=sh.cell(ri,ci).coordinate,result_state='published_derived_table_value_no_pvalues_supplied',values_typed_json=json.dumps([value,None,None,None],ensure_ascii=False)))
    scope.append({'sheet':name,'title':sh.cell(1,1).value,'keyword_matched_rows':annotated,'scan_start_excel_row':start,'annotation_column_indices_1_based':columns})

d=pd.DataFrame(records)
c=pd.DataFrame(contrasts)
d.to_csv(OUT/'published_annotation_rows.tsv',sep='\t',index=False,encoding='utf-8-sig')
c.to_csv(OUT/'published_annotation_contrast_values.tsv',sep='\t',index=False,encoding='utf-8-sig')
selected=c[(c.source_sheet=='Table S17')&(c.contrast_verbatim=='SS vs. SCS')]
selected.to_csv(OUT/'S17_SS_vs_SCS_author_annotations.tsv',sep='\t',index=False,encoding='utf-8-sig')
with (OUT/'published_annotation_source_cells.jsonl').open('w',encoding='utf-8') as f:
    for r in raw_records: f.write(json.dumps(r,ensure_ascii=False)+'\n')
primary=d[d.source_sheet.isin(PRIMARY)]
groups=[]
for gene,sub in primary.groupby('TC_GeneID_verbatim',sort=True):
    groups.append({'TC_GeneID_verbatim':gene,'source_occurrences':' | '.join(f'{r.source_sheet}!{r.source_excel_row}' for _,r in sub.iterrows()),'annotation_wording_matches':';'.join(sorted(set(';'.join(sub.annotation_wording_matches).split(';')))),'protein_descriptions_verbatim':' | '.join(dict.fromkeys(sub.protein_description_verbatim.fillna(''))),'primary_names_verbatim':' | '.join(dict.fromkeys(sub.primary_name_verbatim.fillna(''))),'interpretation':'Published annotation keyword occurrence only; not a new family assignment or cross-species pairing.'})
pd.DataFrame(groups).to_csv(OUT/'primary_DE_tables_unique_author_IDs.tsv',sep='\t',index=False,encoding='utf-8-sig')
with OG.open(encoding='utf-8') as f: header=f.readline().rstrip('\r\n').split('\t')
og_audit={'source_file':str(OG),'sha256':hashlib.sha256(OG.read_bytes()).hexdigest(),'header_verbatim':header,'species_columns':header[1:],'Reaumuria_soongarica_column_present':any(re.search(r'soongarica|Reaumuria|^Rso',x,re.I) for x in header[1:]),'interpretation':'No R. soongarica column in this existing orthogroup table; it supplies no Rso-Tchi pairing. No new pairing was created.'}
(OUT/'Orthogroups_header_audit.json').write_text(json.dumps(og_audit,ensure_ascii=False,indent=2),encoding='utf-8')
stats={'timestamp':datetime.now().astimezone().isoformat(),'source_workbook':str(SOURCE),'source_workbook_sha256':source_hash,'matching_rules':RULES,'reviewed_sheets':scope,'total_row_occurrences':len(d),'primary_table_unique_author_IDs':len(groups),'primary_table_wording_groups':dict(Counter(x['annotation_wording_matches'] for x in groups)),'S17_rows':len(selected),'S17_SS_vs_SCS_result_states':selected.result_state.value_counts().to_dict(),'new_sequence_search_performed':False,'new_cross_species_pairing_created':False,'new_family_identification_performed':False}
(OUT/'audit_summary.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(stats,ensure_ascii=False,indent=2))
print(selected[['TC_GeneID_verbatim','protein_description_verbatim','primary_name_verbatim','logFC_verbatim','regulation_verbatim','result_state']].to_string(index=False))
