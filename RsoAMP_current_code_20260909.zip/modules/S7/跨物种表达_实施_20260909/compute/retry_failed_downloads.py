#!/usr/bin/env python3
"""Retry the full manifest after first wave; quarantine invalid HTML responses."""
import csv, datetime, json, pathlib, subprocess, sys, time
root=pathlib.Path(sys.argv[1]); pid=int(sys.argv[2])
while True:
    proc=pathlib.Path('/proc')/str(pid)/'cmdline'
    if not proc.exists(): break
    try: content=proc.read_bytes()
    except FileNotFoundError: break
    if b'download_inputs.py' not in content: break
    time.sleep(20)
raw=root/'raw_fastq'
if (raw/'ALL_DOWNLOADS_VERIFIED.PASS').exists(): raise SystemExit(0)
rows=list(csv.DictReader(open(root/'metadata/fastq_download_manifest.tsv',encoding='utf-8-sig'),delimiter='\t'))
stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
quarantine=raw/('rejected_responses_'+stamp)
for row in rows:
    row['original_url']=row['url']
    row['file_name']=row['url'].rsplit('/',1)[-1]
    row['url'] += '?download=1'
    part=raw/(row['file_name']+'.part')
    if part.exists():
        with open(part,'rb') as fh: magic=fh.read(2)
        if magic!=b'\x1f\x8b':
            quarantine.mkdir(exist_ok=True)
            part.rename(quarantine/part.name)
            print('Quarantined non-gzip response:',part.name,flush=True)
manifest=root/'metadata/fastq_retry_cache_bypass.tsv'
with open(manifest,'w') as fh:
    w=csv.DictWriter(fh,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
subprocess.run(['python3','-u',str(root/'scripts/download_inputs.py'),'--manifest',str(manifest),'--root',str(raw),'--workers','4'],check=True)
