#!/usr/bin/env python3
import collections, csv, datetime, hashlib, json, math, pathlib, subprocess, sys, tarfile
root=pathlib.Path(sys.argv[1]).resolve()
if not (root/'DE_ANALYSIS_COMPLETE.PASS').exists(): raise RuntimeError('DE analysis not complete')
qc=json.loads((root/'quantification_QC.json').read_text())
if len(qc)!=6 or any(r['num_processed']!=r['expected_read_pairs'] for r in qc): raise RuntimeError('Library fragment count audit failed')
for row in qc:
    meta=json.loads((root/'salmon_quant'/row['run']/'aux_info/meta_info.json').read_text())
    row['transcript_assignment_percent']=meta['percent_mapped']
    row['num_decoy_fragments']=meta['num_decoy_fragments']
    row['decoy_fragment_percent']=100*meta['num_decoy_fragments']/meta['num_processed']
    row['num_valid_targets']=meta['num_valid_targets']
    row['quant_errors']=meta['quant_errors']
    row['index_seq_hash']=meta['index_seq_hash']
    row['rate_definition']='Salmon assignment to annotated transcripts; distinct from genome alignment rate'
    row['processed_pairs_match_ENA_and_S12_clean_reads']=row['num_processed']==row['expected_read_pairs']
    row['fastp_total_reads_match_twice_ENA_pair_count']=row['fastp_total_reads']==2*row['expected_read_pairs']
    row['quality_score_interpretation_note']='Archived FASTQ score encoding is simplified: sampled first 10000 R1 records per library all have Phred 30. fastp Q30 is an archive property, not evidence of original instrument quality. No additional quality-score filtering applied.'
    if meta['num_valid_targets']!=46080 or meta['quant_errors']: raise RuntimeError('Target count or quant error audit failed')
if len({r['index_seq_hash'] for r in qc})!=1: raise RuntimeError('Libraries used different transcript index sequences')
(root/'quantification_QC.json').write_text(json.dumps(qc,indent=2))
group_qc=[]
for group in ('CK','Salt'):
    rows=[r for r in qc if r['condition']==group]
    group_qc.append(dict(condition=group,libraries=len(rows),transcript_assignment_percent_min=min(r['transcript_assignment_percent'] for r in rows),transcript_assignment_percent_max=max(r['transcript_assignment_percent'] for r in rows),decoy_fragment_percent_min=min(r['decoy_fragment_percent'] for r in rows),decoy_fragment_percent_max=max(r['decoy_fragment_percent'] for r in rows),library_types=sorted({t for r in rows for t in r['library_types']}),all_pair_counts_match=all(r['processed_pairs_match_ENA_and_S12_clean_reads'] and r['fastp_total_reads_match_twice_ENA_pair_count'] for r in rows)))
(root/'group_technical_QC_summary.json').write_text(json.dumps(group_qc,indent=2))
de=list(csv.DictReader(open(root/'de_results/Tchinensis_all_gene_DE_results.tsv'),delimiter='\t'))
if len(de)!=26426 or len({r['gene_id'] for r in de})!=26426: raise RuntimeError('DE gene universe cardinality failed')
for row in de:
    if row['contrast']!='Salt_vs_CK': raise RuntimeError('DE contrast label failed')
    if row['padj']!='NA' and not 0 <= float(row['padj']) <= 1: raise RuntimeError('FDR outside [0,1]')
    if row['prefilter_pass']=='TRUE':
        expected=row['padj']!='NA' and float(row['padj'])<0.05 and abs(float(row['log2FoldChange']))>1
        if (row['DE_call_wald_padj_and_effect']=='TRUE')!=expected: raise RuntimeError('DE-call formula mismatch')
counts=list(csv.DictReader(open(root/'de_results/gene_estimated_counts.tsv'),delimiter='\t'))
if len(counts)!=26426 or {r['gene_id'] for r in counts}!={r['gene_id'] for r in de}: raise RuntimeError('Count/DE gene universe mismatch')
count_errors={row['run']:sum(float(r[row['run']]) for r in counts)-row['num_mapped'] for row in qc}
if any(abs(v)>1 for v in count_errors.values()): raise RuntimeError('Estimated counts do not sum to mapped fragments: '+str(count_errors))
validation=dict(reference_genes=len(de),gene_IDs_unique=True,contrast='Salt_vs_CK',DE_call_formula_verified=True,FDR_values_valid=True,estimated_count_sum_minus_Salmon_mapped_fragments=count_errors,prefilter_pass=sum(r['prefilter_pass']=='TRUE' for r in de),inference_status_counts=dict(collections.Counter(r['inference_status'] for r in de)),DE_calls=sum(r['DE_call_wald_padj_and_effect']=='TRUE' for r in de),DE_up=sum(r['DE_call_wald_padj_and_effect']=='TRUE' and float(r['log2FoldChange'])>1 for r in de),DE_down=sum(r['DE_call_wald_padj_and_effect']=='TRUE' and float(r['log2FoldChange']) < -1 for r in de))
(root/'scientific_output_validation.json').write_text(json.dumps(validation,indent=2))
if any(not (root/'salmon_quant'/r['run']/'QUANT_COMPLETE.PASS').exists() for r in qc): raise RuntimeError('Missing library completion')
latest={}
for line in (root/'raw_fastq/download_status.jsonl').read_text().splitlines():
    r=json.loads(line)
    if 'download_status' in r: r['manifest_status_at_selection']=r.pop('download_status')
    latest[r['file_name']]=r
if len(latest)!=12 or any(r['status']!='PASS' or r.get('gzip_check')!='PASS' for r in latest.values()): raise RuntimeError('Not all twelve FASTQ files passed final integrity gates')
(root/'final_input_download_validation.json').write_text(json.dumps(list(latest.values()),indent=2))
commands=[['/path/to/user/tools/miniconda3/envs/salmon_env/bin/salmon','--version'],['/path/to/user/tools/miniconda3/envs/starsolo/bin/gffread','--version'],['/path/to/user/tools/miniconda3/envs/salmon_env/bin/fastp','--version'],['/path/to/user/tools/miniconda3/envs/bat_motif_r/bin/Rscript','--version'],['python3','--version']]
with open(root/'software_versions.txt','w') as fh:
    for cmd in commands:
        result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,check=True)
        fh.write(' '.join(cmd)+'\n'+result.stdout+'\n')
files=[]
for dirname in ('scripts','metadata','logs','de_results','read_qc'):
    files.extend(p for p in (root/dirname).rglob('*') if p.is_file())
for run in [r['run'] for r in qc]:
    files.extend(p for p in (root/'salmon_quant'/run).rglob('*') if p.is_file())
for name in ('quantification_QC.json','group_technical_QC_summary.json','scientific_output_validation.json','library_type_review.json','final_input_download_validation.json','software_versions.txt','workflow_status.json','QUANTIFICATION_COMPLETE.PASS','DE_ANALYSIS_COMPLETE.PASS','raw_fastq/download_status.json','raw_fastq/download_status.jsonl','raw_fastq/ALL_DOWNLOADS_VERIFIED.PASS',
             'reference/reference_QC.json','reference/exon_reconstruction_audit.json','reference/download_status.json','reference/transcript_to_gene.tsv',
             'reference/quantification_GFF_removed_features.tsv','reference/salmon_index_full_genome_decoy/versionInfo.json',
             'reference/salmon_index_full_genome_decoy/info.json'):
    p=root/name
    if p.is_file(): files.append(p)
files=sorted(set(files))
manifest=[]
for p in files:
    h=hashlib.sha256()
    with open(p,'rb') as fh:
        for chunk in iter(lambda:fh.read(8*1024*1024),b''):h.update(chunk)
    manifest.append(dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=h.hexdigest()))
with open(root/'COMPUTE_OUTPUTS_SHA256.tsv','w') as fh:
    w=csv.DictWriter(fh,fieldnames=['path','bytes','sha256'],delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(manifest)
bundle=root/'cross_species_compute_outputs_20260909.tar.gz'
with tarfile.open(bundle,'w:gz') as tar:
    for p in files+[root/'COMPUTE_OUTPUTS_SHA256.tsv']:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
h=hashlib.sha256()
with open(bundle,'rb') as fh:
    for b in iter(lambda:fh.read(8*1024*1024),b''):h.update(b)
status=dict(completed=datetime.datetime.now().astimezone().isoformat(),files=len(files),archive=bundle.name,archive_bytes=bundle.stat().st_size,archive_sha256=h.hexdigest(),all_12_FASTQ_integrity=True,all_6_libraries_complete=True,read_pair_counts_match_official=True,interpretation_review_required=True)
(root/'COMPUTE_DELIVERY_STATUS.json').write_text(json.dumps(status,indent=2))
print(json.dumps(status,indent=2))
