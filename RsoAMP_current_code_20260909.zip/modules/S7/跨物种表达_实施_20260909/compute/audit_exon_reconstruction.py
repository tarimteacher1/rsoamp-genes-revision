#!/usr/bin/env python3
import collections,json,pathlib,sys
root=pathlib.Path(sys.argv[1]); ref=root/'reference'
exons=collections.defaultdict(list)
for line in open(ref/'Tchinensis_quantification_exclude_orphan.gff3'):
    f=line.rstrip('\n').split('\t')
    if len(f)!=9 or f[2]!='exon': continue
    d=dict(x.split('=',1) for x in f[8].split(';') if '=' in x)
    for tx in d['Parent'].split(','): exons[tx].append((int(f[3]),int(f[4])))
seqs={}; tx=None; seq=[]
for line in open(ref/'Tchinensis.full_mRNA_from_GFF.fa'):
    if line.startswith('>'):
        if tx: seqs[tx]=''.join(seq)
        tx=line[1:].split()[0];seq=[]
    else: seq.append(line.strip())
if tx: seqs[tx]=''.join(seq)
issues=[]
for tx, intervals in exons.items():
    source=sum(e-s+1 for s,e in intervals)
    actual=len(seqs.get(tx,''))
    if source!=actual: issues.append(dict(transcript=tx,source_exon_length=source,extracted_length=actual,difference=actual-source))
result=dict(transcript_count=len(seqs),gff_exon_transcripts=len(exons),length_mismatch_count=len(issues),mismatches=issues)
(ref/'exon_reconstruction_audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
