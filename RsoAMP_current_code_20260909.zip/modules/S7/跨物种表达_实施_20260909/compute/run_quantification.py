#!/usr/bin/env python3
"""Run six-library Salmon in isolated outputs after integrity gates."""
import argparse, concurrent.futures, csv, datetime, gzip, json, pathlib, subprocess, time
SALMON = '/path/to/user/tools/miniconda3/envs/salmon_env/bin/salmon'
FASTP = '/path/to/user/tools/miniconda3/envs/salmon_env/bin/fastp'
def now(): return datetime.datetime.now().astimezone().isoformat()
def main():
    p=argparse.ArgumentParser(); p.add_argument('--root',required=True); p.add_argument('--threads',type=int,default=24); p.add_argument('--jobs',type=int,default=2); a=p.parse_args()
    root=pathlib.Path(a.root).resolve(); raw=root/'raw_fastq'; ref=root/'reference'; logs=root/'logs'
    if not (ref/'REFERENCE_COMPLETE.PASS').exists(): raise RuntimeError('Reference gate missing')
    entries=list(csv.DictReader(open(root/'metadata/fastq_download_manifest.tsv',encoding='utf-8-sig'),delimiter='\t'))
    expected_pairs={r['run']:int(r['expected_read_pairs']) for r in csv.DictReader(open(root/'metadata/expected_library_pairs.tsv'),delimiter='\t')}
    groups={}
    for r in entries: groups.setdefault(r['run_accession'],[]).append(r)
    samples=[]
    for run, rows in groups.items():
        paper=rows[0]['paper_sample']
        if len(rows)!=2 or {r['mate'] for r in rows}!={'1','2'}: raise RuntimeError('Paired library manifest invalid')
        samples.append(dict(run=run,paper_sample=paper,condition='CK' if paper.startswith('SCS') else 'Salt',replicate=paper[-1]))
    if len(samples)!=6 or sum(r['condition']=='CK' for r in samples)!=3: raise RuntimeError('Expected six libraries, three CK')
    with open(root/'metadata/sample_sheet.tsv','w') as fh:
        w=csv.DictWriter(fh,fieldnames=['run','paper_sample','condition','replicate'],delimiter='\t',lineterminator='\n'); w.writeheader(); w.writerows(samples)
    def quant(row):
        run=row['run']; out=root/'salmon_quant'/run; out.parent.mkdir(exist_ok=True)
        qclog=root/'read_qc'; qclog.mkdir(exist_ok=True)
        r1=raw/(run+'_1.fastq.gz'); r2=raw/(run+'_2.fastq.gz')
        # A completed sample may start before unrelated libraries finish download.
        # Both mates still require explicit official MD5/gzip PASS records.
        deadline=time.monotonic()+3*60*60
        while True:
            latest={}
            status_path=raw/'download_status.jsonl'
            if status_path.exists():
                for line in status_path.read_text().splitlines():
                    try:
                        record=json.loads(line); latest[record['file_name']]=record
                    except (ValueError,KeyError): pass
            verified=all(x.exists() and latest.get(x.name,{}).get('status')=='PASS' and latest[x.name].get('gzip_check')=='PASS' for x in (r1,r2))
            if verified: break
            if time.monotonic()>deadline: raise RuntimeError('Timed out waiting for verified FASTQ mates: '+run)
            time.sleep(20)
        if not (qclog/(run+'.PASS')).exists():
            cmd=[FASTP,'-i',str(r1),'-I',str(r2),'--disable_adapter_trimming','--disable_quality_filtering','--disable_length_filtering','--disable_trim_poly_g','-w','4','-j',str(qclog/(run+'.json')),'-h',str(qclog/(run+'.html'))]
            # Statistics only: no -o/-O outputs, no altered reads enter Salmon.
            with open(logs/(run+'.fastp.log'),'w') as log: subprocess.run(cmd,stdout=log,stderr=log,check=True)
            (qclog/(run+'.PASS')).write_text(now()+'\n')
        fastp_qc=json.loads((qclog/(run+'.json')).read_text())
        if fastp_qc['summary']['before_filtering']['total_reads'] != 2*expected_pairs[run]:
            raise RuntimeError('fastp total reads differs from official read-pair count: '+run)
        if not (out/'QUANT_COMPLETE.PASS').exists():
            if out.exists(): raise RuntimeError('Existing unmarked quant directory requires review: '+run)
            cmd=[SALMON,'quant','-i',str(ref/'salmon_index_full_genome_decoy'),'-l','A','-1',str(r1),'-2',str(r2),'-p',str(a.threads),'--validateMappings','--seqBias','--gcBias','-o',str(out)]
            (logs/(run+'.salmon.command.json')).write_text(json.dumps(cmd,indent=2))
            print(now(),'START_QUANT',run,flush=True)
            with open(logs/(run+'.salmon.log'),'w') as log: subprocess.run(cmd,stdout=log,stderr=log,check=True)
            meta=json.loads((out/'aux_info/meta_info.json').read_text())
            if not (out/'quant.sf').is_file() or meta.get('num_processed',0)<=0: raise RuntimeError('Quant output incomplete')
            if meta['num_processed'] != expected_pairs[run]: raise RuntimeError('Salmon processed fragments differ from official read pairs: '+run)
            (out/'QUANT_COMPLETE.PASS').write_text(now()+'\n')
        meta=json.loads((out/'aux_info/meta_info.json').read_text())
        formats=json.loads((out/'lib_format_counts.json').read_text())
        result=dict(row, expected_read_pairs=expected_pairs[run], fastp_total_reads=fastp_qc['summary']['before_filtering']['total_reads'], fastp_q30_rate=fastp_qc['summary']['before_filtering']['q30_rate'], fastp_gc_content=fastp_qc['summary']['before_filtering']['gc_content'], num_processed=meta.get('num_processed'), num_mapped=meta.get('num_mapped'), percent_mapped=meta.get('percent_mapped'), library_types=meta.get('library_types'), lib_format_counts=formats)
        print(now(),'PASS_QUANT',run,result['percent_mapped'],flush=True)
        return result
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as pool: results=list(pool.map(quant,samples))
    (root/'quantification_QC.json').write_text(json.dumps(results,indent=2))
    inferred={str(r['library_types']) for r in results}
    (root/'library_type_review.json').write_text(json.dumps(dict(inferred_types=list(inferred),consistent_across_samples=len(inferred)==1,warning='Review individual lib_format_counts and mapping rates before biological interpretation; no sample removed by expression direction.'),indent=2))
    (root/'QUANTIFICATION_COMPLETE.PASS').write_text(now()+'\n')
if __name__=='__main__': main()
