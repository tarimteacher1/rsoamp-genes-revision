#!/usr/bin/env python3
import datetime,json,pathlib,subprocess
root='/path/to/rso_project/revision_20260909_cross_species_expression'
command="""cd /path/to/rso_project/revision_20260909_cross_species_expression
date -Is
cat workflow_status.json
du -sh raw_fastq reference
test ! -f raw_fastq/download_status.json || cat raw_fastq/download_status.json
test ! -f quantification_QC.json || cat quantification_QC.json
test ! -f de_results/analysis_parameters_and_counts.txt || cat de_results/analysis_parameters_and_counts.txt
tail -n 5 logs/prepare_reference.log
tail -n 5 logs/salmon_index.log
"""
result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','dxy@example-host',command],capture_output=True,encoding='utf-8')
data=dict(checked=datetime.datetime.now().astimezone().isoformat(),remote_root=root,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
pathlib.Path(__file__).with_name('latest_remote_snapshot.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
print(result.stdout);print(result.stderr)
