#!/usr/bin/env python3
import csv, datetime, json, pathlib, sys
root=pathlib.Path(sys.argv[1]); raw=root/'raw_fastq'
latest={}
if (raw/'download_status.jsonl').exists():
    for line in (raw/'download_status.jsonl').read_text().splitlines():
        try:
            row=json.loads(line);latest[row['file_name']]=row
        except ValueError: pass
status=dict(checked=datetime.datetime.now().astimezone().isoformat(),workflow=json.loads((root/'workflow_status.json').read_text()),
            FASTQ_verified=sum(r['status']=='PASS' for r in latest.values()),
            all_FASTQ_gate=(raw/'ALL_DOWNLOADS_VERIFIED.PASS').exists(),
            reference_complete=(root/'reference/REFERENCE_COMPLETE.PASS').exists(),samples=[])
sheet=root/'metadata/sample_sheet.tsv'
if sheet.exists():
    for row in csv.DictReader(open(sheet),delimiter='\t'):
        run=row['run']; meta=root/'salmon_quant'/run/'aux_info/meta_info.json'
        out=dict(row,quant_complete=(root/'salmon_quant'/run/'QUANT_COMPLETE.PASS').exists())
        if out['quant_complete']:
            info=json.loads(meta.read_text())
            out.update(assignment_percent=info['percent_mapped'],library_types=info['library_types'],processed_pairs=info['num_processed'],decoy_percent=100*info['num_decoy_fragments']/info['num_processed'])
        qc=root/'read_qc'/(run+'.json')
        if qc.exists():
            data=json.loads(qc.read_text())
            out.update(q30_rate=data['summary']['before_filtering']['q30_rate'],GC_rate=data['summary']['before_filtering']['gc_content'])
        status['samples'].append(out)
status['DE_complete']=(root/'DE_ANALYSIS_COMPLETE.PASS').exists()
(root/'compact_progress.json').write_text(json.dumps(status,indent=2))
print(json.dumps(status,indent=2))
