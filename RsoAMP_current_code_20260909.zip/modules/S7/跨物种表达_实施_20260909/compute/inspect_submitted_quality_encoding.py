#!/usr/bin/env python3
import collections, csv, gzip, json, pathlib, sys
root=pathlib.Path(sys.argv[1]); rows=[]
for sample in csv.DictReader(open(root/'metadata/sample_sheet.tsv'),delimiter='\t'):
    quality=collections.Counter(); read_count=0
    path=root/'raw_fastq'/(sample['run']+'_1.fastq.gz')
    with gzip.open(path,'rt') as fh:
        for i in range(10000):
            header=fh.readline()
            if not header: break
            seq=fh.readline();plus=fh.readline();q=fh.readline().rstrip()
            if not header.startswith('@') or not plus.startswith('+') or len(seq.rstrip())!=len(q): raise RuntimeError('Malformed FASTQ record')
            quality.update(ord(c)-33 for c in q);read_count+=1
    rows.append(dict(run=sample['run'],paper_sample=sample['paper_sample'],mate=1,records_inspected=read_count,
                     observed_phred_scores=dict(sorted(quality.items())),distinct_scores=len(quality)))
out=root/'read_qc/submitted_quality_encoding_check.json'
out.write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))
