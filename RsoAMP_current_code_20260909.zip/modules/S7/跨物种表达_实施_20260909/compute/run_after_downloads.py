#!/usr/bin/env python3
"""Persistent orchestrator for already-running, authorized six-library analysis."""
import datetime, json, pathlib, subprocess, sys, time
root=pathlib.Path(sys.argv[1]).resolve()
def state(phase, status, error=None):
    data=dict(phase=phase,status=status,updated=datetime.datetime.now().astimezone().isoformat(),root=str(root))
    if error: data['error']=str(error)
    tmp=root/'workflow_status.json.tmp'; tmp.write_text(json.dumps(data,indent=2)); tmp.replace(root/'workflow_status.json')
    print(data,flush=True)
def wait_download(directory):
    while not (directory/'ALL_DOWNLOADS_VERIFIED.PASS').exists():
        status=directory/'download_status.json'
        if status.exists() and any(r.get('status')=='FAILED' for r in json.loads(status.read_text())):
            raise RuntimeError('Download failure recorded in '+str(status))
        time.sleep(20)
def run(cmd,log):
    with open(root/'logs'/log,'a') as fh: subprocess.run(cmd,stdout=fh,stderr=fh,check=True)
try:
    state('WAIT_GENOME_DOWNLOAD','RUNNING')
    wait_download(root/'reference')
    state('REFERENCE_EXTRACTION_AND_INDEX','RUNNING')
    if '--wait-existing-reference' in sys.argv:
        while not (root/'reference/REFERENCE_COMPLETE.PASS').exists(): time.sleep(20)
    else:
        run(['python3',str(root/'scripts/prepare_reference.py'),'--root',str(root),'--threads','24'],'prepare_reference.log')
    state('READ_QC_AND_SALMON_PER_LIBRARY_DOWNLOAD_GATES','RUNNING')
    run(['python3',str(root/'scripts/run_quantification.py'),'--root',str(root),'--threads','24','--jobs','2'],'quantification.log')
    state('TXIMPORT_DESEQ2','RUNNING')
    run(['/path/to/user/tools/miniconda3/envs/bat_motif_r/bin/Rscript',str(root/'scripts/run_deseq2.R'),str(root)],'deseq2.log')
    state('DE_ANALYSIS_COMPLETE','PASS_REQUIRES_INTERPRETATION_REVIEW')
except Exception as ex:
    state('WORKFLOW_INTERRUPTED','FAILED',ex)
    raise
