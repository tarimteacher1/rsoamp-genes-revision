cat(R.version.string, "\n")
for (p in c("DESeq2", "tximport", "apeglm", "ashr", "ggplot2", "edgeR")) {
  installed <- requireNamespace(p, quietly = TRUE)
  cat(p, if (installed) as.character(packageVersion(p)) else "NOT_INSTALLED", "\n")
}
