args <- commandArgs(trailingOnly=TRUE)
invisible(parse(file=args[1]))
cat("PASS R parse", args[1], "\n")
