#!/usr/bin/env python3
"""Build full exon-derived transcripts and full-genome decoys without changing sources."""
import argparse, collections, csv, datetime, hashlib, json, pathlib, shutil, subprocess
from urllib.parse import unquote

def fasta_ids(path):
    with open(path) as fh:
        return [line[1:].split()[0] for line in fh if line.startswith('>')]

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for b in iter(lambda: fh.read(8*1024*1024), b''): h.update(b)
    return h.hexdigest()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True)
    p.add_argument('--threads', type=int, default=24)
    a = p.parse_args()
    root = pathlib.Path(a.root).resolve(); ref = root / 'reference'; logs = root / 'logs'
    genome = ref / 'Tchinensis.fasta'; gff = ref / 'Tchinensis_quantification_exclude_orphan.gff3'
    if not (ref / 'ALL_DOWNLOADS_VERIFIED.PASS').exists(): raise RuntimeError('Genome download integrity gate missing')
    mapping, gene_ids, mRNA_counts = {}, set(), collections.Counter()
    with open(gff) as fh:
        for line in fh:
            if line.startswith('#'): continue
            f = line.rstrip('\n').split('\t')
            if len(f) != 9: continue
            d = dict(v.split('=', 1) for v in f[8].split(';') if '=' in v)
            if f[2] == 'gene': gene_ids.add(unquote(d['ID']))
            if f[2] in ('mRNA', 'transcript'):
                tx, gene = unquote(d['ID']), unquote(d['Parent'])
                if ',' in gene: raise RuntimeError('Multi-parent transcript requires explicit review')
                if tx in mapping and mapping[tx] != gene: raise RuntimeError('Conflicting GFF transcript parent')
                mapping[tx] = gene; mRNA_counts[tx] += 1
    if len(mapping) != 46080 or len(gene_ids) != 26426: raise RuntimeError('Unexpected quantification GFF cardinalities')
    if set(mapping.values()) - gene_ids: raise RuntimeError('Unknown parent gene')
    if any(n != 1 for n in mRNA_counts.values()): raise RuntimeError('Duplicate transcript feature')
    # CDS/exon conflicts must not silently expand exons in gffread. Reconstruct
    # exactly from official exon features, retaining gene and transcript IDs.
    extraction_gff = ref / 'Tchinensis_exon_features_for_quantification.gff3'
    with open(gff) as source, open(extraction_gff, 'w') as out:
        for line in source:
            fields = line.rstrip('\n').split('\t')
            if line.startswith('#') or (len(fields)==9 and fields[2] in ('gene','mRNA','transcript','exon')):
                out.write(line)
    transcripts = ref / 'Tchinensis.full_mRNA_from_GFF.fa'
    if not transcripts.exists():
        with open(logs / 'gffread.log', 'w') as log:
            subprocess.run(['/path/to/user/tools/miniconda3/envs/starsolo/bin/gffread', str(extraction_gff), '-g', str(genome), '-w', str(transcripts)+'.building'], stdout=log, stderr=log, check=True)
        pathlib.Path(str(transcripts)+'.building').rename(transcripts)
    tids, gids = fasta_ids(transcripts), fasta_ids(genome)
    if len(tids) != len(set(tids)) or len(gids) != len(set(gids)): raise RuntimeError('Duplicated FASTA IDs')
    if set(tids) != set(mapping): raise RuntimeError('Transcript FASTA/GFF ID set mismatch')
    if set(tids) & set(gids): raise RuntimeError('Transcript/genome ID collision')
    subprocess.run(['python3',str(root/'scripts/audit_exon_reconstruction.py'),str(root)],check=True)
    exon_audit=json.loads((ref/'exon_reconstruction_audit.json').read_text())
    if exon_audit['length_mismatch_count'] != 0: raise RuntimeError('Source-exon reconstruction length mismatch')
    with open(ref / 'transcript_to_gene.tsv', 'w') as fh:
        writer = csv.writer(fh, delimiter='\t', lineterminator='\n')
        writer.writerow(['TXNAME', 'GENEID'])
        writer.writerows((t, mapping[t]) for t in tids)
    decoys = ref / 'decoys.txt'; decoys.write_text('\n'.join(gids)+'\n')
    gentrome = ref / 'gentrome.fa'
    if not gentrome.exists():
        with open(str(gentrome)+'.building', 'wb') as out:
            for source in (transcripts, genome):
                with open(source, 'rb') as fh: shutil.copyfileobj(fh, out, 8*1024*1024)
        pathlib.Path(str(gentrome)+'.building').rename(gentrome)
    provenance = dict(transcripts=len(tids), genes=len(gene_ids), genome_sequences=len(gids), transcript_ids_unique=True, genome_ids_unique=True, no_genome_transcript_id_collision=True, missing_transcripts=[], exon_reconstruction='Only gene/mRNA/exon features passed to gffread; all 46080 transcript lengths equal source exon totals', excluded_orphan_transcript='TC08G1595T2: self-parent not a gene; absent from both official CDS and protein; five GFF lines excluded', input_sha256={str(x.name):sha(x) for x in (genome,gff,ref/'Tchinensis.gff3',extraction_gff,transcripts,ref/'transcript_to_gene.tsv')})
    (ref / 'reference_QC.json').write_text(json.dumps(provenance, indent=2))
    index = ref / 'salmon_index_full_genome_decoy'
    if not (index / 'INDEX_COMPLETE.PASS').exists():
        if index.exists(): raise RuntimeError('Unmarked existing index, review before resume')
        cmd = ['/path/to/user/tools/miniconda3/envs/salmon_env/bin/salmon','index','-t',str(gentrome),'-d',str(decoys),'-i',str(index),'-p',str(a.threads),'-k','31','--keepDuplicates']
        (logs/'salmon_index.command.json').write_text(json.dumps(cmd,indent=2))
        with open(logs/'salmon_index.log','w') as log: subprocess.run(cmd,stdout=log,stderr=log,check=True)
        for name in ('versionInfo.json','complete_ref_lens.bin'):
            if not (index/name).is_file(): raise RuntimeError('Incomplete Salmon index: '+name)
        (index/'INDEX_COMPLETE.PASS').write_text(datetime.datetime.now().astimezone().isoformat()+'\n')
    (ref/'REFERENCE_COMPLETE.PASS').write_text(datetime.datetime.now().astimezone().isoformat()+'\n')
    print('PASS full exon-derived transcriptome and full-genome decoy index', flush=True)
if __name__ == '__main__': main()
