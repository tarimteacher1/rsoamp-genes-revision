#!/usr/bin/env python3
"""Download an explicit public-file manifest, with resumability and integrity gates."""
import argparse, concurrent.futures, csv, datetime, gzip, hashlib, json, os, pathlib, subprocess, threading

lock = threading.Lock()
def now(): return datetime.datetime.now().astimezone().isoformat()
def main():
    p = argparse.ArgumentParser()
    p.add_argument('--manifest', required=True)
    p.add_argument('--root', required=True)
    p.add_argument('--workers', type=int, default=3)
    a = p.parse_args()
    root = pathlib.Path(a.root); root.mkdir(parents=True, exist_ok=True)
    logs = root / 'download_logs'; logs.mkdir(exist_ok=True)
    rows = list(csv.DictReader(open(a.manifest, encoding='utf-8-sig'), delimiter='\t'))
    names = [r.get('file_name') or r['url'].rsplit('/', 1)[-1] for r in rows]
    if len(names) != len(set(names)) or any(pathlib.Path(n).name != n for n in names):
        raise ValueError('Duplicate or unsafe destination names')
    def task(pair):
        row, name = pair
        dest = root / name; part = root / (name + '.part')
        expected = int(row.get('expected_bytes') or row.get('file_size'))
        record = dict(row, file_name=name, started=now())
        try:
            if not dest.exists():
                cmd = ['curl', '--fail', '--location', '--retry', '10', '--retry-delay', '10', '--connect-timeout', '30', '--speed-time', '120', '--speed-limit', '1024', '--continue-at', '-', '--output', str(part), row['url']]
                with open(logs / (name + '.curl.log'), 'ab') as log:
                    subprocess.run(cmd, stdout=log, stderr=log, check=True)
                candidate = part
            else: candidate = dest
            if candidate.stat().st_size != expected:
                raise ValueError('Size mismatch: %s != %s' % (candidate.stat().st_size, expected))
            md5 = hashlib.md5(); sha256 = hashlib.sha256()
            with open(candidate, 'rb') as fh:
                for block in iter(lambda: fh.read(8 * 1024 * 1024), b''):
                    md5.update(block); sha256.update(block)
            record.update(actual_bytes=expected, md5=md5.hexdigest(), sha256=sha256.hexdigest())
            if row.get('expected_md5') and row['expected_md5'].lower() != md5.hexdigest():
                raise ValueError('MD5 mismatch')
            if name.endswith('.gz'):
                with gzip.open(candidate, 'rb') as fh:
                    while fh.read(8 * 1024 * 1024): pass
                record['gzip_check'] = 'PASS'
            if candidate == part: os.replace(part, dest)
            record.update(status='PASS', completed=now())
        except Exception as ex:
            record.update(status='FAILED', completed=now(), error=str(ex))
        with lock:
            with open(root / 'download_status.jsonl', 'a', encoding='utf-8') as fh:
                fh.write(json.dumps(record, ensure_ascii=False) + '\n')
            print(now(), record['status'], name, flush=True)
        return record
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
        result = list(pool.map(task, zip(rows, names)))
    (root / 'download_status.json').write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    if not all(r['status'] == 'PASS' for r in result): raise SystemExit(1)
    (root / 'ALL_DOWNLOADS_VERIFIED.PASS').write_text(now() + '\n', encoding='utf-8')
if __name__ == '__main__': main()
