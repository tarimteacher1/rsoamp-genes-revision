#!/usr/bin/env python3
"""Retrieve a completed compute archive and verify every included file locally."""
import csv, datetime, hashlib, json, pathlib, subprocess, tarfile
HERE=pathlib.Path(__file__).resolve().parent
JOB=HERE.parent
REMOTE='/path/to/rso_project/revision_20260909_cross_species_expression'
HOST='dxy@example-host'
def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as fh:
        for b in iter(lambda:fh.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def copy(name,dest):
    subprocess.run(['scp','-q',HOST+':'+REMOTE+'/'+name,str(dest)],check=True)
def main():
    status_path=HERE/'COMPUTE_DELIVERY_STATUS.json'
    copy('COMPUTE_DELIVERY_STATUS.json',status_path)
    status=json.loads(status_path.read_text())
    archive=HERE/status['archive']
    part=archive.with_suffix(archive.suffix+'.part')
    copy(status['archive'],part)
    if part.stat().st_size!=status['archive_bytes'] or digest(part)!=status['archive_sha256']:
        raise RuntimeError('Archive transfer integrity failed')
    part.replace(archive)
    stage=HERE/'verified_results_staging'
    final=HERE/'verified_results'
    if stage.exists() or final.exists(): raise RuntimeError('Destination exists; inspect before extracting')
    stage.mkdir()
    with tarfile.open(archive,'r:gz') as tf:
        for member in tf.getmembers():
            path=(stage/member.name).resolve()
            if not path.is_relative_to(stage.resolve()): raise RuntimeError('Unsafe tar member '+member.name)
            if not member.isfile() and not member.isdir(): raise RuntimeError('Unexpected tar member type')
        tf.extractall(stage,filter='data')
    manifest=list(csv.DictReader(open(stage/'COMPUTE_OUTPUTS_SHA256.tsv',encoding='utf-8-sig'),delimiter='\t'))
    failures=[]
    for row in manifest:
        p=(stage/row['path']).resolve()
        if not p.is_relative_to(stage.resolve()) or not p.is_file():
            failures.append(row['path']+':missing_or_unsafe')
        elif p.stat().st_size!=int(row['bytes']) or digest(p)!=row['sha256']:
            failures.append(row['path']+':size_or_hash_mismatch')
    if failures: raise RuntimeError(json.dumps(failures))
    stage.rename(final)
    result=dict(verified=datetime.datetime.now().astimezone().isoformat(),status='PASS',
                archive_sha256=status['archive_sha256'],file_count=len(manifest),all_file_hashes_match=True,
                root=str(final),remote_root=REMOTE,source_delivery_status=status)
    (HERE/'verified_results_verification.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(result,indent=2,ensure_ascii=False))
if __name__=='__main__':main()
