#!/usr/bin/env Rscript
suppressPackageStartupMessages({ library(tximport); library(DESeq2); library(apeglm) })
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args) == 1)
root <- normalizePath(args[1], mustWork=TRUE)
stopifnot(file.exists(file.path(root, "QUANTIFICATION_COMPLETE.PASS")))
out <- file.path(root, "de_results")
dir.create(out, showWarnings=FALSE)
samples <- read.delim(file.path(root, "metadata/sample_sheet.tsv"), stringsAsFactors=FALSE)
samples$condition <- factor(samples$condition, levels=c("CK", "Salt"))
rownames(samples) <- samples$run
tx2gene <- read.delim(file.path(root, "reference/transcript_to_gene.tsv"), stringsAsFactors=FALSE)
stopifnot(!anyDuplicated(tx2gene$TXNAME), nrow(samples)==6, sum(samples$condition=="CK")==3)
files <- setNames(file.path(root,"salmon_quant",samples$run,"quant.sf"),samples$run)
stopifnot(all(file.exists(files)))
txi <- tximport(files, type="salmon", tx2gene=tx2gene, countsFromAbundance="no")
dds.all <- DESeqDataSetFromTximport(txi, colData=samples, design=~condition)
prefilter <- rowSums(counts(dds.all)) >= 10
universe <- data.frame(gene_id=rownames(dds.all), total_estimated_count=rowSums(txi$counts),
                      rounded_total_count=rowSums(counts(dds.all)), prefilter_pass=prefilter)
dds <- DESeq(dds.all[prefilter, ])
coef <- "condition_Salt_vs_CK"
stopifnot(coef %in% resultsNames(dds))
wald <- results(dds, name=coef, alpha=0.05)
shrink <- lfcShrink(dds, coef=coef, res=wald, type="apeglm", quiet=TRUE)
res <- as.data.frame(wald)
res$gene_id <- rownames(res)
res$log2FC_apeglm <- shrink$log2FoldChange[match(res$gene_id, rownames(shrink))]
res$lfcSE_apeglm <- shrink$lfcSE[match(res$gene_id, rownames(shrink))]
res$DE_call_wald_padj_and_effect <- !is.na(res$padj) & res$padj < 0.05 & abs(res$log2FoldChange) > 1
# Preserve absent tests and filtering; never replace missing inference with zero.
res$inference_status <- ifelse(is.na(res$pvalue), "NO_WALD_PVALUE_COOKS_OR_OTHER",
                        ifelse(is.na(res$padj), "INDEPENDENT_FILTERED", "TESTED_FDR_AVAILABLE"))
res$contrast <- "Salt_vs_CK"
all <- merge(universe, res, by="gene_id", all.x=TRUE, sort=FALSE)
all$inference_status[!all$prefilter_pass] <- "PREFILTER_TOTAL_COUNT_LT_10"
all$contrast <- "Salt_vs_CK"
all <- all[match(universe$gene_id, all$gene_id),]
write.table(all,file.path(out,"Tchinensis_all_gene_DE_results.tsv"),sep="\t",quote=FALSE,row.names=FALSE,na="NA")
write.table(universe,file.path(out,"gene_prefilter.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
saveRDS(dds, file.path(out, "deseq2_dataset.rds"))
export_matrix <- function(m,n) write.table(data.frame(gene_id=rownames(m),m,check.names=FALSE),file.path(out,n),sep="\t",quote=FALSE,row.names=FALSE)
export_matrix(txi$counts, "gene_estimated_counts.tsv")
export_matrix(txi$abundance, "gene_TPM.tsv")
export_matrix(counts(dds, normalized=TRUE), "gene_normalized_counts.tsv")
vsd <- vst(dds, blind=FALSE)
export_matrix(assay(vsd), "gene_VST.tsv")
pca <- plotPCA(vsd, intgroup="condition", returnData=TRUE)
pca$run <- rownames(pca)
write.table(pca,file.path(out,"PCA_coordinates.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
write.table(data.frame(PC=seq_along(attr(pca,"percentVar")),variance_fraction=attr(pca,"percentVar")),file.path(out,"PCA_variance.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
write.table(cor(assay(vsd)),file.path(out,"sample_pearson_correlation.tsv"),sep="\t",quote=FALSE,col.names=NA)
pdf(file.path(out,"DESeq2_QC.pdf"), width=8, height=6)
plotDispEsts(dds)
plotMA(wald, ylim=c(-6,6), main="Wald LFC; Salt vs CK")
plotMA(shrink, ylim=c(-6,6), main="apeglm LFC; Salt vs CK")
print(plotPCA(vsd, intgroup="condition"))
dev.off()
writeLines(capture.output(sessionInfo()),file.path(out,"R_sessionInfo.txt"))
writeLines(capture.output(metadata(wald)),file.path(out,"wald_result_metadata.txt"))
writeLines(c("Design: ~ condition; reference CK; no paired design.",
  "Prefilter: sum rounded estimated counts >= 10 over six libraries.",
  "tximport: countsFromAbundance=no, transcript effective-length offsets retained.",
  "DESeq2 Wald: alpha=0.05; default Cook's and independent filtering retained.",
  "apeglm LFC for visualization; Wald LFC, pvalue, BH padj retained separately.",
  "DE_call requires Wald BH padj <0.05 and observed abs(Wald log2FC)>1; this is not a threshold-null test.",
  "No sample removal based on expression pattern.",
  paste("genes in reference:",nrow(universe),"prefilter pass:",sum(prefilter)),
  paste("Wald FDR available:",sum(!is.na(res$padj)),"DE calls:",sum(res$DE_call_wald_padj_and_effect))),
  file.path(out,"analysis_parameters_and_counts.txt"))
writeLines(format(Sys.time(),"%Y-%m-%dT%H:%M:%S%z"),file.path(root,"DE_ANALYSIS_COMPLETE.PASS"))
cat("PASS six-library transcript-to-gene DESeq2 reanalysis\n")
