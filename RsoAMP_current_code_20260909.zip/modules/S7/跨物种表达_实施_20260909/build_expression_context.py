"""Join frozen candidate annotations to completed native-study DE outputs.

No sequence matching or cross-species gene pairing is performed here.
"""
from pathlib import Path
from datetime import datetime
import json, csv, hashlib
import pandas as pd
import numpy as np

BASE=Path(__file__).parent
OUT=BASE/"results"
def build():
    result_file=BASE/"compute"/"verified_results"/"de_results"/"Tchinensis_all_gene_DE_results.tsv"
    if not result_file.exists():
        raise SystemExit("Waiting for completed and retrieved six-library DE results; no result inferred.")
    rso_file=BASE/"rso_inputs"/"Rso_primary66_existing_DE.tsv"
    annotation_file=BASE/"published_annotations"/"primary_DE_tables_unique_author_IDs.tsv"
    rso=pd.read_csv(rso_file,sep="\t",dtype={"gene_id":str,"member_id":str})
    anno=pd.read_csv(annotation_file,sep="\t",dtype=str,keep_default_na=False)
    tc=pd.read_csv(result_file,sep="\t",dtype={"gene_id":str})
    assert len(anno)==41 and not anno["TC_GeneID_verbatim"].duplicated().any()
    assert rso["member_id"].nunique()==66 and len(rso)==198
    assert not tc["gene_id"].duplicated().any()
    assert set(anno["TC_GeneID_verbatim"]) <= set(tc["gene_id"])
    subset=anno.merge(tc,left_on="TC_GeneID_verbatim",right_on="gene_id",how="left",validate="one_to_one")
    assert len(subset)==41
    OUT.mkdir(exist_ok=True)
    subset.to_csv(OUT/"Tchi_41_published_annotation_context.tsv",sep="\t",index=False,na_rep="NA",encoding="utf-8-sig")
    rso.to_csv(OUT/"Rso_66_native_study_context.tsv",sep="\t",index=False,na_rep="NA",encoding="utf-8-sig")
    def bool_value(v):
        return pd.NA if pd.isna(v) else str(v).lower()=="true"
    long=[]
    for _,r in rso[rso["contrast"].isin(["S200_vs_CK","S400_vs_CK"])].iterrows():
        long.append({
            "study_species":"Reaumuria soongarica","gene_id":r["gene_id"],"display_id":r["member_id"],
            "annotation_group":r["family"],"group_evidence":"Current curated Rso primary annotation cohort",
            "contrast":r["contrast"],"log2FC_MLE":r["log2FoldChange"],
            "log2FC_display_apeglm":r["log2FC_apeglm"],"lfcSE_MLE":r["lfcSE"],
            "pvalue":r["pvalue"],"padj":r["padj"],"DE_call":bool_value(r["DE_call"]),
            "inference_status":r["DE_test_status"],"source_annotation":"",
            "source_occurrences":"", "pairing":"NO_CROSS_SPECIES_PAIRING",
        })
    for _,r in subset.iterrows():
        group={"lipid_transfer_wording":"Published lipid-transfer wording",
               "snakin_gasa_wording":"Published GASA wording"}[r["annotation_wording_matches"]]
        long.append({
            "study_species":"Tamarix chinensis","gene_id":r["gene_id"],"display_id":r["gene_id"],
            "annotation_group":group,"group_evidence":"Authors' annotation wording in original Tables S14-S17",
            "contrast":"SS_vs_SCS","log2FC_MLE":r["log2FoldChange"],
            "log2FC_display_apeglm":r["log2FC_apeglm"],"lfcSE_MLE":r["lfcSE"],
            "pvalue":r["pvalue"],"padj":r["padj"],
            "DE_call":bool_value(r["DE_call_wald_padj_and_effect"]),
            "inference_status":r["inference_status"],
            "source_annotation":r["protein_descriptions_verbatim"],
            "source_occurrences":r["source_occurrences"],"pairing":"NO_CROSS_SPECIES_PAIRING",
        })
    long=pd.DataFrame(long)
    long["DE_call"]=long["DE_call"].astype("boolean")
    assert len(long)==173
    assert not long.duplicated(["study_species","gene_id","contrast"]).any()
    long.to_csv(OUT/"cross_study_context_long.tsv",sep="\t",index=False,na_rep="NA",encoding="utf-8-sig")
    summaries=[]
    for keys,df in long.groupby(["study_species","annotation_group","contrast"],sort=False):
        summaries.append(dict(zip(["study_species","annotation_group","contrast"],keys))|{
          "entries_in_explicit_context_set":len(df),
          "MLE_available":int(df["log2FC_MLE"].notna().sum()),
          "BH_padj_available":int(df["padj"].notna().sum()),
          "DE_up_in_context_set":int((df["DE_call"] & (df["log2FC_MLE"]>0)).sum()),
          "DE_down_in_context_set":int((df["DE_call"] & (df["log2FC_MLE"]<0)).sum()),
          "interpretation":"Counts describe this selected context set only, not family-wide response rates or a between-species test.",
        })
    pd.DataFrame(summaries).to_csv(OUT/"descriptive_counts_with_scope.tsv",sep="\t",index=False,encoding="utf-8-sig")
    # Compare only original S17 rows with an actual numeric report.
    previous=BASE.parent/"跨物种表达_可行性核查_20260909"/"metadata_final"/"S17_SS_vs_SCS_原值6272行_含缺失标记.tsv"
    source=pd.read_csv(previous,sep="\t",dtype=str,keep_default_na=False)
    (OUT/"S17_original_columns.json").write_text(json.dumps(list(source.columns),ensure_ascii=False),encoding="utf-8")
    status={
        "built_at":datetime.now().astimezone().isoformat(),
        "state":"NATIVE_STUDY_DE_JOINED_TO_EXPLICIT_SEPARATE_CONTEXT_SETS",
        "Rso_genes":66,"Tchi_published_annotation_entries":41,
        "cross_species_sequence_pairs_created":0,
        "Tchi_catalogue_is_exhaustive":False,
        "annotation_sets_are_identically_curated":False,
        "between_species_response_rate_test_performed":False,
        "input_sha256":{str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [rso_file,annotation_file,result_file]},
    }
    (OUT/"context_build_validation.json").write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(status,ensure_ascii=False))
if __name__=="__main__":build()
