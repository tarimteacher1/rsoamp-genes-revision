"""Independent local checks on retrieved results; no change to the fitted model."""
from pathlib import Path
import json, hashlib
import pandas as pd
import numpy as np

J=Path(__file__).parent
R=J/"compute/verified_results"
O=J/"results"
O.mkdir(exist_ok=True)
de=pd.read_csv(R/"de_results/Tchinensis_all_gene_DE_results.tsv",sep="\t")
assert len(de)==26426 and not de.gene_id.duplicated().any()
assert de.prefilter_pass.dtype==bool
assert set(de.DE_call_wald_padj_and_effect.dropna().unique())<={True,False}
called=de.DE_call_wald_padj_and_effect.eq(True)
assert not de.loc[~de.prefilter_pass,["log2FoldChange","pvalue","padj","log2FC_apeglm"]].notna().any().any()
assert ((de.padj<0.05)&(de.log2FoldChange.abs()>1)).equals(called)
assert de.loc[~de.prefilter_pass,"DE_call_wald_padj_and_effect"].isna().all()
assert (de.loc[de.padj.notna(),"padj"].between(0,1)).all()
qc=json.loads((R/"quantification_QC.json").read_text())
assert len(qc)==6 and len({r["run"] for r in qc})==6
assert all(r["num_processed"]==r["expected_read_pairs"]==r["fastp_total_reads"]/2 for r in qc)
assert all(r["library_types"]==["IU"] and not r["quant_errors"] for r in qc)
assert len({r["index_seq_hash"] for r in qc})==1
tpm=pd.read_csv(R/"de_results/gene_TPM.tsv",sep="\t",index_col=0)
counts=pd.read_csv(R/"de_results/gene_estimated_counts.tsv",sep="\t",index_col=0)
assert tpm.shape==counts.shape==(26426,6)
assert (tpm.index==counts.index).all() and set(tpm.index)==set(de.gene_id)
assert (tpm>=0).all().all() and (counts>=0).all().all()
assert np.allclose(tpm.sum(),1e6,rtol=1e-7)
prior=J.parent/"跨物种表达_可行性核查_20260909/metadata_final/S17_SS_vs_SCS_原值6272行_含缺失标记.tsv"
old=pd.read_csv(prior,sep="\t",dtype=str,keep_default_na=False)
old["original_log2FC"]=pd.to_numeric(old["SS_vs_SCS_logFC"],errors="coerce")
numeric=old[old.original_log2FC.notna()]
assert len(numeric)==2831 and not numeric.GeneID.duplicated().any()
check=numeric.merge(de,left_on="GeneID",right_on="gene_id",how="left",validate="one_to_one")
assert len(check)==2831 and check.gene_id.notna().all()
check["direction_matches"]=np.sign(check.original_log2FC)==np.sign(check.log2FoldChange)
check.to_csv(O/"S17_numeric_rows_reanalysis_concordance_QC.tsv",sep="\t",index=False,na_rep="NA",encoding="utf-8-sig")
valid=check.log2FoldChange.notna()
report={
 "state":"PASS",
 "all_gene_rows":len(de),"prefilter_pass":int(de.prefilter_pass.sum()),
 "prefilter_excluded_explicit_NA":int((~de.prefilter_pass).sum()),
 "wald_BH_FDR_available":int(de.padj.notna().sum()),
 "DE_up":int((called & (de.log2FoldChange>0)).sum()),
 "DE_down":int((called & (de.log2FoldChange<0)).sum()),
 "samples":len(qc),"same_reference_index":True,
 "all_sample_read_pairs_equal_ENA_S12_clean":True,
 "transcript_assignment_percent_range":[min(r["percent_mapped"] for r in qc),max(r["percent_mapped"] for r in qc)],
 "TPM_column_sums":tpm.sum().to_dict(),
 "original_S17_numeric_rows":len(check),
 "S17_rows_new_LFC_available":int(valid.sum()),
 "S17_direction_concordant":int(check.loc[valid,"direction_matches"].sum()),
 "S17_direction_concordance_fraction":float(check.loc[valid,"direction_matches"].mean()),
 "S17_logFC_spearman_conditional_QC":float(check.loc[valid,["original_log2FC","log2FoldChange"]].corr(method="spearman").iloc[0,1]),
 "concordance_scope":"Conditional check of source-reported DE rows only; not independent validation, not an unbiased genome-wide concordance estimate, and not a cross-species comparison.",
 "quality_score_scope":"Submitted FASTQ quality encoding is extensively simplified; Q30 does not measure original instrument quality.",
 "new_sequence_pairs_created":0,
}
(O/"independent_result_QA.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(report,ensure_ascii=False))
