"""Append new OOXML worksheets without rewriting any original sheet or cell."""
from pathlib import Path
import argparse,csv,datetime,hashlib,json,re,shutil,zipfile,math
from lxml import etree as E
import openpyxl

ROOT=Path(r"/path/to/revision_workspace")
TASK=ROOT/"跨物种表达_实施_20260909"
OUT=Path(__file__).resolve().parent
FORMAL=ROOT/"Genes_lab_handoff_20260908/01_Current_Editing/03_Supplementary/Genes_RsoAMP_Supplementary_Tables_expression_status_20260904.xlsx"
VERIFIED=TASK/"compute/verified_results"
NS="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG="http://schemas.openxmlformats.org/package/2006/relationships"
CT="http://schemas.openxmlformats.org/package/2006/content-types"
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def tsv(p): return list(csv.DictReader(p.open(encoding="utf-8-sig",newline=""),delimiter="\t"))
def write_tsv(p,rows,fields=None):
    if fields is None: fields=list(rows[0]) if rows else []
    with p.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields,delimiter="\t",extrasaction="ignore");w.writeheader();w.writerows(rows)
def now():return datetime.datetime.now().astimezone().isoformat()
SHEET_NAMES=["S40_TchiSampleProvenance","S41_TchiPublishedAnnotations","S42_TchiSelectedExpression","S43_TchiSampleQC"]
REQUIRED=[
 "COMPUTE_OUTPUTS_SHA256.tsv","DE_ANALYSIS_COMPLETE.PASS","QUANTIFICATION_COMPLETE.PASS",
 "quantification_QC.json","final_input_download_validation.json","library_type_review.json",
 "metadata/sample_sheet.tsv","reference/reference_QC.json","reference/exon_reconstruction_audit.json",
 "read_qc/submitted_quality_encoding_check.json",
 "de_results/Tchinensis_all_gene_DE_results.tsv","de_results/gene_estimated_counts.tsv",
 "de_results/gene_TPM.tsv","de_results/gene_prefilter.tsv",
 "de_results/PCA_coordinates.tsv","de_results/PCA_variance.tsv","de_results/sample_pearson_correlation.tsv",
 "de_results/R_sessionInfo.txt","de_results/analysis_parameters_and_counts.txt",
]
SOURCES={
 "sample_provenance":ROOT/"跨物种表达_可行性核查_20260909/metadata_final/SS_SCS六库_原始与clean_reads逐项核验.tsv",
 "fixed_annotations":TASK/"scope_review/固定41条_呈现范围审阅.tsv",
 "author_annotations":TASK/"published_annotations/primary_DE_tables_unique_author_IDs.tsv",
 "frozen_comparison_rules":TASK/"analysis_rules_before_Tchi_DE.md",
 "text_plan":TASK/"manuscript/text_plan_before_results.md",
}
def prepare():
    OUT.mkdir(parents=True,exist_ok=True)
    lock=OUT/"baseline_lock.json"
    if lock.exists():
        record=js(lock)
        if sha(FORMAL)!=record["workbook_sha256"]: raise RuntimeError("Formal workbook changed since staging baseline; ask root to rebase.")
    else:
        snapshot=OUT/"baseline_original_S1_S39.xlsx"
        shutil.copy2(FORMAL,snapshot)
        wb=openpyxl.load_workbook(snapshot,read_only=True,data_only=False)
        record={"created":now(),"formal_workbook":str(FORMAL),"baseline_snapshot":str(snapshot),
            "workbook_sha256":sha(FORMAL),"original_sheets":wb.sheetnames,
            "source_sha256":{k:sha(p) for k,p in SOURCES.items()}}
        assert len(wb.sheetnames)==40 and all(f"S{i}_" in "|".join(wb.sheetnames) for i in range(1,40))
        wb.close()
        lock.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8")
    missing=[p for p in REQUIRED if not (VERIFIED/p).is_file()]
    status={"time":now(),"state":"PREPARED_WAITING_FOR_VERIFIED_COMPUTE" if missing else "INPUT_FILES_PRESENT_NOT_YET_VALIDATED",
       "missing":missing,"no_new_result_values_generated":True,"formal_workbook_modified":False}
    (OUT/"preparation_status.json").write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding="utf-8")
    return record,status
def assert_verified():
    missing=[p for p in REQUIRED if not (VERIFIED/p).is_file()]
    if missing:raise RuntimeError("Results unavailable; no workbook or File S7 generated. Missing: "+", ".join(missing))
    manifest=tsv(VERIFIED/"COMPUTE_OUTPUTS_SHA256.tsv")
    for r in manifest:
        rel=Path(r["path"])
        if rel.is_absolute() or ".." in rel.parts:raise RuntimeError("Unsafe compute manifest path")
        p=VERIFIED/rel
        if not p.is_file() or p.stat().st_size!=int(r["bytes"]) or sha(p)!=r["sha256"]:
            raise RuntimeError("Compute integrity failure: "+r["path"])
    quant=js(VERIFIED/"quantification_QC.json")
    downloads=js(VERIFIED/"final_input_download_validation.json")
    assert len(quant)==6 and len({r["run"] for r in quant})==6
    assert len(downloads)==12 and len({r["file_name"] for r in downloads})==12
    for r in downloads:
        assert r["status"]=="PASS" and r["gzip_check"]=="PASS"
        assert r["md5"].lower()==r["expected_md5"].lower()
        assert int(r["actual_bytes"])==int(r["expected_bytes"])
    for r in quant:
        assert r["num_processed"]==r["expected_read_pairs"]
        assert r["fastp_total_reads"]==2*r["expected_read_pairs"]
    exon=js(VERIFIED/"reference/exon_reconstruction_audit.json")
    assert exon["transcript_count"]==46080 and exon["length_mismatch_count"]==0
    return manifest,quant,downloads
def make_tables(quant,downloads):
    samples=tsv(VERIFIED/"metadata/sample_sheet.tsv");by_run={r["run"]:r for r in samples}
    assert len(by_run)==6
    prov=tsv(SOURCES["sample_provenance"]);assert len(prov)==6
    dl={r["file_name"]:r for r in downloads}
    s40=[]
    for p in prov:
        run=p["run_accession"];s=by_run[run]
        assert s["paper_sample"]==p["paper_sample"]
        r={"paper_sample":p["paper_sample"],"run_accession":run,"BioSample":p["BioSample"],
           "experiment_accession":p["experiment_accession"],"condition":s["condition"],"biological_replicate":s["replicate"],
           "species":"Tamarix chinensis","tissue":"shoot","contrast":"SS versus SCS",
           "treatment":"300 mM NaCl for 7 days" if s["condition"]=="Salt" else "Matched untreated control at 7 days",
           "source_BioProject":"PRJNA855335","source_paper_DOI":"10.1093/gigascience/giad053",
           "reference_dataset_DOI":"10.5524/102417","source_raw_reads":int(p["S12_raw_reads"]),
           "source_clean_reads":int(p["S12_clean_reads"]),"deposited_read_pairs":int(p["ENA_read_count"]),
           "deposited_count_matches":"Source Table S12 clean reads, not raw reads",
           "library_name":p["library_name"],"sample_alias_verbatim":p["sample_alias"]}
        for mate in [1,2]:
            d=dl[f"{run}_{mate}.fastq.gz"];prefix=f"R{mate}_"
            r.update({prefix+"url":d["url"],prefix+"expected_md5":d["expected_md5"],
             prefix+"observed_md5":d["md5"],prefix+"bytes":int(d["actual_bytes"]),
             prefix+"SHA256":d["sha256"],prefix+"gzip_integrity":d["gzip_check"]})
        s40.append(r)
    annotations=tsv(SOURCES["fixed_annotations"]);assert len(annotations)==41
    s41=[dict(r,interpretation="Published DEG-union annotation keyword selection; not a new family assignment, complete inventory, or Rso-Tchi gene pairing.") for r in annotations]
    de=tsv(VERIFIED/"de_results/Tchinensis_all_gene_DE_results.tsv")
    de_by={r["gene_id"]:r for r in de};assert len(de_by)==len(de)==26426
    tpm=tsv(VERIFIED/"de_results/gene_TPM.tsv");tp={r["gene_id"]:r for r in tpm}
    counts=tsv(VERIFIED/"de_results/gene_estimated_counts.tsv");cp={r["gene_id"]:r for r in counts}
    assert set(de_by)==set(tp)==set(cp)
    s42=[]
    for a in annotations:
        gid=a["TC_GeneID"];assert gid in de_by
        r={"gene_id":gid,"published_annotation_group":a["display_group_only"],
           "author_primary_names":a["primary_author_names"],"annotation_selection":"Fixed before new DE results; selected from original published DEG-union tables"}
        r.update(de_by[gid])
        for p in prov:
            run=p["run_accession"];name=p["paper_sample"]
            assert run in tp[gid] and run in cp[gid]
            r["TPM_"+name]=tp[gid][run];r["estimated_count_"+name]=cp[gid][run]
        s42.append(r)
    pca=tsv(VERIFIED/"de_results/PCA_coordinates.tsv")
    pc_by={r["run"]:r for r in pca};assert len(pc_by)==6 and set(pc_by)==set(by_run)
    variance=tsv(VERIFIED/"de_results/PCA_variance.tsv")
    s43=[]
    for q in quant:
        run=q["run"];fq=js(VERIFIED/"read_qc"/f"{run}.json")
        before=fq["summary"]["before_filtering"];pc=pc_by[run]
        r={"paper_sample":by_run[run]["paper_sample"],"run":run,"condition":by_run[run]["condition"],
           "expected_read_pairs":q["expected_read_pairs"],"fastp_total_reads":q["fastp_total_reads"],
           "fastp_total_bases":before.get("total_bases","NOT_REPORTED"),"fastp_q20_rate":before.get("q20_rate","NOT_REPORTED"),
           "archived_fastp_q30_rate":q["fastp_q30_rate"],"fastp_gc_content":q["fastp_gc_content"],
           "quality_score_interpretation":"Archived quality strings show simplification/uniform-score signatures; computed Q30 describes deposited files, not unaltered instrument quality.",
           "quality_encoding_audit":"File S7 compute/read_qc/submitted_quality_encoding_check.json",
           "salmon_processed_fragments":q["num_processed"],"salmon_mapped_fragments":q["num_mapped"],
           "salmon_percent_mapped":q["percent_mapped"],"salmon_inferred_library_types":json.dumps(q["library_types"]),
           "library_format_counts":json.dumps(q["lib_format_counts"],sort_keys=True),
           "PCA_PC1":pc["PC1"],"PCA_PC2":pc["PC2"],
           "PCA_PC1_variance_fraction":variance[0]["variance_fraction"],"PCA_PC2_variance_fraction":variance[1]["variance_fraction"],
           "PCA_input":"DESeq2 VST; blind=FALSE; plotPCA default top variable genes",
           "read_processing":"fastp statistics only; no additional filtering/trimming; deposited reads quantified",
           "no_expression_based_sample_exclusion":True}
        s43.append(r)
    return [s40,s41,s42,s43],{"reference_genes":len(de),"selected_annotations":41,
       "selected_inference_status":dict(__import__("collections").Counter(r["inference_status"] for r in s42))}
def scalar(v):
    if isinstance(v,(bool,int,float)) or v is None:return v
    if v in {"NA","NaN","-",""}:return v
    if isinstance(v,str):
        if v in {"TRUE","FALSE"}:return v=="TRUE"
        if re.fullmatch(r"-?\d+",v) and not (len(v)>1 and v[0]=="0"):return int(v)
        if re.fullmatch(r"-?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?",v):
            f=float(v)
            if math.isfinite(f):return f
    return v
def sheet_xml(rows,header_style):
    root=E.Element(f"{{{NS}}}worksheet",nsmap={None:NS})
    columns=list(rows[0]);ncols=len(columns)
    E.SubElement(root,f"{{{NS}}}dimension",ref=f"A1:{openpyxl.utils.get_column_letter(ncols)}{len(rows)+1}")
    views=E.SubElement(root,f"{{{NS}}}sheetViews");view=E.SubElement(views,f"{{{NS}}}sheetView",workbookViewId="0")
    E.SubElement(view,f"{{{NS}}}pane",ySplit="1",topLeftCell="A2",activePane="bottomLeft",state="frozen")
    cols=E.SubElement(root,f"{{{NS}}}cols")
    for i,h in enumerate(columns,1):E.SubElement(cols,f"{{{NS}}}col",min=str(i),max=str(i),width=str(min(48,max(16,len(h)*0.9))),customWidth="1")
    data=E.SubElement(root,f"{{{NS}}}sheetData")
    for ri,values in enumerate([columns]+[[r.get(c) for c in columns] for r in rows],1):
        row=E.SubElement(data,f"{{{NS}}}row",r=str(ri))
        for ci,value in enumerate(values,1):
            v=scalar(value) if ri>1 else value
            if v is None:continue
            cell=E.SubElement(row,f"{{{NS}}}c",r=f"{openpyxl.utils.get_column_letter(ci)}{ri}")
            if ri==1 and header_style:cell.set("s",header_style)
            if isinstance(v,bool):cell.set("t","b");E.SubElement(cell,f"{{{NS}}}v").text="1" if v else "0"
            elif isinstance(v,(int,float)):E.SubElement(cell,f"{{{NS}}}v").text=str(v)
            else:
                cell.set("t","inlineStr");s=E.SubElement(cell,f"{{{NS}}}is");t=E.SubElement(s,f"{{{NS}}}t");t.text=str(v)
                if str(v)!=str(v).strip():t.set("{http://www.w3.org/XML/1998/namespace}space","preserve")
    E.SubElement(root,f"{{{NS}}}autoFilter",ref=f"A1:{openpyxl.utils.get_column_letter(ncols)}{len(rows)+1}")
    return E.tostring(root,encoding="UTF-8",xml_declaration=True,standalone=True)
def append_workbook(baseline,tables,dest):
    with zipfile.ZipFile(baseline) as z:raw={n:z.read(n) for n in z.namelist()}
    workbook=E.fromstring(raw["xl/workbook.xml"]);rels=E.fromstring(raw["xl/_rels/workbook.xml.rels"])
    types=E.fromstring(raw["[Content_Types].xml"]);sheets=workbook.find(f"{{{NS}}}sheets")
    number=max(int(m.group(1)) for name in raw if (m:=re.fullmatch(r"xl/worksheets/sheet(\d+).xml",name)))
    sid=max(int(s.get("sheetId")) for s in sheets);rid=max(int(r.get("Id")[3:]) for r in rels if re.fullmatch(r"rId\d+",r.get("Id","")))
    header=E.fromstring(raw[f"xl/worksheets/sheet{number}.xml"]).find(f".//{{{NS}}}c[@r='A1']")
    style=header.get("s","0") if header is not None else "0"
    added={}
    for i,(name,rows) in enumerate(zip(SHEET_NAMES,tables),1):
        part=f"xl/worksheets/sheet{number+i}.xml";relid=f"rId{rid+i}"
        E.SubElement(sheets,f"{{{NS}}}sheet",name=name,sheetId=str(sid+i),attrib={f"{{{REL}}}id":relid})
        E.SubElement(rels,f"{{{PKG}}}Relationship",Id=relid,Type=REL+"/worksheet",Target=f"/worksheets/sheet{number+i}.xml".replace("/worksheets/","/xl/worksheets/"))
        E.SubElement(types,f"{{{CT}}}Override",PartName="/"+part,ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")
        added[part]=sheet_xml(rows,style)
    changed={"xl/workbook.xml":workbook,"xl/_rels/workbook.xml.rels":rels,"[Content_Types].xml":types}
    with zipfile.ZipFile(dest,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,data in raw.items():
            if name in changed:data=E.tostring(changed[name],encoding="UTF-8",xml_declaration=True,standalone=True)
            z.writestr(name,data)
        for name,data in added.items():z.writestr(name,data)
    with zipfile.ZipFile(dest) as z:
        untouched=[name for name in raw if name not in changed]
        assert all(raw[name]==z.read(name) for name in untouched)
        assert all(raw[name]==z.read(name) for name in raw if name.startswith("xl/worksheets/"))
    old=openpyxl.load_workbook(baseline,read_only=True,data_only=False);new=openpyxl.load_workbook(dest,read_only=True,data_only=False)
    cells=0
    for name in old.sheetnames:
        a=old[name];b=new[name];assert (a.max_row,a.max_column)==(b.max_row,b.max_column)
        for ar,br in zip(a.iter_rows(),b.iter_rows()):
            for ac,bc in zip(ar,br):
                assert ac.value==bc.value and ac.data_type==bc.data_type,(name,ac.coordinate,ac.value,bc.value)
                cells+=1
    assert new.sheetnames==old.sheetnames+SHEET_NAMES
    assert [new[name].max_row-1 for name in SHEET_NAMES]==[6,41,41,6]
    old.close();new.close()
    return {"old_sheets_preserved":40,"old_S1_S39_cells_plus_README_compared":cells,
      "all_old_worksheet_XML_byte_identical":True,"all_untouched_ZIP_parts_byte_identical":True}
def package_s7(tables):
    folder=OUT/"File_S7_contents";folder.mkdir(exist_ok=True)
    include={}
    def add(p,relative):
        if p.is_file():include[str(relative).replace("\\","/")]=p
    for p in VERIFIED.rglob("*"):
        if not p.is_file():continue
        rel=p.relative_to(VERIFIED);parts=rel.parts
        if p.suffix.lower() in {".fa",".fasta",".faa",".fna",".gff",".gff3",".rds"}:continue
        if any(x in str(rel).lower() for x in ["fastq.gz","rso_full_reference_proteins","query.faa"]):continue
        if parts[0] in {"de_results","read_qc","salmon_quant","metadata","logs","reference","scripts"} or len(parts)==1:
            add(p,Path("compute")/rel)
    for dirname in ["published_annotations","scope_review"]:
        for p in (TASK/dirname).iterdir():
            if p.is_file():add(p,Path(dirname)/p.name)
    for p in (TASK/"reference").iterdir():
        if not p.is_file():continue
        if p.name in {"Tchinensis_gene_expression.csv","Orthogroups.tsv"}:continue
        if p.suffix.lower() in {".json",".tsv",".md",".py"}:add(p,Path("reference_audit")/p.name)
    for p in (TASK/"compute").iterdir():
        if p.is_file() and p.suffix.lower() in {".py",".R"}:add(p,Path("scripts")/p.name)
    add(SOURCES["sample_provenance"],"metadata/source_Table_S12_six_library_match.tsv")
    add(TASK/"analysis_rules_before_Tchi_DE.md","analysis_rules_before_Tchi_DE.md")
    add(OUT/"build_supplement_stage.py","scripts/build_supplement_stage.py")
    add(OUT/"baseline_lock.json","metadata/staging_baseline_provenance.json")
    for name,rows in zip(SHEET_NAMES,tables):add(OUT/(name+".tsv"),Path("tables")/(name+".tsv"))
    readme=OUT/"File_S7_README.md"
    readme.write_text("""# File S7: Public T. chinensis expression context

This package contains reproducible six-library RNA-seq reanalysis outputs and a fixed, literature-selected annotation list. It does not contain a newly identified complete AMP family catalogue or Rso-Tchi gene pairs.

Sources: Liu et al., GigaScience 2023, DOI 10.1093/gigascience/giad053; GigaDB 10.5524/102417; BioProject PRJNA855335. Samples SS1-3 versus matched SCS1-3 represent shoot NaCl treatment at 7 days. Deposited read counts match the original clean-read counts; no claim is made that these downloads are unprocessed raw reads.

The 41 displayed genes were selected before the new differential results from published DEG-union annotations: 33 lipid-transfer-related and 8 GASA/gibberellin-regulated entries. Their source descriptions and cells are retained. Historical DEG selection, differing gene-set definitions and experimental conditions prevent complete-family response-rate comparisons, conserved-ortholog claims or species-effect tests. Reanalysis does not provide independent R. soongarica qRT-PCR or functional validation.

The reference uses exact GFF Parent mapping. One self-parented transcript absent from official protein/CDS files was excluded without guessing a repaired model. Full mRNA was reconstructed from original exon features, avoiding three implicit expansions caused by coding-feature inconsistencies. Reference SHA256 and audits are supplied; genome, protein and CDS sequences are retrieved from the documented official URLs.

Quality strings in sampled deposited reads show simplification/uniform-score signatures. The computed fastp Q30 is retained as a property of archived files and must not be interpreted as evidence of excellent unaltered sequencing-instrument quality. The original quality-encoding audit is included under compute/read_qc.

Reproduction order: verify public downloads against expected bytes, MD5 and gzip integrity; obtain the official genome and GFF; prepare the documented exon-derived reference and full-genome decoy Salmon index; quantify all six libraries with recorded commands; run tximport/DESeq2 and apeglm using the complete reference background; extract the fixed annotation list without using outcome direction as selection. scripts and compute/scripts retain the actual commands and versions; adjust the documented executable paths to the destination environment. The data are estimated counts with effective-length offsets, not rounded TPM. Wald coefficients, shrinkage estimates and filtering states remain distinct.

Tables S40-S43 provide sample provenance, original published annotations, the fixed list's new expression estimates and sample QC. Full gene-level estimated counts, TPM, DE, VST/PCA and quantification diagnostics are in compute. Unknown or untested values remain NA, never zero.

FASTQ files, full reference sequences, and unexecuted homology-query inputs are excluded. This is a submission supplement; it is not claimed to be part of the earlier GitHub snapshot. MANIFEST_SHA256.tsv verifies every included file. Reproducing the analysis requires independently downloading the excluded public inputs.
""",encoding="utf-8")
    add(readme,"README.md")
    manifest=[]
    for relative,p in sorted(include.items()):
        manifest.append({"path":relative,"bytes":p.stat().st_size,"sha256":sha(p)})
    mf=OUT/"File_S7_MANIFEST_SHA256.tsv";write_tsv(mf,manifest)
    dest=OUT/"File_S7_Tchinensis_expression_context_20260909.zip"
    with zipfile.ZipFile(dest,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for relative,p in sorted(include.items()):z.write(p,relative)
        z.write(mf,"MANIFEST_SHA256.tsv")
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        for r in manifest:
            b=z.read(r["path"]);assert len(b)==r["bytes"] and hashlib.sha256(b).hexdigest()==r["sha256"]
    return {"path":str(dest),"bytes":dest.stat().st_size,"sha256":sha(dest),"files_in_manifest":len(manifest),"zip_CRC_pass":True,"all_internal_SHA256_verified":True}
def build():
    lock,status=prepare()
    assert sha(FORMAL)==lock["workbook_sha256"]
    for k,p in SOURCES.items():
        if sha(p)!=lock["source_sha256"][k]:raise RuntimeError("Frozen source changed: "+k)
    manifest,quant,downloads=assert_verified()
    tables,scope=make_tables(quant,downloads)
    for name,rows in zip(SHEET_NAMES,tables):write_tsv(OUT/(name+".tsv"),rows)
    dest=OUT/"Genes_RsoAMP_Supplementary_Tables_S40_S43_staged_20260909.xlsx"
    check=append_workbook(Path(lock["baseline_snapshot"]),tables,dest)
    package=package_s7(tables)
    assert sha(FORMAL)==lock["workbook_sha256"],"Formal source changed during build; rebase before installation."
    validation={"state":"STAGED_VERIFIED_NOT_INSTALLED","time":now(),"formal_source_sha256":lock["workbook_sha256"],
      "formal_source_unchanged":True,"workbook":str(dest),"workbook_sha256":sha(dest),
      "new_sheet_data_rows":dict(zip(SHEET_NAMES,[len(r) for r in tables])),"compute_files_hash_verified":len(manifest),
      "preservation":check,"scope":scope,"File_S7":package,"formal_documents_modified":False}
    (OUT/"validation.json").write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(validation,ensure_ascii=False,indent=2))
if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--prepare",action="store_true");p.add_argument("--build",action="store_true");args=p.parse_args()
    if args.build:build()
    else:
        lock,status=prepare();print(json.dumps(status,ensure_ascii=False,indent=2))
