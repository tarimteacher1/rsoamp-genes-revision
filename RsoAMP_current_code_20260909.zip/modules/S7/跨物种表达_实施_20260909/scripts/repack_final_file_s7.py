"""Package completed results and the frozen Figure S2 without changing the workbook.

This is local staging orchestration. Packaged analytical scripts retain their
project-relative paths and can run after extraction; excluded public read and
reference inputs must be downloaded to rerun the upstream computation.
"""
from pathlib import Path, PurePosixPath
import csv, hashlib, json, zipfile, datetime, shutil

OUT = Path(__file__).resolve().parent
TASK = OUT.parent
ROOT = TASK.parent
PREVIOUS = ROOT / "跨物种表达_可行性核查_20260909"
VERIFIED = TASK / "compute/verified_results"
IMPL = TASK.name
FEAS = PREVIOUS.name
WORKBOOK = OUT / "Genes_RsoAMP_Supplementary_Tables_S40_S43_staged_20260909.xlsx"
FORMAL = ROOT / "Genes_lab_handoff_20260908/01_Current_Editing/03_Supplementary/Genes_RsoAMP_Supplementary_Tables_expression_status_20260904.xlsx"
SHEETS = ["S40_TchiSampleProvenance", "S41_TchiPublishedAnnotations",
          "S42_TchiSelectedExpression", "S43_TchiSampleQC"]

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def js(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

def rows(p):
    with p.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))

def write_tsv(p, data):
    with p.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(data[0]), delimiter="\t")
        w.writeheader()
        w.writerows(data)

def main():
    validation_path = OUT / "validation.json"
    validation = js(validation_path)
    workbook_before = sha(WORKBOOK)
    assert workbook_before == validation["workbook_sha256"]
    formal_before = sha(FORMAL)
    original_manifest = rows(OUT / "File_S7_MANIFEST_SHA256.tsv")
    previous_archive_sha = validation["File_S7"]["sha256"]
    previous_reproduction_check = validation["File_S7"].get("actual_reproduction_check")
    original_tables = {}
    for name in SHEETS:
        hits = [r for r in original_manifest if r["path"].endswith("/" + name + ".tsv")]
        assert len(hits) == 1, (name, len(hits))
        assert sha(OUT / (name + ".tsv")) == hits[0]["sha256"]
        original_tables[name] = hits[0]["sha256"]

    status = js(TASK / "figures/Figure_S2_status.json")
    assert status["phase"] == "COMPLETE_VISUAL_QA_PASS"
    assert status["frozen_for_FileS7_packaging"] is True
    assert status["simulated_data_used"] is False
    assert status["fixed_annotation_rows"] == 41
    assert status["DE_marked_rows"] == 13
    assert status["FDR_unavailable_rows"] == 11
    figure_manifest = rows(TASK / "figures/Figure_S2_outputs_SHA256.tsv")
    for r in figure_manifest:
        p = TASK / "figures" / r["name"]
        assert p.stat().st_size == int(r["bytes"]) and sha(p) == r["sha256"], p
    assert js(TASK / "results/independent_result_QA.json")["state"] == "PASS"
    assert js(TASK / "compute/verified_results_verification.json")["status"] == "PASS"

    include = {}
    banned_suffixes = {".fa", ".fasta", ".faa", ".fna", ".gff", ".gff3", ".rds", ".png"}
    def add(p, rel, allow=False):
        assert p.is_file(), p
        relative = str(rel).replace("\\", "/")
        pp = PurePosixPath(relative)
        assert not pp.is_absolute() and ".." not in pp.parts
        assert not any(x in relative.lower() for x in
                       ["fastq.gz", "query.faa", "rso_full_reference_proteins"])
        assert allow or p.suffix.lower() not in banned_suffixes, p
        assert relative not in include, relative
        include[relative] = p

    for p in VERIFIED.rglob("*"):
        if p.is_file() and p.suffix.lower() not in banned_suffixes:
            rel = p.relative_to(VERIFIED)
            if any(x in str(rel).lower() for x in ["fastq.gz", "query.faa"]):
                continue
            add(p, Path(IMPL) / "compute/verified_results" / rel)
    for dirname in ["published_annotations", "scope_review", "results"]:
        for p in (TASK / dirname).iterdir():
            if p.is_file() and p.suffix.lower() not in banned_suffixes:
                add(p, Path(IMPL) / dirname / p.name)
    for p in (TASK / "reference").iterdir():
        if p.is_file() and p.suffix.lower() in {".json", ".tsv", ".md", ".py"}:
            add(p, Path(IMPL) / "reference_audit" / p.name)
    for p in (TASK / "compute").iterdir():
        if p.is_file() and p.suffix.lower() in {".py", ".r"}:
            add(p, Path(IMPL) / "compute" / p.name)
    add(TASK / "compute/verified_results_verification.json",
        Path(IMPL) / "compute/verified_results_verification.json")
    for name in ["build_expression_context.py", "independent_result_qa.py",
                 "analysis_rules_before_Tchi_DE.md"]:
        add(TASK / name, Path(IMPL) / name)
    for p in (TASK / "rso_inputs").iterdir():
        if p.is_file() and p.suffix.lower() in {".tsv", ".json"}:
            add(p, Path(IMPL) / "rso_inputs" / p.name)
    for p in (TASK / "figures").iterdir():
        if p.is_file() and p.suffix.lower() in {".pdf", ".svg", ".tsv", ".json", ".py", ".txt", ".md"}:
            add(p, Path(IMPL) / "figures" / p.name)
    for name in ["S17_SS_vs_SCS_原值6272行_含缺失标记.tsv",
                 "SS_SCS六库_原始与clean_reads逐项核验.tsv"]:
        add(PREVIOUS / "metadata_final" / name, Path(FEAS) / "metadata_final" / name)
    add(PREVIOUS / "metadata/T_chinensis_PRJNA855335.json",
        Path(FEAS) / "metadata/T_chinensis_PRJNA855335.json")
    for name in SHEETS:
        add(OUT / (name + ".tsv"), Path(IMPL) / "tables" / (name + ".tsv"))
    add(OUT / "baseline_lock.json", Path(IMPL) / "metadata/staging_baseline_provenance.json")
    add(OUT / "build_supplement_stage.py", Path(IMPL) / "scripts/build_supplement_stage.py")
    add(Path(__file__), Path(IMPL) / "scripts/repack_final_file_s7.py")
    # Keep the literal short path referenced by the unchanged S43 worksheet.
    add(VERIFIED / "read_qc/submitted_quality_encoding_check.json",
        "compute/read_qc/submitted_quality_encoding_check.json")

    readme = OUT / "File_S7_README.md"
    readme.write_text(f"""# File S7: Public T. chinensis expression context

This submission supplement contains completed six-library RNA-seq reanalysis, the fixed published-annotation list, independent numerical QA, the actual Figure S2 source data and plotting script, and provenance. It is not claimed to be included in the earlier GitHub snapshot.

## Sources and scope

Liu et al., GigaScience 2023, DOI https://doi.org/10.1093/gigascience/giad053; GigaDB https://doi.org/10.5524/102417; BioProject PRJNA855335. SS1–3 versus SCS1–3 are the shoot 7-day NaCl comparison and matched controls. Downloaded read-pair counts match the paper's **clean** read counts. They are not asserted to be unprocessed instrument reads.

The 41 entries (33 broad lipid-transfer-related annotations and eight GASA/gibberellin-regulated annotations) were fixed from the original authors' Tables S14–S17 before inspection of the new expression results. These historical DEG tables include the target contrast. This is not independent experimental validation, a genome-wide family census, a family discovery analysis using the Rso M2 rules, or a matched ortholog comparison. Differing gene-list ascertainment, salts, tissues and experimental designs prevent unbiased family response-rate, conserved-response or species-effect claims. This analysis cannot replace independent R. soongarica qRT-PCR.

## Layout and direct reproduction of Figure S2

Two sibling directories retain the original analytical scripts' relative paths:

- `{IMPL}/`: final verified compute outputs, `results/`, `figures/`, `published_annotations/`, scope records, `rso_inputs/` with TSV/JSON only, and the actual analysis scripts.
- `{FEAS}/`: the original S17 contrast cells required by the conditional reanalysis QA, the six-library S12 match, and ENA metadata. Original missing `-` cells are not converted to zero.

Extract the whole ZIP, keep both directories together, and from `{IMPL}` run:

```text
python independent_result_qa.py
python build_expression_context.py
python figures/draw_external_expression_figure.py --out reproduced_figure
```

These commands use packaged processed data and do not need original reads or full reference sequences. The supplied PDF/SVG are the frozen, visually reviewed figure. PNG derivatives are omitted. The figure source manifest also documents PNGs produced during the original run; those rows are provenance records, not missing files promised by this package. Use the root `MANIFEST_SHA256.tsv` to verify actual ZIP contents.

Suggested Python package list: pandas, numpy, scipy, matplotlib and **PyMuPDF**. PyMuPDF supplies the `fitz` import used by the plotting script and is required for its PDF inspection and image rendering.

The figure validation records Python 3.13.5, pandas 3.0.3, numpy 2.4.3 and matplotlib 3.10.8. The same runtime used for the successful package reproduction was additionally checked to use PyMuPDF 1.27.2. A matching installation of the verified packages is:

```text
python -m pip install pandas==3.0.3 numpy==2.4.3 matplotlib==3.10.8 PyMuPDF==1.27.2
```

SciPy is a suggested general analysis dependency; its version is not recorded in the figure validation, and it was not installed or required in the successful three-command reproduction in this runtime. No tested SciPy version is claimed.

Analytical scripts use project-relative paths; upstream compute and staging orchestration retain recorded machine paths, which must be adapted to a destination machine. The staging scripts document workbook preservation and are not required to redraw Figure S2.

## Upstream reanalysis and audit

`{IMPL}/compute/verified_results/` contains complete gene-level estimated counts, TPM, DE, VST/PCA outputs, Salmon summaries, read QC, reference audits, download integrity records, command logs and actual compute scripts. Runtime versions are preserved in R session information and compute logs. To rerun upstream analysis, obtain the public FASTQs and official genome/GFF using the documented URLs; validate expected bytes, MD5 and gzip integrity; reconstruct the documented exact exon-derived full mRNA; create the full-genome decoy Salmon index; quantify six libraries; then use the recorded tximport/DESeq2/apeglm workflow with its full reference background. Do not submit TPM as counts or round estimates independently of this workflow.

Gene assignment uses authoritative GFF Parent relationships. One self-parented mRNA absent from official protein/CDS was excluded without guessing a replacement model. Three coding-feature inconsistencies prompted exact original-exon reconstruction rather than gffread's implicit model expansion. The final 46,080 mRNAs all match original exon lengths. Reference sequences and large FASTQs are intentionally excluded; their recorded hashes and download provenance remain.

Deposited quality strings show extensive simplification/uniform-score signatures. The retained fastp Q30 values describe archived files and do not establish excellent original instrument quality. The unchanged Table S43 short reference `compute/read_qc/submitted_quality_encoding_check.json` is supplied as an exact duplicate alias; the canonical copy is inside the verified-results directory.

S40 records six-library design/provenance and actual download verification; S41 retains source wording for the fixed 41 annotations; S42 provides their new DE/TPM/counts with filtering state; S43 provides sample read/quantification/library/PCA diagnostics. NA means unavailable or not tested and is never replaced by zero. The historical S17 concordance is conditional on rows reported with numeric values, not an unbiased or independent validation.

`results/` includes 13 called DE entries and 11 without FDR estimates among the fixed 41, with the original selection limits preserved. No new sequence pairing was performed. Unexecuted homology-query FASTA inputs and full reference FASTA/GFF files are excluded.

Every included file is listed with bytes and SHA-256 in the root manifest. Source-specific manifests inside the archive may also record intentionally excluded upstream files; only the root manifest describes this ZIP's contents.
""", encoding="utf-8")
    add(readme, "README.md")
    manifest = [{"path": relative, "bytes": p.stat().st_size, "sha256": sha(p)}
                for relative, p in sorted(include.items())]
    documentation_repack = None
    if previous_reproduction_check:
        old_by = {r["path"]: r for r in original_manifest}
        new_by = {r["path"]: r for r in manifest}
        assert set(old_by) == set(new_by)
        changes = [p for p in old_by if old_by[p]["sha256"] != new_by[p]["sha256"]]
        assert set(changes) <= {"README.md", IMPL + "/scripts/repack_final_file_s7.py"}, changes
        documentation_repack = {
            "previous_archive_sha256": previous_archive_sha,
            "previous_actual_reproduction_validation": previous_reproduction_check,
            "changed_members": sorted(changes),
            "all_analytical_scripts_inputs_results_and_figures_SHA256_unchanged": True,
            "recalculation_or_redrawing_performed": False,
        }
    mf = OUT / "File_S7_MANIFEST_SHA256.tsv"
    write_tsv(mf, manifest)
    dest = OUT / "File_S7_Tchinensis_expression_context_20260909.zip"
    temporary = OUT / "File_S7_final_build.tmp.zip"
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for relative, p in sorted(include.items()):
            assert sha(p) == next(r["sha256"] for r in manifest if r["path"] == relative), p
            z.write(p, relative)
        z.write(mf, "MANIFEST_SHA256.tsv")
    with zipfile.ZipFile(temporary) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(manifest) + 1
        for r in manifest:
            b = z.read(r["path"])
            assert len(b) == r["bytes"] and hashlib.sha256(b).hexdigest() == r["sha256"]
    assert sha(WORKBOOK) == workbook_before
    assert sha(FORMAL) == formal_before
    assert all(sha(OUT / (name + ".tsv")) == digest for name, digest in original_tables.items())
    temporary.replace(dest)
    package = {
        "path": str(dest), "bytes": dest.stat().st_size, "sha256": sha(dest),
        "files_in_manifest": len(manifest), "zip_CRC_pass": True,
        "all_internal_SHA256_verified": True, "final_figure_frozen": True,
        "figure_PDF_sha256": sha(TASK / "figures/Figure_S2_external_expression_context.pdf"),
        "figure_source_manifest_verified_files": len(figure_manifest),
        "project_relative_layout_preserved": True,
        "reference_sequences_and_unexecuted_query_FASTA_excluded": True,
    }
    validation["File_S7"] = package
    if documentation_repack is not None:
        package["actual_reproduction_check"] = {
            "state": "PASS_CARRIED_FORWARD_FOR_IDENTICAL_ANALYTICAL_CONTENT",
            **documentation_repack,
        }
    validation["final_package_repack"] = {
        "time": datetime.datetime.now().astimezone().isoformat(),
        "workbook_sha256_unchanged": workbook_before,
        "new_table_TSV_SHA256_unchanged": original_tables,
        "formal_source_readonly_SHA256_at_repack": formal_before,
        "formal_source_unchanged_during_repack": True,
        "workbook_or_formal_source_written": False,
    }
    validation_path.write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "File_S7_SHA256.txt").write_text(package["sha256"] + "  " + dest.name + "\n", encoding="utf-8")
    print(json.dumps(package, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
