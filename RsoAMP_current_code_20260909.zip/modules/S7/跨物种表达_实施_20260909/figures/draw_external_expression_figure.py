"""Figure S2 from completed observed data only; no simulated data or pairing."""
from pathlib import Path
import argparse
import json
import hashlib
import platform
import textwrap
from datetime import datetime
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Patch
from matplotlib.lines import Line2D
from matplotlib.gridspec import GridSpec
from matplotlib.colors import Normalize
import fitz

HERE=Path(__file__).parent
ROOT=HERE.parent
FIXED=HERE/'Figure_S2_fixed_author_annotation_rows.tsv'
SAMPLES=['SCS1','SCS2','SCS3','SS1','SS2','SS3']
COLORS={'CK':'#0072B2','Salt':'#D55E00'}
GROUP_COLORS={'lipid_transfer_wording':'#7962A8','snakin_gasa_wording':'#339789'}
GROUP_NAMES={'lipid_transfer_wording':'Lipid transfer-related wording (33)',
             'snakin_gasa_wording':'GASA-related wording (8)'}
NA_COLOR='#D4D7DB'
KEYWORDS=['gene_id','log2FoldChange','padj','log2FC_apeglm','inference_status']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load_inputs(verified):
    files={
        'de':verified/'de_results'/'Tchinensis_all_gene_DE_results.tsv',
        'tpm':verified/'de_results'/'gene_TPM.tsv',
        'pca':verified/'de_results'/'PCA_coordinates.tsv',
        'variance':verified/'de_results'/'PCA_variance.tsv',
        'samples':verified/'metadata'/'sample_sheet.tsv',
        'complete':verified/'DE_ANALYSIS_COMPLETE.PASS',
        'fixed_annotations':FIXED,
    }
    missing=[str(p) for p in files.values() if not p.is_file()]
    if missing:
        raise RuntimeError('Observed, completed inputs required. Missing: '+', '.join(missing))
    frozen=json.loads((HERE/'Figure_S2_fixed_input_scope.json').read_text(encoding='utf-8'))
    assert sha(FIXED)==frozen['sha256'],'Fixed annotation file changed after freezing'
    fixed=pd.read_csv(FIXED,sep='\t').sort_values(['annotation_wording_matches','TC_GeneID_verbatim'],kind='stable')
    assert len(fixed)==41 and fixed.TC_GeneID_verbatim.is_unique
    assert fixed.TC_GeneID_verbatim.tolist()==frozen['gene_IDs_ordered']
    assert fixed.annotation_wording_matches.value_counts().to_dict()=={'lipid_transfer_wording':33,'snakin_gasa_wording':8}
    samples=pd.read_csv(files['samples'],sep='\t')
    assert samples.run.is_unique and samples.paper_sample.is_unique
    assert set(samples.paper_sample)==set(SAMPLES)
    samples=samples.set_index('paper_sample').loc[SAMPLES].reset_index()
    assert list(samples.condition)==['CK']*3+['Salt']*3
    runs=samples.run.tolist()
    tpm=pd.read_csv(files['tpm'],sep='\t').set_index('gene_id')
    assert tpm.index.is_unique and set(runs)<=set(tpm.columns)
    tpm=tpm[runs].apply(pd.to_numeric,errors='raise')
    assert not (tpm<0).any().any()
    tpm.columns=SAMPLES
    de=pd.read_csv(files['de'],sep='\t',na_values=['NA'])
    assert all(k in de for k in KEYWORDS) and de.gene_id.is_unique
    de=de.set_index('gene_id')
    # No current significance or expression value is used to select rows.
    genes=fixed.TC_GeneID_verbatim.tolist()
    m=tpm.reindex(genes)
    log=np.log2(m+1.0)
    row_mean=log.mean(axis=1,skipna=False)
    row_sd=log.std(axis=1,ddof=0,skipna=False)
    z=log.sub(row_mean,axis=0).div(row_sd.replace(0,np.nan),axis=0)
    d=de.reindex(genes)
    states=d.inference_status.fillna('GENE_ABSENT_FROM_REANALYSIS')
    tested=d.padj.notna()
    calls=tested&(d.padj<0.05)&(d.log2FoldChange.abs()>1)
    # All DE marking is derived from MLE and Wald BH padj, never shrunken LFC.
    if 'DE_call_wald_padj_and_effect' in d:
        existing=d.DE_call_wald_padj_and_effect
        for i in existing.dropna().index:
            actual=str(existing.loc[i]).lower() in ('true','1')
            assert actual==bool(calls.loc[i]),f'DE call mismatch: {i}'
    pca=pd.read_csv(files['pca'],sep='\t')
    assert pca.run.is_unique and set(pca.run)==set(runs)
    pca=pca.set_index('run').loc[runs]
    if 'condition' in pca:
        assert list(pca.condition)==list(samples.condition)
    assert np.isfinite(pca[['PC1','PC2']].to_numpy()).all()
    variance=pd.read_csv(files['variance'],sep='\t').set_index('PC').variance_fraction
    table=fixed.set_index('TC_GeneID_verbatim').join(m.add_prefix('TPM_')).join(z.add_prefix('rowZ_')).join(d)
    table['figure_DE_mark']=np.where(calls,'DE',np.where(tested,'tested_criteria_not_met','FDR_unavailable'))
    table['rowZ_state']=np.where(row_sd.isna(),'missing_quantification',np.where(row_sd==0,'no_within_row_variation','defined'))
    table.index.name='gene_id'
    return files,fixed,samples,m,z,d,states,tested,calls,pca,variance,table

def style():
    mpl.rcParams.update({
        'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],
        'font.size':7.5,'axes.titlesize':8,'axes.labelsize':7.5,
        'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,
        'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
        'axes.linewidth':0.55,'xtick.major.width':0.55,'ytick.major.width':0.55,
        'figure.dpi':150,'savefig.facecolor':'white',
    })

def save_and_audit(fig,out,stem,label_artists,input_files,stats):
    out.mkdir(parents=True,exist_ok=True)
    # Save an exact physical canvas; do not silently crop away millimetre sizing.
    for ext in ['pdf','svg']:
        fig.savefig(out/f'{stem}.{ext}')
    for dpi in [300,600]:
        fig.savefig(out/f'{stem}_{dpi}dpi.png',dpi=dpi)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    boxes=[(name,t.get_window_extent(renderer)) for name,t in label_artists]
    overlaps=[]
    for i,(name,b) in enumerate(boxes):
        for name2,b2 in boxes[i+1:]:
            if b.overlaps(b2):
                overlaps.append([name,name2])
    clip=[name for name,b in boxes if b.x0<0 or b.y0<0 or b.x1>fig.bbox.width or b.y1>fig.bbox.height]
    doc=fitz.open(out/f'{stem}.pdf')
    page=doc[0]
    fonts=page.get_fonts(full=True)
    page.get_pixmap(matrix=fitz.Matrix(1.8,1.8),alpha=False).save(out/f'{stem}_preview.png')
    stats.update({
        'figure_width_mm':page.rect.width/72*25.4,'figure_height_mm':page.rect.height/72*25.4,
        'pdf_pages':len(doc),'pdf_font_types':sorted(set(f[2] for f in fonts)),
        'text_labels_checked_for_overlap':len(boxes),'detected_overlap_pairs':overlaps,
        'labels_outside_canvas':clip,'input_sha256':{k:{'path':str(p),'sha256':sha(p)} for k,p in input_files.items()},
        'versions':{'python':platform.python_version(),'matplotlib':mpl.__version__,'numpy':np.__version__,'pandas':pd.__version__},
        'generated_at':datetime.now().astimezone().isoformat(),
        'manual_visual_review_required':True,
    })
    (out/f'{stem}_validation.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
    return stats

def draw(verified,out):
    loaded=load_inputs(verified)
    files,fixed,samples,tpm,z,de,states,tested,calls,pca,variance,table=loaded
    table.to_csv(out/'Figure_S2_plot_data_41_fixed_rows.tsv',sep='\t',encoding='utf-8-sig',na_rep='NA')
    style()
    # Exact panel rectangles are intentional: automatic constrained layout
    # collapses the short horizontal colour bars beside the 41 text labels.
    # Physical-size export plus explicit label-bounding-box audit is used here.
    fig=plt.figure(figsize=(180/25.4,220/25.4),layout=None)
    axp=fig.add_axes([0.13,0.795,0.38,0.14])
    axi=fig.add_axes([0.57,0.777,0.40,0.17]); axi.axis('off')
    fig.suptitle(r'External expression context in $\it{T. chinensis}$',fontsize=10,fontweight='bold')
    fig.text(0.035,0.949,'A   Six-library expression structure',fontsize=8,fontweight='bold')
    text_check=[]
    for paper,run,cond in samples[['paper_sample','run','condition']].itertuples(index=False,name=None):
        x,y=pca.loc[run,['PC1','PC2']]
        axp.scatter(x,y,s=30,c=COLORS[cond],marker='o' if cond=='CK' else '^',edgecolor='white',linewidth=0.6,zorder=3)
        # Annotation is only a sample identifier, with a deterministic offset.
        rank=SAMPLES.index(paper)%3
        offsets=[(4,5),(4,-9),(-4,5)]
        dx,dy=offsets[rank]
        a=axp.annotate(paper,(x,y),xytext=(dx,dy),textcoords='offset points',fontsize=7,
                       ha='right' if dx<0 else 'left',va='bottom')
        text_check.append(('PCA_'+paper,a))
    axp.set_xlabel(f'PC1 ({100*variance.loc[1]:.1f}%)')
    axp.set_ylabel(f'PC2 ({100*variance.loc[2]:.1f}%)')
    axp.spines[['top','right']].set_visible(False)
    axp.margins(x=0.24,y=0.30)
    axp.axhline(0,color='#ECEEF0',lw=0.5,zorder=0)
    axp.axvline(0,color='#ECEEF0',lw=0.5,zorder=0)
    axi.text(0,1.0,'300 mM NaCl, 7 days | shoot',fontweight='bold',va='top',fontsize=8)
    axi.text(0,0.84,'Concurrent controls; 3 libraries per condition',va='top',fontsize=7.2)
    axi.legend(handles=[
        Line2D([],[],marker='o',linestyle='',color=COLORS['CK'],label='SCS: control',markersize=4),
        Line2D([],[],marker='^',linestyle='',color=COLORS['Salt'],label='SS: salt',markersize=4)],
        loc='upper left',bbox_to_anchor=(-0.04,0.76),frameon=False,ncol=2,columnspacing=1,handletextpad=0.3)
    axi.text(0,0.52,'Published annotation wording',fontsize=7.3,fontweight='bold',va='top')
    for j,(group,col) in enumerate(GROUP_COLORS.items()):
        yy=0.37-j*0.14
        axi.add_patch(Rectangle((0,yy-0.025),0.028,0.045,transform=axi.transAxes,color=col,clip_on=False))
        axi.text(0.05,yy,GROUP_NAMES[group],va='center',fontsize=7.2)
    axi.text(0,0.05,'Fixed list from published DE tables; no Rso pairing',va='center',fontsize=7,color='#50535A')

    axh=fig.add_axes([0.31,0.105,0.45,0.585])
    axf=fig.add_axes([0.805,0.105,0.045,0.585])
    axs=fig.add_axes([0.89,0.105,0.055,0.585])
    cmap=mpl.colormaps['RdBu_r'].copy(); cmap.set_bad(NA_COLOR)
    znorm=Normalize(-2,2,clip=True)
    # pcolormesh remains vector in PDF/SVG; each cell reflects observed values.
    im=axh.pcolormesh(np.arange(7)-0.5,np.arange(42)-0.5,np.ma.masked_invalid(z.to_numpy()),
                     cmap=cmap,norm=znorm,edgecolors='white',linewidth=0.25)
    axh.set_xlim(-0.62,5.5);axh.set_ylim(40.5,-0.5)
    axh.set_xticks(range(6),SAMPLES,rotation=0)
    axh.xaxis.tick_top();axh.tick_params(axis='x',length=0,pad=5)
    labels=[f'{r.TC_GeneID_verbatim}  {r.primary_names_verbatim}' for r in fixed.itertuples(index=False)]
    axh.set_yticks(range(41),labels,fontsize=7.1)
    axh.tick_params(axis='y',length=0,pad=6)
    text_check.extend((f'gene_{i}',t) for i,t in enumerate(axh.get_yticklabels()))
    fig.text(0.035,0.727,'B   Fixed published annotation set',fontweight='bold',fontsize=8)
    for y,g in enumerate(fixed.annotation_wording_matches):
        axh.add_patch(Rectangle((-0.62,y-0.5),0.095,1,color=GROUP_COLORS[g],linewidth=0,clip_on=False))
    for x in range(6):
        axh.plot([x-0.46,x+0.46],[-0.65,-0.65],lw=2.5,color=COLORS['CK' if x<3 else 'Salt'],clip_on=False)
    axh.axvline(2.5,color='white',lw=1.5)
    axh.axhline(32.5,color='white',lw=2)
    for spine in axh.spines.values():spine.set_visible(False)
    lfc=de.log2FC_apeglm.to_numpy(float)
    finite=np.abs(lfc[np.isfinite(lfc)])
    lfc_limit=max(2,float(np.ceil(finite.max()))) if len(finite) else 2.0
    fnorm=Normalize(-lfc_limit,lfc_limit,clip=True)
    fim=axf.pcolormesh([-0.5,0.5],np.arange(42)-0.5,np.ma.masked_invalid(lfc[:,None]),
                     cmap=cmap,norm=fnorm,edgecolors='white',linewidth=0.25)
    axf.set_xlim(-0.5,0.5);axf.set_ylim(40.5,-0.5);axf.set_xticks([]);axf.set_yticks([])
    axf.set_title('log$_2$FC\napeglm',fontsize=7.1,pad=8)
    axf.axhline(32.5,color='white',lw=2)
    for spine in axf.spines.values():spine.set_visible(False)
    axs.set_xlim(-0.5,0.5);axs.set_ylim(40.5,-0.5);axs.set_xticks([]);axs.set_yticks([])
    axs.set_title('Wald\nDE',fontsize=7.1,pad=8)
    for i in range(41):
        if calls.iloc[i]:
            axs.scatter(0,i,s=13,color='#25262A',marker='o')
        elif tested.iloc[i]:
            axs.scatter(0,i,s=11,facecolor='white',edgecolor='#B0B4BA',linewidth=0.65,marker='o')
        else:
            axs.text(0,i,'NA',ha='center',va='center',fontsize=6.5,color='#5A5E65')
    for spine in axs.spines.values():spine.set_visible(False)
    caxz=fig.add_axes([0.31,0.061,0.20,0.012])
    caxf=fig.add_axes([0.59,0.061,0.16,0.012])
    axkey=fig.add_axes([0.785,0.020,0.20,0.070]);axkey.axis('off')
    fig.colorbar(im,cax=caxz,orientation='horizontal',ticks=[-2,0,2],extend='both',label='Row Z of log$_2$(TPM + 1)')
    fig.colorbar(fim,cax=caxf,orientation='horizontal',ticks=[-lfc_limit,0,lfc_limit],label='Salt / control log$_2$FC')
    axkey.text(0,0.90,'● DE     ○ criteria not met',fontsize=7,va='top')
    axkey.text(0,0.43,'NA: FDR unavailable',fontsize=7,va='top')
    axkey.add_patch(Rectangle((0,-0.15),0.055,0.24,color=NA_COLOR,transform=axkey.transAxes,clip_on=False))
    axkey.text(0.09,-0.04,'Undefined heatmap value',fontsize=7,va='center')
    stats={'fixed_rows':41,'wording_groups':fixed.annotation_wording_matches.value_counts().to_dict(),
           'row_order':'annotation wording group, then source TC gene ID; no clustering or response-based selection',
           'TPM_missing_gene_IDs':tpm.index[tpm.isna().all(axis=1)].tolist(),
           'rowZ_undefined_gene_IDs':z.index[z.isna().all(axis=1)].tolist(),
           'FDR_unavailable_gene_IDs':de.index[~tested].tolist(),
           'DE_marked_gene_IDs':de.index[calls].tolist(),
           'apeglm_color_limit':lfc_limit,'row_Z_color_limits':[-2,2],
           'PCA_variance_fraction':variance.to_dict(),
           'NA_filled_with_zero':False,'new_cross_species_pairing':False}
    report=save_and_audit(fig,out,'Figure_S2_external_expression_context',text_check,files,stats)
    plt.close(fig)
    write_caption(out,report)
    print(json.dumps(report,ensure_ascii=False,indent=2))

def write_caption(out,stats):
    caption="""Figure S2. External expression context in Tamarix chinensis.
(A) Principal component analysis of the six reanalysed shoot RNA-seq libraries from the published T. chinensis study (PRJNA855335). SS1–SS3 received 300 mM NaCl for 7 days after a 2-h 200 mM NaCl pretreatment; SCS1–SCS3 are contemporaneous controls. Coordinates were obtained from DESeq2 variance-stabilized expression using the 500 most variable genes, without selecting the 41 annotated entries shown in panel B. Axis labels indicate the fractions of variance explained.
(B) All 41 distinct author gene identifiers retrieved from annotation text in published Tables S14–S17 are displayed in a fixed order by wording group and TC identifier. These consist of 33 entries with broad lipid-transfer-related annotation wording and eight with GASA/gibberellin-regulated-protein wording. Labels retain the original TC identifiers and author-supplied primary names. The set includes EARLI1/AZI1, DIR1 and LTPG/xylogen-related annotations and is not a newly curated nsLTP or Snakin catalogue. Expression heatmap colours show row Z-scores of log2(TPM + 1) across the six libraries (population standard deviation); the displayed Z-score scale is clipped at ±2. TPM values were obtained from the new Salmon/tximport reanalysis, not from the published CSV of unconfirmed units. Grey expression cells indicate unavailable quantification or an undefined Z-score for a row without within-row variation; all six grey expression rows in this reanalysis have zero estimated TPM in all six libraries, which does not establish absence of expression under other conditions. The adjacent effect column shows apeglm-shrunken log2 fold changes for salt relative to control; unavailable effects are grey. Filled circles mark genes meeting both Wald BH-adjusted P < 0.05 and absolute unshrunken (MLE) log2 fold change > 1. Open circles indicate available FDR estimates that do not meet both criteria; NA indicates that no FDR estimate is available. This marking uses the unshrunken coefficient, separately from the displayed apeglm effect, and does not constitute a threshold-null test of an effect exceeding one. Low-count, prefiltered rows can still show coloured expression cells because the heatmap represents within-row relative values; these colours alone do not indicate statistically significant change.
The 41-entry set was fixed from published annotations before inspecting the new expression results. It was historically selected through differential-expression tables spanning multiple tissues, time points and contrasts, including the target contrast; it is therefore not a genome-wide family census and should not be used to infer unbiased family response rates. Missing published results and absent keyword matches do not establish absence of a gene, family membership or salt responsiveness. This figure provides external expression context: the T. chinensis NaCl/shoot experiment differs from the R. soongarica Na2SO4/tender-leaf experiment, and no row-wise Rso–Tc correspondence, orthology, conserved response or species-effect comparison is inferred. This secondary analysis does not constitute independent experimental validation.
Source: Liu et al. (2023), GigaScience 12, giad053, doi:10.1093/gigascience/giad053; supporting data doi:10.5524/102417. Details of the reanalysis, filtering and unavailable inference states are retained in the accompanying evidence tables.
"""
    (out/'Figure_S2_legend_EN.txt').write_text(caption,encoding='utf-8')
    chinese="""图 S2. 中华柽柳的外部表达背景。
（A）对已发表中华柽柳研究（PRJNA855335）的六个地上部组织 RNA-seq 文库重新分析。SS1–SS3 为 200 mM NaCl 预处理 2 h 后以 300 mM NaCl 处理 7 d；SCS1–SCS3 为同期对照。PCA 使用 DESeq2 方差稳定化后变异最大的 500 个基因，不以 B 面板的 41 个条目筛选 PCA 输入。坐标轴标出解释的方差比例。
（B）展示从原作者补表 S14–S17 注释文字中检索得到的全部 41 个不同 TC 基因编号，包括 33 个带广义 lipid-transfer 相关措辞的条目和 8 个带 GASA/gibberellin-regulated-protein 措辞的条目。先按注释措辞组别、再按 TC 编号排序，保留原作者编号及主名称。该集合包括 EARLI1/AZI1、DIR1 和 LTPG/xylogen 等名称，不是重新鉴定的严格 nsLTP 或 Snakin 家族目录。表达热图为新 Salmon/tximport 重分析 TPM 经 log2(TPM+1) 转换后，按行在六个文库间计算的 Z 分数，标准差采用总体标准差；展示色阶限制为 ±2。没有使用单位未确认的原发表 CSV 作为本图 TPM 来源。灰色表达格表示定量缺失或无行内变异导致 Z 分数未定义；本次六个全灰表达行在六库中均为零估计 TPM，不能据此推断基因在所有条件下均不表达。右侧色列表示盐处理相对对照的 apeglm 收缩 log2 倍数变化，缺失效应为灰色。实心圆表示同时满足 Wald BH 调整后 P<0.05 和未收缩 MLE |log2FC|>1；空心圆表示有 FDR 数值但不同时满足两项条件；NA 表示 FDR 不可用。显著性标记使用 MLE，与展示用的 apeglm 效应分开，不是针对效应超过 1 的阈值原假设检验。低计数预过滤而标记为 NA 的行仍可能有热图颜色，因为颜色表示行内相对值，不能单凭颜色判定显著变化。
41 个条目在查看本次重分析表达结果之前已按已发表注释固定，但其历史来源为包含当前目标比较及其他组织、时间点和比较的差异基因表，存在选择偏倚。因此它不是全基因组家族普查，也不能用于推断无偏的家族响应比例。原表缺失值或未命中文字关键词不证明基因缺失、家族归属或不响应。本图仅提供外部表达背景：中华柽柳为 NaCl/地上部组织实验，与红砂 Na2SO4/嫩叶实验不同；未建立逐行 Rs–Tc 对应、直系同源、保守响应或物种效应比较，也不构成独立实验验证。
来源：Liu et al.（2023），GigaScience 12，giad053，doi:10.1093/gigascience/giad053；支持数据 doi:10.5524/102417。重分析方法、过滤及不可检验状态保存在配套证据表中。
"""
    (out/'Figure_S2_legend_ZH.txt').write_text(chinese,encoding='utf-8')

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--verified-results',type=Path,default=ROOT/'compute'/'verified_results')
    ap.add_argument('--out',type=Path,default=HERE)
    args=ap.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    draw(args.verified_results,args.out)
