from pathlib import Path
import csv,json,hashlib,datetime
P=Path(__file__).resolve().parent
ROOT=P.parents[1]
API=ROOT/"跨物种表达_可行性核查_20260909/literature/reference/gigadb_102417_files.json"
items=json.loads(API.read_text())["data"]["data"]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
downloads=[]
for entry in items:
    p=P/entry["file_name"]
    if not p.is_file():continue
    downloads.append({"file":p.name,"public_url":entry["url"],
       "expected_API_bytes":entry["file_size"],"actual_bytes":p.stat().st_size,
       "byte_size_matches_API":p.stat().st_size==entry["file_size"],"local_SHA256":sha(p),
       "upstream_MD5":entry.get("file_attributes",{}).get("MD5 checksum",""),
       "upstream_MD5_verification":"UNAVAILABLE_NO_PUBLISHER_MD5_IN_API"})
critical={"Tchinensis.gff3","Tchinensis_cds.fa","Tchinensis_pep.fa","Tchinensis_gene_expression.csv"}
assert critical<={r["file"] for r in downloads}
assert all(r["byte_size_matches_API"] for r in downloads if r["file"] in critical)
(P/"official_downloads_verified.json").write_text(json.dumps(downloads,ensure_ascii=False,indent=2),encoding="utf-8")
rows=[]
for p in sorted(P.iterdir()):
    if p.is_file() and p.name!="reference_delivery_SHA256.tsv":
        rows.append({"file":p.name,"bytes":p.stat().st_size,"sha256":sha(p)})
with (P/"reference_delivery_SHA256.tsv").open("w",encoding="utf-8-sig",newline="") as f:
    w=csv.DictWriter(f,fieldnames=["file","bytes","sha256"],delimiter="\t");w.writeheader();w.writerows(rows)
print(json.dumps({"time":datetime.datetime.now().astimezone().isoformat(),"files_hashed":len(rows),
 "critical_official_file_sizes_verified":sorted(critical),
 "source_API_SHA256":sha(API)},ensure_ascii=False,indent=2))
