from pathlib import Path
import csv,json,hashlib,re,collections,datetime,warnings
from Bio import SeqIO
from Bio.Seq import Seq
ROOT=Path(r"/path/to/revision_workspace")
OUT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,rows,fields=None):
    if fields is None:fields=list(rows[0])
    with (OUT/name).open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields,delimiter="\t",extrasaction="ignore")
        w.writeheader();w.writerows(rows)
source_paths={
 "gff":OUT/"Tchinensis.gff3","cds":OUT/"Tchinensis_cds.fa","protein":OUT/"Tchinensis_pep.fa",
 "expression":OUT/"Tchinensis_gene_expression.csv",
 "S17":ROOT/"跨物种表达_可行性核查_20260909/metadata_final/S17_SS_vs_SCS_原值6272行_含缺失标记.tsv",
 "official_api":ROOT/"跨物种表达_可行性核查_20260909/literature/reference/gigadb_102417_files.json",
}
hashes={k:sha(p) for k,p in source_paths.items()}
genes={};tx={};features=collections.Counter();keys=collections.Counter()
children=collections.defaultdict(lambda:collections.defaultdict(list))
duplicate_gene=[];duplicate_tx=[];bad_rows=[];bad_parent_rows=[]
for line_number,line in enumerate(source_paths["gff"].open(),1):
    if line.startswith("#"):continue
    f=line.rstrip("\n").split("\t")
    if len(f)!=9:bad_rows.append(line_number);continue
    seqid,source,kind,start,end,score,strand,phase,attribute=f
    attrs=dict(x.split("=",1) for x in attribute.split(";") if "=" in x)
    keys.update(attrs.keys());features[kind]+=1
    record={"id":attrs.get("ID",""),"seqid":seqid,"start":int(start),"end":int(end),"strand":strand,"phase":phase,"parent":attrs.get("Parent",""),"source_row":line_number}
    if kind=="gene":
        if record["id"] in genes:duplicate_gene.append(record["id"])
        genes[record["id"]]=record
    elif kind=="mRNA":
        if record["id"] in tx:duplicate_tx.append(record["id"])
        tx[record["id"]]=record
    else:
        for parent in record["parent"].split(","):
            if parent:children[parent][kind].append(record)
assert not bad_rows and not duplicate_gene and not duplicate_tx
orphan_transcripts={tid for tid,t in tx.items() if t["parent"] not in genes}
assert all(k in tx for k in children)
pep_records=list(SeqIO.parse(source_paths["protein"],"fasta"))
cds_records=list(SeqIO.parse(source_paths["cds"],"fasta"))
pep={r.id:str(r.seq) for r in pep_records}
assert all(r.id.endswith("-CDS") for r in cds_records)
cds={r.id[:-4]:str(r.seq).upper() for r in cds_records}
assert len(pep)==len(pep_records) and len(cds)==len(cds_records)
assert set(pep)<=set(tx) and set(cds)<=set(tx)
expr=list(csv.DictReader(source_paths["expression"].open(encoding="utf-8-sig")))
expr_ids={r["Gene ID"] for r in expr}
s17=list(csv.DictReader(source_paths["S17"].open(encoding="utf-8-sig"),delimiter="\t"))
s17_ids={r["GeneID"] for r in s17}
assert len(expr_ids)==len(expr) and expr_ids<=set(genes) and s17_ids<=expr_ids
per_gene=collections.defaultdict(list)
qc=[];exceptions=[]
for transcript_id,t in tx.items():
    if t["parent"] in genes:per_gene[t["parent"]].append(transcript_id)
    c=cds.get(transcript_id);p=pep.get(transcript_id)
    exons=children[transcript_id]["exon"];cfeatures=children[transcript_id]["CDS"]
    strand=t["strand"]
    ordered=sorted(cfeatures,key=lambda x:x["start"],reverse=strand=="-")
    phases=[r["phase"] for r in ordered]
    c_feature_len=sum(r["end"]-r["start"]+1 for r in ordered)
    exon_len=sum(r["end"]-r["start"]+1 for r in exons)
    phase_continuity=[]
    if ordered:
        cumulative=ordered[0]["end"]-ordered[0]["start"]+1-int(ordered[0]["phase"])
        for feature in ordered[1:]:
            expected=(3-cumulative%3)%3
            phase_continuity.append(int(feature["phase"])==expected)
            cumulative+=feature["end"]-feature["start"]+1
    translated=""
    if c:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            translated=str(Seq(c).translate())
    normalize=lambda s:s[:-1] if s.endswith("*") else s
    match=bool(c is not None and p is not None and normalize(translated)==normalize(p))
    exon_overlap=False
    ex_sorted=sorted(exons,key=lambda x:x["start"])
    for a,b in zip(ex_sorted,ex_sorted[1:]):
        if a["end"]>=b["start"]:exon_overlap=True
    cds_in_exons=all(any(e["start"]<=q["start"] and q["end"]<=e["end"] for e in exons) for q in cfeatures)
    child_consistency=all(q["seqid"]==t["seqid"] and q["strand"]==strand and t["start"]<=q["start"]<=q["end"]<=t["end"] for group in children[transcript_id].values() for q in group)
    gene=genes.get(t["parent"])
    gene_consistency=bool(gene and gene["seqid"]==t["seqid"] and gene["strand"]==strand and gene["start"]<=t["start"]<=t["end"]<=gene["end"])
    flags=[]
    if transcript_id in orphan_transcripts:flags.append("MRNA_PARENT_NOT_A_GENE")
    if c is None:flags.append("CDS_FASTA_MISSING")
    if p is None:flags.append("PROTEIN_FASTA_MISSING")
    if c and len(c)%3:flags.append("CDS_LENGTH_NOT_MULTIPLE_OF_3")
    if c and not c.startswith("ATG"):flags.append("NON_ATG_OR_PARTIAL_START")
    if c and c[-3:] not in {"TAA","TAG","TGA"}:flags.append("NO_TERMINAL_STOP")
    if c and "*" in normalize(translated):flags.append("INTERNAL_TRANSLATION_STOP")
    if p and "*" in normalize(p):flags.append("INTERNAL_PROTEIN_STOP")
    if c and p and not match:flags.append("TRANSLATION_MISMATCH")
    if c and c_feature_len not in {len(c),len(c)-3,len(c)+3}:flags.append("GFF_CDS_LENGTH_DIFFERENCE_GT_TERMINAL_STOP")
    if any(not q for q in phase_continuity):flags.append("CDS_PHASE_DISCONTINUITY")
    if not ordered:flags.append("NO_CDS_FEATURE")
    if not exons:flags.append("NO_EXON_FEATURE")
    if exon_overlap:flags.append("OVERLAPPING_EXON_SEGMENTS")
    if not cds_in_exons:flags.append("CDS_NOT_CONTAINED_IN_EXON")
    if not child_consistency:flags.append("CHILD_COORDINATE_INCONSISTENCY")
    if not gene_consistency:flags.append("GENE_TRANSCRIPT_COORDINATE_INCONSISTENCY")
    row={
     "transcript_id":transcript_id,"gene_id":t["parent"],"chromosome":t["seqid"],"strand":strand,
     "CDS_FASTA_original_id":transcript_id+"-CDS" if c is not None else "",
     "transcript_start":t["start"],"transcript_end":t["end"],
     "exon_count":len(exons),"full_mRNA_exon_length_nt":exon_len,
     "CDS_feature_count":len(ordered),"CDS_feature_total_length_nt":c_feature_len,
     "CDS_FASTA_length_nt":len(c) if c is not None else "",
     "CDS_vs_GFF_feature_length_difference":len(c)-c_feature_len if c is not None else "",
     "protein_length_aa":len(p) if p is not None else "",
     "has_five_prime_UTR_features":bool(children[transcript_id]["five_prime_UTR"]),
     "has_three_prime_UTR_features":bool(children[transcript_id]["three_prime_UTR"]),
     "exon_bases_outside_CDS":exon_len-c_feature_len,
     "protein_present":p is not None,"CDS_present":c is not None,
     "translation_matches_after_only_terminal_stop_removal":match,
     "CDS_phase_consistent":all(phase_continuity),"CDS_contained_in_exons":cds_in_exons,
     "GFF_gene_parent_mapping":"EXACT_GFF_MRNA_PARENT",
     "gene_in_published_expression":t["parent"] in expr_ids,
     "gene_in_S17_union_DEGs":t["parent"] in s17_ids,
     "qc_flags":";".join(flags) if flags else "PASS",
     "protein_sha256":hashlib.sha256(p.encode()).hexdigest() if p else "",
     "CDS_sha256":hashlib.sha256(c.encode()).hexdigest() if c else "",
    }
    qc.append(row)
    if flags:exceptions.append(row)
write("official_tx2gene.tsv",[{"transcript_id":tid,"gene_id":t["parent"]} for tid,t in tx.items() if tid not in orphan_transcripts])
write("official_protein_tx2gene.tsv",[{"protein_id":tid,"transcript_id":tid,"gene_id":tx[tid]["parent"]} for tid in pep])
write("official_CDS_tx2gene.tsv",[{"CDS_FASTA_id":tid+"-CDS","transcript_id":tid,"gene_id":tx[tid]["parent"],"ID_conversion":"REMOVE_EXPLICIT_TERMINAL_-CDS_MATCH_GFF_MRNA"} for tid in cds])
write("transcript_reference_QC.tsv",qc)
write("transcript_reference_QC_exceptions.tsv",exceptions)
grows=[]
for gene_id,g in genes.items():
    transcripts=per_gene[gene_id];available=[t for t in transcripts if t in pep]
    assert available
    representative=sorted(available,key=lambda tid:(-len(pep[tid]),tid))[0]
    grows.append({"gene_id":gene_id,"chromosome":g["seqid"],"start":g["start"],"end":g["end"],"strand":g["strand"],
      "GFF_transcript_count":len(transcripts),"protein_isoform_count":len(available),
      "protein_transcript_ids":";".join(available),
      "representative_longest_protein_id":representative,
      "representative_selection_rule":"LONGEST_PROTEIN_PER_EXACT_GFF_PARENT_THEN_LEXICOGRAPHIC_ID",
      "published_expression_present":gene_id in expr_ids,"published_S17_union_DEG_present":gene_id in s17_ids,
      "expression_ID":gene_id if gene_id in expr_ids else "",
      "S17_ID":gene_id if gene_id in s17_ids else ""})
write("gene_reference_and_expression_crosswalk.tsv",grows)
with (OUT/"Tchinensis_longest_protein_per_gene.faa").open("w") as f:
    for g in grows:
        tid=g["representative_longest_protein_id"]
        f.write(f">{g['gene_id']} protein_id={tid} selection=longest_exact_GFF_Parent\n{pep[tid]}\n")
write("S17_gene_to_all_protein_isoforms.tsv",[{"S17_GeneID":gid,"protein_id":tid,"GFF_gene_id":gid,"mapping_evidence":"EXACT_GFF_MRNA_PARENT"} for gid in sorted(s17_ids) for tid in per_gene[gid] if tid in pep])
removed=[]
with (OUT/"Tchinensis_quantification_exclude_orphan.gff3").open("w") as target:
    for line_number,line in enumerate(source_paths["gff"].open(),1):
        if line.startswith("#"):target.write(line);continue
        fields=line.rstrip("\n").split("\t")
        attrs=dict(x.split("=",1) for x in fields[8].split(";") if "=" in x)
        identifier=attrs.get("ID","");parents=set(attrs.get("Parent","").split(","))
        if identifier in orphan_transcripts or parents&orphan_transcripts:
            removed.append({"source_row":line_number,"feature":fields[2],"ID":identifier,"Parent":attrs.get("Parent",""),
               "reason":"EXCLUDE_UNRESOLVED_ORPHAN_MRNA_ABSENT_OFFICIAL_CDS_AND_PROTEIN","source_GFF_line":line.rstrip("\n")})
        else:target.write(line)
assert orphan_transcripts=={"TC08G1595T2"} and len(removed)==5
assert not orphan_transcripts&pep.keys() and not orphan_transcripts&cds.keys()
write("quantification_GFF_removed_features.tsv",removed)
source_api=json.loads(source_paths["official_api"].read_text())["data"]["data"]
write("source_provenance_SHA256.tsv",[{"source":k,"path":str(p),"bytes":p.stat().st_size,"sha256":hashes[k],
  "public_URL":next((r["url"] for r in source_api if r["file_name"]==p.name),"")} for k,p in source_paths.items()])
counts=collections.Counter(flag for r in qc for flag in r["qc_flags"].split(";"))
status={
 "created_at":datetime.datetime.now().astimezone().isoformat(),
 "GFF_gene_count":len(genes),"GFF_mRNA_count":len(tx),"protein_record_count":len(pep),"CDS_record_count":len(cds),
 "GFF_mRNAs_missing_protein":sorted(set(tx)-set(pep)),"GFF_mRNAs_missing_CDS_FASTA":sorted(set(tx)-set(cds)),
 "GFF_mRNAs_without_valid_gene_Parent":sorted(orphan_transcripts),
 "quantification_GFF_excluded_transcripts":sorted(orphan_transcripts),"quantification_GFF_excluded_feature_rows":len(removed),
 "all_proteins_have_exact_GFF_Parent":True,"all_CDS_have_exact_GFF_Parent":True,
 "CDS_ID_rule":"Each source CDS header ends in -CDS; removing only that explicit suffix matches the GFF mRNA ID, then Parent gives gene ID.",
 "all_genes_have_one_or_more_protein_models":True,"multi_isoform_genes":sum(len(v)>1 for v in per_gene.values()),
 "published_expression_gene_count":len(expr_ids),"published_expression_IDs_with_exact_GFF_gene_match":len(expr_ids&genes.keys()),
 "S17_gene_count":len(s17_ids),"S17_IDs_with_exact_GFF_gene_match":len(s17_ids&genes.keys()),
 "translation_matches":sum(r["translation_matches_after_only_terminal_stop_removal"] for r in qc),
 "qc_flags":dict(counts),"gene_model_requires_sequence_based_genome_check":True,
 "full_mRNA_extraction":"USE_GFF_EXONS_WITH_GENOME; CDS_FASTA_OMITS_UTR_BASES",
 "published_expression_units":"NOT_DECLARED_IN_DOWNLOAD; CANNOT_USE_DIRECTLY_AS_RAW_COUNTS",
 "prior_feasibility_correction":"Zero direct overlap between protein transcript IDs and expression gene IDs did not establish version mismatch. Complete GFF Parent links all expression and S17 genes to supplied proteins. No guessed numeric remapping used.",
 "source_files_unchanged":all(sha(p)==hashes[k] for k,p in source_paths.items())
}
assert status["source_files_unchanged"]
(OUT/"reference_validation.json").write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(status,ensure_ascii=False,indent=2))
