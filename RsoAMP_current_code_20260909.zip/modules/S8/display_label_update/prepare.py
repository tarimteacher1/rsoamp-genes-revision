from pathlib import Path
import hashlib,json,shutil
R=Path(__file__).resolve().parent
W=R.parent
B=W/'Genes_lab_handoff_20260908/01_Current_Editing'
S=R/'stage'
assert not S.exists(), 'Stage already exists; inspect before continuing'
files={str(p.relative_to(B)):hashlib.sha256(p.read_bytes()).hexdigest() for p in B.rglob('*') if p.is_file()}
shutil.copytree(B,S)
(R/'formal_baseline_sha256.json').write_text(json.dumps(files,ensure_ascii=False,indent=2),encoding='utf8')
C=R/'中文同步';C.mkdir()
old=W/'全文图表同步_20260909/中文同步'
for p in old.iterdir():
 if p.is_file():shutil.copy2(p,C/p.name)
print(json.dumps({'formal_files':len(files),'stage':str(S)},ensure_ascii=False))
