"""Versioned display-label update; source audit snapshots and author originals stay intact."""
from pathlib import Path
import csv,hashlib,io,json,re,shutil,sys,zipfile
from datetime import datetime
R=Path(__file__).resolve().parent;W=R.parent;S=R/'stage'
B=W/'Genes_lab_handoff_20260908/01_Current_Editing'
D=R/'交付';P=Path(r'/path/to/artwork')/R.name
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def j(name,data):(R/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
def cp(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert sha(p)==sha(q)
def manifest(folder):
 rows=[{'path':p.relative_to(folder).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(folder.rglob('*')) if p.is_file() and p.name!='SHA256_MANIFEST.tsv']
 with (folder/'SHA256_MANIFEST.tsv').open('w',encoding='utf-8-sig',newline='') as f:
  c=csv.DictWriter(f,fieldnames=['path','bytes','sha256'],delimiter='\t',lineterminator='\n');c.writeheader();c.writerows(rows)
 return rows
def package():
 src=B/'03_Supplementary/File_S8_catalogue_synced_figures_20260909.zip'
 with zipfile.ZipFile(src) as z:payload={n:z.read(n) for n in z.namelist()}
 payload.pop('SHA256_MANIFEST.tsv')
 old_readme=payload['README.md'].decode('utf8')
 note='''## Display-label update, 9 September 2026

Current nsLTP groups are displayed consecutively as L1, L2 and L3: previous L1 -> L1, previous L3 -> L2 (RsLTP39/RsLTP40 plus TaLTP24), previous L4 -> L3 (RsLTP5/RsLTP6). Colours, taxon membership, inferred trees and support values are unchanged. Historical audit group L2 (RsLTP26/RsLTP38), which failed the joint threshold in full-gappyout, is distinct from current display L2. Historical identifiers and their evidence are retained in explicitly historical columns/files. See current_tables/current_group_renaming.tsv.

The current figures, group metadata and current workbooks in this archive incorporate the label change. The original integration scripts and integration_audit records describe the preceding full-catalogue assembly; they are historical execution records, not new validation of the display labels. The current label-update scripts and validation are in display_label_update/. Do not rerun the earlier manuscript builder over the current merged Word documents. Files S1-S7 are unchanged.

'''
 payload['README.md']=(old_readme.split('\n',1)[0]+'\n\n'+note+old_readme.split('\n',1)[1].lstrip()).encode('utf8')
 oldcopy='analysis/系统树_F2/STAGE_COPY_MANIFEST.tsv'
 if oldcopy in payload:
  payload['history/pre_display_renumbering/STAGE_COPY_MANIFEST.tsv']=payload.pop(oldcopy)
 payload['integration_audit/README_DISPLAY_LABEL_UPDATE.md']=('These records document the original full-catalogue integration before consecutive nsLTP display renumbering. They retain their original old/new text and then-current figure hashes. Current labels and validation are supplied in display_label_update/, analysis/系统树_F2/current_group_renaming.tsv and the regenerated root SHA256_MANIFEST.tsv. The original stage-copy manifest is retained under history/pre_display_renumbering/.\n').encode('utf8')
 changes=[]
 def put(n,data):
  before=payload.get(n);payload[n]=data
  if before!=data:changes.append(n)
 # This is a current plotting/audit overlay, not an overwrite of historical raw inference.
 F=R/'phylogeny_update'
 for p in F.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name not in ['MANIFEST_SHA256.tsv']:
   put('analysis/系统树_F2/'+p.relative_to(F).as_posix(),p.read_bytes())
 # Regenerate the nested manifest because the selected-group audit and figure labels changed.
 prefix='analysis/系统树_F2/'
 rows=[{'relative_path':n[len(prefix):],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for n,data in payload.items() if n.startswith(prefix) and n!=prefix+'MANIFEST_SHA256.tsv']
 buf=io.StringIO();c=csv.DictWriter(buf,fieldnames=['relative_path','bytes','sha256'],delimiter='\t',lineterminator='\n');c.writeheader();c.writerows(sorted(rows,key=lambda r:r['relative_path']))
 put(prefix+'MANIFEST_SHA256.tsv',('\ufeff'+buf.getvalue()).encode('utf8'))
 for folder,prefix in [('03_Supplementary','current_tables/'),('04_Figures','current_figures/'),('05_Newick_iTOL','current_newick/')]:
  for p in (S/folder).rglob('*'):
   if p.is_file() and (folder!='03_Supplementary' or p.suffix in ['.xlsx','.tsv']):put(prefix+p.relative_to(S/folder).as_posix(),p.read_bytes())
 for p in R.iterdir():
  if p.is_file() and p.suffix in ['.py','.json','.md','.tsv'] and p.name not in ['formal_baseline_sha256.json']:
   put('display_label_update/'+p.name,p.read_bytes())
 for p in (R/'中文同步').iterdir():
  if p.is_file() and p.suffix in ['.py','.json','.tsv']:
   put('display_label_update/中文回复构建/'+p.name,p.read_bytes())
 # Rebuild the payload manifest after every last change.
 rows=[{'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for n,data in sorted(payload.items())]
 buf=io.StringIO();c=csv.DictWriter(buf,fieldnames=['path','bytes','sha256'],delimiter='\t',lineterminator='\n');c.writeheader();c.writerows(rows)
 out=S/'03_Supplementary'/src.name
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n,data in payload.items():z.writestr(n,data)
  z.writestr('SHA256_MANIFEST.tsv','\ufeff'+buf.getvalue())
 with zipfile.ZipFile(out) as z:
  assert z.testzip() is None
  assert all(hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256'] for r in rows)
 out.with_suffix('.zip.sha256').write_text(sha(out)+'  '+out.name+'\n',encoding='utf8')
 j('package_QA.json',{'status':'PASS','payload_files':len(rows),'all_payload_hashes_verified':True,'updated_entries':changes,'sha256':sha(out)})
 print('Packaged and verified File S8:',len(rows),'payload files')
def install():
 baseline=json.loads((R/'formal_baseline_sha256.json').read_text(encoding='utf8'))
 assert all((B/p).exists() and sha(B/p)==h for p,h in baseline.items()),'Formal source changed since snapshot; inspect before installation.'
 change=[(p,p.relative_to(S)) for p in S.rglob('*') if p.is_file() and (not (B/p.relative_to(S)).exists() or sha(p)!=sha(B/p.relative_to(S)))]
 backup=R/'正式覆盖前备份';assert not backup.exists(),'Install already attempted; inspect journal.'
 rows=[]
 for p,rel in change:
  q=B/rel
  if q.exists():cp(q,backup/rel)
  cp(p,q);rows.append({'path':rel.as_posix(),'sha256':sha(q)})
 assert all(sha(p)==sha(B/rel) for p,rel in change)
 j('installation_QA.json',{'status':'PASS','changed_files':rows,'backup':str(backup),'all_installed_hashes_verified':True})
 print('Installed',len(change),'changed files; original files backed up')
def deliver():
 assert not D.exists(),'Delivery exists; inspect before rebuilding.'
 D.mkdir()
 for folder,target in [('04_Figures','02_图片'),('05_Newick_iTOL','05_Newick_iTOL'),('03_Supplementary','03_补充材料')]:shutil.copytree(S/folder,D/target)
 for p in (S/'06_Reproducibility').glob('File_S1*.zip'):cp(p,D/'03_补充材料'/p.name)
 cp(next((S/'01_Manuscript').glob('*.docx')),D/'01_正式文稿/稿件_Figure2编号同步_20260909.docx')
 cp(next((S/'02_Response').glob('*.docx')),D/'01_正式文稿/英文回复_Figure2编号同步_20260909.docx')
 for p in (S/'07_PDF_Preview').glob('*.pdf'):cp(p,D/'01_正式文稿'/p.name)
 for ext in ['docx','md']:cp(R/'中文同步'/('回复审稿人_中文版_20260909.'+ext),D/'01_正式文稿'/('回复审稿人_中文版_20260909.'+ext))
 for p in R.iterdir():
  if p.is_file() and p.suffix in ['.md','.json','.py','.tsv']:cp(p,D/'04_日志与核验'/p.name)
 readme='''# Figure 2 连续编号同步版

当前 nsLTP 分组：L1（RsLTP13、RsLTP22），L2（RsLTP39、RsLTP40），L3（RsLTP5、RsLTP6）。其他物种序列和组内总数见图及映射表。对应旧编号为 L1、L3、L4；颜色、成员和支持值未变。

请从 02_图片/Vector_PDF/Figure2_catalogue_synced_20260909.pdf 和 01_正式文稿 继续编辑。正文、中英文回复、Figure S1、成员标签对应表和 File S8 已同步。旧审核 L2（RsLTP26/RsLTP38）与新图 L2 是不同分组，历史证据保留。

本次只调整组的显示编号，不修改基因名称，也未重跑系统树、改变家族目录或补做实验。完整工作日志与核验结果在 04_日志与核验。上一版全文图表同步目录和作者手工原图保留，后续不要混用。

换电脑后运行 核验迁移.ps1 核对文件完整性。这里的校验确认本地两个目录一致，不代表云端已完成同步。
'''
 (D/'00_先读说明.md').write_text(readme,encoding='utf8')
 cp(W/'全文图表同步_20260909/交付/核验迁移.ps1',D/'核验迁移.ps1')
 rows=manifest(D)
 assert not P.exists(),'Author destination exists; inspect before overwrite.'
 shutil.copytree(D,P)
 assert all(sha(P/r['path'])==r['sha256'] for r in rows)
 j('delivery_QA.json',{'status':'PASS','destination':str(P),'payload_files':len(rows),'all_destination_hashes_verified':True})
 print(json.dumps({'delivery':str(P),'verified_files':len(rows)},ensure_ascii=False))
if __name__=='__main__':{'package':package,'install':install,'deliver':deliver}[sys.argv[1]]()
