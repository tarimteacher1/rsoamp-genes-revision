"""Patch current display identifiers without reserializing numeric worksheet data."""
from pathlib import Path
import csv,io,json,re,zipfile,hashlib,xml.etree.ElementTree as ET
import openpyxl
R=Path(__file__).resolve().parent; S=R/'stage/03_Supplementary'
B=R.parent/'Genes_lab_handoff_20260908/01_Current_Editing/03_Supplementary'
baseline=json.loads((R/'formal_baseline_sha256.json').read_text(encoding='utf8'))
baseline={k.replace('\\','/'):v for k,v in baseline.items()}
M={'L3':'L2','L4':'L3'}
NOTE=('Current Figure 2 nsLTP display labels were renumbered on 2026-09-09: '
      'historical L1 -> current L1, historical L3 -> current L2 (RsLTP39/RsLTP40), '
      'historical L4 -> current L3 (RsLTP5/RsLTP6). Historical audit group L2 '
      '(RsLTP26/RsLTP38) remains unhighlighted; it is distinct from current display L2. '
      'Membership, colours and support values are unchanged.')
N={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
   'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
audit=[]
for name in ['Genes_RsoAMP_Supplementary_Tables_expression_status_20260904.xlsx','Member_label_crosswalk_20260909.xlsx']:
 p=S/name; source=B/name
 assert hashlib.sha256(source.read_bytes()).hexdigest()==baseline['03_Supplementary/'+name]
 w=openpyxl.load_workbook(source,read_only=True,data_only=False)
 edits={}
 for ws in w:
  if ws.title.startswith('H'):continue
  for row in ws:
   for c in row:
    if c.value in M if isinstance(c.value,str) else False:
     edits[(ws.title,c.coordinate)]=(c.value,M[c.value])
 if 'README' in w.sheetnames:
  ws=w['README']; row=next(row for row in ws if row[0].value=='family_vs_phylogenetic_group')
  c=row[1];edits[(ws.title,c.coordinate)]=(c.value,c.value+' '+NOTE)
 expected={key:new for key,(old,new) in edits.items()}
 old_values={ws.title:tuple(ws.values) for ws in w};w.close()
 with zipfile.ZipFile(source) as z: payload={n:z.read(n) for n in z.namelist()};infos=z.infolist()
 rels={x.attrib['Id']:x.attrib['Target'].lstrip('/') for x in ET.fromstring(payload['xl/_rels/workbook.xml.rels'])}
 sheetpaths={x.attrib['name']:rels[x.attrib['{'+N['r']+'}id']] for x in ET.fromstring(payload['xl/workbook.xml']).find('m:sheets',N)}
 sheetpaths={k:v if v.startswith('xl/') else 'xl/'+v for k,v in sheetpaths.items()}
 changed=set()
 for (sheet,coord),(old,new) in edits.items():
  entry=sheetpaths[sheet];raw=payload[entry].decode('utf8')
  pat=r'(<c\b[^>]*\br="'+re.escape(coord)+r'"[^>]*>)(.*?)(</c>)'
  hits=list(re.finditer(pat,raw,re.S));assert len(hits)==1,(sheet,coord)
  hit=hits[0];cell=hit.group(0)
  assert 't="inlineStr"' in cell,(sheet,coord,cell)
  from xml.sax.saxutils import escape
  target='<t>'+escape(old)+'</t>'
  assert target in cell,(sheet,coord,cell)
  replacement=cell.replace(target,'<t>'+escape(new)+'</t>',1)
  raw=raw[:hit.start()]+replacement+raw[hit.end():]
  payload[entry]=raw.encode('utf8');changed.add(entry)
  audit.append({'file':p.name,'sheet':sheet,'cell':coord,'old':old,'new':new})
 tmp=p.with_suffix('.updated.xlsx')
 with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
  for info in infos:z.writestr(info,payload[info.filename])
 with zipfile.ZipFile(source) as a,zipfile.ZipFile(tmp) as b:
  assert all(a.read(n)==b.read(n) for n in a.namelist() if n not in changed)
  for n in changed:
   numeric=r'<c\b[^>]*\bt="n"[^>]*>.*?</c>'
   assert re.findall(numeric,a.read(n).decode('utf8'),re.S)==re.findall(numeric,b.read(n).decode('utf8'),re.S)
 nw=openpyxl.load_workbook(tmp,read_only=True,data_only=False)
 for ws in nw:
  for i,row in enumerate(ws):
   for j,c in enumerate(row):
    coord=openpyxl.utils.get_column_letter(j+1)+str(i+1)
    want=expected.get((ws.title,coord),old_values[ws.title][i][j]);assert c.value==want,(ws.title,coord)
 nw.close();tmp.replace(p)
tsv=S/'Member_label_crosswalk_20260909.tsv'
with (B/tsv.name).open(encoding='utf-8-sig',newline='') as f:
 rd=csv.DictReader(f,delimiter='\t');fields=rd.fieldnames;rows=list(rd)
for row in rows:
 old=row['Figure2_supported_group']
 if old in M:row['Figure2_supported_group']=M[old]
with tsv.open('w',encoding='utf-8-sig',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=fields,delimiter='\t',lineterminator='\n');wr.writeheader();wr.writerows(rows)
(R/'workbook_label_changes.json').write_text(json.dumps({'status':'PASS','edits':audit,'unaffected_zip_entries_identical':True,'all_numeric_XML_preserved':True,'all_other_cell_values_preserved':True},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'status':'PASS','edited_cells':len(audit),'files':3},ensure_ascii=False))
