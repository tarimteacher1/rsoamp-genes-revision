from pathlib import Path
import csv,hashlib,json,shutil
R=Path(__file__).resolve().parent;S=R/'stage';F=R/'phylogeny_update'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copy2(F/'current_group_renaming.tsv',S/'03_Supplementary/current_group_renaming.tsv')
# Refresh current-path manifests after the coordinated caption update. Historical text-only snapshots stay historical.
for name in ['FILES8_REPLACEMENTS.tsv','stage_changed_files.tsv']:
 p=F/name
 with p.open(encoding='utf-8-sig',newline='') as f:
  rd=csv.DictReader(f,delimiter='\t');fields=rd.fieldnames;rows=list(rd)
 for row in rows:
  key=next((k for k in ['source_relative_to_new_root','stage_relative_path','stage_path','relative_path'] if k in row),None)
  if key:
   rel=row[key];candidate=R/rel
   if not candidate.is_file():candidate=S/rel
   assert candidate.is_file(),(name,rel)
   if 'sha256' in row:row['sha256']=sha(candidate)
   if 'bytes' in row:row['bytes']=str(candidate.stat().st_size)
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=fields,delimiter='\t',lineterminator='\n');wr.writeheader();wr.writerows(rows)
note='''# 当前 Figure 2 连续编号版 · 2026-09-09

本正式目录的 Figure 2 当前 nsLTP 分组为 **L1、L2、L3**，依次对应旧显示／审核编号 L1、L3、L4。新 L2 是 RsLTP39/RsLTP40 所在组，新 L3 是 RsLTP5/RsLTP6 所在组；成员、颜色、支持值未变。历史审核 L2（RsLTP26/RsLTP38）保留其未通过门槛的历史记录，与新显示 L2 明确区分。

正文、中英文回复、Figure S1C、补充表对应标签和 File S8 已同步。正式主稿33页、英文回复13页、中文参考回复15页。当前中文 PDF 位于 `07_PDF_Preview/回复审稿人_中文版_20260909.pdf`。

作者接续目录：`/path/to/artwork\\Figure2编号同步_20260909`。本次日志、安装前备份和核验在 `/path/to/revision_workspace\\Figure2编号同步_20260909`。

此次接续已包含当日此前完成的主目录73、外部 Figure S2、S40–S43／File S7 与完整 Figure1–8 更新；独立 qRT-PCR 仍未开展。下方若有旧页数、旧图范围或旧交付路径，仅为历史记录。
'''
(S/'FIGURE2_LABELS_CURRENT_20260909.md').write_text(note,encoding='utf8')
p=S/'FIGURE_PACKAGE_CURRENT_20260909.md';old=p.read_text(encoding='utf8')
p.write_text(note+'\n---\n\n## 历史版本记录\n\n'+old,encoding='utf8')
print('Updated current label map, manifests and formal entry-point notes.')
