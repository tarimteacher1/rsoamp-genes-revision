"""Layout-only two-column figures from frozen, previously validated source TSVs."""
from pathlib import Path
from collections import Counter
import csv,json,hashlib,re
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
from matplotlib.text import Text
import fitz
O=Path(__file__).resolve().parent;S=O.parent/'注释_F1_F3_F4'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.2,'svg.fonttype':'none','pdf.fonttype':42,'ps.fonttype':42,'axes.linewidth':.55,'text.color':'#27323B'})
def read(name):
 with (S/name).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f,delimiter='\t'))
structure=read('Figure3_structure_summary_primary73.tsv');features=read('Figure3_structure_features_primary73.tsv')
defs=read('Figure4_motif_definitions.tsv');hits=read('Figure4_motif_scan_sites_primary73.tsv');seqs=read('Figure4_sequence_coverage_primary73.tsv')
F=['Defensin','Snakin_GASA','nsLTP'];labels={'Defensin':'Defensin','Snakin_GASA':'Snakin/GASA','nsLTP':'nsLTP'}
col={'Defensin':'#C43D3D','Snakin_GASA':'#2E6F9E','nsLTP':'#2F7D4A'}
def key(r):return (F.index(r['family']),int(re.search(r'\d+$',r['member_id'])[0]))
structure.sort(key=key);seqs.sort(key=key)
assert {r['member_id'] for r in structure}=={r['member_id'] for r in seqs} and len(structure)==len(seqs)==73
assert Counter(r['family'] for r in structure)==Counter({'Defensin':15,'Snakin_GASA':18,'nsLTP':40})
assert len(hits)==246 and len(defs)==15
panels=[('Defensin','A',.585,.255),('Snakin_GASA','B',.16,.345),('nsLTP','C',.16,.68)]
def panel(fig,fam,letter,bottom,height,kind):
 x=.105 if fam!='nsLTP' else .605; width=.245 if kind=='structure' else .365
 ax=fig.add_axes([x,bottom,width,height]);rr=[r for r in structure if r['family']==fam]
 ax.set_ylim(len(rr)-.5,-.5);ax.set_yticks(range(len(rr)));ax.set_yticklabels([r['member_id'] for r in rr],fontstyle='italic',fontsize=9)
 ax.tick_params(axis='y',length=0,pad=4);ax.tick_params(axis='x',labelsize=8,length=2.5,pad=3)
 ax.spines[['top','right','left']].set_visible(False);ax.spines['bottom'].set_color('#A1ADB6')
 fig.text(.028 if fam!='nsLTP' else .528,bottom+height+.035,f'{letter}  {labels[fam]} (n = {len(rr)})',fontsize=10,weight='bold',color=col[fam],ha='left')
 return ax,rr
def qa_and_save(fig,base,expected,extra):
 fig.canvas.draw();renderer=fig.canvas.get_renderer();texts=[];outside=[]
 for obj in fig.findobj(Text):
  if not obj.get_visible() or not obj.get_text().strip():continue
  bb=obj.get_window_extent(renderer)
  # Tick duplicates can exist as inactive Text objects; their extents are empty.
  if bb.width<=0 or bb.height<=0:continue
  if bb.x0<-.25 or bb.y0<-.25 or bb.x1>fig.bbox.width+.25 or bb.y1>fig.bbox.height+.25:outside.append(obj.get_text())
  texts.append((obj.get_text(),bb))
 overlaps=[]
 for i,(a,bb) in enumerate(texts):
  for b,bc in texts[i+1:]:
   if bb.overlaps(bc):overlaps.append([a,b])
 assert not outside,(base,'outside',outside)
 assert not overlaps,(base,'overlap',overlaps)
 for ext in ['pdf','svg','png']:fig.savefig(O/(base+'.'+ext),dpi=600,facecolor='white')
 fig.savefig(O/(base+'_preview.png'),dpi=160,facecolor='white')
 doc=fitz.open(O/(base+'.pdf'));assert len(doc)==1
 txt=doc[0].get_text();missing=[n for n in expected if not re.search(r'\b'+n+r'\b',txt)];assert not missing,missing
 assert all('Type3' not in str(f) for f in doc[0].get_fonts(full=True))
 q={'status':'PASS','figure_inches':[7.2,8.3],'member_label_font_pt':9,'other_labels_min_font_pt':8,'members':len(expected),'all_73_IDs_present_in_PDF':True,'text_objects_checked':len(texts),'overlapping_text':overlaps,'text_outside_canvas':outside,'PDF_pages':len(doc),'PDF_TrueType_fonts':True,'SVG_text_preserved':'<text' in (O/(base+'.svg')).read_text(encoding='utf-8'),'PNG_dpi':600,'matplotlib_version':matplotlib.__version__,**extra}
 (O/(base+'_QA.json')).write_text(json.dumps(q,indent=2)+'\n');plt.close(fig);return q

def f3():
 fig=plt.figure(figsize=(7.2,8.3),dpi=140,facecolor='white')
 fig.text(.028,.984,'Gene structures | 73 primary members',fontsize=12,weight='medium',va='top')
 handles=[Patch(facecolor='#657A8D',label='Coding exon'),Patch(facecolor='#CED5DB',edgecolor='#97A4AE',label='UTR / noncoding exon'),Line2D([],[],color='#9AA3AA',lw=.7,label='Intron')]
 fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.016,.959),ncol=3,frameon=False,fontsize=8,columnspacing=1.25,handlelength=1.4)
 fig.text(.028,.911,'Source: A, annotation; M6, reconstructed. UTR: S, source; M, model-derived; NR, not recorded.',fontsize=8)
 drawn=[];drawnfeatures=[]
 for fam,letter,bottom,height in panels:
  ax,rr=panel(fig,fam,letter,bottom,height,'structure');ax.set_xlim(-.005,1.005);ax.set_xticks([0,.5,1]);ax.set_xticklabels(['0','0.5','1'])
  for yy,r in enumerate(rr):
   n=r['member_id'];drawn.append(n)
   for s in [s for s in features if s['member_id']==n]:
    left=float(s['relative_start_0to1']);width=float(s['relative_width']);typ=s['feature_type'];drawnfeatures.append(s)
    if typ=='intron':ax.plot([left,left+width],[yy,yy],color='#9AA3AA',lw=.6,zorder=1)
    elif typ=='noncoding_exon_or_UTR':ax.add_patch(Rectangle((left,yy-.18),width,.36,facecolor='#CED5DB',edgecolor='#97A4AE',lw=.32,hatch='////' if s['UTR_status']=='M' else None,zorder=3))
    else:ax.add_patch(Rectangle((left,yy-.28),width,.56,facecolor=col[fam],edgecolor='none',zorder=4))
   for xx,v in [(1.12,f"{int(r['transcript_span_bp']):,}"),(1.32,r['source_label']),(1.49,r['UTR_status'])]:ax.text(xx,yy,v,transform=ax.get_yaxis_transform(),ha='center',va='center',fontsize=8)
  for xx,v in [(1.12,'Span'),(1.32,'Src'),(1.49,'UTR')]:ax.text(xx,1.016,v,transform=ax.transAxes,ha='center',va='bottom',fontsize=8,weight='bold')
 fig.text(.028,.097,'Position is normalized separately for each full source transcript (5′ → 3′); span is in bp.',fontsize=8)
 fig.text(.028,.073,'M: inferred noncoding exon portions (hatched), without an independently annotated UTR or TSS.',fontsize=8)
 fig.text(.028,.049,'NR does not imply UTR absence. Coding blocks include the terminal stop codon.',fontsize=8)
 assert len(drawn)==73 and len(drawnfeatures)==len(features)
 return qa_and_save(fig,'Figure3_primary73_compact',drawn,{'features_drawn':len(drawnfeatures),'source_counts':dict(Counter(r['source_label'] for r in structure)),'UTR_status_counts':dict(Counter(r['UTR_status'] for r in structure)),'data_changed':False,'layout':'DEF15 above SNA18 left; LTP40 right; independent model normalization retained'})

def f4():
 fig=plt.figure(figsize=(7.2,8.3),dpi=140,facecolor='white');palette=list(plt.cm.tab10.colors[:5])
 fig.text(.028,.984,'MEME motifs | 73 primary proteins',fontsize=12,weight='medium',va='top')
 fig.legend(handles=[Patch(facecolor=palette[i],label=f'Motif {i+1}') for i in range(5)],loc='upper left',bbox_to_anchor=(.016,.959),ncol=5,frameon=False,fontsize=8,columnspacing=1.25,handlelength=1.4)
 weak=[x for x in defs if float(x['motif_Evalue'])>1]
 assert {(r['family'],r['motif_rank'],float(r['motif_Evalue'])) for r in weak}=={('Defensin','5',3.0),('Snakin_GASA','5',27.0)}
 fig.text(.028,.911,'Exploratory motif 5: defensin E = 3.0; Snakin/GASA E = 27.',fontsize=8)
 drawn=[];drawnhits=[]
 for fam,letter,bottom,height in panels:
  ax,rr=panel(fig,fam,letter,bottom,height,'motif');ax.set_xlim(0,max(int(r['protein_length_aa']) for r in rr)*1.035);ax.xaxis.set_major_locator(MaxNLocator(nbins=3,integer=True,prune=None));ax.set_xticks([x for x in ax.get_xticks() if 0<=x<=ax.get_xlim()[1]])
  for yy,r in enumerate(rr):
   n=r['member_id'];drawn.append(n);length=int(r['protein_length_aa']);ax.plot([.5,length+.5],[yy,yy],lw=.6,color='#BCC5CC',zorder=1)
   for h in [h for h in hits if h['member_id']==n]:
    start=int(h['start_1based']);width=int(h['width_aa']);rank=int(h['motif_rank']);assert start+width-1<=length
    patch=Rectangle((start-.5,yy-.28),width,.56,facecolor=palette[rank-1],edgecolor='none',zorder=3)
    patch.set_gid(f"motif-{fam}-{n}-{h['motif_id']}-{start}");ax.add_patch(patch);drawnhits.append(h)
 fig.text(.028,.097,'Axes show full-precursor positions in amino acids; complete proteins are retained.',fontsize=8)
 fig.text(.028,.073,'All five requested motifs per family are shown (site P ≤ 10⁻⁴); weak motif E-values are flagged above.',fontsize=8)
 fig.text(.028,.049,'Ranks and colours are family-specific and do not imply motif homology between families.',fontsize=8)
 assert len(drawn)==73 and len(drawnhits)==len(hits)==246
 return qa_and_save(fig,'Figure4_primary73_compact',drawn,{'motif_sites_drawn':len(drawnhits),'motifs_per_family':dict(Counter(r['family'] for r in defs)),'weak_Evalues':{'Defensin_motif5':3.0,'Snakin_GASA_motif5':27.0},'positions_and_widths_from_original_TSV':True,'data_changed':False,'layout':'DEF15 above SNA18 left; LTP40 right; family-specific amino-acid scales retained'})

if __name__=='__main__':
 sourcefiles=['Figure3_structure_summary_primary73.tsv','Figure3_structure_features_primary73.tsv','Figure4_motif_definitions.tsv','Figure4_motif_scan_sites_primary73.tsv','Figure4_sequence_coverage_primary73.tsv','plot_structure_and_motifs_primary73.py']
 before={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in sourcefiles}
 q={'Figure3':f3(),'Figure4':f4()}
 assert before=={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in sourcefiles}
 (O/'source_hashes_unchanged.json').write_text(json.dumps({'source_directory':str(S),'source_SHA256':before,'original_sources_and_script_unchanged':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(q,indent=2))

