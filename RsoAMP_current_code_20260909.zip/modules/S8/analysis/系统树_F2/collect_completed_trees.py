"""Read and collect finished outputs only; never launches or alters inference."""
from pathlib import Path
import argparse,base64,hashlib,json,subprocess
B=Path(__file__).resolve().parent
REMOTE='/path/to/rso_project/manuscript_sync_20260909/phylogeny'
parser=argparse.ArgumentParser();parser.add_argument('--fetch',action='store_true');a=parser.parse_args()
code='''from pathlib import Path
import json,hashlib,base64
B=Path(%r)
families=['Defensin','Snakin_GASA','nsLTP'];strategies=['full.untrimmed','full.gappyout','core.untrimmed','core.gappyout']
result={'states':json.loads((B/'status.json').read_text()),'completed':[],'progress':{},'files':[]}
files=[]
for f in families:
 for s in strategies:
  p=B/f/(f+'.'+s);report=Path(str(p)+'.iqtree')
  if report.exists() and 'Total wall-clock time used:' in report.read_text():
   result['completed'].append(f+'.'+s)
   files.extend(q for q in p.parent.glob(p.name+'.*') if q.is_file() and not q.name.endswith(('.ckp.gz','.model.gz')))
  else:
   log=Path(str(p)+'.log')
   if log.exists():result['progress'][f+'.'+s]=log.read_text().splitlines()[-3:]
 if %r:files.extend(p for p in (B/f).glob('*.faa'))
if %r:
 files.extend(p for p in [B/'status.json',B/'commands.json',B/'runner.py',B/'runner_resumed.py',B/'runner_per_strategy.py'] if p.exists())
 for p in sorted(set(files)):
  raw=p.read_bytes();result['files'].append({'path':p.relative_to(B).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'base64':base64.b64encode(raw).decode()})
print(json.dumps(result))
'''%(REMOTE,a.fetch,a.fetch)
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','example-host','python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=90)
if p.returncode:raise RuntimeError(p.stderr)
r=json.loads(p.stdout);root=B/'collected';root.mkdir(exist_ok=True)
for v in r['files']:
 data=base64.b64decode(v.pop('base64'));assert hashlib.sha256(data).hexdigest()==v['sha256']
 dest=root/v['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
(B/'collection_status.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
print(json.dumps({'completed_tree_count':len(r['completed']),'active_states':{k:v for k,v in r['states'].items() if v!='complete'},'progress':r['progress']},indent=2));print('Verified files:',len(r['files']))
