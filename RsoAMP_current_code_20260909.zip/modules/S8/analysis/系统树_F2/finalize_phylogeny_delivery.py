from pathlib import Path
from collections import Counter
import csv,hashlib,json,re,sys,xml.etree.ElementTree as ET
MAIN_ONLY='--main-only' in sys.argv
import openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
from PIL import Image
B=Path(__file__).resolve().parent;A=B/'审核表';FAMS=['Defensin','Snakin_GASA','nsLTP']
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
audit=json.loads((A/'audit_status.json').read_text(encoding='utf-8'));assert audit['all_12_complete']
fqa=json.loads((A/'figure_QA.json').read_text(encoding='utf-8'));assert fqa['main_primary_Rso_members']==73
collection=json.loads((B/'collection_status.json').read_text(encoding='utf-8'));assert len(collection['completed'])==12
for x in collection['files']:assert sha(B/'collected'/x['path'])==x['sha256']
for r in read(A/'completed8_before_remaining_strategy_reschedule.tsv'):
 assert sha(B/r['tree_file'])==r['tree_sha256'] and sha(B/r['iqtree_report'])==r['report_sha256']
groups=read(A/'key_branch_evidence.tsv');legacy=read(A/'legacy_group_reassessment.tsv');taxa=read(A/'taxon_metadata_verified_sequences.tsv');labels=read(A/'tip_label_key.tsv');align=read(A/'alignment_comparison.tsv')
assert len(labels)==312 and len(align)==12
for g in groups:assert g['identical_all_taxon_split_strategies']=='4'
for fam in FAMS:
 seen=set()
 for g in [x for x in groups if x['family']==fam]:
  s=set(g['all_taxon_ids'].split(';'));assert not s&seen;seen|=s
sources=fqa['source_trees'];figqa=[]
for s in sources:
 fam=s['family'];letter={'Defensin':'A','Snakin_GASA':'B','nsLTP':'C'}[fam]
 stems=[f'Figure2{letter}_{fam}_primary73_key_clades']+([] if MAIN_ONLY else [f'FigureS1{letter}_{fam}_primary73_full'])
 for stem in stems:
  pdf=B/'图件/Vector_PDF'/(stem+'.pdf');svg=B/'图件/Editable_SVG'/(stem+'.svg');png=B/'图件/High_Resolution_PNG'/(stem+'.png')
  raw=pdf.read_bytes();txt=svg.read_text(encoding='utf-8');im=Image.open(png);text_nodes={''.join(n.itertext()) for n in ET.fromstring(txt).iter() if n.tag.endswith('}text')}
  assert b'/FontFile2' in raw and b'/Subtype /Type3' not in raw
  required=[r['display_label'] for r in labels if r['family']==fam and (stem.startswith('FigureS1') or r['shown_in_main']=='True')]
  assert all(x in text_nodes for x in required),(stem,[x for x in required if x not in text_nodes])
  figqa.append({'figure':stem,'checked_tip_labels':len(required),'all_required_labels_in_SVG':True,'embedded_TrueType':True,'PNG_pixels':im.size,'PNG_dpi':im.info.get('dpi')})
combined=B/'图件/Editable_SVG/Figure2_combined_primary73_key_clades.svg'
combined_text={''.join(n.itertext()) for n in ET.parse(combined).iter() if n.tag.endswith('}text')}
required_primary=[r['display_label'] for r in labels if r['category']=='primary_Rso']
assert all(n in combined_text for n in required_primary) and 'RsLTP20*' in combined_text
assert all('x:RsLTP'+str(i) not in combined_text for i in [2,18,30])
workbook=openpyxl.Workbook();workbook.remove(workbook.active)
numeric_fields={'rso_group_size','supported_strategy_count','maximum_identical_all_taxon_split_strategies','node','sh_alrt','ufboot','canonical_split_size','primary_rso_group_size','sequence_count','alignment_sites','tree_log_likelihood','seed','rso_restricted_strategies','identical_all_taxon_split_strategies','total_sequences','Rso_sequences','source_split_supported_strategies','current_matching_four_strategy_splits','qualifying_four_strategy_split_count','length_aa','core_length_aa','actual_full_length_aa','actual_core_length_aa','core_start_1based','core_end_1based'}
def cell(k,v):
 if not v:return None
 if k in numeric_fields:
  n=float(v);return int(n) if n.is_integer() else n
 if v in ('True','TRUE'):return True
 if v in ('False','FALSE'):return False
 return v
for sheet,name in [('S7_PhyloGroups','S7_PhyloGroups.tsv'),('S8_PhyloSupport','S8_PhyloSupport.tsv'),('Alignment_comparison','alignment_comparison.tsv'),('Historical_current_config','historical_vs_current_configuration.tsv'),('Selected_groups','key_branch_evidence.tsv'),('All_stable_splits','all_four_strategy_stable_split_candidates.tsv'),('Legacy_reassessment','legacy_group_reassessment.tsv'),('Legacy_strategy_support','legacy_group_strategy_support.tsv'),('Rso_placement74','rso_phylogenetic_placement_summary.tsv'),('Taxa_sequences312','taxon_metadata_verified_sequences.tsv'),('Figure_tip_labels312','tip_label_key.tsv')]:
 rr=read(A/name);ws=workbook.create_sheet(sheet);ws.append(list(rr[0]));
 for r in rr:ws.append([cell(k,v) for k,v in r.items()])
 ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
 for c in ws[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='244A61');c.alignment=Alignment(wrap_text=True)
 for col in ws.columns:ws.column_dimensions[col[0].column_letter].width=min(48,max(14,len(str(col[0].value))+2))
workbook.save(B/'F2_S1_S7_S8_replacement_tables.xlsx')
(A/'final_QA.json').write_text(json.dumps({'tree_count':12,'input_taxa_total':312,'catalogue_primary_Rso_in_main':73,'catalogue_extended_Rso_in_main':1,'all_frozen_extended_Rso_Tau_catalogue_members_in_input':113,'remote_transfer_SHA256_checks':len(collection['files']),'all_12_sources_finished':True,'selected_groups_disjoint':True,'no_biological_root_inferred':True,'figure_export_checks':figqa},indent=2),encoding='utf-8')
count=Counter(g['family'] for g in groups);ng=len(groups)
retained=[r['legacy_group'] for r in legacy if r['previously_highlighted']=='True' and r['selected_current_group']]
lost=[r['legacy_group'] for r in legacy if r['previously_highlighted']=='True' and not r['selected_current_group']]
new=[g['group_label'] for g in groups if not g['legacy_group_label'] or g['legacy_group_previously_highlighted']!='True']
summary=f"The updated four-strategy phylogenetic analysis supported {ng} non-overlapping local groups ({count['Defensin']} defensin, {count['Snakin_GASA']} Snakin/GASA and {count['nsLTP']} nsLTP groups), without assigning formal subfamilies."
details=' '.join(f"{g['group_label']}: {g['members'].replace(';', ', ')} ({g['total_sequences']} total sequences; full-gappyout SH-aLRT/UFBoot {g['source_support']})." for g in groups)
legacytext=f"Of the seven previously highlighted groups, {len(retained)} retain four-strategy support in the current reconstructions"+(' ('+', '.join(retained)+')' if retained else '')+'.'
if lost:legacytext+=' '+', '.join(lost)+' no longer meet the complete current criterion and are not retained as highlighted groups.'
if new:legacytext+=' Newly qualifying or promoted local groups are '+', '.join(new)+'.'
methods="Maximum-likelihood analyses were rerun for the complete merged catalogue, retaining historical reference and boundary-control sampling and adding the newly represented catalogue sequences and reviewed OsC4 reference Q6ZFW0. The family inputs contained 110 defensin, 43 Snakin/GASA and 159 nsLTP sequences, respectively, and included all 113 extended-catalogue members of the two species. All 73 primary R. soongarica members and the extended candidate RsLTP20 were represented. Four strategies per family compared full precursors and an operational core bounded by the first and last cysteine, each analyzed with an untrimmed or trimAl v1.5.rev1 gappyout alignment. This core is an analytical sequence segment, not an experimentally mapped mature peptide. MAFFT v7.526 used local-pair alignment and 1,000 refinement iterations. IQ-TREE 3.1.2 used ModelFinder with the default candidate model set (MFP), 1,000 SH-aLRT replicates, 1,000 ultrafast bootstrap replicates with BNNI optimization, four threads per inference and seed 20260909. A stable local group required an identical all-taxon unrooted bipartition in all four strategies, each with SH-aLRT ≥ 80% and UFBoot ≥ 95%, and at least two primary R. soongarica members on the local side, with at least one primary member outside that side. R. soongarica-restricted grouping alone was insufficient. Qualifying historical groups retained their names; remaining smallest disjoint local splits were selected to avoid nested colour overlays, and all qualifying nested splits remain in the audit table. The full-gappyout trees supply Figure 2 and the full Figure S1. Main-display copies retain all primary R. soongarica members, RsLTP20, nearest non-Rso context sequences and all taxa in highlighted groups; branches failing the joint threshold are collapsed in these display copies. Original full trees, support values and branch lengths are preserved. Circular radius is a cladogram layout, not evolutionary distance or evidence for a biological root."
caption="Figure 2. Updated sensitivity-qualified phylogenetic relationships of AMP-family proteins. (A) Defensin, (B) Snakin/GASA and (C) nsLTP. The panels use the full-precursor gappyout maximum-likelihood trees and include all 73 primary R. soongarica members across the three families. Bold labels denote primary R. soongarica members; RsLTP20* is the extended-catalogue candidate. Historical excluded Rso context sequences, where shown, carry x; RsLTP2, RsLTP18 and RsLTP30 are primary members and have no x. Coloured groups satisfy the same all-taxon unrooted split and SH-aLRT ≥ 80%/UFBoot ≥ 95% in all four alignment strategies; n is the number of all sequences in the highlighted group. Numerical labels report SH-aLRT/UFBoot in the display-source tree. Low-support internal branches are collapsed in main-display copies. These are supported local relationships, not formal subfamilies. Radial lengths are not to scale and the centre does not imply a biological root. Complete uncollapsed 110-, 43- and 159-tip trees are provided in Figure S1 and all branch values in Table S8."
results=summary+' '+legacytext+' '+details
discussion="The merged-catalogue analysis evaluates local relationships using the current sequences and newly reconstructed trees. "+legacytext+" Four-strategy agreement supports the highlighted local splits, but it does not establish antimicrobial activity, a formal subfamily system or a resolved evolutionary backbone. Unresolved or analysis-sensitive relationships remain explicitly unassigned."
response="We have now rerun all 12 prespecified family/region/trimming analyses using the merged catalogue. The 110-, 43- and 159-sequence inputs include every primary R. soongarica member, its extended RsLTP20 candidate and the complete current two-species extended panel, together with retained reference/boundary controls. The run used IQ-TREE 3.1.2, default MFP model selection, 1,000 SH-aLRT and 1,000 UFBoot replicates, BNNI and a fixed seed; full sequences and first-to-last-cysteine operational cores were independently aligned and analyzed with and without gappyout trimming. "+summary+' '+legacytext+" We require identical all-taxon splits and the joint support threshold in all four strategies, and retain all branch-level results, including nested splits and unsupported historical groups. Figure 2, the complete Figure S1, Table S7 and Table S8 have been regenerated from these new outputs. This response concerns the updated 12-tree sensitivity analysis only."
response_labels="We regenerated the circular key-clade figures as vector PDF with embedded TrueType fonts, editable SVG with text labels, and 600-dpi PNG. The main panels contain all 73 primary R. soongarica labels in bold; RsLTP20 carries an asterisk for extended-catalogue status, and obsolete exclusion prefixes were removed from RsLTP2, RsLTP18 and RsLTP30. Historical reference aliases were preserved and new aliases assigned without renumbering the old ones. Complete taxon-to-alias/source/sequence mappings and separate all-node support-audit panels are supplied."
paths={'combined':str((B/'图件/Vector_PDF/Figure2_combined_primary73_key_clades.pdf').resolve()),'individual':{f:str((B/f'图件/Vector_PDF/Figure2{l}_{f}_primary73_key_clades.pdf').resolve()) for l,f in zip('ABC',FAMS)},'supplementary':{f:str((B/f'图件/Vector_PDF/FigureS1{l}_{f}_primary73_full.pdf').resolve()) for l,f in zip('ABC',FAMS)}}
integration={'abstract':summary,'methods':methods,'results':results,'caption':caption,'discussion':discussion,'response':response,'response_labels':response_labels,'figure_paths':paths,'tree_paths':str((B/'collected').resolve()),'table_paths':{'workbook':str((B/'F2_S1_S7_S8_replacement_tables.xlsx').resolve()),'S7':str((A/'S7_PhyloGroups.tsv').resolve()),'S8':str((A/'S8_PhyloSupport.tsv').resolve()),'selected_groups':str((A/'key_branch_evidence.tsv').resolve()),'taxon_metadata':str((A/'taxon_metadata_verified_sequences.tsv').resolve())},'scope':{'primary_rso':73,'extended_rso':1,'full_taxa':[110,43,159],'selected_groups':ng,'groups_by_family':dict(count),'retained_historical_groups':retained,'unretained_historical_groups':lost,'new_or_promoted_groups':new,'old_rooting_tests_scope':'historical fixed-taxon analysis only; no new rooting inference'}}
integration['figure_stem']='系统树_F2/图件/High_Resolution_PNG/Figure2_combined_primary73_key_clades'
integration['artifact_paths']=integration['table_paths']
integration['table_paths']={'S7_PhyloGroups':'系统树_F2/审核表/S7_PhyloGroups.tsv','S8_PhyloSupport':'系统树_F2/审核表/S8_PhyloSupport.tsv'}
integration['primary_group_mapping_path']='系统树_F2/审核表/primary73_group_mapping.tsv'
integration['scope']['supplementary_figure_export_status']='pending' if MAIN_ONLY else 'complete'
integration['caption_S1']='Figure S1. Complete maximum-likelihood trees for the updated AMP-family sampling. (A) Defensin, 110 sequences; (B) Snakin/GASA, 43 sequences; and (C) nsLTP, 159 sequences. These are the complete, uncollapsed full-precursor gappyout trees underlying Figure 2. Bold labels denote primary R. soongarica members, RsLTP20* denotes the extended candidate and x identifies historical Rso exclusions. Coloured local groups meet the identical-all-taxon-split criterion and SH-aLRT ≥ 80%/UFBoot ≥ 95% in all four strategies; labels on their stems report the source-tree support and n counts all sequences in each group. Dashed branches fall below the joint support threshold in this source tree. Complete numerical support values are supplied in the separate all-node support-audit panels and Table S8. The circular cladogram preserves topology and node support but does not scale radial distances by evolutionary branch length; its centre is not a biological root. Group names are descriptive local relationships, not formal subfamilies. Exact taxon IDs, source accessions and display aliases accompany the trees.'
comparison_note='The historical 20260902 run restricted ModelFinder to LG, WAG, JTT, VT and DAYHOFF with E, I, G4 and R4 rate settings and seed 20260902. The current run uses the complete default MFP search and seed 20260909. Alignments were regenerated with four MAFFT threads (historically 16). The Snakin/GASA inputs remained the same 43 sequences; its full alignments changed from 353/94 to 372/117 columns (untrimmed/gappyout), whereas its two core alignments are identical by taxon and column. Differences between historical and current tree estimates therefore are not treated as a single-factor test of adding sequences or changing the random seed. Both within-current-run scheduling changes preserved inputs, alignments, inference settings and checkpoints.'
integration['comparison_with_historical']=comparison_note
integration['response']+=' '+comparison_note
if 'G1' in lost:
 g1_note='Snakin/GASA retained its original 43 input sequences. In the current reconstructions, G1 has UFBoot support of 94% and 92% in the untrimmed-core and gappyout-core trees, respectively, indicating support sensitivity near the 95% cutoff; this loss of four-strategy qualification is not attributed to adding catalogue members.'
 integration['discussion']+=' '+g1_note
 integration['results']+=' '+g1_note
if 'L2' in lost:
 l2_note='The historical nsLTP group L2 (RsLTP26 and RsLTP38) falls below both thresholds in the full-gappyout reconstruction (SH-aLRT/UFBoot 77.7%/90%), while its corresponding split passes in the other three strategies.'
 integration['results']+=' '+l2_note
 integration['response']+=' '+l2_note
integration_payload=json.dumps(integration,ensure_ascii=False,indent=2).encode('utf-8')
(B/'Captions_Methods_Results_EN.md').write_text('\n\n'.join('# '+k+'\n\n'+integration[k] for k in ['abstract','methods','results','caption','caption_S1','discussion','response','response_labels','comparison_with_historical']),encoding='utf-8')
readme=f'''# 更新目录的 Figure 2 / Figure S1 / S7 / S8 独立交付

新 12 树全部完成并取回，三家族完整取样为 110 / 43 / 159 个序列。主图显示全部 73 个 Rso 主成员及 RsLTP20* 扩展候选。输入覆盖双物种完整扩展目录 113 个成员，蛋白均与冻结目录精确一致；保留历史参考和边界对照。原作者图、正式文稿和旧 16 个定根测试未被覆盖。

本次 {ng} 个非重叠高亮组：DEF {count['Defensin']}、SNA {count['Snakin_GASA']}、nsLTP {count['nsLTP']}。旧七组保留 {len(retained)} 个（{', '.join(retained)}）；不再达标者为 {', '.join(lost) or '无'}。新增或提升组为 {', '.join(new) or '无'}。组名不代表正式亚家族。

## 可整合文件

- `final_integration.json`：root 请求的摘要/Methods/Results/Figure2图注/Discussion/两类 reviewer response 文案，以及图表实际路径。
- `图件/Vector_PDF/Figure2_combined_primary73_key_clades.pdf`：组合主图；同目录三个主图单面板及三个完整 FigureS1 面板。对应 SVG 与 600-dpi PNG 在 Editable_SVG 和 High_Resolution_PNG；预览在 Previews。
- `图件/Support_audit`：三个完整树的矩形全节点数值支持审计图。
- `F2_S1_S7_S8_replacement_tables.xlsx`：S7 分组、S8 全分支、比对规模/模型、选中组、所有稳定分割、旧组逐策略核对、74 Rso 放置状态、312 序列及别名。
- `审核表/key_branch_evidence.tsv` 是最终高亮组。`S7_PhyloGroups.tsv` 保留 Rso-restricted 统计，并增加 identical-all-taxon 分割核对列；不能将 restricted 4/4 自动等同稳定高亮。
- `审核表/legacy_group_strategy_support.tsv` 区分历史取样投影仍相同但支持不足、全体新取样分割改变、投影不存在等情况。
- `collected`：所有 12 树、IQ-TREE 报告、日志、全长/核心输入与比对，保留新运行 SHA-256。原报告保留真实服务器路径和完整参数。`Newick_iTOL` 为展示副本和可追溯标签文件。
- `审核表/final_QA.json`：最终检验；`MANIFEST_SHA256.tsv`：目录文件清单。

## 解释边界

联合阈值固定为 SH-aLRT ≥ 80 / UFBoot ≥ 95，稳定关系要求四策略同一 all-taxon 无根分割。旧支持组优先保留原名，其他最小不重叠局部分割依次分配新编号；所有嵌套稳定分割仍在审核表中，避免重复色块覆盖。稳定 canonical 侧若跨任意展示起点而不能直接画为子树，保留为稳定审核记录但不着色；未着色不能据此解释为不稳定。Core 为全前体第一至最后 Cys 的操作性区段，不是独立实验界定的成熟肽。主图仅折叠未达联合阈值的展示节点；完整树不折叠。径向长度仅为 cladogram 排版，中心不是祖先根。旧 16 个定根测试仍仅对应其历史固定取样，不能由本次取回结果改写为新全目录已定根。

原脚本样式快照保存在 `style_source_snapshot`，本次仅调用其绘图函数，不调用硬编码旧七组的旧 main。新运行审计及图件构建脚本为 `collect_completed_trees.py`、`audit_updated_phylogeny.py`、`plot_updated_key_clades.py`、`finalize_phylogeny_delivery.py`。收集脚本只读取已完成输出，不启动树。
'''
(B/'README_交付与范围.md').write_text(readme+'\n\n## 历史参数比较\n\n'+comparison_note+('\n\n当前主图和表已冻结；完整 S1 图件导出仍在补齐。\n' if MAIN_ONLY else '\n\n主图、完整 S1 和支持度审计图导出全部完成。\n'),encoding='utf-8')
rows=[]
for p in sorted(B.rglob('*')):
 if p.is_file() and p.name not in ['MANIFEST_SHA256.tsv','final_integration.json','.final_integration.pending'] and '__pycache__' not in p.parts:rows.append({'relative_path':p.relative_to(B).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
rows.append({'relative_path':'final_integration.json','bytes':len(integration_payload),'sha256':hashlib.sha256(integration_payload).hexdigest()})
with (B/'MANIFEST_SHA256.tsv').open('w',encoding='utf-8-sig',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');wr.writeheader();wr.writerows(rows)
(B/'.final_integration.pending').write_bytes(integration_payload)
(B/'.final_integration.pending').replace(B/'final_integration.json')
print(json.dumps(integration['scope'],indent=2))
