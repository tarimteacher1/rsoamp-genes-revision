"""Rename current display groups from frozen sources; no tree inference."""
from pathlib import Path
import csv,hashlib,json,re,shutil
import openpyxl
B=Path(__file__).resolve().parent;W=B.parent.parent
OLD=B/'historical_audit_snapshot';A=B/'审核表'
MAP={'L1':'L1','L3':'L2','L4':'L3'}
NAMESPACE='Historical audit labels before consecutive display renumbering; not current display labels.'
CURRENT_FIELDS={'group_label','selected_group','stable_group','selected_current_group','selected_groups'}
def remap(s):return ';'.join(MAP.get(v,v) for v in s.split(';')) if isinstance(s,str) else s
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');wr.writeheader();wr.writerows(rows)
mapping=[]
for r in read(OLD/'审核表/key_branch_evidence.tsv'):
 if r['family']=='nsLTP':mapping.append({'historical_audit_group':r['group_label'],'current_display_group':MAP[r['group_label']],'Rso_members':r['members'],'all_taxon_ids':r['all_taxon_ids'],'n_all_sequences':r['total_sequences'],'color_unchanged':r['color'],'full_gappyout_support_unchanged':r['source_support'],'change_scope':'Display label only; members, colour, support and trees unchanged.'})
write(B/'current_group_renaming.tsv',sorted(mapping,key=lambda r:r['current_display_group']))
write(A/'current_group_renaming.tsv',sorted(mapping,key=lambda r:r['current_display_group']))
changes=[]
for p in sorted((OLD/'审核表').glob('*.tsv')):
 rows=read(p)
 if not rows:continue
 changed=False
 for r in rows:
  for k in CURRENT_FIELDS & r.keys():
   new=remap(r[k])
   if new!=r[k]:changes.append({'file':p.name,'field':k,'old':r[k],'new':new});r[k]=new;changed=True
  if 'legacy_group' in r or 'legacy_group_label' in r:
   r['historical_label_namespace']=NAMESPACE;changed=True
  if 'group_label' in r and 'selection_note' in r:
   r['selection_note']='Selected biological split unchanged; current display label follows current_group_renaming.tsv; legacy_group_label retains historical audit identity.';changed=True
 if changed:write(A/p.name,rows)
 else:shutil.copy2(p,A/p.name)

def update_json(obj,key=''):
 if isinstance(obj,dict):
  ans={k:update_json(v,k) for k,v in obj.items()}
  if 'legacy_group' in ans or 'legacy_group_label' in ans:ans['historical_label_namespace']=NAMESPACE
  return ans
 if isinstance(obj,list):
  return [remap(v) if key=='key_groups' and isinstance(v,str) else update_json(v,key) for v in obj]
 if key in CURRENT_FIELDS|{'label','key_groups'} and isinstance(obj,str):return remap(obj)
 return obj
for p in (OLD/'审核表').glob('*.json'):
 obj=update_json(json.loads(p.read_text(encoding='utf-8')))
 (A/p.name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')

# Update only current group cells in the existing supporting workbook.
book=openpyxl.load_workbook(OLD/'F2_S1_S7_S8_replacement_tables.xlsx')
for ws in book.worksheets:
 header={c.value:c.column for c in ws[1]}
 for field in CURRENT_FIELDS & header.keys():
  for cells in ws.iter_rows(min_row=2,min_col=header[field],max_col=header[field]):
   c=cells[0]
   if isinstance(c.value,str):c.value=remap(c.value)
book.save(B/'F2_S1_S7_S8_replacement_tables.xlsx')

# Keep a usable metadata/caption packet alongside the changed plots.
obj=json.loads((OLD/'final_integration.json').read_text(encoding='utf-8'))
oldret='Of the seven previously highlighted groups, 5 retain four-strategy support in the current reconstructions (D1, G2, L1, L3, L4). G1, L2 no longer meet the complete current criterion and are not retained as highlighted groups. Newly qualifying or promoted local groups are D2.'
newret='Five of the seven historical audit groups retain four-strategy support. Their current display labels are D1, G2, L1, L2 and L3; the nsLTP crosswalk is historical L1 to current L1, historical L3 to current L2 and historical L4 to current L3. Historical G1 and historical audit group L2 (RsLTP26 and RsLTP38) no longer meet the complete current criterion. D2 remains the newly qualifying defensin group.'
for k in ['results','discussion','response']:
 obj[k]=obj[k].replace(oldret,newret)
 obj[k]=obj[k].replace('L4: RsLTP5, RsLTP6','L3: RsLTP5, RsLTP6').replace('L3: RsLTP39, RsLTP40','L2: RsLTP39, RsLTP40')
 obj[k]=obj[k].replace('The historical nsLTP group L2 (RsLTP26 and RsLTP38)','Historical audit group L2 (RsLTP26 and RsLTP38; not current display L2)')
obj['methods']=obj['methods'].replace('Qualifying historical groups retained their names; remaining smallest disjoint local splits were selected to avoid nested colour overlays, and all qualifying nested splits remain in the audit table.','Qualifying biological splits are unchanged. The current nsLTP display uses consecutive labels L1, L2 and L3, corresponding to historical audit groups L1, L3 and L4, respectively; the crosswalk preserves the earlier audit identity. Remaining smallest disjoint local splits were selected to avoid nested colour overlays, and all qualifying nested splits remain in the audit table.')
note=' Current nsLTP display groups are L1 (RsLTP13/RsLTP22), L2 (RsLTP39/RsLTP40) and L3 (RsLTP5/RsLTP6); historical audit labels are retained separately in the crosswalk.'
obj['caption']+=note;obj['caption_S1']+=note
obj['response_labels']+=' The current nsLTP group labels were made consecutive: L1, L2 and L3 replace historical audit labels L1, L3 and L4, respectively, without changing members, colours, branch support or topology.'
obj['scope']['current_display_groups']=['D1','D2','G2','L1','L2','L3']
obj['scope']['historical_label_namespace']=NAMESPACE
obj['current_group_renaming']=mapping
obj['figure_stem']='phylogeny_update/图件/High_Resolution_PNG/Figure2_combined_primary73_key_clades'
obj['primary_group_mapping_path']='phylogeny_update/审核表/primary73_group_mapping.tsv'
obj['table_paths']={'S7_PhyloGroups':'phylogeny_update/审核表/S7_PhyloGroups.tsv','S8_PhyloSupport':'phylogeny_update/审核表/S8_PhyloSupport.tsv'}
def current_paths(v):
 if isinstance(v,dict):return {k:current_paths(x) for k,x in v.items()}
 if isinstance(v,list):return [current_paths(x) for x in v]
 if isinstance(v,str):
  portable=v.replace('\\','/')
  if '/系统树_F2/' in portable and (re.match(r'^[A-Za-z]:/',portable) or portable.startswith('/')):
   return str(B/portable.split('/系统树_F2/',1)[1])
  return v.replace(str(W/'全文图表同步_20260909/系统树_F2'),str(B))
 return v
obj=current_paths(obj)
(B/'final_integration.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
(B/'Captions_Methods_Results_EN.md').write_text('\n\n'.join('# '+k+'\n\n'+obj[k] for k in ['abstract','methods','results','caption','caption_S1','discussion','response','response_labels','comparison_with_historical']),encoding='utf-8')
(B/'README_交付与范围.md').write_text('# Figure 2 连续显示编号同步\n\n当前分组为 D1、D2、G2、L1、L2、L3。nsLTP 仅显示标签由历史 L1/L3/L4 改为当前 L1/L2/L3；成员、颜色、支持和树完全不变。历史 audit L2（RsLTP26/RsLTP38）未通过当前门槛，不能与新 display L2（RsLTP39/RsLTP40）混淆。\n\n`current_group_renaming.tsv` 为精确对照，`legacy_group` / `legacy_group_label` / 历史支持表保留原编号并标注命名范围。S7/S8 的基因集及分支支持未改变。`style_source_snapshot` 是历史绘图样式源；其中旧示例/分组推导代码仅作历史快照，本次仅调用绘图函数，不调用旧 main 或重建任何树。当前输出由更新后的 `plot_updated_key_clades.py` 读取当前表生成。\n\n原冻结包未被修改。\n',encoding='utf-8')
write(B/'changed_current_table_cells.tsv',changes)
print('Current table label cells changed:',len(changes))
