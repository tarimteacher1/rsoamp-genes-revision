"""Create an exact copy plan from existing exports; does not install files."""
from pathlib import Path
import csv
import hashlib

B = Path(__file__).resolve().parent
rows = []
for sub in ['Vector_PDF', 'Editable_SVG', 'High_Resolution_PNG']:
    for p in sorted((B / '图件' / sub).glob('*')):
        if p.is_file() and p.name.startswith(('Figure2', 'FigureS1')):
            rows.append((p, f'04_Figures/{sub}/{p.name}', 'main_or_complete_supplementary_figure'))
for p in sorted((B / '图件' / 'Support_audit').rglob('*')):
    if p.is_file() and 'Previews' not in p.parts:
        rows.append((p, '05_Newick_and_annotations/Support_audit/' + p.relative_to(B / '图件' / 'Support_audit').as_posix(), 'all_node_support_audit_figure'))
for p in sorted((B / 'Newick_iTOL').glob('*')):
    if p.is_file():
        rows.append((p, '05_Newick_and_annotations/Updated_primary73/' + p.name, 'display_tree_or_iTOL_labels'))
for p in sorted((B / 'collected').rglob('*')):
    if p.is_file() and p.suffix in ('.treefile', '.iqtree', '.log', '.faa', '.contree', '.splits', '.ufboot'):
        rows.append((p, '05_Newick_and_annotations/Updated_primary73/Inference_outputs/' + p.relative_to(B / 'collected').as_posix(), 'verified_inference_source'))
for p in sorted((B / '审核表').glob('*.tsv')):
    rows.append((p, '05_Newick_and_annotations/Updated_primary73/Audit_tables/' + p.name, 'traceable_audit_table'))
dest = B / 'STAGE_COPY_MANIFEST.tsv'
with dest.open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['source_relative_to_sync_root', 'destination_relative_to_stage', 'kind', 'bytes', 'sha256'], delimiter='\t')
    writer.writeheader()
    for p, target, kind in rows:
        writer.writerow({'source_relative_to_sync_root': p.relative_to(B.parent).as_posix(), 'destination_relative_to_stage': target, 'kind': kind, 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
print(f'{len(rows)} existing files recorded in {dest}')
