"""Layout proof for already completed families while the remaining family runs."""
from pathlib import Path
import csv,sys,copy
sys.dont_write_bytecode=True
from Bio import Phylo
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
B=Path(__file__).resolve().parent;W=B.parent.parent
SRC=W/'Genes_lab_handoff_20260908/02_Workspace/9_2_major_revision/Genes_key_clade_review_20260903'
sys.path.insert(0,str(SRC/'06_Scripts'))
import build_key_clade_figures as style
from plot_circular_phylogenies import read_tsv
meta=read_tsv(B/'taxon_metadata.tsv');rows=read_tsv(B/'审核表/S8_PhyloSupport.tsv')
labels={r['newick_id']:r['display_label'] for r in read_tsv(SRC/'04_Newick_and_annotations/tip_label_key.tsv')}
groups=[('Defensin','D1',['RsDEF13','RsDEF14'],'#287CB4'),('Defensin','D2',['RsDEF15','RsDEF16','RsDEF17','RsDEF18','RsDEF19','RsDEF20'],'#CE6941'),('Snakin_GASA','G2',['RsSNA14','RsSNA15','RsSNA17','RsSNA18','RsSNA19','RsSNA3','RsSNA5','RsSNA8'],'#CE6941')]
out=B/'layout_proofs_completed_families';out.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'Arial','pdf.fonttype':42,'svg.fonttype':'none'})
for fam in ['Defensin','Snakin_GASA']:
 tree=Phylo.read(B/'collected'/fam/(fam+'.full.gappyout.treefile'),'newick');tree.ladderize()
 primary={r['current_member_id'] for r in meta if r['family']==fam and r['current_species']=='rso' and r['current_status']=='primary'}
 aliases={t.name:labels.get(t.name,t.name.removeprefix('RSO_')) for t in tree.get_terminals()};rr=[]
 for f,g,wanted,color in groups:
  if f!=fam:continue
  choices=[r for r in rows if r['family']==fam and r['strategy']=='full.gappyout' and set(r['rso_group'].split(';'))==set(wanted) and r['joint_support']=='TRUE']
  for r in choices:
   ids=set(r['canonical_unrooted_split'].split(';'));sts={v['strategy'] for v in rows if v['family']==fam and v['canonical_unrooted_split']==r['canonical_unrooted_split'] and v['joint_support']=='TRUE'}
   if len(sts)==4:break
  else:raise ValueError('Expected completed-family group not supported')
  node=tree.common_ancestor([t for t in tree.get_terminals() if t.name in ids]);assert {t.name for t in node.get_terminals()}==ids
  rr.append({'all_taxon_ids':';'.join(sorted(ids)),'group_label':g,'color':color,'highlight_in_main':True,'total_sequences':len(ids),'source_support':node.name})
 display=style.main_display(tree,primary,set(),rr)
 fig=plt.figure(figsize=(9,9));ax=fig.add_axes([.02,.095,.96,.85]);q=style.draw(ax,display,aliases,primary,rr,fam,10.5)
 fig.savefig(out/(fam+'_completed_family_layout.png'),dpi=140,facecolor='white');plt.close(fig)
 print(fam,q)
