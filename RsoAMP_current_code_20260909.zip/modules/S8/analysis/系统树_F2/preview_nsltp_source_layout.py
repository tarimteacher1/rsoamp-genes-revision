from pathlib import Path
import sys
sys.dont_write_bytecode=True
from Bio import Phylo
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
B=Path(__file__).resolve().parent;W=B.parent.parent
SRC=W/'Genes_lab_handoff_20260908/02_Workspace/9_2_major_revision/Genes_key_clade_review_20260903'
sys.path.insert(0,str(SRC/'06_Scripts'))
import build_key_clade_figures as style
from plot_circular_phylogenies import aliases_for,read_tsv
meta=read_tsv(B/'taxon_metadata.tsv');primary={r['current_member_id'] for r in meta if r['family']=='nsLTP' and r['current_species']=='rso' and r['current_status']=='primary'}
tree=Phylo.read(B/'collected/nsLTP/nsLTP.full.gappyout.treefile','newick');tree.ladderize()
aliases=aliases_for(tree,primary,'nsLTP')
old_aliases={r['newick_id']:r['display_label'] for r in read_tsv(SRC/'04_Newick_and_annotations/tip_label_key.tsv')}
number=max(int(v[5:]) for v in old_aliases.values() if v.startswith('TaLTP'))
for tax in sorted(aliases):
 if tax in old_aliases:aliases[tax]=old_aliases[tax]
 elif tax.startswith('TAU_'):number+=1;aliases[tax]='TaLTP'+f'{number:02d}'
aliases['RSO_RsLTP20']='RsLTP20*';assert len(set(aliases.values()))==len(aliases)
base_category=style.tip_category
style.tip_category=lambda n,p:'extended_Rso' if n=='RSO_RsLTP20' else base_category(n,p)
plt.rcParams.update({'font.family':'Arial','pdf.fonttype':42,'svg.fonttype':'none'})
fig=plt.figure(figsize=(13,13));ax=fig.add_axes([.02,.095,.96,.85]);q=style.draw(ax,tree,aliases,primary,[],'nsLTP full-gappyout source | layout proof only',8.4,True)
out=B/'layout_proofs_completed_families';out.mkdir(exist_ok=True);fig.savefig(out/'nsLTP_source_layout_no_group_decisions.png',dpi=120,facecolor='white')
print(q)
