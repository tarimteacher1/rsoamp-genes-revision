from pathlib import Path
import csv,hashlib,json,re,shutil,xml.etree.ElementTree as ET,zipfile
import openpyxl
B=Path(__file__).resolve().parent;W=B.parent.parent;ST=B.parent/'stage'
OLD=W/'全文图表同步_20260909/系统树_F2';FORMAL=W/'Genes_lab_handoff_20260908/01_Current_Editing'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 with p.open(encoding='utf-8-sig') as f:return list(csv.DictReader(f,delimiter='\t'))
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');wr.writeheader();wr.writerows(rows)
M={'L4 (n=2)':'L3 (n=2)','L3 (n=3)':'L2 (n=3)'}
stems=['Figure2_combined_primary73_key_clades','Figure2C_nsLTP_primary73_key_clades','FigureS1C_nsLTP_primary73_full']
checks=[]
def semantic(svg,mapped=False):
 ans=[]
 for n in ET.parse(svg).getroot().iter():
  tag=n.tag.split('}')[-1]
  if tag not in {'path','line','circle','rect','polygon','polyline','text'}:continue
  attrs=tuple(sorted((k,v) for k,v in n.attrib.items() if k not in {'id','clip-path'}))
  text=''.join(n.itertext()) if tag=='text' else ''
  if mapped:text=M.get(text,text)
  ans.append((tag,attrs,text))
 return ans
for stem in stems:
 new=B/'图件/Editable_SVG'/(stem+'.svg');old=OLD/'图件/Editable_SVG'/(stem+'.svg')
 a=semantic(old,True);b=semantic(new)
 assert a==b,(stem,'Geometry/style/content differ beyond exact label mapping')
 texts=[''.join(n.itertext()) for n in ET.parse(new).getroot().iter() if n.tag.endswith('}text')]
 assert not any(t.startswith('L4 (') for t in texts)
 assert 'L1 (n=4)' in texts and 'L2 (n=3)' in texts and 'L3 (n=2)' in texts
 checks.append({'check':'SVG geometry/style/text identical except group-label mapping','target':stem,'result':'PASS'})
for p in (OLD/'图件').rglob('*'):
 if p.is_file() and p.stem not in stems:assert sha(p)==sha(B/'图件'/p.relative_to(OLD/'图件')),p
for directory in ['collected','Newick_iTOL']:
 for p in (OLD/directory).rglob('*'):
  if p.is_file():assert sha(p)==sha(B/directory/p.relative_to(OLD/directory)),p
checks.append({'check':'All collected inference files, Newick/iTOL and all other figure bytes unchanged','target':'independent source copy','result':'PASS'})
oldrows=read(OLD/'审核表/key_branch_evidence.tsv');newrows=read(B/'审核表/key_branch_evidence.tsv')
for old,new in zip(oldrows,newrows):
 for field in ['members','all_taxon_ids','color','source_support','four_strategy_supports','total_sequences','Rso_sequences','legacy_group_label']:
  assert old[field]==new[field],(field,old['members'])
current={r['group_label']:r for r in newrows if r['family']=='nsLTP'}
assert set(current)=={'L1','L2','L3'}
assert current['L2']['members']=='RsLTP39;RsLTP40' and current['L3']['members']=='RsLTP5;RsLTP6'
checks.append({'check':'Current groups and all scientific evidence unchanged','target':'key_branch_evidence.tsv','result':'PASS'})
for name in ['S7_PhyloGroups.tsv','S8_PhyloSupport.tsv','alignment_comparison.tsv','taxon_metadata_verified_sequences.tsv','tip_label_key.tsv']:
 assert sha(OLD/'审核表'/name)==sha(B/'审核表'/name),name

bookold=openpyxl.load_workbook(OLD/'F2_S1_S7_S8_replacement_tables.xlsx');booknew=openpyxl.load_workbook(B/'F2_S1_S7_S8_replacement_tables.xlsx')
diffs=[]
assert bookold.sheetnames==booknew.sheetnames
for ws in bookold:
 other=booknew[ws.title];assert ws.max_row==other.max_row and ws.max_column==other.max_column
 headers={c.column:c.value for c in ws[1]}
 for row in ws:
  for c in row:
   n=other[c.coordinate]
   if c.value!=n.value:
    assert headers[c.column] in {'group_label','selected_current_group','selected_group'},(ws.title,c.coordinate,headers[c.column])
    assert (c.value,n.value) in {('L3','L2'),('L4','L3')}
    diffs.append({'sheet':ws.title,'cell':c.coordinate,'field':headers[c.column],'historical_value':c.value,'current_value':n.value})
assert len(diffs)==10,diffs
write(B/'workbook_label_cells_changed.tsv',diffs)
checks.append({'check':'Workbook changed exactly 10 current-label cells; all other values including legacy labels identical','target':'F2_S1_S7_S8_replacement_tables.xlsx','result':'PASS'})

# Install only the three figure sets which actually contain group-number text.
for stem in stems:
 name='Figure2_catalogue_synced_20260909' if stem.startswith('Figure2_combined') else stem
 for sub,ext in [('Vector_PDF','pdf'),('Editable_SVG','svg'),('High_Resolution_PNG','png'),('Previews','png')]:
  dst=ST/'04_Figures'/sub/(name+'.'+ext);dst.parent.mkdir(parents=True,exist_ok=True)
  shutil.copy2(B/'图件'/sub/(stem+'.'+ext),dst)
for p in (B/'审核表').glob('*'):
 if p.is_file() and p.suffix in {'.tsv','.json'}:
  dst=ST/'05_Newick_iTOL/Audit_tables'/p.name;shutil.copy2(p,dst)
shutil.copy2(B/'current_group_renaming.tsv',ST/'05_Newick_iTOL/current_group_renaming.tsv')

integration=json.loads((B/'final_integration.json').read_text(encoding='utf-8'))
legend=ST/'04_Figures/Figure_legends.md';text=legend.read_text(encoding='utf-8')
oldcaption=json.loads((OLD/'final_integration.json').read_text(encoding='utf-8'))['caption_S1']
if integration['caption_S1'] not in text and oldcaption in text:text=text.replace(oldcaption,integration['caption_S1'])
assert integration['caption_S1'] in text
legend.write_text(text,encoding='utf-8')
v=ST/'05_Newick_iTOL/Figure2_CURRENT_VERSION.md';text=v.read_text(encoding='utf-8')
paragraph='Current display-label update: nsLTP groups are L1 (RsLTP13/RsLTP22), L2 (RsLTP39/RsLTP40) and L3 (RsLTP5/RsLTP6). The historical audit crosswalk is L1→L1, L3→L2 and L4→L3. Historical audit L2 (RsLTP26/RsLTP38) remains unhighlighted and is not current display L2. Only display labels changed; group membership, colours, supports, topology and gene/taxon identifiers are unchanged. See current_group_renaming.tsv.\n'
if paragraph not in text:text+='\n'+paragraph
v.write_text(text,encoding='utf-8')
changed=[]
for folder in ['04_Figures','05_Newick_iTOL']:
 for p in (ST/folder).rglob('*'):
  if p.is_file():
   relative=p.relative_to(ST);old=FORMAL/relative
   if not old.exists() or sha(p)!=sha(old):changed.append({'stage_relative_path':relative.as_posix(),'bytes':p.stat().st_size,'sha256':sha(p),'previous_sha256':sha(old) if old.exists() else '', 'zip_relative_path':('current_figures/' if folder=='04_Figures' else 'current_newick/')+p.relative_to(ST/folder).as_posix()})
write(B/'stage_changed_files.tsv',changed)

# Exact package paths for root's ZIP update; root owns package manifests.
replacements=[]
for r in changed:replacements.append({'source_relative_to_new_root':'stage/'+r['stage_relative_path'],'zip_relative_path':r['zip_relative_path'],'sha256':r['sha256']})
for p in B.rglob('*'):
 if not p.is_file() or '__pycache__' in p.parts or p.name in {'FILES8_REPLACEMENTS.tsv','display_label_update_QA.json','stage_changed_files.tsv'}:continue
 rel=p.relative_to(B);old=OLD/rel
 if not old.exists() or sha(p)!=sha(old):replacements.append({'source_relative_to_new_root':'phylogeny_update/'+rel.as_posix(),'zip_relative_path':'analysis/系统树_F2/'+rel.as_posix(),'sha256':sha(p)})
write(B/'FILES8_REPLACEMENTS.tsv',replacements)
qa={'status':'PASS','current_nsLTP_groups':{k:{'members':r['members'],'n':int(r['total_sequences']),'color':r['color'],'source_support':r['source_support'],'historical_audit_group':r['legacy_group_label']} for k,r in current.items()},'checks':checks,'workbook_label_cell_changes':10,'trees_recomputed':False,'all_scientific_evidence_and_colours_unchanged':True,'only_three_figure_sets_rendered_and_staged':stems,'stage_changed_files':len(changed),'zip_replacements_or_additions':len(replacements),'historical_namespace_note':'Historical audit L2 refers to RsLTP26/RsLTP38, not new current display L2 (RsLTP39/RsLTP40).'}
(B/'display_label_update_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(qa,ensure_ascii=False,indent=2))
