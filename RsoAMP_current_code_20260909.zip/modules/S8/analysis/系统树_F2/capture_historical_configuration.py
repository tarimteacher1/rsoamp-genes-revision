from pathlib import Path
import subprocess,json,hashlib
B=Path(__file__).resolve().parent;W=B.parent.parent
code="""from pathlib import Path
import json,hashlib
B=Path('/path/to/rso_project/revision_R1_20260902/08_reproducibility/commands')
out=[]
for f in ['Defensin','Snakin_GASA','nsLTP']:
 for region in ['full','core']:
  for trim in ['untrimmed','gappyout']:
   p=B/(f+'.'+region+'.'+trim+'.iqtree.command.txt');s=p.read_text()
   out.append({'family':f,'strategy':region+'.'+trim,'remote_path':str(p),'command':s.strip(),'file_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
print(json.dumps(out))
"""
r=subprocess.run(['ssh','-o','BatchMode=yes','example-host','python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=20)
assert r.returncode==0,r.stderr
rr=json.loads(r.stdout);assert len(rr)==12
for row in rr:
 assert '-mset LG,WAG,JTT,VT,DAYHOFF' in row['command'] and '-mrate E,I,G4,R4' in row['command']
 assert '-seed 20260902' in row['command']
(B/'historical_20260902_commands_verified.json').write_text(json.dumps(rr,indent=2,ensure_ascii=False),encoding='utf-8')
print('Verified 12 historical command records with restricted model/rate sets and seed 20260902.')
