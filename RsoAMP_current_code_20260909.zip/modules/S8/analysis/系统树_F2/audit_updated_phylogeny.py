"""Audit frozen inputs and completed IQ-TREE outputs; no inference or rerooting."""
from pathlib import Path
from collections import defaultdict,Counter
import csv,hashlib,json,re
from Bio import Phylo,SeqIO
B=Path(__file__).resolve().parent;W=B.parent.parent;C=B/'collected';O=B/'审核表';O.mkdir(exist_ok=True)
OLD=W/'Genes_lab_handoff_20260908/02_Workspace/9_2_major_revision/revision_R1_20260902/02_phylogeny'
LEG=W/'Genes_lab_handoff_20260908/02_Workspace/9_2_major_revision/Genes_key_clade_review_20260903/04_Newick_and_annotations'
FAMS=['Defensin','Snakin_GASA','nsLTP'];STRATS=['full.untrimmed','full.gappyout','core.untrimmed','core.gappyout']
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def write(p,rows):
 if not rows:return
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def split(s):return set(s.split(';')) if s else set()
def joined(s):return ';'.join(sorted(s))
def canonical(a,b):return min((tuple(sorted(a)),tuple(sorted(b))),key=lambda x:(len(x),x))
def support(n):
 m=re.fullmatch(r'([\d.]+)/([\d.]+)',str(n or ''))
 return tuple(map(float,m.groups())) if m else ('','')
meta=read(B/'taxon_metadata.tsv');byid={r['taxon_id']:r for r in meta};assert len(byid)==len(meta)
cat=read(W/'成员判定收尾_20260909/统一目录/统一成员目录_扩展113.tsv')
catmap={(r['species'],r['member_id']):r for r in cat}
primary={f:{r['taxon_id'] for r in meta if r['family']==f and r['current_species']=='rso' and r['current_status']=='primary'} for f in FAMS}
inputrows=[];inputqa=[]
for fam in FAMS:
 full={s.id:str(s.seq) for s in SeqIO.parse(B/fam/(fam+'.full.faa'),'fasta')}
 core={s.id:str(s.seq) for s in SeqIO.parse(B/fam/(fam+'.core.faa'),'fasta')}
 oldfull={s.id:str(s.seq) for s in SeqIO.parse(OLD/fam/(fam+'.full.faa'),'fasta')}
 oldcore={s.id:str(s.seq) for s in SeqIO.parse(OLD/fam/(fam+'.core.faa'),'fasta')}
 assert set(full)==set(core)=={r['taxon_id'] for r in meta if r['family']==fam}
 changes=[]
 for tax,aa in full.items():
  rr=byid[tax];start=aa.find('C');end=aa.rfind('C')+1
  assert core[tax]==aa[start:end]
  assert hashlib.sha256(aa.encode()).hexdigest()==rr['sha256']
  if tax in oldfull:assert oldfull[tax]==aa
  if tax in oldcore and oldcore[tax]!=core[tax]:changes.append(tax)
  if rr['current_status'] in ('primary','extended'):
   c=catmap[(rr['current_species'],rr['current_member_id'])];assert aa==c['full_sequence']
  inputrows.append({**rr,'actual_full_length_aa':len(aa),'actual_core_length_aa':len(core[tax]),'core_start_1based':start+1,'core_end_1based':end,'core_definition':'operational_first_to_last_cysteine_in_full_precursor','full_sequence':aa,'core_sequence':core[tax],'core_sha256':hashlib.sha256(core[tax].encode()).hexdigest(),'historical_source_note_status':'provenance_only; current_status overrides old inclusion wording','same_full_as_historical':tax in oldfull,'same_core_as_historical':tax in oldcore and oldcore[tax]==core[tax]})
 inputqa.append({'family':fam,'taxa':len(full),'primary_rso':len(primary[fam]),'current_tamarix_primary':sum(r['family']==fam and r['current_species']=='tau' and r['current_status']=='primary' for r in meta),'added_taxa':sorted(set(full)-set(oldfull)),'changed_historical_core_taxa':changes,'all_current_catalogue_sequences_match':True})
write(O/'taxon_metadata_verified_sequences.tsv',inputrows)
assert sum(len(v) for v in primary.values())==73
assert sum(r['current_status'] in ('primary','extended') for r in meta)==113
branches=[];alignment=[];trees={};complete=[]
for fam in FAMS:
 for st in STRATS:
  tp=C/fam/(fam+'.'+st+'.treefile');rp=tp.with_suffix('.iqtree')
  if not rp.exists() or 'Total wall-clock time used:' not in rp.read_text(encoding='utf-8'):continue
  report=rp.read_text(encoding='utf-8');tree=Phylo.read(tp,'newick');trees[(fam,st)]=tree
  allids={t.name for t in tree.get_terminals()};assert allids=={r['taxon_id'] for r in meta if r['family']==fam}
  assert len(allids)==len(tree.get_terminals())
  region,trim=st.split('.');ap=C/fam/(fam+'.'+region+('.aligned.faa' if trim=='untrimmed' else '.gappyout.faa'))
  seqs={r.id:str(r.seq) for r in SeqIO.parse(ap,'fasta')};assert set(seqs)==allids
  inputs={r.id:str(r.seq) for r in SeqIO.parse(B/fam/(fam+'.'+region+'.faa'),'fasta')}
  if trim=='untrimmed':assert all(s.replace('-','')==inputs[t] for t,s in seqs.items())
  else:
   untrim={r.id:str(r.seq) for r in SeqIO.parse(C/fam/(fam+'.'+region+'.aligned.faa'),'fasta')}
   order=sorted(seqs);original=list(zip(*(untrim[t] for t in order)));retained=list(zip(*(seqs[t] for t in order)))
   j=0
   for col in retained:
    while j<len(original) and original[j]!=col:j+=1
    assert j<len(original),(fam,st,'trimmed column not present in source alignment')
    j+=1
  sizes={len(s) for s in seqs.values()};assert len(sizes)==1
  def match(p):
   m=re.search(p,report,re.M);return m.group(1) if m else ''
  log=tp.with_suffix('.log').read_text(encoding='utf-8');command=re.search(r'^Command: (.+)$',log,re.M).group(1)
  for flag in ['-m MFP','-alrt 1000','-bb 1000','-bnni','-nt 4','-seed 20260909']:assert flag in command
  alignment.append({'family':fam,'strategy':st,'alignment_region':region,'trimming':trim,'sequence_count':len(allids),'alignment_sites':next(iter(sizes)),'best_fit_model_BIC':match(r'^Best-fit model according to BIC: (.+)$'),'tree_log_likelihood':match(r'^Log-likelihood of the tree: ([-\d.]+)'),'iqtree_version':report.splitlines()[0],'seed':match(r'^Random seed number: (\d+)'),'completed':True,'command_from_log':command,'alignment_sha256':sha(ap),'tree_sha256':sha(tp),'report_sha256':sha(rp),'iqtree_report':str(rp.relative_to(B)),'tree_file':str(tp.relative_to(B))})
  complete.append(fam+'.'+st)
  for index,n in enumerate(tree.get_nonterminals(order='preorder'),1):
   if n is tree.root:continue
   a={t.name for t in n.get_terminals()};b=allids-a;canon=canonical(a,b);sh,uf=support(n.name)
   ra={x[4:] for x in a if x.startswith('RSO_')};rb={x[4:] for x in b if x.startswith('RSO_')}
   rg=canonical(ra,rb) if ra and rb else ()
   pa={x[4:] for x in a&primary[fam]};pb={x[4:] for x in b&primary[fam]};pg=canonical(pa,pb) if pa and pb else ()
   branches.append({'family':fam,'strategy':st,'alignment_region':region,'trimming':trim,'node':index,'sh_alrt':sh,'ufboot':uf,'joint_support':'TRUE' if sh!='' and sh>=80 and uf>=95 else 'FALSE','side_a_taxa':joined(a),'side_b_taxa':joined(b),'canonical_unrooted_split':';'.join(canon),'canonical_split_size':len(canon),'rso_group':';'.join(rg),'rso_group_size':len(rg),'primary_rso_group':';'.join(pg),'primary_rso_group_size':len(pg),'tree_file':str(tp.relative_to(B))})
edge_keys=[(r['family'],r['strategy'],r['canonical_unrooted_split']) for r in branches]
assert len(edge_keys)==len(set(edge_keys)), 'Duplicate canonical edge in a strategy: inspect an artificial binary root before comparing support.'
write(O/'S8_PhyloSupport.tsv',branches);write(O/'alignment_comparison.tsv',alignment)
historical_commands=json.loads((B/'historical_20260902_commands_verified.json').read_text(encoding='utf-8'))
historical_command_map={(r['family'],r['strategy']):r for r in historical_commands}
run_comparison=[]
for r in alignment:
 fam=r['family'];st=r['strategy'];region,trim=st.split('.')
 oldreport=OLD/fam/(fam+'.'+st+'.iqtree');text=oldreport.read_text(encoding='utf-8')
 def oldvalue(p):
  m=re.search(p,text,re.M);return m.group(1) if m else ''
 oldali=OLD/fam/(fam+'.'+region+'.mafft_linsi'+('.gappyout' if trim=='gappyout' else '')+'.faa')
 newali=C/fam/(fam+'.'+region+('.aligned.faa' if trim=='untrimmed' else '.gappyout.faa'))
 oldseqs={x.id:str(x.seq) for x in SeqIO.parse(oldali,'fasta')};newseqs={x.id:str(x.seq) for x in SeqIO.parse(newali,'fasta')}
 run_comparison.append({'family':fam,'strategy':st,'old_taxa':len(oldseqs),'new_taxa':len(newseqs),'same_taxon_set':set(oldseqs)==set(newseqs),'same_alignment_by_taxon_ignoring_record_order':oldseqs==newseqs,'old_alignment_sites':len(next(iter(oldseqs.values()))),'new_alignment_sites':r['alignment_sites'],'old_best_fit_model_BIC':oldvalue(r'^Best-fit model according to BIC: (.+)$'),'new_best_fit_model_BIC':r['best_fit_model_BIC'],'old_seed':oldvalue(r'^Random seed number: (\d+)'),'new_seed':r['seed'],'old_model_search':'MFP; mset LG,WAG,JTT,VT,DAYHOFF; mrate E,I,G4,R4','new_model_search':'MFP default complete candidate set','old_IQTREE_threads':'AUTO up to 16','new_IQTREE_threads':4,'old_MAFFT_threads':16,'new_MAFFT_threads':4,'old_command':historical_command_map[(fam,st)]['command'],'new_command':r['command_from_log'],'comparison_interpretation':'Multiple run differences; not a single-factor test of adding catalogue members or changing seed.'})
write(O/'historical_vs_current_configuration.tsv',run_comparison)
groups=[]
for fam in FAMS:
 keys=sorted({r['rso_group'] for r in branches if r['family']==fam and r['joint_support']=='TRUE' and r['rso_group']})
 for k in keys:
  rr=[r for r in branches if r['family']==fam and r['rso_group']==k and r['joint_support']=='TRUE'];sts={r['strategy'] for r in rr};sp=defaultdict(set)
  for r in rr:sp[r['canonical_unrooted_split']].add(r['strategy'])
  vals=[]
  for st in STRATS:
   sub=[r for r in rr if r['strategy']==st]
   if sub:
    best=max(sub,key=lambda r:(r['sh_alrt'],r['ufboot']));vals.append(f"{st}={best['sh_alrt']}/{best['ufboot']}")
  groups.append({'family':fam,'rso_group':k,'rso_group_size':len(split(k)),'supported_strategy_count':len(sts),'supported_strategies':joined(sts),'support_values':';'.join(vals),'stability_class':f'RSO_RESTRICTED_{len(sts)}_OF_4','maximum_identical_all_taxon_split_strategies':max(map(len,sp.values())),'primary_rso_members':joined(x[4:] for x in primary[fam] if x[4:] in split(k)),'interpretation':'restricted-Rso agreement alone is insufficient for highlighted group'})
write(O/'S7_PhyloGroups.tsv',groups)
qa={'input_checks':inputqa,'completed_tree_count':len(complete),'completed_trees':complete,'all_12_complete':len(complete)==12,'branch_rows':len(branches),'rules':{'SH_aLRT_min':80,'UFBoot_min':95,'identical_all_taxon_split_strategies':4,'minimum_primary_Rso_on_selected_side':2,'root_inference':'none; unrooted splits','colour_selection':'legacy stable splits first, then smallest disjoint local splits; nested stable splits remain in audit table'}}
(O/'audit_status.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
print(json.dumps(qa,indent=2))
if len(complete)<12:raise SystemExit(0)

oldgroups=read(LEG/'key_branch_evidence.tsv');oldsets={f:{r['taxon_id'] for r in read(OLD/f/(f+'.taxon_manifest.tsv'))} for f in FAMS}
candidates=[]
for fam in FAMS:
 stable=defaultdict(set)
 for r in branches:
  if r['family']==fam and r['joint_support']=='TRUE':stable[r['canonical_unrooted_split']].add(r['strategy'])
 source=trees[(fam,'full.gappyout')]
 for key,sts in stable.items():
  if len(sts)!=4:continue
  ids=split(key);pids=ids&primary[fam]
  if not 2<=len(pids)<len(primary[fam]):continue
  nodes=[n for n in source.get_nonterminals() if {t.name for t in n.get_terminals()}==ids]
  displayable=bool(nodes)
  historical=[r for r in oldgroups if r['family']==fam and ids&oldsets[fam]==split(r['all_taxon_ids'])]
  hist=historical[0] if len(historical)==1 else None
  rr=[r for r in branches if r['family']==fam and r['canonical_unrooted_split']==key]
  supports=';'.join(st+'='+str(next(r for r in rr if r['strategy']==st)['sh_alrt'])+'/'+str(next(r for r in rr if r['strategy']==st)['ufboot']) for st in STRATS)
  candidates.append({'family':fam,'members':joined(x[4:] for x in pids),'all_Rso_members':joined(x[4:] for x in ids if x.startswith('RSO_')),'rso_restricted_strategies':4,'identical_all_taxon_split_strategies':4,'color':hist['color'] if hist else '', 'group_label':hist['group_label'] if hist else '', 'interpretation':'four-strategy stable unrooted split; not a formal subfamily','source_support':nodes[0].name if nodes else '', 'total_sequences':len(ids),'Rso_sequences':len(pids),'all_taxon_ids':key,'source_split_supported_strategies':4,'highlight_in_main':False,'source_orientation_displayable':displayable,'legacy_group_label':hist['group_label'] if hist else '', 'legacy_group_previously_highlighted':hist['highlight_in_main'] if hist else '', 'four_strategy_supports':supports,'selection_note':'pending'})
palette=['#287CB4','#CE6941','#26947B','#BA4D8E','#798832','#8056A5','#AD8553','#236B62']
selected=[]
for fam,prefix in zip(FAMS,['D','G','L']):
 used=set();number=max([int(re.sub(r'\D','',r['group_label'])) for r in oldgroups if r['family']==fam],default=0)
 cc=[r for r in candidates if r['family']==fam]
 cc.sort(key=lambda r:(not bool(r['legacy_group_label']),r['total_sequences'],r['members']))
 for r in cc:
  ids=split(r['all_taxon_ids'])
  if not r['source_orientation_displayable']:
   r['selection_note']='Stable canonical side crosses the arbitrary display origin; retained in audit, not coloured.';continue
  if ids&used:
   r['selection_note']='Nested/overlapping stable split retained in audit; no duplicate colour overlay.';continue
  if not r['group_label']:
   number+=1;r['group_label']=prefix+str(number);r['color']=palette[(number-1)%len(palette)]
  else:r['group_label']=r['group_label'].rstrip('*')
  used|=ids;r['highlight_in_main']=True;r['selection_note']='Selected non-overlapping local group; legacy identity retained when its old-taxon projection matches.';selected.append(r)
 for i,r in enumerate(cc,1):r['candidate_id']=fam+'.stable'+str(i)
write(O/'all_four_strategy_stable_split_candidates.tsv',candidates)
write(O/'key_branch_evidence.tsv',selected)
legacy=[]
for g in oldgroups:
 fam=g['family'];oldids=split(g['all_taxon_ids']);match=[r for r in candidates if r['family']==fam and split(r['all_taxon_ids'])&oldsets[fam]==oldids]
 legacy.append({'family':fam,'legacy_group':g['group_label'],'legacy_members':g['members'],'previously_highlighted':g['highlight_in_main'],'current_matching_four_strategy_splits':len(match),'selected_current_group':';'.join(r['group_label'] for r in match if r['highlight_in_main']),'current_members':';'.join(r['members'] for r in match),'result':'retained' if any(r['highlight_in_main'] for r in match) else 'no qualifying selected four-strategy split; historical label not forced'})
write(O/'legacy_group_reassessment.tsv',legacy)
legacy_support=[]
for g in oldgroups:
 fam=g['family'];oldids=split(g['all_taxon_ids'])
 for st in STRATS:
  matches=[]
  for r in branches:
   if r['family']!=fam or r['strategy']!=st:continue
   for side in ['side_a_taxa','side_b_taxa']:
    ids=split(r[side])
    if ids&oldsets[fam]==oldids:matches.append((r,ids))
  if not matches:
   legacy_support.append({'family':fam,'legacy_group':g['group_label'],'strategy':st,'legacy_taxon_projection_present':False,'sh_alrt':'','ufboot':'','joint_support':'FALSE','current_side_taxa':'','added_taxa_on_side':'','note':'No split reproduces the historical complete-taxon side after projection.'})
  for r,ids in matches:
   legacy_support.append({'family':fam,'legacy_group':g['group_label'],'strategy':st,'legacy_taxon_projection_present':True,'sh_alrt':r['sh_alrt'],'ufboot':r['ufboot'],'joint_support':r['joint_support'],'current_side_taxa':joined(ids),'added_taxa_on_side':joined(ids-oldsets[fam]),'note':'Projected correspondence alone does not establish an identical updated all-taxon split in four strategies.'})
write(O/'legacy_group_strategy_support.tsv',legacy_support)
placement=[]
for r in meta:
 if r['current_species']!='rso' or r['current_status'] not in ('primary','extended'):continue
 t=r['taxon_id'];cc=[g for g in candidates if t in split(g['all_taxon_ids'])];sel=[g for g in cc if g['highlight_in_main']]
 placement.append({'family':r['family'],'member_id':r['current_member_id'],'catalogue_tier':r['current_status'],'qualifying_four_strategy_split_count':len(cc),'selected_group':';'.join(g['group_label'] for g in sel),'placement_status':'four-strategy local canonical-side group' if cc else 'not assigned to a qualifying local canonical-side group','formal_subfamily_assigned':False})
write(O/'rso_phylogenetic_placement_summary.tsv',placement)
primary_mapping=[{**r,'stable_group':r['selected_group']} for r in placement if r['catalogue_tier']=='primary']
assert len(primary_mapping)==73
write(O/'primary73_group_mapping.tsv',primary_mapping)
qa.update({'stable_split_candidates':len(candidates),'selected_disjoint_groups':len(selected),'selected_groups':[{'family':r['family'],'label':r['group_label'],'members':r['members'],'total_sequences':r['total_sequences'],'support':r['source_support']} for r in selected],'legacy_group_reassessment':legacy})
(O/'audit_status.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
print(json.dumps(qa,indent=2))
