from pathlib import Path
import subprocess,json,concurrent.futures,threading,traceback
B=Path(__file__).resolve().parent
T=Path('/path/to/user/tools/miniconda3/envs/cotton/bin')
lock=threading.Lock();states={};commands=[]
def state(k,v):
 with lock:
  states[k]=v;(B/'status.json').write_text(json.dumps(states,indent=2))
def job(item):
 fam,mode,label=item;key=fam+'.'+mode+'.'+label;d=B/fam
 try:
  report=d/(key+'.iqtree')
  if report.exists() and 'Total wall-clock time used:' in report.read_text():
   state(key,'complete');return
  ali=d/(fam+'.'+mode+('.aligned.faa' if label=='untrimmed' else '.gappyout.faa'))
  assert ali.exists() and ali.stat().st_size>0,str(ali)
  args=[str(T/'iqtree3'),'-s',str(ali),'-m','MFP','-alrt','1000','-bb','1000','-bnni','-nt','4','-seed','20260909','-pre',str(d/key)]
  with lock:
   commands.append(args);(B/'commands_per_strategy.json').write_text(json.dumps(commands,indent=2))
  state(key,'tree_running')
  with (d/(key+'.run.log')).open('a') as f:subprocess.run(args,stdout=f,stderr=f,check=True)
  assert report.exists() and 'Total wall-clock time used:' in report.read_text()
  state(key,'complete')
 except Exception:
  (d/(key+'.error.txt')).write_text(traceback.format_exc());state(key,'error')
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 list(ex.map(job,[(f,m,l) for f in ['Defensin','Snakin_GASA','nsLTP'] for m in ['full','core'] for l in ['untrimmed','gappyout']]))
