"""Reuse the author's circular key-clade layout with current audited data."""
from pathlib import Path
import copy,csv,hashlib,json,re,sys,shutil
sys.dont_write_bytecode=True
MAIN_ONLY='--main-only' in sys.argv
SUPP_ONLY='--supp-only' in sys.argv
NS_ONLY='--all-families' not in sys.argv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from Bio import Phylo
B=Path(__file__).resolve().parent;W=B.parent.parent;A=B/'审核表';O=B/'图件';N=B/'Newick_iTOL';N.mkdir(exist_ok=True)
OLD=W/'Genes_lab_handoff_20260908/02_Workspace/9_2_major_revision/Genes_key_clade_review_20260903'
STYLE=B/'style_source_snapshot';STYLE.mkdir(exist_ok=True)
for name in ['build_key_clade_figures.py','plot_circular_phylogenies.py','export_phylogeny_itol_package.py']:
 assert (STYLE/name).is_file(), 'Required preserved style snapshot is missing.'
sys.path.insert(0,str(STYLE))
import build_key_clade_figures as style
from plot_circular_phylogenies import read_tsv,write_tsv,fingerprint
from export_phylogeny_itol_package import make_main_display_tree,support_is_joint
FAMS=['Defensin','Snakin_GASA','nsLTP']
records=read_tsv(A/'key_branch_evidence.tsv');meta=read_tsv(A/'taxon_metadata_verified_sequences.tsv');byid={r['taxon_id']:r for r in meta}
assert {r['group_label'] for r in records if r['family']=='nsLTP'}=={'L1','L2','L3'}, 'Expected current consecutive display labels.'
assert next(r for r in records if r['group_label']=='L2')['members']=='RsLTP39;RsLTP40'
assert next(r for r in records if r['group_label']=='L3')['members']=='RsLTP5;RsLTP6'
for r in records:
 r['highlight_in_main']=r['highlight_in_main']=='True'
 r['total_sequences']=int(r['total_sequences'])
 r['Rso_sequences']=int(r['Rso_sequences'])
primary={f:{r['current_member_id'] for r in meta if r['family']==f and r['current_species']=='rso' and r['current_status']=='primary'} for f in FAMS}
extended={r['taxon_id'] for r in meta if r['current_species']=='rso' and r['current_status']=='extended'}
def category(name,pm):
 if name in extended:return 'extended_Rso'
 if name.startswith('RSO_'):return 'primary_Rso' if name[4:] in pm else 'excluded_Rso'
 if name.startswith('TAU_'):return 'Tamarix'
 if name.startswith(('NEG2S_','AMBPRO_')):return 'boundary_control'
 return 'positive_reference'
style.tip_category=category
oldlabels=read_tsv(B/'historical_tip_label_key.tsv');oldmap={r['newick_id']:r['display_label'] for r in oldlabels}
def aliases_for(tree,fam):
 aliases={};prefix={'Defensin':'TaDEF','Snakin_GASA':'TaGAS','nsLTP':'TaLTP'}[fam]
 n=max([int(r['display_label'][len(prefix):]) for r in oldlabels if r['family']==fam and r['display_label'].startswith(prefix)],default=0)
 for tax in sorted(t.name for t in tree.get_terminals()):
  if tax in oldmap:label=oldmap[tax]
  elif tax.startswith('RSO_'):label=tax[4:]
  elif tax.startswith('TAU_'):n+=1;label=prefix+f'{n:02d}'
  else:label=tax.removeprefix('NSPOS_').removeprefix('UNI_').removeprefix('POS_')
  if tax in extended:label+='*'
  aliases[tax]=label
 assert len(set(aliases.values()))==len(aliases)
 return aliases
def save(fig,name,sub=''):
 dest=O/sub;style.save_figure(fig,name,dest)
 p=dest/'Previews';p.mkdir(parents=True,exist_ok=True);fig.savefig(p/(name+'.png'),dpi=130,facecolor='white')
def footer(fig,size=8):
 fig.text(.5,.046,'Bold: primary R. soongarica catalogue   *: extended RsLTP20   x: historical exclusion',ha='center',fontsize=size,color='#555555')
 fig.text(.5,.026,'n: all sequences in group   |   SH-aLRT / UFBoot (%)   |   Groups are not formal subfamilies',ha='center',fontsize=size,color='#555555')
 fig.text(.5,.009,'Circular cladogram; radial lengths not to scale; centre is not a biological root',ha='center',fontsize=size,color='#555555')
plt.rcParams.update({'font.family':'Arial','pdf.fonttype':42,'svg.fonttype':'none'})
proofs=[];labels=[];panels=[];sources=[]
for letter,fam in zip('ABC',FAMS):
 source=B/'collected'/fam/(fam+'.full.gappyout.treefile');tree=Phylo.read(source,'newick');fp=fingerprint(tree);tree.ladderize()
 rr=[r for r in records if r['family']==fam];aliases=aliases_for(tree,fam)
 for r in rr:
  ids=set(r['all_taxon_ids'].split(';'));node=tree.common_ancestor([t for t in tree.get_terminals() if t.name in ids])
  assert {t.name for t in node.get_terminals()}==ids and node.name==r['source_support']
 display=style.main_display(tree,primary[fam],{t[4:] for t in extended} if fam=='nsLTP' else set(),rr)
 dtips={t.name for t in display.get_terminals()};assert {'RSO_'+n for n in primary[fam]}<=dtips
 if fam=='nsLTP':assert 'RSO_RsLTP20' in dtips
 targets=[(False,display,f'Figure2{letter}_{fam}_primary73_key_clades'),(True,tree,f'FigureS1{letter}_{fam}_primary73_full')]
 targets=[x for x in targets if (not MAIN_ONLY or not x[0]) and (not SUPP_ONLY or x[0])]
 if NS_ONLY and fam!='nsLTP':targets=[]
 for full,t,name in targets:
  fig=plt.figure(figsize=(13,13) if full else (9,9));ax=fig.add_axes([.02,.095,.96,.85])
  proof=style.draw(ax,t,aliases,primary[fam],rr,f'({letter}) {style.TITLES[fam]} | {len(t.get_terminals())} sequences',8.4 if full else 10.5,full)
  footer(fig,8.1 if full else 7.1);save(fig,name);plt.close(fig)
  Phylo.write(t,N/(name+'.nwk'),'newick',format_branch_length='%1.10f')
  (N/(name+'.itol_labels.txt')).write_text('LABELS\nSEPARATOR TAB\nDATA\n'+'\n'.join(tip.name+'\t'+('x:' if category(tip.name,primary[fam])=='excluded_Rso' else '')+aliases[tip.name] for tip in t.get_terminals())+'\n',encoding='utf-8')
  proofs.append({'figure':name,'full_tree':full,'rerooted':False,**proof})
 if not MAIN_ONLY and not NS_ONLY:
  audit,proof=style.support_audit(tree,aliases,primary[fam],rr,f'({letter}) {style.TITLES[fam]}')
  save(audit,f'Support_audit_{letter}_{fam}_all_nodes','Support_audit');plt.close(audit);proofs.append({'figure':'support_audit_'+fam,**proof})
 for tip in tree.get_terminals():
  m=byid[tip.name];label=('x:' if category(tip.name,primary[fam])=='excluded_Rso' else '')+aliases[tip.name]
  labels.append({'family':fam,'newick_id':tip.name,'display_label':label,'alias_without_status_prefix':aliases[tip.name],'category':category(tip.name,primary[fam]),'shown_in_main':tip.name in dtips,**{k:m[k] for k in ['source_group','source_id','current_status','current_member_id','current_species','current_model_source','actual_full_length_aa','actual_core_length_aa','sha256','core_sha256']}})
 assert fingerprint(tree)==fp
 sources.append({'family':fam,'main_tips':len(dtips),'full_tips':len(tree.get_terminals()),'primary_Rso':len(primary[fam]),'selected_groups':';'.join(r['group_label'] for r in rr),'source':str(source.relative_to(B)),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'original_topology_support_lengths_preserved':True})
 panels.append((display,aliases,primary[fam],rr,letter,fam))
if not SUPP_ONLY:
 fig=plt.figure(figsize=(8.4,11.2))
 for pos,(tree,aliases,pm,rr,letter,fam) in zip(((.025,.57,.46,.39),(.515,.57,.46,.39),(.10,.10,.80,.47)),panels):
  ax=fig.add_axes(pos);proof=style.draw(ax,tree,aliases,pm,rr,f'({letter}) {style.TITLES[fam]}',8.4 if letter!='C' else 9.0)
  proofs.append({'figure':'Figure2_combined_primary73_key_clades','panel':letter,**proof})
 footer(fig,7.2);save(fig,'Figure2_combined_primary73_key_clades');plt.close(fig)
write_tsv(A/'tip_label_key.tsv',labels);write_tsv(A/'figure_source_manifest.tsv',sources)
assert len([r for r in labels if r['category']=='primary_Rso' and r['shown_in_main']])==73
assert next(r for r in labels if r['newick_id']=='RSO_RsLTP20')['display_label']=='RsLTP20*'
assert all(next(r for r in labels if r['newick_id']=='RSO_RsLTP'+str(i))['display_label']=='RsLTP'+str(i) for i in [2,18,30])
(A/'figure_QA.json').write_text(json.dumps({'figures':proofs,'source_trees':sources,'main_primary_Rso_members':73,'extended_star':'RsLTP20*','restored_2_18_30_without_x':True,'historical_aliases_retained':True,'same_coloured_taxon_not_in_multiple_groups':True},indent=2),encoding='utf-8')
shutil.copyfile(A/'figure_QA.json',A/('figure_QA_main.json' if MAIN_ONLY else 'figure_QA_supplement.json' if SUPP_ONLY else 'figure_QA_all.json'))
print(json.dumps(sources,indent=2))
