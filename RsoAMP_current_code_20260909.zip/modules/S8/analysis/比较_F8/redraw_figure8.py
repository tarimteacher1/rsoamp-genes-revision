from pathlib import Path
import json
import re
import argparse

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch, FancyBboxPatch, Polygon, Patch
from matplotlib.lines import Line2D
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
from pypdf import PdfReader

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'
D=json.loads((DATA/'plot_data.json').read_text(encoding='utf8'))
G=D['genes'];S=D['summary']
FAMILY={'Defensin':'#C43D3D','Snakin_GASA':'#2E6F9E','nsLTP':'#2F7D4A'}
NAME={'Defensin':'Defensin','Snakin_GASA':'Snakin/GASA','nsLTP':'nsLTP'}
SPECIES={'RSO':'#4D758B','TAU':'#AD8358'}
SPECIES_NAME={'RSO':'R. soongarica','TAU':'T. austromongolica'}
plt.rcParams.update({'font.family':'Arial','font.size':8,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.linewidth':.6,'axes.labelcolor':'#24323B','text.color':'#24323B','xtick.major.width':.6,'ytick.major.width':.6,'savefig.facecolor':'white'})

def curve(ax,x1,y1,x2,y2,color,lw=1,alpha=1,ls='-',zorder=1):
    d=(y2-y1)*.42
    path=MPath([(x1,y1),(x1,y1+d),(x2,y2-d),(x2,y2)],[MPath.MOVETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4])
    obj=PathPatch(path,fill=False,edgecolor=color,lw=lw,alpha=alpha,linestyle=ls,zorder=zorder)
    ax.add_patch(obj)

def ribbon(ax,a,b,c,d,y1,y2,color,alpha=.12,zorder=1):
    mid1=y1+(y2-y1)*.4;mid2=y2-(y2-y1)*.4
    verts=[(a,y1),(a,mid1),(c,mid2),(c,y2),(d,y2),(d,mid2),(b,mid1),(b,y1),(a,y1)]
    codes=[MPath.MOVETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4,MPath.LINETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4,MPath.CLOSEPOLY]
    ax.add_patch(PathPatch(MPath(verts,codes),fc=color,ec='none',alpha=alpha,zorder=zorder))

def title(fig,label,text,y):
    fig.text(.038,y,label,fontweight='bold',fontsize=12,va='top')
    fig.text(.087,y-.001,text,fontsize=10,fontweight='bold',va='top')

def inventory(fig):
    title(fig,'A','Family inventories',.960)
    ax=fig.add_axes([.13,.794,.82,.12])
    groups=list(FAMILY);x=np.arange(3)
    for i,sp in enumerate(['RSO','TAU']):
        rows=[next(r for r in D['counts'] if r['family']==f and r['species'].startswith('Reaumuria' if sp=='RSO' else 'Tamarix')) for f in groups]
        xpos=x+(-.17 if i==0 else .17)
        for xx,r in zip(xpos,rows):
            n=int(r['annotated_catalogue_members']);m=int(r['additional_homology_models'])
            ax.bar(xx,n,width=.29,color=SPECIES[sp],lw=0,zorder=3)
            if m:ax.bar(xx,m,width=.29,bottom=n,facecolor='#F6EEE6',edgecolor=SPECIES[sp],hatch='////',lw=.7,zorder=3)
            ax.text(xx,n+m+1,str(n+m),ha='center',va='bottom',fontsize=9)
    ax.set_ylim(0,45);ax.set_yticks([0,20,40]);ax.set_ylabel('Candidate members',fontsize=8)
    ax.set_xticks(x,[NAME[f] for f in groups]);ax.tick_params(labelsize=8,length=3,pad=4)
    ax.spines[['top','right']].set_visible(False);ax.spines[['left','bottom']].set_color('#819198')
    ax.grid(axis='y',lw=.35,color='#E4E9EC',zorder=0)
    handles=[Patch(fc=SPECIES[s],label=SPECIES_NAME[s]) for s in ['RSO','TAU']]
    fig.legend(handles=handles,loc='upper right',bbox_to_anchor=(.96,.953),frameon=False,ncol=2,prop={'style':'italic','size':8},handlelength=1.4,columnspacing=1.4)
    fig.text(.13,.755,'Hatching: reconstructed/homology models. Extended tier: one additional nsLTP per species.',fontsize=7.5,color='#586871')

def macrosynteny(fig):
    title(fig,'B','Chromosome-scale synteny',.726)
    ax=fig.add_axes([.065,.510,.885,.191]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
    gap=15_000_000;start={};totals={}
    for sp in ['RSO','TAU']:
        at=0
        for c in D['chromosomes'][sp]:start[(sp,c['chrom'])]=at;at+=c['length']+gap
        totals[sp]=at-gap
    denom=max(totals.values());xbase=.025;avail=.95
    def xp(k,pos):return xbase+avail*(start[(G[k]['species'],G[k]['chrom'])]+pos)/denom
    omitted=[]
    for b in D['blocks']:
        pairs=b['pairs'];a=[p['gene1'] for p in pairs];h=[p['gene2'] for p in pairs]
        if any((G[k]['species'],G[k]['chrom']) not in start for k in [a[0],h[0]]):omitted.append(b['id']);continue
        ax1=xp(a[0],min(G[k]['start'] for k in a));ax2=xp(a[0],max(G[k]['end'] for k in a))
        bx1=xp(h[0],min(G[k]['start'] for k in h));bx2=xp(h[0],max(G[k]['end'] for k in h))
        if b['orientation']=='minus':bx1,bx2=bx2,bx1
        ribbon(ax,ax1,ax2,bx1,bx2,.725,.225,'#A5AEB5',.11)
    for r in D['amp_pairs']:
        a,h=r['rso_gene'],r['tamarix_gene'];direct=r['direct_amp_to_amp_anchor']=='YES'
        fam=r['rso_amp_family'] or r['tamarix_amp_family'];color=FAMILY[fam] if direct else '#777E85'
        u=xp(a,(G[a]['start']+G[a]['end'])/2);v=xp(h,(G[h]['start']+G[h]['end'])/2)
        curve(ax,u,.725,v,.225,color,lw=1.15 if direct else .9,alpha=.84,ls='-' if direct else (0,(3,2)),zorder=3)
        ax.plot([u,v],[.725,.225],linestyle='none',marker='o',ms=2,markerfacecolor=color if direct else 'white',markeredgecolor=color,markeredgewidth=.6,zorder=6)
    for sp,y,lab_y in [('RSO',.725,.807),('TAU',.225,.15)]:
        for c in D['chromosomes'][sp]:
            x=xbase+avail*start[(sp,c['chrom'])]/denom;w=avail*c['length']/denom
            ax.add_patch(FancyBboxPatch((x,y-.021),w,.042,boxstyle='round,pad=0,rounding_size=0.006',fc=SPECIES[sp],ec='#637982',lw=.4,zorder=5))
            ax.text(x+w/2,lab_y,str(int(c['chrom'][3:])),ha='center',va='center',fontsize=8,color=SPECIES[sp])
        ax.text(xbase,.938 if sp=='RSO' else .035,SPECIES_NAME[sp],fontsize=9,fontstyle='italic',color=SPECIES[sp],ha='left',va='center')
    x=.83;width=avail*100_000_000/denom
    ax.plot([x,x+width],[.943,.943],color='#4F5D65',lw=.9)
    ax.text(x+width/2,.982,'100 Mb',ha='center',va='bottom',fontsize=7.5)
    ax.text(.978,.035,f"{len(D['blocks'])-len(omitted)} background blocks",ha='right',fontsize=7.5,color='#63727A')
    handles=[Line2D([0],[0],color=FAMILY[f],lw=1.5,label=f'{NAME[f]} ({S["direct_pairs_by_family"][f]})') for f in FAMILY]
    fig.legend(handles=handles,loc='lower left',bbox_to_anchor=(.077,.479),frameon=False,ncol=3,fontsize=7.5,handlelength=1.9,columnspacing=1.7)
    fig.text(.087,.471,'Solid: both ends in the catalogue (25 pairs); dashed: one end outside it (5 pairs).',fontsize=7.5,color='#586871')
    return omitted

def gene_arrow(ax,x1,x2,y,strand,color,additional=False):
    width=x2-x1;half=.042;head=min(width*.45,.005)
    if strand=='+':v=[(x1,y-half),(x2-head,y-half),(x2,y),(x2-head,y+half),(x1,y+half)]
    else:v=[(x2,y-half),(x1+head,y-half),(x1,y),(x1+head,y+half),(x2,y+half)]
    ax.add_patch(Polygon(v,closed=True,facecolor='#FFF3F0' if additional else color,edgecolor=color,linewidth=.7 if additional else .2,hatch='////' if additional else None,zorder=5))

def spread_labels(items,lo=.25,hi=.97):
    if not items:return []
    # Allocate measured-in-axes approximate text widths, retaining true endpoints.
    ordered=sorted(items,key=lambda r:r[0]);widths=[max(.052,len(s)*.009) for _,s,_ in ordered]
    xs=[]
    for i,((x,s,k),w) in enumerate(zip(ordered,widths)):
        left=lo+w/2 if not xs else xs[-1]+widths[i-1]/2+w/2+.014
        xs.append(max(x,left))
    if xs[-1]+widths[-1]/2>hi:
        delta=xs[-1]+widths[-1]/2-hi;xs=[x-delta for x in xs]
    return [(new,old,s,k) for new,(old,s,k) in zip(xs,ordered)]

def short_label(k):
    a=G[k].get('amp',{})
    if not a:return G[k]['source_id']
    s=a['display_id']
    if s.startswith('evm.model.'):return s.removeprefix('evm.model.')
    if s.startswith('TAU_DEF_'):return s.removeprefix('TAU_')
    return s

LABEL_RECORDS=[]
def local_context(ax,c,header=None,compact=True):
    ax.set_xlim(0,1);ax.set_ylim(-.14,1.22);ax.axis('off')
    focal={g for r in c['focus_pairs'] for g in [r['rso_gene'],r['tamarix_gene']]}
    focalpairs={(r['rso_gene'],r['tamarix_gene']):r for r in c['focus_pairs']}
    xleft=.235;xright=.977;ys=[.64,.28]
    transforms={};points={}
    for track,y in zip(c['tracks'],ys):
        lo,hi=track['start'],track['end']
        def xp(pos,t=track):
            ratio=(pos-t['start'])/(t['end']-t['start']);ratio=1-ratio if t['reverse'] else ratio
            return xleft+(xright-xleft)*ratio
        transforms[track['species']]=xp
        for k in track['genes']:
            g=G[k];u,v=sorted([xp(g['start']),xp(g['end'])]);points[k]=(u,v,y)
    for p in c['pairs']:
        a,b=p['gene1'],p['gene2'];u,v,y1=points[a];w,z,y2=points[b]
        r=focalpairs.get((a,b));color=FAMILY[(r['rso_amp_family'] or r['tamarix_amp_family'])] if r else '#A5AEB5'
        if r and r['direct_amp_to_amp_anchor']!='YES':color='#777E85'
        ribbon(ax,u,v,w,z,y1,y2,color,.24 if r else .30,2 if r else 1)
        curve(ax,(u+v)/2,y1,(w+z)/2,y2,color,1.15 if r else .6,.8 if r else .45,'-' if not r or r['direct_amp_to_amp_anchor']=='YES' else (0,(3,2)),3 if r else 1)
    for track,y in zip(c['tracks'],ys):
        sp=track['species'];reverse=track['reverse'];xp=transforms[sp]
        ax.plot([xleft,xright],[y,y],color='#88969F',lw=.6,zorder=3)
        ax.text(.004,y,SPECIES_NAME[sp],color=SPECIES[sp],fontsize=7.8,fontstyle='italic',ha='left',va='center')
        coords=f"{track['chrom']}  {track['start']/1e6:.3f}\u2013{track['end']/1e6:.3f} Mb"
        if reverse:coords=f"{track['chrom']}  {track['end']/1e6:.3f}\u2013{track['start']/1e6:.3f} Mb (reversed)"
        ax.text(xright,.995 if sp=='RSO' else -.108,coords,ha='right',va='center',fontsize=7.2,color='#61717B')
        labels=[]
        for k in track['genes']:
            g=G[k];u,v,_=points[k];selected=k in focal
            color=FAMILY[g['amp']['family']] if selected and 'amp' in g else '#7F8B93'
            strand=g['strand']
            if reverse:strand='-' if strand=='+' else '+'
            gene_arrow(ax,u,v,y,strand,color,g['model_source']=='additional_homology_model')
            if selected:
                additional=g['model_source']=='additional_homology_model'
                ax.plot((u+v)/2,y,marker='D' if additional else 'o',markersize=3 if additional else 2.7,markeredgecolor=color,markerfacecolor='white' if additional else color,markeredgewidth=.7,zorder=6)
                labels.append(((u+v)/2,short_label(k),k))
        for xpos,orig,s,k in spread_labels(labels):
            labely=.847 if sp=='RSO' else .065
            obj=ax.text(xpos,labely,s,ha='center',va='center',fontsize=7.6,color=FAMILY[G[k]['amp']['family']] if 'amp' in G[k] else '#59656B',zorder=8)
            ax.plot([orig,xpos],[y+(.055 if sp=='RSO' else -.055),labely+(-.065 if sp=='RSO' else .065)],color='#667680',lw=.45,zorder=7)
            LABEL_RECORDS.append((obj,k,c['block']))
    ax.text(.004,1.147,header or f"Block {c['block']}",fontsize=8.5,fontweight='bold',va='center')
    ax.text(.977,1.147,f"Block {c['block']}" if header else '',fontsize=7.5,color='#657781',ha='right',va='center')

def main():
    fig=plt.figure(figsize=(7.2,9.3))
    fig.text(.962,.984,'Primary computational catalogue',fontsize=7.5,ha='right',color='#586871')
    inventory(fig);omitted=macrosynteny(fig)
    fig.text(.087,.456,'Anchor reference excludes the seven new Rso models; absence of links is not absence of homology.',fontsize=6.7,color='#586871')
    title(fig,'C','Local genomic context: one example per family',.438)
    for bottom,c in zip([.305,.171,.037],D['examples']):
        ax=fig.add_axes([.07,bottom,.89,.120]);local_context(ax,c,NAME[c['family']])
    fig.text(.07,.018,'Dots: focal gene positions; open diamonds: additional homology models. Arrows show orientation.',fontsize=7,color='#61717B')
    fig.text(.07,.006,'Local rows are scaled independently; reversed coordinate directions are labelled.',fontsize=7,color='#61717B')
    fig.canvas.draw();renderer=fig.canvas.get_renderer()
    overlaps=[]
    for i,(obj,k,b) in enumerate(LABEL_RECORDS):
        for other,h,c in LABEL_RECORDS[i+1:]:
            if b==c and obj.get_window_extent(renderer).overlaps(other.get_window_extent(renderer)):
                overlaps.append([k,h,b])
    assert not overlaps,overlaps
    stem=BASE/'Figure8_primary73_synced_20260909'
    fig.savefig(stem.with_suffix('.pdf'))
    fig.savefig(stem.with_suffix('.svg'))
    fig.savefig(stem.with_suffix('.png'),dpi=600)
    fig.savefig(BASE/'Figure8_primary73_synced_20260909_preview.png',dpi=160)
    plt.close(fig)
    # A complete atlas prevents the three main-panel examples becoming the only
    # inspectable genomic contexts. The same fixed selection procedure is used.
    with PdfPages(BASE/'全部30对_局部共线性核对.pdf') as pdf:
        for offset in range(0,len(D['all_pair_contexts']),4):
            page=plt.figure(figsize=(8.27,11.69))
            page.text(.07,.974,'AMP-involving synteny: all candidate-pair contexts',fontsize=12,fontweight='bold')
            page.text(.07,.949,'Primary catalogue · existing-reference anchors · independent genomic scales per row',fontsize=8,color='#657781')
            for j,c in enumerate(D['all_pair_contexts'][offset:offset+4]):
                r=c['focus_pairs'][0];fam=r['rso_amp_family'] or r['tamarix_amp_family']
                a=page.add_axes([.065,.712-j*.217,.90,.179])
                local_context(a,c,f"{offset+j+1:02d}  {NAME[fam]}  |  Block {c['block']}",compact=False)
                a.text(.004,-.25,('Both ends in current catalogue' if r['direct_amp_to_amp_anchor']=='YES' else 'One endpoint is outside current AMP catalogue'),fontsize=7.5,color='#68777E')
                a.text(.004,-.38,r['rso_gene']+'  /  '+r['tamarix_gene'],fontsize=7,color='#68777E')
            page.text(.07,.010,'Grey genes and links provide local context; highlighted genes are the focal pair. Reversed rows are labelled.',fontsize=7.5,color='#657781')
            pdf.savefig(page);plt.close(page)
    reader=PdfReader(stem.with_suffix('.pdf'))
    assert len(reader.pages)==1
    text=reader.pages[0].extract_text()
    for name in ['RsDEF6','RsSNA3','RsLTP5','RsLTP13']:assert name in text,name
    qa=dict(matplotlib_version=matplotlib.__version__,figure_inches=[7.2,9.3],main_pdf_pages=len(reader.pages),main_pdf_raster_images=len(reader.pages[0].images),all_pairs_atlas_pages=len(PdfReader(BASE/'全部30对_局部共线性核对.pdf').pages),main_focal_label_overlaps=overlaps,macro_blocks_omitted=omitted,macro_blocks_drawn=len(D['blocks'])-len(omitted),highlighted_pairs=len(D['amp_pairs']),families=list(FAMILY),catalogue_counts_status='merged primary: Rso 15/18/40; Tamarix 5/7/26',labels='SVG text retained; PDF TrueType fonts')
    assert not omitted
    (DATA/'figure_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(qa,ensure_ascii=False))

if __name__=='__main__':main()
