"""Package replacement TSVs and verify transfer/figure structure; no document editing."""
from pathlib import Path
import csv,gzip,hashlib,json,re,shutil
import fitz
ROOT=Path(__file__).resolve().parent
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def write(p,rows):
 with p.open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
qa=json.loads((ROOT/'figures/figure5_qa.json').read_text());order={m:i for i,m in enumerate(qa['row_order'])};patterns={m:i for i,m in enumerate(qa['column_order'])}
cat={r['gene_id']:r for r in read(ROOT/'primary73_promoter_catalogue.tsv')}
replacements=ROOT/'replacement_tables';replacements.mkdir(exist_ok=True)
tablemap={
 'S9_PromoterOccur':'cis_element_full_results.tsv',
 'S10_PromoterEnrich':'cis_element_enrichment.tsv',
 'S28_PromoterQC':'promoter_extraction_audit.tsv',
 'S29_PromoterSensitivity':'cis_element_sensitivity.tsv'}
meta=[]
for name,source in tablemap.items():
 rows=read(ROOT/'results'/source)
 if name=='S9_PromoterOccur':rows.sort(key=lambda r:(order[r['member_id']],patterns[r['element']]))
 if name=='S28_PromoterQC':
  rows.sort(key=lambda r:order[r['member_id']])
  for r in rows:
   r['source_model_id']=cat[r['gene_id']]['source_model_id'];r['frozen_source_id']=cat[r['gene_id']]['source_id']
 write(replacements/(name+'.tsv'),rows)
 meta.append({'sheet_name':name,'tsv_file':'replacement_tables/'+name+'.tsv','data_rows':len(rows),'columns':len(rows[0]),'source_file':'results/'+source})
shutil.copyfile(ROOT/'motif_sources.tsv',replacements/'S27_MotifSources.tsv')
meta.append({'sheet_name':'S27_MotifSources','tsv_file':'replacement_tables/S27_MotifSources.tsv','data_rows':15,'columns':11,'source_file':'motif_sources.tsv (unchanged exact patterns and provenance)'})
meta.sort(key=lambda r:int(re.search(r'\d+',r['sheet_name'])[0]));write(ROOT/'table_replacement_map.tsv',meta)
audit=read(ROOT/'results/all_gene_upstream_audit.tsv')
background=[{k:r[k] for k in ['gene_id','chrom','gene_start','gene_end','strand','official_annotation','target','promoter_start_1based','promoter_end_1based','promoter_length_bp','primary_full_length','S1_clean','S2_clean_utr']} for r in audit if r['target']=='0']
assert len(background)==21725 and all(r['official_annotation']=='1' for r in background)
write(ROOT/'background_cohort_membership.tsv',background)
targetseq={}
with gzip.open(ROOT/'results/upstream_sequences.fa.gz','rt') as f:
 for head in f:
  gid=head[1:].strip();seq=next(f).strip()
  if gid in cat:targetseq[cat[gid]['member_id']]=(gid,seq)
with (ROOT/'primary73_upstream_proxies.fa').open('w') as f:
 for member in qa['row_order']:
  gid,seq=targetseq[member];f.write('>'+member+' gene_id='+gid+'\n'+seq+'\n')
assert len(targetseq)==73 and all(len(s)==2000 for _,s in targetseq.values())
# Structural PDF and SVG verification complements the visual preview review.
doc=fitz.open(ROOT/'figures/Figure5_promoter_motif_occurrence.pdf');assert len(doc)==1
page=doc[0];text=page.get_text();missing=[m for m in order if not re.search(r'\b'+m+r'\b',text)];assert not missing,missing
clipped=[]
for block in page.get_text('dict')['blocks']:
 for line in block.get('lines',[]):
  for span in line['spans']:
   x0,y0,x1,y1=span['bbox']
   if min(x0,y0)<0 or x1>page.rect.width or y1>page.rect.height:clipped.append(span['text'])
assert not clipped,clipped
fonts=page.get_fonts(full=True);assert fonts and all('Type3' not in str(f) for f in fonts)
svg=(ROOT/'figures/Figure5_promoter_motif_occurrence.svg').read_text()
assert '<text' in svg
qa.update({'PDF_pages':1,'PDF_all_73_member_labels_present':True,'PDF_text_outside_page':clipped,'PDF_font_records':[list(f) for f in fonts],'SVG_text_preserved':True,'preview_visually_reviewed':True,'target_family_counts':{f:sum(r['family']==f for r in cat.values()) for f in ['Defensin','Snakin_GASA','nsLTP']}})
(ROOT/'figures/figure5_qa.json').write_text(json.dumps(qa,indent=2)+'\n')
# Remote SHA-256 values captured after successful completion, before transfer.
remote={
 'all_gene_motif_counts.tsv':'6e7345071a3b6c501f444a133d31113833e4602f3eade168e2ab317e87acb4ab',
 'all_gene_upstream_audit.tsv':'8d6c86b8a3abbd8eaeb81b789726a27ed031f690ca60ffb7d1464f8a68f13ef4',
 'cis_element_enrichment.tsv':'5400a91665e9b70b216868d35800fd64476431013c4d8375ae3b94a2161759b8',
 'cis_element_full_results.tsv':'9345289c6a77ea5fadf349a1a139357e663bbff47a62df398fcd1c066c1d2177',
 'cis_element_sensitivity.tsv':'27055decdff4bb5b8c4d12bf5f558f76143d00efdb418c9f42587ffe4594cd1e',
 'overlap_changes_after_novel7.tsv':'9cfdc09a23e8b19c7cd80ad49c6135aa3a0d0c2b6ade5b631f9af5570caf7346',
 'promoter_extraction_audit.tsv':'1a6465e8713dd5ed2c89e385f23fe115777c51fdc34bab762a872471fa40b9f3',
 'PROMOTER_PRIMARY73_COMPLETE.PASS':'547736a378581e116cd69b2496b55e8f457895aaedae3bf12b8386f14c26e4de',
 'summary.json':'66639b78e86383515db2d725ee7c4c81e25aed668763f16cb10b530a7dc90431',
 'upstream_sequences.fa.gz':'e73c23a12e150629849d637fd76fc36458181d88f28062070f490828e9b22674'}
checks=[{'file':name,'remote_sha256':sha,'local_sha256':hashlib.sha256((ROOT/'results'/name).read_bytes()).hexdigest()} for name,sha in remote.items()]
assert all(r['remote_sha256']==r['local_sha256'] for r in checks)
(ROOT/'transfer_qa.json').write_text(json.dumps({'files':checks,'status':'PASS'},indent=2)+'\n')
print(json.dumps({'tables':meta,'transfer':'PASS','figure':'PASS','targets_fasta':len(targetseq)},indent=2))
