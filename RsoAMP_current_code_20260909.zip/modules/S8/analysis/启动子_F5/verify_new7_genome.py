"""Independently check the seven new upstream sequences directly against FASTA."""
import argparse,gzip,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--genome',required=True,type=Path)
p.add_argument('--models',required=True,type=Path)
p.add_argument('--sequences',required=True,type=Path)
p.add_argument('--out',required=True,type=Path)
a=p.parse_args();models=json.loads(a.models.read_text());wanted={r['gene_id'] for r in models}
observed={}
with gzip.open(a.sequences,'rt') as f:
 for header in f:
  seq=next(f).strip();gid=header[1:].strip()
  if gid in wanted:observed[gid]=seq
assert set(observed)==wanted and len(wanted)==7
bychrom={}
for r in models:bychrom.setdefault(r['chrom'],[]).append(r)
checked=[]
def check(chrom,parts):
 if chrom not in bychrom:return
 reference=''.join(parts).upper()
 for r in bychrom[chrom]:
  boundary=int(r['start']) if r['strand']=='+' else int(r['end'])
  positions=range(boundary-2000,boundary) if r['strand']=='+' else range(boundary+2000,boundary,-1)
  # Access each genomic coordinate as a one-based position, independent of slicing.
  expected=''.join(reference[pos-1] for pos in positions)
  if r['strand']=='-':expected=expected.translate(str.maketrans('ACGT','TGCA'))
  assert expected==observed[r['gene_id']],r['member_id']
  checked.append({'member_id':r['member_id'],'strand':r['strand'],'length':len(expected),'sequence_sha256':hashlib.sha256(expected.encode()).hexdigest()})
with a.genome.open() as f:
 chrom=None;parts=[]
 for line in f:
  if line.startswith('>'):
   check(chrom,parts);chrom=line[1:].split()[0];parts=[]
  elif chrom in bychrom:parts.append(line.strip())
 check(chrom,parts)
assert len(checked)==7
result={'method':'independent one-based coordinate enumeration from original genome FASTA','checked':checked,'status':'PASS'}
a.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
