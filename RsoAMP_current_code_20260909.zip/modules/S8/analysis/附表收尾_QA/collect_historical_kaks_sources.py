"""Read-only extraction of the existing 63-member Ka/Ks source sequences."""
from pathlib import Path
import csv,hashlib,json
P=Path('/path/to/rso_project')
O=P/'revision_R1_20260902/07_promoter_kaks_methods/supplement_closure_20260909'
O.mkdir(parents=True,exist_ok=True)
def read(p,sep='\t'):
 with p.open() as f:return list(csv.DictReader(f,delimiter=sep))
cat=read(P/'revision_R1_20260902/03_annotation_rescue/final_amp_primary_catalogue.tsv')
cat=[r for r in cat if r['catalogue_status'].startswith('INCLUDED')];assert len(cat)==63
wanted={r['protein_id'] for r in cat}
def fasta(path):
 out={};name=None;parts=[]
 with path.open() as f:
  for line in f:
   if line.startswith('>'):
    if name in wanted:out[name]=''.join(parts).upper()
    name=line[1:].split()[0];parts=[]
   elif name in wanted:parts.append(line.strip())
 if name in wanted:out[name]=''.join(parts).upper()
 assert set(out)==wanted
 return out
proteins=fasta(P/'data/protein.fa');cds=fasta(P/'data/cds.fa')
files=['revision_R1_20260902/03_annotation_rescue/final_amp_primary_catalogue.tsv','intermediate/kaks_input.axt','intermediate/kaks_out.txt','intermediate/dup_pairs.tsv','tables/T1_AMP_members.csv']
source_files={s:{'sha256':hashlib.sha256((P/s).read_bytes()).hexdigest(),'text':(P/s).read_text()} for s in files}
out={'scope':'Existing sources only; no Ka/Ks or duplication discovery rerun','old_primary_count':63,'members':[dict(r,protein_sequence=proteins[r['protein_id']],cds_sequence=cds[r['protein_id']]) for r in cat],'source_files':source_files}
(O/'historical_kaks_sources.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'old_primary_count':63,'file':str(O/'historical_kaks_sources.json'),'sha256':hashlib.sha256((O/'historical_kaks_sources.json').read_bytes()).hexdigest()}))
