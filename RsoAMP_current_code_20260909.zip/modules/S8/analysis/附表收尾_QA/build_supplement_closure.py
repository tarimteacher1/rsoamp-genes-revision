"""Bounded S11 membership/sequence audit and evidence-grounded S5/S6 updates."""
from pathlib import Path
from collections import Counter
import csv,hashlib,io,json,math,re,shutil
import openpyxl
O=Path(__file__).resolve().parent;P=O.parents[1]
R=P/'Genes_lab_handoff_20260908/02_Workspace/9_2_major_revision/revision_R1_20260902'
B=P/'全文图表同步_20260909/baseline/03_Supplementary/Genes_RsoAMP_Supplementary_Tables_expression_status_20260904.xlsx'
F=P/'Genes_lab_handoff_20260908/01_Current_Editing/03_Supplementary/Genes_RsoAMP_Supplementary_Tables_expression_status_20260904.xlsx'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def seqsha(s):return hashlib.sha256(s.encode()).hexdigest()
def rows(p):
 with p.open(encoding='utf-8-sig') as f:return list(csv.DictReader(f,delimiter='\t'))
def write(p,data):
 with p.open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]),delimiter='\t');w.writeheader();w.writerows(data)
def sheet(w,n):
 vals=list(w[n].values);return [{k:('' if v is None else v) for k,v in zip(vals[0],r)} for r in vals[1:]]
wb=openpyxl.load_workbook(B,read_only=True,data_only=False);formal=openpyxl.load_workbook(F,read_only=True,data_only=False)
orig={n:sheet(wb,n) for n in ['S11_KaKsAudit','S5_BackfillLoci','S6_GenomeRescue']}
for n,r in orig.items():assert r==sheet(formal,n),n+' changed since frozen baseline; inspect before overwrite'
cur=rows(P/'成员判定收尾_20260909/统一目录/统一成员目录_主分析111.tsv');cur={r['member_id']:r for r in cur if r['species']=='rso'};assert len(cur)==73
hist=json.loads((O/'sources/historical_kaks_sources.json').read_text())
assert sha(O/'sources/historical_kaks_sources.json')=='870f774ad2893abee70be2316a7341c32eddc17afa8640a594197aee85414f26'
old={r['member_id']:r for r in hist['members']};assert len(old)==63 and set(old)<=set(cur)
seqchecks=[]
for m,r in old.items():
 n=cur[m];assert r['protein_sequence']==n['full_sequence'] and r['cds_sequence']==n['cds_with_stop_sequence'],m
 seqchecks.append({'member_id':m,'historical_protein_id':r['protein_id'],'current_protein_id':n['protein_id'],'protein_identical':True,'CDS_with_stop_identical':True,'protein_sha256':seqsha(r['protein_sequence']),'CDS_with_stop_sha256':seqsha(r['cds_sequence'])})
write(O/'old63_sequence_identity.tsv',seqchecks)
source_tables={k:list(csv.DictReader(io.StringIO(v['text']),delimiter='\t')) for k,v in hist['source_files'].items() if k.endswith(('dup_pairs.tsv','kaks_out.txt'))}
pairsource=source_tables['intermediate/dup_pairs.tsv'];raw={r['Sequence']:r for r in source_tables['intermediate/kaks_out.txt']}
assert len(pairsource)==len(raw)==len(orig['S11_KaKsAudit'])==23
s11=[];numeric=['Ka','Ks','Ka_Ks','fisher_p'];rawnames=['Ka','Ks','Ka/Ks','P-Value(Fisher)']
for row in orig['S11_KaKsAudit']:
 r=dict(row);a,b=r['member_a'],r['member_b'];assert a in old and b in old
 assert any(x['member_a']==a and x['member_b']==b and x['mode']==r['duplication_mode'] for x in pairsource)
 for k,rk in zip(numeric,rawnames):
  x=raw[r['pair']][rk];y=r[k]
  assert (str(x)==str(y)) or (x!='NA' and y!='NA' and math.isclose(float(x),float(y),rel_tol=1e-14)),(r['pair'],k,x,y)
 r.update({'current_primary_membership':'BOTH_MEMBERS_IN_PRIMARY73','current_member_a_protein_id':cur[a]['protein_id'],'current_member_b_protein_id':cur[b]['protein_id'],'current_source_sequence_status':'BOTH_PROTEIN_AND_CDS_IDENTICAL_TO_HISTORICAL_INPUTS','member_a_protein_sha256':seqsha(old[a]['protein_sequence']),'member_b_protein_sha256':seqsha(old[b]['protein_sequence']),'member_a_CDS_with_stop_sha256':seqsha(old[a]['cds_sequence']),'member_b_CDS_with_stop_sha256':seqsha(old[b]['cds_sequence']),'pair_set_scope':'23_HISTORICALLY_NOMINATED_PAIRS_NOT_A_NEW_PRIMARY73_DUPLICATION_CENSUS','fisher_scope':'NOMINAL_PAIR_LEVEL_P_VALUES_NO_NEW_MULTIPLE_TEST_CORRECTION'})
 s11.append(r)
usable=sum(r['reliability_class']=='USABLE_WITH_SHORT_PEPTIDE_CAUTION' for r in s11);supported=sum(r['fisher_supported_ratio_below_one']=='YES' for r in s11)
assert usable==19 and supported==16
write(O/'S11_KaKsAudit.tsv',s11)
(O/'S11_KaKsAudit.json').write_text(json.dumps(s11,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# M5 facts are checked against the completed September 8 evidence audit and its
# original raw files; no new six-family search or remapping is claimed.
m5=P/'R1M5_审查_20260908';live=json.loads((m5/'remote_live_audit.json').read_text(encoding='utf-8'))
sourceqa=[]
for path,info in live['source_files'].items():
 if path.startswith('revision_R1_20260902/'):
  local=R/path.split('/',1)[1]
  assert sha(local)==info['sha256'],path
  shutil.copyfile(local,O/'sources'/local.name);sourceqa.append({'source':str(local.relative_to(P)),'sha256':sha(local),'matches_prior_remote_evidence':True})
seeds=(m5/'历史搜索原始记录/short_seeds.fa').read_text();families=Counter(x[1:].split('|')[0] for x in seeds.splitlines() if x.startswith('>'))
assert families==Counter({'Defensin':63,'Thionin':5,'Snakin_GASA':60})
hsp=[x.split('\t') for x in (m5/'历史搜索原始记录/tblastn_raw.tsv').read_text().splitlines()]
assert len(hsp)==1003 and Counter(x[0].split('|')[0] for x in hsp)==Counter({'Defensin':120,'Snakin_GASA':883})
log=(m5/'历史搜索原始记录/tblastn.log').read_text();assert '2026-07-02' in log and '128' in log and 'e<1e-5' in log
backfill={r['member_id']:r for r in rows(R/'03_annotation_rescue/backfill_locus_audit_final.tsv')};long={r['member_id']:r for r in rows(R/'03_annotation_rescue/isoseq_backfill_support.tsv')}
assert len(backfill)==6 and not (set(backfill)&set(cur))
assert all(x['exact_translation_matches'] and len(x['short_reads'])==9 and all(y['depth_sum']==0 and y['qualifying_fragments']==0 for y in x['short_reads']) for x in live['six_locus_live_recheck'])
assert long['RsDEF7']['primary_reads_overlapping_coding_interval']=='1' and long['RsDEF7']['coding_length_bp']=='258' and abs(float(long['RsDEF7']['maximum_aligned_coding_fraction'])-19/258)<0.0001
for m,r in backfill.items():
 c=r['historical_locus'].split(':')[0];start,end=int(r['coding_start']),int(r['coding_end'])
 assert not any(x['source_branch']=='M6_new_supported_locus' and x['chromosome']==c and int(x['start'])<=end and int(x['end'])>=start for x in cur.values())
changes=[]
def update(r,field,value,sheetname,key):
 if r[field]!=value:changes.append({'sheet':sheetname,'row_id':key,'field':field,'before':r[field],'after':value})
 r[field]=value
s5=[]
for row in orig['S5_BackfillLoci']:
 r=dict(row);m=r['member_id'];e=backfill[m];lr=long[m]
 assert r['short_read_evidence_class']==e['short_read_evidence_class'] and r['isoseq_transcript_evidence_class']==lr['transcript_evidence_class']
 update(r,'rna_short_read_support',e['short_read_evidence_class'],'S5_BackfillLoci',m)
 update(r,'long_read_transcript_support',lr['transcript_evidence_class'],'S5_BackfillLoci',m)
 # The old simultaneous short+long read gate is retained as historical audit data,
 # but it is not presented as a universal requirement for new computational members.
 note='Genomically encoded historical fragment; no complete start-to-stop model supported by the examined local ORF context or transcript evidence; no short-read coding-interval coverage in the nine tested libraries.'
 note+=(' One long read overlaps 19/258 coding bases (7.36%); insufficient to establish a complete model.' if m=='RsDEF7' else ' No aligned long-read target overlap was detected in the existing support audit.')
 update(r,'exclusion_reason',note,'S5_BackfillLoci',m)
 r.update({'current_primary_membership':'NOT_IN_PRIMARY73','current_evidence_decision':'HISTORICAL_GENOMIC_FRAGMENT_COMPLETE_GENE_MODEL_NOT_ESTABLISHED','primary_long_reads_overlapping_coding_interval':int(lr['primary_reads_overlapping_coding_interval']),'coding_interval_length_bp':int(lr['coding_length_bp']),'legacy_combined_gate_scope':'HISTORICAL_SHORT_AND_LONG_READ_GATE_NOT_A_UNIVERSAL_REQUIREMENT_FOR_PRIMARY_MEMBERS','evidence_review_date':'2026-09-08','table_reconciliation_date':'2026-09-09'})
 s5.append(r)
write(O/'S5_BackfillLoci.tsv',s5)
overlap={r['id']:r for r in live['overlap_checks']};assert len(overlap)==31
s6=[]
for row in orig['S6_GenomeRescue']:
 r=dict(row);sid=r['screen_locus_id'];m=r['known_backfill_member_id']
 if m:
  assert m in backfill and int(r['overlapping_gene_model_count'])==0
  update(r,'final_rescue_classification',backfill[m]['final_gene_model_status'],'S6_GenomeRescue',sid)
  status='HISTORICAL_FRAGMENT_COMPLETE_MODEL_NOT_SUPPORTED';same='NOT_APPLICABLE_NO_GENE_SPAN_OVERLAP'
  note='Evidence review completed; complete gene model remains unconfirmed; excluded from primary73.'
 else:
  same='YES' if overlap[sid]['same_strand_gene_overlap'] else 'NO';status='CODING_MODEL_IDENTITY_NOT_ESTABLISHED_BY_GENE_SPAN_OVERLAP_ALONE'
  note='Geometric overlap only; this table does not prove a same-strand complete AMP coding model.'
  if same=='NO':
   update(r,'final_rescue_classification','OPPOSITE_STRAND_GENE_SPAN_OVERLAP_MODEL_IDENTITY_UNRESOLVED','S6_GenomeRescue',sid)
   update(r,'primary_catalogue_inclusion','NOT_ADDED_FROM_THIS_UNRESOLVED_SEARCH_INTERVAL','S6_GenomeRescue',sid)
   note+=(' GWRS014 partly overlaps the previously audited incomplete M6_OVERLAP15 fragment; that observation does not resolve this complete locus model.' if sid=='GWRS014' else ' GWRS017 has no complete follow-up model adjudication established in the checked evidence.')
 r.update({'same_strand_gene_span_overlap':same,'coding_model_identity_status':status,'search_scope':'HISTORICAL_2026_07_02_TBLASTN_128_SEEDS_DEFENSIN63_THIONIN5_SNAKIN_GASA60','interpretation_limit':note,'evidence_review_date':'2026-09-08','table_reconciliation_date':'2026-09-09'})
 s6.append(r)
assert len(s6)==37 and sum(int(r['raw_hsp_count']) for r in s6)==1003 and sum(int(r['overlapping_gene_model_count'])==0 for r in s6)==6
assert sum(r['same_strand_gene_span_overlap']=='NO' for r in s6)==2
write(O/'S6_GenomeRescue.tsv',s6);write(O/'S5_S6_field_changes.tsv',changes)
summary={'status':'PASS','scope':'Bounded reconciliation of existing results; no new Ka/Ks calculation, duplication census, genome search or mapping','source_formal_sheets_equal_frozen_baseline_before_edit':True,'old63_members_all_retained_in_primary73':True,'old63_protein_and_CDS_sequences_identical_to_original_sources':True,'historical_pairs':23,'pairs_both_members_in_primary73':23,'unique_historical_pair_members':len({r[k] for r in s11 for k in ['member_a','member_b']}),'existing_numeric_Ka_Ks_Fisher_values_match_raw_output':True,'usable_with_short_peptide_caution':19,'nominal_Fisher_supported_ratio_below_one':16,'new_primary73_duplication_census_performed':False,'M5_historical_seeds':dict(families),'M5_historical_HSPs':1003,'M5_historical_intervals':37,'M5_gene_span_overlaps':31,'M5_opposite_strand_only_intervals':['GWRS014','GWRS017'],'M5_six_fragments_primary73_excluded':True,'M5_six_fragments_nonoverlapping_new7_M6':True,'prior_54_short_read_combinations_zero_coding_depth_confirmed_from_checked_evidence':True,'RsDEF7_long_read_overlap':'1 read, 19/258 bases (7.36%); no complete model','source_checks':sourceqa,'updated_existing_cells':len(changes),'table_rows':{'S11_KaKsAudit':23,'S5_BackfillLoci':6,'S6_GenomeRescue':37},'formal_files_written':False}
(O/'supplement_closure_QA.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='source_checks'},ensure_ascii=False,indent=2))
