"""Filter fixed current RBH and existing genomic-anchor edges for five catalogues."""
from pathlib import Path
from collections import Counter
import csv,json,hashlib,openpyxl
O=Path(__file__).resolve().parent;P=O.parents[1];D=P/'全文图表同步_20260909/比较_F8/data'
def read(p):
 with p.open(encoding='utf-8-sig') as f:return list(csv.DictReader(f,delimiter='\t'))
def write(p,rows):
 with p.open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
wpath=P/'Genes_lab_handoff_20260908/01_Current_Editing/03_Supplementary/Genes_RsoAMP_Supplementary_Tables_expression_status_20260904.xlsx'
snapshot=O/'sources/S35_historical_snapshot.json'
if snapshot.exists():historic=json.loads(snapshot.read_text(encoding='utf-8'))
else:
 w=openpyxl.load_workbook(wpath,read_only=True,data_only=False)
 vals=list(w['S35_BoundarySensitivity'].values);historic=[{k:('' if v is None else v) for k,v in zip(vals[0],r)} for r in vals[1:]]
assert len(historic)==5
(O/'sources/S35_historical_snapshot.json').write_text(json.dumps(historic,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
catpath=P/'成员判定收尾_20260909/统一目录/统一成员目录_扩展113.tsv'
cat={r['id']:r for r in read(catpath)};assert len(cat)==113 and Counter(r['species'] for r in cat.values())==Counter({'rso':74,'tau':39})
rbh=read(D/'S20_Extended_RBH.tsv');primary_rbh=read(D/'S20_RBH_Pairs.tsv');s21=read(D/'S21_Synteny.tsv')
assert len(rbh)==28 and len(primary_rbh)==27
rbhkeys={(r['query_id'],r['best_other_id']) for r in rbh};assert len(rbhkeys)==28
assert all(r['unique_reciprocal_best_hit']=='True' and r['minimum_half_length_both_sides']=='True' for r in rbh)
plot=json.loads((D/'plot_data.json').read_text(encoding='utf-8'));assert len(plot['blocks'])==588
# Use every real anchor, including pairs omitted by the historical reader.
# Deduplicate multiple block records for the same interspecies gene pair.
anchors={}
for block in plot['blocks']:
 for pair in block['pairs']:
  a,b=pair['gene1'],pair['gene2']
  if a.startswith('TAU__'):a,b=b,a
  assert a.startswith('RSO__') and b.startswith('TAU__')
  key=(a,b)
  if key not in anchors:anchors[key]={'rso_id':a,'tau_id':b,'mcscanx_blocks':[],'any_old_reader_kept':False}
  anchors[key]['mcscanx_blocks'].append(str(block['id']))
  anchors[key]['any_old_reader_kept']|=bool(pair['old_reader_kept'])
assert len(anchors)==17621
labels={'extended':'Current merged extended catalogue','primary_without_C4':'Current merged primary catalogue (C4 pair omitted)','without_IPR044741_route':'Extended catalogue after omitting the two IPR044741-route-dependent candidates','without_both':'Extended catalogue after omitting both C4 and IPR044741-route-dependent pairs','primary_without_profile_edge_cases':'Primary catalogue after the same historical profile-edge omissions'}
out=[];edges=[];primary_ids={k for k,r in cat.items() if r['include_primary']=='True'}
assert len(primary_ids)==111
for old in historic:
 key=old['scenario'];removed=set(filter(None,str(old['removed_ids']).split(';')))
 assert removed<=set(cat),(key,removed-set(cat))
 ids=set(cat)-removed;fc=Counter((cat[i]['species'],cat[i]['family']) for i in ids);tc=Counter(cat[i]['species'] for i in ids)
 rb=[(a,b) for a,b in rbhkeys if a in ids and b in ids]
 links=[(a,b) for a,b in anchors if a in ids or b in ids]
 both=[(a,b) for a,b in links if a in ids and b in ids]
 concordant=[(a,b) for a,b in both if cat[a]['family']==cat[b]['family']]
 nsrb=[(a,b) for a,b in rb if cat[a]['family']==cat[b]['family']=='nsLTP']
 nscol=[(a,b) for a,b in both if cat[a]['family']==cat[b]['family']=='nsLTP']
 if key=='primary_without_C4':
  assert ids==primary_ids and len(rb)==27 and len(both)==25 and len(links)==30
  assert set(rb)=={(r['query_id'],r['best_other_id']) for r in primary_rbh}
  assert set(links)=={(r['rso_gene'],r['tamarix_gene']) for r in s21}
 if key=='extended':assert tc['rso']==74 and tc['tau']==39 and len(rb)==28 and len(both)==26 and len(links)==31
 r={'scenario':key,'current_scenario_label':labels[key],
 'current_catalogue_scope':'Merged M2 plus M6 frozen catalogue; current counts include seven newly supported Rso models',
 'current_rso_nsLTP':fc['rso','nsLTP'],'current_tau_nsLTP':fc['tau','nsLTP'],
 'current_rso_minus_tau_nsLTP':fc['rso','nsLTP']-fc['tau','nsLTP'],'current_rso_to_tau_nsLTP_ratio':fc['rso','nsLTP']/fc['tau','nsLTP'],
 'current_rso_total_candidates':tc['rso'],'current_tau_total_candidates':tc['tau'],
 'current_filtered_RBH_pairs':len(rb),'current_filtered_nsLTP_RBH_pairs':len(nsrb),
 'current_existing_collinear_links_all':len(links),'current_existing_collinear_links_both_retained':len(both),
 'current_existing_collinear_links_family_concordant':len(concordant),'current_existing_nsLTP_collinear_both_retained':len(nscol),
 'current_retained_new_Rso_models':sum(cat[i]['species']=='rso' and cat[i]['source_branch']=='M6_new_supported_locus' for i in ids),
 'current_removed_ids':';'.join(sorted(removed)),
 'current_RBH_method':'Filter the fixed 28-edge extended RBH result from the current cross-species rerun; primary27 edge set independently matches S20_RBH_Pairs; no per-scenario BLAST or best-hit rerun',
 'current_synteny_method':'Filter unique interspecies pairs from all 588 existing MCScanX blocks; includes historical-reader-omitted anchors; no MCScanX rerun; seven new Rso models absent from genomic anchor reference',
 'historical_scope':'Earlier M2-only candidate snapshot; M6 excluded; values preserved verbatim'}
 r.update({'historical_'+k:v for k,v in old.items()});out.append(r)
 for a,b in sorted(rb):edges.append({'scenario':key,'edge_type':'FIXED_CURRENT_EXTENDED_RBH','rso_id':a,'tau_id':b,'rso_family':cat[a]['family'],'tau_family':cat[b]['family'],'rso_retained':True,'tau_retained':True,'both_retained':True,'mcscanx_blocks':'','any_old_reader_kept':''})
 for a,b in sorted(links):
  edge=anchors[a,b]
  edges.append({'scenario':key,'edge_type':'EXISTING_UNIQUE_MCSCANX_ANCHOR','rso_id':a,'tau_id':b,'rso_family':cat.get(a,{}).get('family',''),'tau_family':cat.get(b,{}).get('family',''),'rso_retained':a in ids,'tau_retained':b in ids,'both_retained':a in ids and b in ids,'mcscanx_blocks':';'.join(sorted(set(edge['mcscanx_blocks']),key=int)),'any_old_reader_kept':edge['any_old_reader_kept']})
write(O/'S35_current_and_historical.tsv',out);write(O/'S35_filtered_edges_audit.tsv',edges)
summary={'status':'PASS','scenarios':len(out),'primary_RBH_exactly_matches_current_S20':True,'primary_30_anchor_edges_exactly_match_current_S21':True,'primary_RBH':27,'extended_RBH':28,'primary_direct_anchors':25,'extended_direct_anchors':26,'unique_interspecies_anchor_pairs_considered':17621,'C4_direct_anchor_present_in_block_283':('RSO__gmmChr04G004380.1','TAU__evm.model.Chr10.1284') in anchors,'C4_anchor_historical_reader_kept':anchors['RSO__gmmChr04G004380.1','TAU__evm.model.Chr10.1284']['any_old_reader_kept'],'per_scenario_inference_rerun':False,'source_sha256':{str(p.relative_to(P)):sha(p) for p in [catpath,D/'S20_Extended_RBH.tsv',D/'S20_RBH_Pairs.tsv',D/'S21_Synteny.tsv',D/'plot_data.json']}}
(O/'S35_QA.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps([{k:r[k] for k in ['scenario','current_rso_nsLTP','current_tau_nsLTP','current_rso_total_candidates','current_tau_total_candidates','current_filtered_RBH_pairs','current_filtered_nsLTP_RBH_pairs','current_existing_collinear_links_all','current_existing_collinear_links_both_retained','current_existing_nsLTP_collinear_both_retained']} for r in out],indent=2))
