from pathlib import Path
import csv,json,hashlib,subprocess,collections,re,xml.etree.ElementTree as ET
from PIL import Image
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
O=Path(__file__).resolve().parent;D=O/'data';R=O.parent.parent
def t(p):return list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter='\t'))
def w(p,rr):
 with p.open('w',encoding='utf-8-sig',newline='') as h:
  a=csv.DictWriter(h,fieldnames=list(rr[0]),delimiter='\t',lineterminator='\n');a.writeheader();a.writerows(rr)
script=r'''
from pathlib import Path
import json,hashlib
O=Path('/path/to/rso_project/figure_sync_20260909_primary73_annotation')
out={'exitcodes':{},'files':[],'logs':{}}
for fam in ['Defensin','Snakin_GASA','nsLTP']:
 out['exitcodes'][fam]=(O/(fam+'.exitcode')).read_text().strip()
 for suffix in ['stdout.log','stderr.log']:out['logs'][fam+'.'+suffix]=(O/(fam+'.'+suffix)).read_text()
for p in sorted((O/'meme').rglob('*')):
 if p.is_file():out['files'].append({'path':str(p.relative_to(O/'meme')),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
print(json.dumps(out))
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','example-host','python3 -'],input=script,text=True,encoding='utf-8',capture_output=True,timeout=30,check=True)
remote=json.loads(p.stdout);assert set(remote['exitcodes'].values())=={'0'}
for x in remote['files']:
 local=O/'MEME_primary73'/x['path'];assert local.stat().st_size==x['bytes'] and hashlib.sha256(local.read_bytes()).hexdigest()==x['sha256']
(O/'MEME_completion_and_transfer_validation.json').write_text(json.dumps(remote,indent=2),encoding='utf-8')
s=t(O/'Figure3_structure_summary_primary73.tsv');h=t(O/'Figure4_motif_scan_sites_primary73.tsv');defs=t(O/'Figure4_motif_definitions.tsv');amp=t(D/'amp_catalogue.tsv')
motifocc=[]
for m in defs:
 hh=[x for x in h if x['family']==m['family'] and x['motif_id']==m['motif_id']]
 motifocc.append(dict(m,scan_hits=len(hh),primary_members_with_scan_hits=len({x['member_id'] for x in hh}),primary_family_size=sum(x['family']==m['family'] for x in amp)))
w(O/'Figure4_motif_member_summary.tsv',motifocc)
change=[];old=json.loads((O/'MEME_dispatch_and_provenance.json').read_text(encoding='utf-8'))['old_meme_inputs_and_commands']
for fam,entry in old.items():
 a=set(entry['input_names']);b={x['member_id'] for x in amp if x['family']==fam}
 change.append({'family':fam,'old_MEME_input_count':len(a),'new_primary_MEME_input_count':len(b),'removed_from_old_MEME_input':';'.join(sorted(a-b)),'added_to_new_MEME_input':';'.join(sorted(b-a)),'action':'MEME5.5.9_reestimated_all_five_motifs_from_new_family_input; old_motifs_not_reused'})
w(O/'Figure4_old_new_search_scope.tsv',change)
chrrows=[{'chromosome':c,'Defensin':sum(x['chrom']==c and x['family']=='Defensin' for x in amp),'Snakin_GASA':sum(x['chrom']==c and x['family']=='Snakin_GASA' for x in amp),'nsLTP':sum(x['chrom']==c and x['family']=='nsLTP' for x in amp),'total_primary':sum(x['chrom']==c for x in amp)} for c in sorted({x['chrom'] for x in amp})]
w(O/'Figure1_chromosome_member_counts.tsv',chrrows)
stats={'primary_members':73,'extended_member_RsLTP20_plotted':False,'family_counts':dict(collections.Counter(x['family'] for x in amp)),'chromosome_counts':chrrows,'structure_CDS_segment_counts':{fam:dict(collections.Counter(x['CDS_segments'] for x in s if x['family']==fam)) for fam in old},'source_UTR_counts':dict(collections.Counter(x['UTR_status'] for x in s)),'UTR_not_recorded_members':[x['member_id'] for x in s if x['UTR_status']=='NR'],'meme_member_scan_summary':motifocc}
(O/'Results_numbers_F1_F3_F4.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')

book=Workbook();book.remove(book.active)
tables=[('S1_Catalogue73',O/'S1_Catalogue_primary73.tsv'),('Chr_counts',O/'Figure1_chromosome_member_counts.tsv'),('Structure73',O/'Figure3_structure_summary_primary73.tsv'),('Structure_features',O/'Figure3_structure_features_primary73.tsv'),('MEME_motifs15',O/'Figure4_motif_member_summary.tsv'),('MEME_scan_sites',O/'Figure4_motif_scan_sites_primary73.tsv'),('MEME_contrib_sites',O/'Figure4_motif_contributing_sites.tsv'),('MEME_coverage73',O/'Figure4_sequence_coverage_primary73.tsv'),('MEME_old_new',O/'Figure4_old_new_search_scope.tsv')]
for name,p in tables:
 rr=t(p);ws=book.create_sheet(name);ws.append(list(rr[0]));[ws.append(list(r.values())) for r in rr];ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
 for cell in ws[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='284A60');cell.alignment=Alignment(wrap_text=True,vertical='top')
 ws.row_dimensions[1].height=34
 for col in ws.columns:
  letter=col[0].column_letter;ws.column_dimensions[letter].width=min(45,max(13,len(str(col[0].value))*.88))
book.save(O/'F1_F3_F4_replacement_tables_primary73.xlsx')

exports=[]
names=['Figure1_primary73_ideogram_gene_density','Figure3_primary73_gene_structure','Figure4_primary73_conserved_motifs']
for name in names:
 pdf=(O/(name+'.pdf')).read_bytes();assert b'/FontFile2' in pdf and b'/Subtype /Type3' not in pdf
 tree=ET.parse(O/(name+'.svg'));texts=[''.join(x.itertext()) for x in tree.iter() if x.tag.endswith('}text')]
 for row in amp:assert any(row['member_id']==x.strip() for x in texts),(name,row['member_id'])
 with Image.open(O/(name+'.png')) as im:
  dpi=im.info.get('dpi');assert dpi and abs(dpi[0]-600)<.1
  exports.append({'figure':name,'PNG_size_px':list(im.size),'PNG_dpi':list(dpi),'PDF_TrueType_fonts_embedded':True,'PDF_Type3_fonts':False,'SVG_all73_labels_found':True,'visual_preview_reviewed':True})
qa={'all_three_figures_complete':True,'scope':'73 primary only; RsLTP20 remains extended and is not in these figures','exports':exports,'meme_exitcodes':remote['exitcodes'],'meme_downloaded_files_sha256_verified':len(remote['files']),'meme_total_scan_sites':len(h),'MEME_parameters':'-protein -nmotifs 5 -minw 6 -maxw 50 -mod zoops -maxsize 200000; MEME5.5.9; same as historical XML','Figure1':json.loads((D/'Figure1_primary73_ideogram_gene_density_qa.json').read_text(encoding='utf-8')),'Figure3':json.loads((D/'Figure3_QA.json').read_text(encoding='utf-8')),'Figure4':json.loads((D/'Figure4_QA.json').read_text(encoding='utf-8')),'old_source_figure_files_modified':False,'formal_manuscript_or_supplement_workbook_modified':False}
(O/'QA_annotation_figures.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'meme_verified_files':len(remote['files']),'exports':exports,'structure_CDS_segment_counts':stats['structure_CDS_segment_counts']},indent=2))
