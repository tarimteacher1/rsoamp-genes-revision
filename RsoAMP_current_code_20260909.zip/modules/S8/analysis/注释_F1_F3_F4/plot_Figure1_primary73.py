"""Reproduce Figure 1 from the included, verified inputs. Python 3 + Matplotlib + NumPy.

No inferred centromeres. Gene names can move for legibility; locus marks never move.
Run: python redraw_figure1.py
"""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import math
import xml.etree.ElementTree as ET
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import PathPatch, Rectangle
from matplotlib.path import Path as MplPath
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D

OUT=Path(__file__).resolve().parent
DATA=OUT/'data'
def read(name):
    with (DATA/name).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f,delimiter='\t'))
members=read('amp_catalogue.tsv')
density=read('gene_density_1Mb.tsv')
lengths={r['chrom']:int(r['length_bp']) for r in read('chromosome_lengths.tsv')}
audit=json.loads((DATA/'source_audit.json').read_text(encoding='utf-8'))
assert hashlib.sha256((DATA/'amp_catalogue.tsv').read_bytes()).hexdigest()==audit['catalogue_sha256']
assert len(members)==73 and len({r['member_id'] for r in members})==73
assert Counter(r['family'] for r in members)=={'Defensin':15,'Snakin_GASA':18,'nsLTP':40}
assert sum(int(r['gene_count']) for r in density)==audit['gene_count_on_11_chromosomes']==21339
assert lengths==audit['chromosome_lengths']
for r in members:
    assert 1<=int(r['start'])<=int(r['end'])<=lengths[r['chrom']]
for chrom in lengths:
    d=[r for r in density if r['chrom']==chrom]
    assert int(d[0]['start_1based'])==1 and int(d[-1]['end_1based'])==lengths[chrom]
    assert all(int(a['end_1based'])+1==int(b['start_1based']) for a,b in zip(d,d[1:]))

COLORS={'Defensin':'#C43D3D','Snakin_GASA':'#2E6F9E','nsLTP':'#2F7D4A'}
NAMES={'Defensin':'Defensin','Snakin_GASA':'Snakin/GASA','nsLTP':'nsLTP'}
CMAP=LinearSegmentedColormap.from_list('gene_density',['#F2F5F7','#C1D0DC','#7896AD','#2C506F'])
NORM=Normalize(0,70)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.2,'svg.fonttype':'none',
                    'pdf.fonttype':42,'ps.fonttype':42,'axes.linewidth':0.65,
                    'savefig.dpi':600,'text.color':'#27323B'})

def separate_labels(positions,gap,lo,hi):
    """Bounded isotonic regression gives minimum squared displacement at fixed spacing."""
    if not positions:return []
    assert hi-lo>=(len(positions)-1)*gap
    blocks=[]
    for i,y in enumerate(positions):
        blocks.append([y-i*gap,1])
        while len(blocks)>1 and blocks[-2][0]/blocks[-2][1]>blocks[-1][0]/blocks[-1][1]:
            a,b=blocks[-2:];blocks[-2:]=[[a[0]+b[0],a[1]+b[1]]]
    base=[]
    for total,n in blocks:base.extend([max(lo,min(hi-(len(positions)-1)*gap,total/n))]*n)
    result=[v+i*gap for i,v in enumerate(base)]
    assert all(b-a>=gap-1e-8 for a,b in zip(result,result[1:]))
    return result

def capsule(ax,x,length,width=.245):
    """Use matching DISPLAY radii: visually semicircular ends on unequal x/y scales."""
    dx=abs(ax.transData.transform((1,0))[0]-ax.transData.transform((0,0))[0])
    dy=abs(ax.transData.transform((0,1))[1]-ax.transData.transform((0,0))[1])
    rx=width/2;ry=rx*dx/dy
    k=.5522847498307936
    v=[(x,0),(x+k*rx,0),(x+rx,ry-k*ry),(x+rx,ry),
       (x+rx,length-ry),(x+rx,length-ry+k*ry),(x+k*rx,length),(x,length),
       (x-k*rx,length),(x-rx,length-ry+k*ry),(x-rx,length-ry),
       (x-rx,ry),(x-rx,ry-k*ry),(x-k*rx,0),(x,0),(x,0)]
    c=[MplPath.MOVETO]+[MplPath.CURVE4]*3+[MplPath.LINETO]+[MplPath.CURVE4]*6+[MplPath.LINETO]+[MplPath.CURVE4]*3+[MplPath.CLOSEPOLY]
    return PathPatch(MplPath(v,c),facecolor='#EDF0F2',edgecolor='#6D7A84',lw=.7,zorder=2),rx,ry

def sides_for(rows):
    """Split only clusters of >=3 nearby genes, preserving locus order on each side."""
    clusters=[]
    for r in rows:
        if not clusters or int(r['start'])-int(clusters[-1][-1]['start'])>4_500_000:
            clusters.append([])
        clusters[-1].append(r)
    sides={}
    for cluster in clusters:
        for i,r in enumerate(cluster):
            sides[r['member_id']]=(-1 if len(cluster)>=3 and i%2==0 else 1)
    return sides

def draw(with_density=True):
    fig=plt.figure(figsize=(12.6,10.8),facecolor='white',dpi=120)
    axes=[fig.add_axes([.085,.527,.895,.347]),fig.add_axes([.085,.091,.895,.347])]
    for ax in axes:
        ax.set_xlim(-1.04,11.69);ax.set_ylim(150,-12)
        ax.set_xticks([]);ax.set_yticks(range(0,141,20))
        ax.tick_params(axis='y',length=3,width=.65,pad=5,labelsize=9,colors='#687581')
        ax.spines[['top','bottom','right']].set_visible(False)
        ax.spines['left'].set_color('#ACB5BC')
        ax.spines['left'].set_bounds(0,140)
        ax.set_ylabel('Position (Mb)',fontsize=10,labelpad=12,color='#46535E')
    fig.canvas.draw()
    texts=[];layout=[];patches=[];leaders=[]
    chroms=sorted(lengths)
    for ax,group,letter in zip(axes,[chroms[:6],chroms[6:]],'AB'):
        ax.text(-.045,1.045,letter,transform=ax.transAxes,fontsize=14,weight='bold',ha='left',va='bottom')
        for i,chrom in enumerate(group):
            x=i*2.15;length=lengths[chrom]/1e6
            p,rx,ry=capsule(ax,x,length)
            p.set_gid('chromosome-'+chrom);ax.add_patch(p);patches.append((ax,p,chrom))
            if with_density:
                for d in [r for r in density if r['chrom']==chrom]:
                    y=(int(d['start_1based'])-1)/1e6;h=(int(d['end_1based'])-int(d['start_1based'])+1)/1e6
                    band=Rectangle((x-rx,y),2*rx,h,facecolor=CMAP(NORM(float(d['genes_per_Mb']))),edgecolor='none',lw=0,zorder=2.1)
                    band.set_clip_path(p);ax.add_patch(band)
                outline=PathPatch(p.get_path(),facecolor='none',edgecolor='#647380',lw=.7,zorder=2.2)
                ax.add_patch(outline)
            ax.text(x,-5.8,chrom,ha='center',va='center',fontsize=10.4,weight='bold')
            ax.text(x,length+3.9,f'{length:.2f} Mb',ha='center',va='top',fontsize=7.8,color='#84909A')
            rows=sorted([r for r in members if r['chrom']==chrom],key=lambda r:int(r['start']))
            sides=sides_for(rows)
            dy_px=abs(ax.transData.transform((0,1))[1]-ax.transData.transform((0,0))[1])
            gap=(11.9*fig.dpi/72)/dy_px
            for side in (-1,1):
                subset=[r for r in rows if sides[r['member_id']]==side]
                pos=[int(r['start'])/1e6 for r in subset]
                ys=separate_labels(pos,gap,.7,length-.7)
                for r,y,ly in zip(subset,pos,ys):
                    color=COLORS[r['family']];name=r['member_id']
                    # All loci stay at original catalogue start / 1e6; the cap is purely cosmetic.
                    mark=ax.plot([x-rx*.82,x+rx*.82],[y,y],color=color,lw=1.15,solid_capstyle='round',zorder=5)[0]
                    mark.set_gid('locus-'+name)
                    lx=[x+side*rx*.82,x+side*(rx+.058),x+side*.300,x+side*.350]
                    line=ax.plot(lx,[y,y,ly,ly],color=color,lw=.58,alpha=.78,solid_capstyle='round',zorder=4)[0]
                    line.set_gid('leader-'+name);leaders.append(line)
                    t=ax.text(x+side*.385,ly,name,ha='left' if side>0 else 'right',va='center',fontsize=9.2,fontstyle='italic',color=color,zorder=6)
                    t.set_gid('label-'+name);texts.append((ax,t,name))
                    assert list(mark.get_ydata())==[int(r['start'])/1e6]*2
                    layout.append({'member_id':name,'family':r['family'],'chrom':chrom,'start_bp':int(r['start']),'end_bp':int(r['end']),'locus_y_Mb':y,'label_y_Mb':ly,'label_side':'right' if side>0 else 'left'})
    fig.text(.085,.967,'Chromosomal distribution of AMP genes',ha='left',va='center',fontsize=16,weight='medium')
    fig.text(.98,.967,'Reaumuria soongarica',ha='right',va='center',fontsize=12,fontstyle='italic',color='#596672')
    handles=[Line2D([],[],color=COLORS[f],lw=2.3,label=f'{NAMES[f]}  ({Counter(r["family"] for r in members)[f]})') for f in COLORS]
    fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.078,.939),frameon=False,ncol=3,fontsize=10,handlelength=1.6,columnspacing=2.1)
    fig.text(.085,.03,'73 primary AMP loci  •  Shared genomic scale across both panels',fontsize=9,color='#65727E',ha='left')
    if with_density:
        cax=fig.add_axes([.789,.914,.173,.0115])
        cb=fig.colorbar(plt.cm.ScalarMappable(norm=NORM,cmap=CMAP),cax=cax,orientation='horizontal',ticks=[0,20,40,60,70])
        cb.solids.set_rasterized(False)
        cb.outline.set_visible(False);cb.ax.tick_params(labelsize=7.7,length=2,color='#8694A1',pad=2)
        cax.set_title('Gene density (genes / Mb)',fontsize=9,pad=5,loc='left')
    fig.canvas.draw();renderer=fig.canvas.get_renderer()
    boxes=[(ax,t.get_window_extent(renderer),name) for ax,t,name in texts]
    overlaps=[];rod_overlaps=[];out_of_canvas=[]
    for j,(ax,b,name) in enumerate(boxes):
        for ax2,b2,name2 in boxes[j+1:]:
            if ax is ax2 and b.overlaps(b2):overlaps.append([name,name2])
        for ax2,patch,chrom in patches:
            if ax is ax2 and b.overlaps(patch.get_window_extent(renderer)):rod_overlaps.append([name,chrom])
        if b.x0<0 or b.y0<0 or b.x1>fig.bbox.width or b.y1>fig.bbox.height:out_of_canvas.append(name)
    assert not overlaps,overlaps
    assert not rod_overlaps,rod_overlaps
    assert not out_of_canvas,out_of_canvas
    assert len(texts)==len(leaders)==73
    name='Figure1_primary73_ideogram_gene_density' if with_density else 'Figure1_ideogram_clean'
    fig.savefig(OUT/f'{name}.svg',metadata={'Creator':'Matplotlib; actual FAI chromosome lengths and GFF-derived 1 Mb gene density; no centromere inference.'})
    fig.savefig(OUT/f'{name}.pdf',metadata={'Title':'Chromosomal distribution of AMP genes in Reaumuria soongarica','Author':'','Subject':'Chromosome-scaled gene positions; centromeres not inferred'})
    fig.savefig(OUT/f'{name}.png',dpi=600)
    fig.savefig(OUT/f'{name}_preview.png',dpi=160)
    tree=ET.parse(OUT/f'{name}.svg');ns={'s':'http://www.w3.org/2000/svg'}
    ids={e.attrib.get('id') for e in tree.iter()}
    assert {f'locus-{r["member_id"]}' for r in members}<=ids
    assert {f'label-{r["member_id"]}' for r in members}<=ids
    assert {f'leader-{r["member_id"]}' for r in members}<=ids
    # Native SVG tooltips retain exact coordinates for later visual editing.
    byid={e.attrib.get('id'):e for e in tree.iter()}
    ET.register_namespace('','http://www.w3.org/2000/svg')
    ET.register_namespace('xlink','http://www.w3.org/1999/xlink')
    for r in members:
        for prefix in ('locus-','label-','leader-'):
            el=byid[prefix+r['member_id']]
            title=ET.Element('{http://www.w3.org/2000/svg}title')
            title.text=f"{r['member_id']} | {r['chrom']}:{int(r['start']):,}-{int(r['end']):,} ({r['strand']}) | {NAMES[r['family']]}"
            el.insert(0,title)
    tree.write(OUT/f'{name}.svg',encoding='utf-8',xml_declaration=True)
    with (DATA/f'{name}_label_positions.tsv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(layout[0]),delimiter='\t');w.writeheader();w.writerows(layout)
    qa={'matplotlib':matplotlib.__version__,'numpy':np.__version__,'labels':len(texts),'leaders':len(leaders),'label_overlaps':overlaps,'label_rod_overlaps':rod_overlaps,'labels_outside_canvas':out_of_canvas,'all_locus_y_values_match_catalogue_starts':True,'same_Mb_scale_on_both_panels':axes[0].get_ylim()==axes[1].get_ylim() and axes[0].get_position().height==axes[1].get_position().height,'centromeres_added':False,'density_windows':len(density) if with_density else 0,'density_color_range_genes_per_Mb':[0,70] if with_density else None,'density_values_clipped':False,'shape':'capsule; both ends follow display-space semicircles, no biological centromere or telomere annotation implied','PNG_dpi':600,'size_inches':[12.6,10.8]}
    qa['same_Mb_scale_on_both_panels']=bool(axes[0].get_ylim()==axes[1].get_ylim() and abs(axes[0].get_position().height-axes[1].get_position().height)<1e-12)
    assert qa['same_Mb_scale_on_both_panels']
    assert all(0<=float(r['genes_per_Mb'])<=70 for r in density)
    (DATA/f'{name}_qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
    plt.close(fig)
    print(json.dumps({'figure':name,**qa},ensure_ascii=False))

if __name__=='__main__':
    draw(True)
    # Single approved gene-density style retained.
