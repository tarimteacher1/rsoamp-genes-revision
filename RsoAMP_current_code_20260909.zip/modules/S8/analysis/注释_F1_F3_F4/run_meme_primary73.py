from pathlib import Path
import csv,json,hashlib,subprocess,time
O=Path(__file__).resolve().parent;R=O.parent.parent
U=R/'成员判定收尾_20260909/统一目录'
rows=[r for r in csv.DictReader((U/'统一成员目录_主分析111.tsv').open(encoding='utf-8-sig'),delimiter='\t') if r['species']=='rso']
assert len(rows)==73
families=['Defensin','Snakin_GASA','nsLTP']
(O/'inputs').mkdir(exist_ok=True)
payload={}
for fam in families:
    rr=sorted([r for r in rows if r['family']==fam],key=lambda x:int(''.join(c for c in x['member_id'] if c.isdigit())))
    s=''.join('>'+r['member_id']+'\n'+r['full_sequence']+'\n' for r in rr)
    (O/'inputs'/f'{fam}_primary73.faa').write_text(s,encoding='ascii')
    payload[fam]=s
assert [sum(r['family']==f for r in rows) for f in families]==[15,18,40]
script=r'''
from pathlib import Path
import os,json,subprocess,hashlib,time,xml.etree.ElementTree as ET
payload=__PAYLOAD__
B=Path('/path/to/rso_project')
O=B/'figure_sync_20260909_primary73_annotation'
if O.exists():
 raise RuntimeError('Independent output already exists; inspect status before any reuse, never overwrite old results.')
O.mkdir();(O/'inputs').mkdir();(O/'meme').mkdir()
exe='/path/to/user/tools/miniconda3/envs/cotton/bin/meme'
version=subprocess.check_output([exe,'-version'],text=True).strip()
assert version=='5.5.9',version
env=os.environ.copy();env['PATH']=str(Path(exe).parent)+':'+env['PATH'];env['OMP_NUM_THREADS']='1'
old={};jobs={}
for fam,seq in payload.items():
 p=O/'inputs'/f'{fam}_primary73.faa';p.write_text(seq)
 root=ET.parse(B/'intermediate/meme'/fam/'meme.xml').getroot()
 old[fam]={'command_line':root.findtext('model/command_line'),'input_names':[s.get('name') for s in root.findall('training_set/sequence')]}
 cmd=[exe,str(p),'-protein','-oc',str(O/'meme'/fam),'-nmotifs','5','-minw','6','-maxw','50','-mod','zoops','-maxsize','200000']
 # A per-family wrapper records terminal status without holding an SSH session open.
 runner=O/f'run_{fam}.py'
 runner.write_text('import subprocess,json,pathlib,os\ncmd='+repr(cmd)+'\nenv=os.environ.copy()\nenv["PATH"]='+repr(str(Path(exe).parent))+ '+":"+env["PATH"]\nenv["OMP_NUM_THREADS"]="1"\np=pathlib.Path('+repr(str(O/'meme'/fam))+')\nwith open('+repr(str(O/f'{fam}.stdout.log'))+',"w") as a,open('+repr(str(O/f'{fam}.stderr.log'))+',"w") as b:\n r=subprocess.run(cmd,env=env,stdout=a,stderr=b)\npathlib.Path('+repr(str(O/f'{fam}.exitcode'))+').write_text(str(r.returncode))\n')
 h=open(O/f'{fam}.launcher.log','w');proc=subprocess.Popen(['python3',str(runner)],stdout=h,stderr=h,start_new_session=True);h.close()
 jobs[fam]={'pid':proc.pid,'command':cmd,'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'sequences':seq.count('>')}
data={'remote_root':str(O),'meme_version':version,'jobs':jobs,'old_meme_inputs_and_commands':old,'start_UTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'parallelism':'three independent serial family runs; no reused old sequence search'}
(O/'provenance.json').write_text(json.dumps(data,indent=2));print(json.dumps(data))
'''.replace('__PAYLOAD__',repr(payload))
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','example-host','python3 -'],input=script,capture_output=True,text=True,encoding='utf-8',timeout=30)
if p.returncode:raise RuntimeError(p.stderr)
d=json.loads(p.stdout);(O/'MEME_dispatch_and_provenance.json').write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(d,indent=2,ensure_ascii=False))
