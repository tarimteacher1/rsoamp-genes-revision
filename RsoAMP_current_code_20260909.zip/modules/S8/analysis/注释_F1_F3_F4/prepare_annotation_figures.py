from pathlib import Path
import csv,json,hashlib,shutil,collections
O=Path(__file__).resolve().parent;R=O.parent.parent;U=R/'成员判定收尾_20260909/统一目录';D=O/'data'
D.mkdir(exist_ok=True);(O/'inputs').mkdir(exist_ok=True)
def t(p):return list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter='\t'))
def w(p,rr):
 with p.open('w',encoding='utf-8-sig',newline='') as h:
  a=csv.DictWriter(h,fieldnames=list(rr[0]),delimiter='\t',lineterminator='\n');a.writeheader();a.writerows(rr)
rows=[x for x in t(U/'统一成员目录_主分析111.tsv') if x['species']=='rso']
assert len(rows)==73 and collections.Counter(x['family'] for x in rows)=={'Defensin':15,'Snakin_GASA':18,'nsLTP':40}
old=t(R/'Figure1_重绘_20260908/data/amp_catalogue.tsv')
newnames={x['member_id'] for x in rows}-{x['member_id'] for x in old}
assert newnames=={'RsDEF15','RsDEF16','RsDEF17','RsDEF18','RsDEF19','RsDEF20','RsLTP2','RsLTP18','RsLTP30','RsLTP41'}
f1=[];s1=[]
for r in rows:
 f1.append({'member_id':r['member_id'],'family':r['family'],'protein_id':r['protein_id'],'chrom':r['chromosome'],'start':r['start'],'end':r['end'],'strand':r['strand'],'source_branch':r['source_branch'],'added_to_old63':r['member_id'] in newnames})
 s1.append({'member_id':r['member_id'],'family':r['family'],'protein_id':r['protein_id'],'gene_id':r['original_gene_parent'],'chrom':r['chromosome'],'start':r['start'],'end':r['end'],'strand':r['strand'],'length_aa':r['protein_length_aa'],'historical_source':'M6_reconstructed_transcript' if r['source_candidate_id'] else 'annotated','historical_subclass':'','final_subclass':'computational_family_member','final_subtype':r['gpi_evidence_category'],'catalogue_status':'PRIMARY_COMPUTATIONAL_MEMBER','classification_confidence':r['decision_layer'],'classification_reason':r['identity_route'],'source_branch':r['source_branch'],'original_model_id':r['source_model_id'],'candidate_alias':r['source_candidate_id'],'protein_sha256':r['protein_sha256'],'cds_with_stop_sha256':r['cds_with_stop_sha256'],'source_gene_feature_ID':r['source_gene_feature_ID'],'old_Salmon_reference_status':r['old_Salmon_reference_status']})
w(D/'amp_catalogue.tsv',f1);w(O/'S1_Catalogue_primary73.tsv',s1)
for name in ['chromosome_lengths.tsv','gene_density_1Mb.tsv','genome.fa.fai']:
 shutil.copy2(R/'Figure1_重绘_20260908/data'/name,D/name)
audit=json.loads((R/'Figure1_重绘_20260908/data/source_audit.json').read_text(encoding='utf-8'))
shutil.copy2(R/'Figure1_重绘_20260908/data/source_audit.json',D/'legacy_density_source_audit.json')
audit['catalogue_sha256']=hashlib.sha256((D/'amp_catalogue.tsv').read_bytes()).hexdigest()
audit['catalogue_family_counts']=dict(collections.Counter(x['family'] for x in rows))
audit['catalogue_path']=str(U/'统一成员目录_主分析111.tsv')
audit['coordinate_checks']=[{'member_id':r['member_id'],'within_chromosome':1<=int(r['start'])<=int(r['end'])<=audit['chromosome_lengths'][r['chromosome']],'source':r['gff_source']} for r in rows]
assert all(x['within_chromosome'] for x in audit['coordinate_checks'])
audit['density_scope']='unchanged reference annotation gene features; M6 additions are locus overlays, not an undocumented rewrite of genome-wide annotation density'
audit['primary_count']=73;audit['added_or_restored_to_old63']=sorted(newnames)
(D/'source_audit.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False),encoding='utf-8')
script=(R/'Figure1_重绘_20260908/redraw_figure1.py').read_text(encoding='utf-8')
script=script.replace('==63','==73').replace("'Defensin':9,'Snakin_GASA':18,'nsLTP':36","'Defensin':15,'Snakin_GASA':18,'nsLTP':40").replace('63 AMP loci','73 primary AMP loci').replace('    draw(False)','    # Single approved gene-density style retained.').replace('Figure1_ideogram_gene_density','Figure1_primary73_ideogram_gene_density')
(O/'plot_Figure1_primary73.py').write_text(script,encoding='utf-8')
for name in ['rso_主分析_73.protein.faa','rso_主分析_73.cds_with_stop.fna','rso_主分析_73.coding.gff3','rso_source_model_features.raw.gff3','统一成员目录_主分析111.tsv']:
 shutil.copy2(U/name,O/'inputs'/name)
w(O/'input_manifest_SHA256.tsv',[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [U/'统一成员目录_主分析111.tsv',U/'rso_主分析_73.protein.faa',U/'rso_主分析_73.cds_with_stop.fna',U/'rso_主分析_73.coding.gff3',U/'rso_source_model_features.raw.gff3',R/'Figure1_重绘_20260908/redraw_figure1.py',R/'Figure1_重绘_20260908/data/gene_density_1Mb.tsv',R/'Figure1_重绘_20260908/data/chromosome_lengths.tsv']])
print('73 primary members; ten changes relative to old63:',sorted(newnames))
