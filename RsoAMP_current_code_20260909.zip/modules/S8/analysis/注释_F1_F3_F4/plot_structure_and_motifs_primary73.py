from pathlib import Path
import csv,json,re,hashlib,collections,xml.etree.ElementTree as ET
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
from matplotlib.lines import Line2D

O=Path(__file__).resolve().parent;I=O/'inputs';D=O/'data'
FAMS=['Defensin','Snakin_GASA','nsLTP'];LABEL={'Defensin':'Defensin','Snakin_GASA':'Snakin/GASA','nsLTP':'nsLTP'}
COL={'Defensin':'#C43D3D','Snakin_GASA':'#2E6F9E','nsLTP':'#2F7D4A'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7.5,'svg.fonttype':'none','pdf.fonttype':42,'ps.fonttype':42,'axes.linewidth':.6,'savefig.dpi':600,'text.color':'#27323B'})
def t(p):return list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter='\t'))
def w(p,rr):
 with p.open('w',encoding='utf-8-sig',newline='') as h:
  a=csv.DictWriter(h,fieldnames=list(rr[0]),delimiter='\t',lineterminator='\n');a.writeheader();a.writerows(rr)
def key(r):return(FAMS.index(r['family']),int(re.search(r'\d+$',r['member_id'])[0]))
rows=sorted([r for r in t(I/'统一成员目录_主分析111.tsv') if r['species']=='rso'],key=key)
byname={r['member_id']:r for r in rows}
assert len(rows)==73 and len(byname)==73
def attrs(s):return dict(a.split('=',1) for a in s.strip(';').split(';') if '=' in a)
def gff(p):
 out=[]
 for l in p.read_text(encoding='utf-8').splitlines():
  if l.startswith('#'):continue
  z=l.split('\t')
  if len(z)!=9:continue
  out.append({'chrom':z[0],'source':z[1],'type':z[2],'a':int(z[3]),'b':int(z[4]),'strand':z[6],'phase':z[7],'attrs':attrs(z[8])})
 return out
raw=gff(I/'rso_source_model_features.raw.gff3');coding=gff(I/'rso_主分析_73.coding.gff3')
tx={x['attrs']['ID']:x for x in raw if x['type'] in ['mRNA','transcript']}
features=collections.defaultdict(list)
for x in raw:
 for p in x['attrs'].get('Parent','').split(','):
  if p:features[p].append(x)
normalized=collections.defaultdict(list)
for x in coding:
 for p in x['attrs'].get('Parent','').split(','):
  if p:normalized[p].append(x)
def merge(segs):
 out=[]
 for a,b in sorted(set(segs)):
  if out and a<=out[-1][1]+1:out[-1]=(out[-1][0],max(b,out[-1][1]))
  else:out.append((a,b))
 return out
def subtract(segs,cuts):
 out=[]
 for a,b in segs:
  spans=[(a,b)]
  for c,d in cuts:
   nxt=[]
   for x,y in spans:
    if d<x or c>y:nxt.append((x,y));continue
    if x<c:nxt.append((x,c-1))
    if d<y:nxt.append((d+1,y))
   spans=nxt
  out.extend(spans)
 return out
structure=[];segments=[]
for r in rows:
 name=r['member_id'];is_m6=bool(r['source_candidate_id']);tid=name+'.t1' if is_m6 else r['protein_id']
 assert tid in tx,(name,tid)
 model=tx[tid];rr=features[tid];n=normalized[r['id']+'.transcript']
 cds=[(x['a'],x['b']) for x in n if x['type']=='CDS'];stop=[(x['a'],x['b']) for x in n if x['type']=='stop_codon']
 assert cds and sum(b-a+1 for a,b in cds)==len(r['full_sequence'])*3
 assert sum(b-a+1 for a,b in stop)==3
 a,b=model['a'],model['b'];assert (a,b)==(int(r['start']),int(r['end']))
 strand=r['strand'];span=b-a+1
 explicit_utr=[(x['a'],x['b']) for x in rr if x['type'] in ['five_prime_UTR','three_prime_UTR','UTR']]
 exon=[(x['a'],x['b']) for x in rr if x['type']=='exon']
 if is_m6:
  assert exon
  noncoding=subtract(merge(exon),merge(cds+stop));utr_status='M';utr_provenance='noncoding_exonic_segments_derived_from_complete_M6_exon_CDS_stop_model'
 else:
  noncoding=merge(explicit_utr);utr_status='S' if explicit_utr else 'NR'
  utr_provenance='explicit_UTR_features_in_source_annotation' if explicit_utr else 'UTR_features_not_recorded_not_evidence_of_UTR_absence'
 if not exon:exon=merge(cds+stop+noncoding)
 else:exon=merge(exon)
 introns=[(e[1]+1,f[0]-1) for e,f in zip(exon,exon[1:]) if e[1]+1<=f[0]-1]
 source='M6' if is_m6 else 'A'
 row={'member_id':name,'family':r['family'],'original_model_id':r['source_model_id'],'plotted_source_transcript_ID':tid,'source_label':source,'chrom':model['chrom'],'start_1based':a,'end_1based':b,'strand':strand,'transcript_span_bp':span,'CDS_segments':len(cds),'CDS_length_excluding_stop_nt':sum(d-c+1 for c,d in cds),'coding_sequence_complete_start_stop':r['CDS_complete_start_stop'],'exonic_segments_from_source_features':len(exon),'intron_count_within_source_features':len(introns),'UTR_status':utr_status,'UTR_or_noncoding_exonic_bp':sum(d-c+1 for c,d in noncoding),'UTR_evidence':utr_provenance,'protein_length_aa':len(r['full_sequence']),'source_branch':r['source_branch'],'GFF_provenance':r['gff_source'],'orientation':'5prime_to_3prime; minus_strand_models_reversed_for_display'}
 structure.append(row)
 for typ,ss in [('CDS',cds),('stop_codon',stop),('noncoding_exon_or_UTR',noncoding),('intron',introns)]:
  for c,d in ss:
   left=(c-a)/span if strand=='+' else (b-d)/span
   width=(d-c+1)/span
   assert 0<=left and left+width<=1+1e-12
   segments.append({'member_id':name,'family':r['family'],'source_label':source,'feature_type':typ,'chrom':model['chrom'],'start_1based':c,'end_1based':d,'strand':strand,'length_bp':d-c+1,'relative_start_0to1':left,'relative_width':width,'UTR_status':utr_status})
w(O/'Figure3_structure_summary_primary73.tsv',structure);w(O/'Figure3_structure_features_primary73.tsv',segments)

def canvas_qa(fig,items,name):
 fig.canvas.draw();renderer=fig.canvas.get_renderer();boxes=[];outside=[];overlap=[]
 for label,text in items:
  b=text.get_window_extent(renderer)
  if b.x0<-.1 or b.y0<-.1 or b.x1>fig.bbox.width+.1 or b.y1>fig.bbox.height+.1:outside.append(label)
  boxes.append((label,b))
 for i,(a,b) in enumerate(boxes):
  for c,d in boxes[i+1:]:
   if b.overlaps(d):overlap.append([a,c])
 assert not outside,(name,outside)
 assert not overlap,(name,overlap)
 return {'text_objects_checked':len(items),'overlapping_text':overlap,'text_outside_canvas':outside}
def save(fig,name):
 for ext in ['pdf','svg','png']:
  fig.savefig(O/(name+'.'+ext),dpi=600,facecolor='white')
 fig.savefig(O/(name+'_preview.png'),dpi=160,facecolor='white')

def draw_structure():
 fig=plt.figure(figsize=(8.45,12.6),facecolor='white',dpi=120)
 ax=fig.add_axes([.14,.072,.59,.805]);positions={};headers=[];y=0
 for fam in FAMS:
  headers.append((fam,y-.85))
  for r in [x for x in structure if x['family']==fam]:positions[r['member_id']]=y;y+=1
  y+=2.2
 for name,yy in positions.items():
  ss=[s for s in segments if s['member_id']==name]
  for s in ss:
   left=float(s['relative_start_0to1']);width=float(s['relative_width']);typ=s['feature_type']
   if typ=='intron':ax.plot([left,left+width],[yy,yy],color='#9AA3AA',lw=.55,zorder=1)
   elif typ=='noncoding_exon_or_UTR':ax.add_patch(Rectangle((left,yy-.17),width,.34,facecolor='#CED5DB',edgecolor='#97A4AE',lw=.32,hatch='////' if s['UTR_status']=='M' else None,zorder=3))
   else:ax.add_patch(Rectangle((left,yy-.28),width,.56,facecolor=COL[s['family']],edgecolor='none',zorder=4))
 ax.set_ylim(y-2.4,-2.1);ax.set_xlim(-.006,1.01)
 ax.set_yticks(list(positions.values()));ax.set_yticklabels(list(positions),fontsize=7.15,fontstyle='italic')
 ax.tick_params(axis='y',length=0,pad=4);ax.tick_params(axis='x',labelsize=7)
 ax.spines[['top','left','right']].set_visible(False);ax.spines['bottom'].set_color('#9AA3AA')
 ax.set_xlabel("Relative position in source transcript model (5′ → 3′)",fontsize=8,labelpad=7)
 texts=[('name-'+n,t) for n,t in zip(positions,ax.get_yticklabels())]
 for r in structure:
  yy=positions[r['member_id']]
  for xx,text,tag in [(1.105,f"{r['transcript_span_bp']:,}",'span'),(1.235,r['source_label'],'source'),(1.365,r['UTR_status'],'utr')]:
   h=ax.text(xx,yy,text,transform=ax.get_yaxis_transform(),ha='center',va='center',fontsize=6.5,color='#536371');texts.append((tag+'-'+r['member_id'],h))
 for fam,yy in headers:
  ax.text(0,yy,f'{LABEL[fam]}  (n = {sum(r["family"]==fam for r in rows)})',transform=ax.get_yaxis_transform(),color=COL[fam],fontsize=8.1,fontweight='bold',ha='left',va='bottom')
 for xx,text in [(1.105,'Span (bp)'),(1.235,'Source'),(1.365,'UTR')]:ax.text(xx,1.015,text,transform=ax.transAxes,ha='center',fontsize=6.6,fontweight='bold',color='#536371')
 fig.text(.14,.97,'Gene structures of 73 primary-catalogue members',fontsize=12.5,weight='medium',ha='left')
 handles=[Patch(facecolor='#657A8D',label='Coding exon (family colour)'),Patch(facecolor='#CED5DB',edgecolor='#97A4AE',label='Source UTR / noncoding exon'),Line2D([],[],color='#9AA3AA',lw=.7,label='Intron')]
 fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.132,.954),ncol=3,frameon=False,fontsize=7,columnspacing=1.2,handlelength=1.5)
 fig.text(.14,.915,'Source: A, reference annotation; M6, reconstructed transcript.\nUTR: S, source annotation; M, model-derived (hatched); NR, not recorded.',fontsize=7,color='#64717C',ha='left',va='top',linespacing=1.5)
 fig.text(.14,.022,'Models are normalized separately; unrecorded UTRs are not inferred absent. Terminal stop codons are included in coloured blocks.',fontsize=6.5,color='#64717C',ha='left')
 qa=canvas_qa(fig,texts,'Figure3')
 qa.update({'members':len(positions),'family_counts':dict(collections.Counter(r['family'] for r in structure)),'source_counts':dict(collections.Counter(r['source_label'] for r in structure)),'UTR_status_counts':dict(collections.Counter(r['UTR_status'] for r in structure)),'all_73_have_source_models_and_coding_features':True,'all_CDS_lengths_match_frozen_proteins':True,'minus_strand_display_reversed':True,'no_UTR_absence_inferred_from_coding_only_GFF':True,'normalization':'individual_full_source_mRNA_spans','matplotlib':matplotlib.__version__})
 save(fig,'Figure3_primary73_gene_structure');plt.close(fig)
 (D/'Figure3_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8');return qa

def motif_data():
 defs=[];hits=[];contrib=[];seqtable=[];qa={};pwm=[]
 for fam in FAMS:
  p=O/'MEME_primary73'/fam/'meme.xml';root=ET.parse(p).getroot()
  names={s.get('id'):(s.get('name'),int(s.get('length'))) for s in root.findall('training_set/sequence')}
  expected={r['member_id'] for r in rows if r['family']==fam}
  assert {n for n,l in names.values()}==expected
  assert all(len(byname[n]['full_sequence'])==l for n,l in names.values())
  assert root.get('version')=='5.5.9'
  assert root.findtext('model/nmotifs')=='5' and root.findtext('model/type')=='zoops'
  assert root.findtext('model/min_width')=='6' and root.findtext('model/max_width')=='50'
  motifs={x.get('id'):x for x in root.findall('motifs/motif')};assert len(motifs)==5
  threshold=float(root.find('scanned_sites_summary').get('p_thresh'));famchecks=0
  for mid,m in motifs.items():
   rank=int(mid.rsplit('_',1)[1]);width=int(m.get('width'))
   defs.append({'family':fam,'family_motif_key':fam+':'+mid,'motif_rank':rank,'motif_id':mid,'consensus':m.get('name'),'width_aa':width,'training_sites':int(m.get('sites')),'motif_Evalue':m.get('e_value'),'motif_pvalue':m.get('p_value'),'information_content':m.get('ic'),'XML_source':str(p.relative_to(O)),'XML_SHA256':hashlib.sha256(p.read_bytes()).hexdigest()})
   for pos,aa in enumerate(m.findall('probabilities/alphabet_matrix/alphabet_array'),1):
    for v in aa.findall('value'):pwm.append({'family':fam,'motif_id':mid,'position_1based':pos,'amino_acid':v.get('letter_id'),'probability':float(v.text)})
   for c in m.findall('contributing_sites/contributing_site'):
    n,l=names[c.get('sequence_id')];pos=int(c.get('position'));s=''.join(z.get('letter_id') for z in c.findall('site/letter_ref'))
    assert s==byname[n]['full_sequence'][pos:pos+width],(fam,n,mid,pos,s)
    famchecks+=1;contrib.append({'family':fam,'member_id':n,'motif_id':mid,'start_1based':pos+1,'end_1based':pos+width,'XML_position_0based':pos,'matched_sequence':s,'site_pvalue':c.get('pvalue')})
  for sn in root.findall('scanned_sites_summary/scanned_sites'):
   n,l=names[sn.get('sequence_id')]
   for s in sn.findall('scanned_site'):
    mid=s.get('motif_id');pos=int(s.get('position'));width=int(motifs[mid].get('width'));pv=float(s.get('pvalue'))
    assert 0<=pos<pos+width<=l and pv<=threshold
    hits.append({'family':fam,'member_id':n,'motif_id':mid,'family_motif_key':fam+':'+mid,'motif_rank':int(mid.rsplit('_',1)[1]),'start_1based':pos+1,'end_1based':pos+width,'XML_position_0based':pos,'width_aa':width,'site_pvalue':s.get('pvalue'),'scan_reporting_threshold':threshold,'protein_length_aa':l,'matched_sequence':byname[n]['full_sequence'][pos:pos+width]})
  for n in sorted(expected,key=lambda n:int(re.search(r'\d+$',n)[0])):
   hh=[h for h in hits if h['member_id']==n]
   seqtable.append({'family':fam,'member_id':n,'protein_length_aa':len(byname[n]['full_sequence']),'protein_sha256':byname[n]['protein_sha256'],'motif_scan_sites':len(hh),'motif_ranks_present':';'.join(str(v) for v in sorted({x['motif_rank'] for x in hh})),'represented_in_XML_training_set':True,'drawn_in_Figure4':True})
  qa[fam]={'input_sequences':len(names),'motifs_found':len(motifs),'contributing_site_sequence_coordinate_checks':famchecks,'scan_sites':sum(h['family']==fam for h in hits),'scan_threshold':threshold,'reason_for_stopping':root.findtext('model/reason_for_stopping'),'old_XML_not_reused':True}
 assert len(seqtable)==73
 for fn,rr in [('Figure4_motif_definitions.tsv',defs),('Figure4_motif_scan_sites_primary73.tsv',hits),('Figure4_motif_contributing_sites.tsv',contrib),('Figure4_sequence_coverage_primary73.tsv',seqtable),('Figure4_motif_probability_matrices.tsv',pwm)]:w(O/fn,rr)
 return defs,hits,seqtable,qa

def draw_motifs():
 defs,hits,seqtable,qa=motif_data();palette=list(plt.cm.tab10.colors[:5])
 ns=[sum(r['family']==f for r in rows) for f in FAMS]
 fig,axes=plt.subplots(3,1,figsize=(7.6,13.8),gridspec_kw={'height_ratios':ns,'hspace':.36},dpi=120)
 fig.subplots_adjust(left=.15,right=.97,bottom=.06,top=.92)
 checked=[]
 for ax,fam,letter in zip(axes,FAMS,'ABC'):
  rr=[r for r in rows if r['family']==fam];nn={r['member_id']:i for i,r in enumerate(rr)}
  for r in rr:
   y=nn[r['member_id']];length=len(r['full_sequence'])
   ax.plot([.5,length+.5],[y,y],lw=.55,color='#C0C8CE',zorder=1)
   for h in [x for x in hits if x['member_id']==r['member_id']]:
    rect=Rectangle((h['start_1based']-.5,y-.28),h['width_aa'],.56,facecolor=palette[h['motif_rank']-1],edgecolor='none',zorder=3)
    rect.set_gid('motif-'+fam+'-'+r['member_id']+'-'+h['motif_id']+'-'+str(h['start_1based']));ax.add_patch(rect)
  ax.set_yticks(range(len(rr)));ax.set_yticklabels([r['member_id'] for r in rr],fontsize=7.2,fontstyle='italic')
  checked.extend([(r['member_id'],a) for r,a in zip(rr,ax.get_yticklabels())])
  ax.set_ylim(len(rr)-.4,-.75);ax.set_xlim(0,max(len(r['full_sequence']) for r in rr)*1.025)
  ax.set_xlabel('Precursor position (aa)',fontsize=8,labelpad=5);ax.tick_params(axis='y',length=0,pad=5);ax.tick_params(axis='x',labelsize=7)
  ax.spines[['top','right','left']].set_visible(False);ax.spines['bottom'].set_color('#A1ADB6')
  ax.set_title(f'{letter}   {LABEL[fam]} (n = {len(rr)})',loc='left',color=COL[fam],fontsize=10,pad=10,weight='bold')
 fig.text(.15,.975,'De novo MEME motifs in 73 primary-catalogue proteins',fontsize=12,weight='medium',ha='left')
 fig.legend(handles=[Patch(facecolor=palette[i],label=f'Motif {i+1}') for i in range(5)],loc='upper left',bbox_to_anchor=(.141,.962),ncol=5,frameon=False,fontsize=8,handlelength=1.8,columnspacing=1.3)
 fig.text(.15,.019,'Motifs were learned separately within each family; the same rank or colour does not imply homology between families.',fontsize=6.8,color='#657480',ha='left')
 textqa=canvas_qa(fig,checked,'Figure4')
 save(fig,'Figure4_primary73_conserved_motifs');plt.close(fig)
 qa.update({'total_sequences':len(seqtable),'members_without_reported_scan_sites':[x['member_id'] for x in seqtable if x['motif_scan_sites']==0],'all_sequences_shown_even_without_scan_sites':True,'text_QA':textqa,'motif_numbering':'family_specific_rank; not cross-family homology','plot_positions':'one-based residue-centred blocks; exported XML positions also retained','matplotlib':matplotlib.__version__})
 (D/'Figure4_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8');return qa

if __name__=='__main__':
 q3=draw_structure();q4=draw_motifs()
 print(json.dumps({'Figure3':q3,'Figure4':q4},indent=2))
