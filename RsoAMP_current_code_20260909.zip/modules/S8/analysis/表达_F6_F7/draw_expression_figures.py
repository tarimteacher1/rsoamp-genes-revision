"""Replot audited expression; no inference/model/BH recomputation is performed."""
from pathlib import Path
import csv, json, math, hashlib, xml.etree.ElementTree as ET
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.colors import ListedColormap

OUT = Path(__file__).resolve().parent
TABLES, FIG, QA = OUT/'tables', OUT/'figures', OUT/'qa'
COLORS={'Defensin':'#C43D3D','Snakin_GASA':'#2E6F9E','nsLTP':'#2F7D4A'}
NAMES={'Defensin':'Defensin','Snakin_GASA':'Snakin/GASA','nsLTP':'nsLTP'}
FLAG='DE_call_FDR_lt_0.05_abs_log2FC_gt_1'
SAMPLES=['SRR27540881','SRR27540880','SRR27540879','SRR27540878','SRR27540877','SRR27540876','SRR27540875','SRR27540884','SRR27540883']
CONTRASTS=['S200_vs_CK','S400_vs_CK']
POSITIONS={
 'S200_vs_CK':{
  'RsSNA10':(.60,11.4),'RsLTP12':(1.88,9.6),'RsLTP3':(.70,7.6),
  'RsDEF9':(-1.10,5.8),'RsLTP17':(.45,4.1),'RsDEF13':(2.00,3.2),
  'RsSNA17':(-1.87,3.6),'RsLTP2':(2.03,5.3)},
 'S400_vs_CK':{
  'RsDEF11':(2.95,39.1),'RsLTP12':(4.10,28.3),'RsLTP3':(2.20,22.7),
  'RsDEF13':(5.25,22.9),'RsSNA10':(1.15,17.4),'RsLTP36':(-3.35,17.3),
  'RsLTP35':(.70,14.0),'RsDEF14':(4.75,12.8),'RsLTP17':(3.70,10.5),
  'RsLTP16':(3.75,7.4),'RsSNA16':(-2.10,9.2),'RsSNA15':(0,7.0),
  'RsSNA17':(-3.60,7.3),'RsLTP22':(-2.85,4.0),'RsLTP24':(2.45,4.25),
  'RsLTP39':(2.80,1.15),'RsDEF9':(-2.95,1.55),'RsLTP2':(1.4,26.3)}
}

def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
def finite(v):
 try:return math.isfinite(float(v))
 except (TypeError,ValueError):return False
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def saves(fig,stem):
 for ext in ['pdf','svg']:fig.savefig(FIG/(stem+'.'+ext))
 fig.savefig(FIG/(stem+'.png'),dpi=600)
 fig.savefig(FIG/(stem+'_preview.png'),dpi=150)

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.5,'axes.titlesize':13,
 'axes.labelsize':11,'xtick.labelsize':10,'ytick.labelsize':10,'axes.linewidth':.8,
 'svg.fonttype':'none','pdf.fonttype':42,'savefig.dpi':600})
source_hashes={p.name:sha(p) for p in [TABLES/'AMP_VST_73.tsv',TABLES/'S14_AMP_DE_73x3.tsv']}

# Figure 6: preserve the original family/catalogue ordering and row-wise VST z score.
vst=read(TABLES/'AMP_VST_73.tsv')
vst=[r for r in vst if all(finite(r[s]) for s in SAMPLES)]
assert len(vst)==52
mat=np.array([[float(r[s]) for s in SAMPLES] for r in vst])
sd=mat.std(axis=1,ddof=0);zero_sd=(sd==0);sd[zero_sd]=1
z=(mat-mat.mean(axis=1,keepdims=True))/sd[:,None]
assert np.max(np.abs(z.mean(axis=1)))<1e-12
lim=math.ceil(float(np.max(np.abs(z)))*2)/2
fig=plt.figure(figsize=(7.6,11.7))
ax=fig.add_axes([.22,.105,.58,.75]);strip=fig.add_axes([.105,.105,.018,.75])
cbax=fig.add_axes([.84,.64,.022,.18])
heat=ax.pcolormesh(np.arange(10),np.arange(53),z,cmap='RdBu_r',vmin=-lim,vmax=lim,rasterized=False)
ax.set_xlim(0,9);ax.set_ylim(52,0)
ax.set_yticks(np.arange(52)+.5,labels=[r['member_id'] for r in vst],fontsize=8.5)
ax.set_xticks(np.arange(9)+.5,labels=['Rep. 1','Rep. 2','Rep. 3']*3,rotation=90,fontsize=9)
ax.tick_params(axis='both',length=0,pad=5)
for s in ax.spines.values():s.set_visible(False)
for col in [3,6]:ax.axvline(col,color='white',lw=1.6)
fams=list(COLORS);indices=np.array([fams.index(r['family']) for r in vst])
strip.imshow(indices[:,None],aspect='auto',cmap=ListedColormap(list(COLORS.values())),vmin=0,vmax=2,origin='upper',extent=[0,1,52,0])
strip.set_axis_off()
for i in range(1,52):
 if vst[i]['family']!=vst[i-1]['family']:ax.axhline(i,color='white',lw=1.5);strip.axhline(i,color='white',lw=1.5)
for x,label,col in [(1.5,'CK','#63768D'),(4.5,'200 mM','#C49A47'),(7.5,'400 mM','#8B647C')]:
 ax.text(x,1.026,label,transform=ax.get_xaxis_transform(),ha='center',va='bottom',fontsize=11,fontweight='bold',color=col)
 ax.plot([x-1.4,x+1.4],[1.011,1.011],transform=ax.get_xaxis_transform(),lw=4,color=col,clip_on=False)
cbar=fig.colorbar(heat,cax=cbax);cbar.set_label('Row-wise VST z score',fontsize=10,labelpad=7)
cbar.ax.tick_params(labelsize=9)
fig.suptitle('Expression profiles of reference-covered AMP genes',y=.979,fontsize=14)
fig.text(.5,.95,'52 count-filtered members across nine RNA-seq libraries',ha='center',fontsize=11,color='#444444')
fig.legend(handles=[Patch(color=c,label=NAMES[f]) for f,c in COLORS.items()],loc='upper center',bbox_to_anchor=(.50,.925),ncol=3,frameon=False,fontsize=10)
fig.text(.5,.036,'73 primary members: 66 in the original reference, including 52 passing the count filter.\nSeven new models were not quantified; no missing values were imputed.',ha='center',va='center',fontsize=9,color='#444444',linespacing=1.6)
fig.canvas.draw()
assert not any(t.get_window_extent(fig.canvas.get_renderer()).overlaps(strip.bbox) for t in ax.get_yticklabels())
saves(fig,'Figure6_expression_heatmap_52')
plt.close(fig)
write(TABLES/'Figure6_VST_row_zscore_52.tsv',[{'member_id':r['member_id'],'family':r['family'],**{s:format(z[i,j],'.16g') for j,s in enumerate(SAMPLES)}} for i,r in enumerate(vst)])
heatqa={'rows':52,'samples':SAMPLES,'row_order':[r['member_id'] for r in vst],'normalization':'z score of frozen-model VST per row; population SD (ddof=0)','family_counts':{f:sum(r['family']==f for r in vst) for f in fams},'max_abs_z_score':float(abs(z).max()),'symmetric_color_limits':[-lim,lim],'color_clipped_values':int(np.sum(abs(z)>lim)),'zero_variance_rows':int(sum(zero_sd)),'clustering':'none; preserved catalogue/family order','imputed_missing_values':0}

# Figure 7: original MLE display, BH threshold, and leader-line labeling style.
rows=read(TABLES/'S14_AMP_DE_73x3.tsv')
fig,axes=plt.subplots(1,2,figsize=(12.2,7.7),sharey=True)
fig.subplots_adjust(left=.075,right=.982,bottom=.17,top=.82,wspace=.21)
fig.suptitle('Differential expression among reference-covered AMP genes',y=.979,fontsize=15)
handles=[Line2D([],[],marker='o',linestyle='None',color=c,label=NAMES[f],markersize=7) for f,c in COLORS.items()]
handles.append(Line2D([],[],marker='o',linestyle='None',color='#BBBBBB',label='Does not meet both DE cutoffs',markersize=6))
fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.54,.937),ncol=4,frameon=False,fontsize=10.5,columnspacing=1.6)
fig.text(.53,.070,'BH-adjusted P < 0.05 and |log2 fold change (MLE)| > 1; all DE genes are labeled.',ha='center',fontsize=10,color='#444444')
fig.text(.53,.027,'66 reference-covered members out of 73 primary members; 52 passed the count filter.\nMembers lacking finite statistics are omitted from the scatter plots, with reasons retained in Table S14.',ha='center',fontsize=9,color='#444444',linespacing=1.5)
report={'source_sha256':source_hashes,'matplotlib_version':matplotlib.__version__,'x_field':'log2FoldChange (unshrunken MLE)','y_field':'-log10(padj_BH)','no_axis_break_or_coordinate_truncation':True,'label_policy':'all DE genes with individual leader lines','panels':{},'all_point_tooltips':[]}
audited=[];anns=[];points=[]
for axis,contrast,letter in zip(axes,CONTRASTS,'AB'):
 group=[r for r in rows if r['contrast']==contrast]
 selected=[r for r in group if finite(r['log2FoldChange']) and finite(r['padj_BH'])]
 de=[r for r in selected if r[FLAG].upper()=='TRUE']
 assert set(POSITIONS[contrast])=={r['member_id'] for r in de}
 up=sum(float(r['log2FoldChange'])>0 for r in de);down=len(de)-up
 axis.set_xlim((-2.65,2.65) if contrast==CONTRASTS[0] else (-4.6,6.3))
 axis.set_ylim(-1.3,41.6);axis.set_yticks(range(0,41,5))
 axis.set_xticks([-2,-1,0,1,2] if contrast==CONTRASTS[0] else [-4,-2,0,2,4,6])
 axis.axhline(-math.log10(.05),ls='--',lw=.7,color='#888888',zorder=1)
 for threshold in [-1,1]:axis.axvline(threshold,ls='--',lw=.7,color='#888888',zorder=1)
 axis.set_xlabel('log2 fold change (MLE)',labelpad=8)
 axis.set_title(f'({letter}) {contrast.replace("_vs_"," vs ")}  |  {len(de)} DE: {up} up, {down} down',loc='left',pad=12,fontweight='bold',fontsize=12)
 axis.spines[['top','right']].set_visible(False);axis.tick_params(direction='out')
 for row in sorted(selected,key=lambda r:r[FLAG].upper()=='TRUE'):
  x=float(row['log2FoldChange']);p=float(row['padj_BH']);y=-math.log10(max(p,1e-300));sig=row[FLAG].upper()=='TRUE'
  assert sig==(p<.05 and abs(x)>1)
  assert axis.get_xlim()[0]<x<axis.get_xlim()[1] and axis.get_ylim()[0]<y<axis.get_ylim()[1]
  gid=f'point_{contrast}_{row["member_id"]}'
  point=axis.scatter([x],[y],s=42 if sig else 21,c=COLORS[row['family']] if sig else '#BFBFBF',alpha=.98 if sig else .62,edgecolors='white' if sig else 'none',linewidths=.45 if sig else 0,zorder=4 if sig else 2)
  point.set_gid(gid)
  tooltip=f'{row["member_id"]} | {NAMES[row["family"]]} | {contrast} | MLE log2FC={x:.6g} | BH-adjusted P={p:.6g} | {row["DE_direction"]}'
  report['all_point_tooltips'].append({'gid':gid,'tooltip':tooltip})
  audited.append({'contrast':contrast,'member_id':row['member_id'],'family':row['family'],'x_MLE':row['log2FoldChange'],'padj_BH':row['padj_BH'],'y_minus_log10_padj':format(y,'.16g'),'DE':sig,'DE_direction':row['DE_direction'],'text_label':sig,'leader_line':sig,'label_x':POSITIONS[contrast].get(row['member_id'],('',''))[0],'label_y':POSITIONS[contrast].get(row['member_id'],('',''))[1]})
  points.append((axis,row['member_id'],x,y))
 for row in de:
  x=float(row['log2FoldChange']);y=-math.log10(max(float(row['padj_BH']),1e-300))
  ann=axis.annotate(row['member_id'],xy=(x,y),xytext=POSITIONS[contrast][row['member_id']],textcoords='data',ha='center',va='center',fontsize=10.5,color='#202020',zorder=6,bbox={'boxstyle':'square,pad=0.10','facecolor':'white','edgecolor':'none','alpha':.96},arrowprops={'arrowstyle':'-','color':'#686868','lw':.7,'shrinkA':2,'shrinkB':3,'connectionstyle':'arc3,rad=0'},annotation_clip=False)
  ann.set_gid(f'label_{contrast}_{row["member_id"]}');anns.append((axis,contrast,row['member_id'],ann))
 report['panels'][contrast]={'catalogue_rows':len(group),'plotted':len(selected),'DE':len(de),'labels':len(de),'leader_lines':len(de),'up':up,'down':down,'omitted':[{'member_id':r['member_id'],'reason':r['DE_test_status']} for r in group if r not in selected]}
axes[0].set_ylabel('−log10(BH-adjusted P)',labelpad=10)
fig.canvas.draw();renderer=fig.canvas.get_renderer();boxes=[]
for axis,contrast,name,ann in anns:
 box=ann._get_layout(renderer)[0].translated(*ann.get_transform().transform(ann.get_position()))
 boxes.append((axis,contrast,name,box))
overlap=[];outside=[];point_overlap=[]
for i,(axis,contrast,name,box) in enumerate(boxes):
 if not axis.bbox.contains(box.x0,box.y0) or not axis.bbox.contains(box.x1,box.y1):outside.append([contrast,name])
 for a2,c2,n2,b2 in boxes[i+1:]:
  if axis is a2 and box.overlaps(b2):overlap.append([contrast,name,n2])
 for a2,n2,x,y in points:
  if axis is a2 and box.padded(2).contains(*axis.transData.transform((x,y))):point_overlap.append([contrast,name,n2])
leader_lengths=[]
for axis,contrast,name,ann in anns:
 vertices=ann.arrow_patch.get_path().transformed(ann.arrow_patch.get_transform()).vertices
 leader_lengths.append({'contrast':contrast,'member_id':name,'length_figure_dpi_px':round(sum(math.hypot(*(b-a)) for a,b in zip(vertices,vertices[1:])),2)})
report['layout_checks']={'overlapping_label_pairs':overlap,'labels_outside_axes':outside,'labels_over_points':point_overlap,'leader_lengths':leader_lengths}
saves(fig,'Figure7_expression_volcano_all_DE_labeled_66');plt.close(fig)

# Retain full native SVG point tooltips (including gray points).
NS='http://www.w3.org/2000/svg';ET.register_namespace('',NS);ET.register_namespace('xlink','http://www.w3.org/1999/xlink')
svgpath=FIG/'Figure7_expression_volcano_all_DE_labeled_66.svg'
tree=ET.parse(svgpath);elements={e.get('id'):e for e in tree.iter() if e.get('id')}
for item in report['all_point_tooltips']:
 title=ET.Element(f'{{{NS}}}title');title.text=item['tooltip'];elements[item['gid']].insert(0,title)
tree.write(svgpath,encoding='utf-8',xml_declaration=True)
write(TABLES/'Figure7_plotted_points_and_labels.tsv',audited)

# Supplementary visualization sensitivity: shrinkage affects display, not original DE calls.
fig,axes=plt.subplots(1,2,figsize=(12.2,7.1),sharey=True)
fig.subplots_adjust(left=.075,right=.98,bottom=.17,top=.83,wspace=.21)
fig.suptitle('apeglm display sensitivity for the original DE calls',y=.98,fontsize=15)
fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.54,.935),ncol=4,frameon=False,fontsize=10)
sensitivity=[];sensitivity_annotations=[];sensitivity_points=[]
for axis,contrast in zip(axes,CONTRASTS):
 selected=[r for r in rows if r['contrast']==contrast and finite(r['log2FC_apeglm']) and finite(r['padj_BH'])]
 for r in selected:
  sig=r[FLAG].upper()=='TRUE';x=float(r['log2FC_apeglm']);y=-math.log10(max(float(r['padj_BH']),1e-300))
  axis.scatter(x,y,s=40 if sig else 20,c=COLORS[r['family']] if sig else '#BFBFBF',alpha=.9 if sig else .6,edgecolors='white' if sig else 'none',linewidths=.4,zorder=4 if sig else 2)
  sensitivity_points.append((axis,r['member_id'],x,y))
  if sig:
   pos=POSITIONS[contrast][r['member_id']]
   if contrast=='S200_vs_CK' and r['member_id']=='RsSNA17':pos=(-1.93,1.0)
   if contrast=='S400_vs_CK' and r['member_id']=='RsLTP17':pos=(3.35,10.5)
   ann=axis.annotate(r['member_id'],(x,y),xytext=pos,ha='center',va='center',fontsize=9.5,bbox={'facecolor':'white','edgecolor':'none','pad':.7},arrowprops={'arrowstyle':'-','color':'#777777','lw':.6,'shrinkB':3})
   sensitivity_annotations.append((axis,contrast,r['member_id'],ann))
  sensitivity.append({'contrast':contrast,'member_id':r['member_id'],'x_apeglm':r['log2FC_apeglm'],'x_MLE_for_DE_call':r['log2FoldChange'],'padj_BH':r['padj_BH'],'DE_call_original_MLE_cutoffs':sig})
 axis.axhline(-math.log10(.05),ls='--',lw=.7,color='#888888')
 axis.axvline(0,lw=.5,color='#BBBBBB')
 axis.set_xlim((-2.65,2.65) if contrast==CONTRASTS[0] else (-4.6,6.3));axis.set_ylim(-1.3,41.6)
 axis.set_xlabel('log2 fold change (apeglm-shrunken)');axis.set_title(contrast.replace('_vs_',' vs '),loc='left',fontweight='bold')
 axis.spines[['top','right']].set_visible(False)
axes[0].set_ylabel('−log10(BH-adjusted P)')
fig.text(.53,.055,'Colors and labels use the unchanged original BH-adjusted P and MLE fold-change criteria.\nNo |shrunken log2FC| cutoff is applied; this is a display sensitivity figure, not a new DE analysis.',ha='center',fontsize=10,linespacing=1.6)
fig.canvas.draw();renderer=fig.canvas.get_renderer();sboxes=[]
for axis,contrast,name,ann in sensitivity_annotations:
 box=ann._get_layout(renderer)[0].translated(*ann.get_transform().transform(ann.get_position()))
 sboxes.append((axis,contrast,name,box))
slabel_overlap=[];spoint_overlap=[];soutside=[]
for i,(axis,contrast,name,box) in enumerate(sboxes):
 if not axis.bbox.contains(box.x0,box.y0) or not axis.bbox.contains(box.x1,box.y1):soutside.append([contrast,name])
 for a2,c2,n2,b2 in sboxes[i+1:]:
  if axis is a2 and box.overlaps(b2):slabel_overlap.append([contrast,name,n2])
 for a2,n2,x,y in sensitivity_points:
  if axis is a2 and box.padded(2).contains(*axis.transData.transform((x,y))):spoint_overlap.append([contrast,name,n2])
report['apeglm_display_layout_checks']={'overlapping_label_pairs':slabel_overlap,'labels_over_points':spoint_overlap,'labels_outside_axes':soutside}
saves(fig,'Figure7_apeglm_display_sensitivity');plt.close(fig)
write(TABLES/'Figure7_apeglm_display_sensitivity.tsv',sensitivity)

assert all(sha(TABLES/name)==hashvalue for name,hashvalue in source_hashes.items())
(QA/'figure6_verification.json').write_text(json.dumps(heatqa,indent=2),encoding='utf-8')
(QA/'figure7_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
assert not overlap and not outside and not point_overlap,report['layout_checks']
assert not slabel_overlap and not spoint_overlap and not soutside,report['apeglm_display_layout_checks']
assert min(r['length_figure_dpi_px'] for r in leader_lengths)>3
print(json.dumps({'Figure6':heatqa,'Figure7_panels':report['panels'],'layout_checks':report['layout_checks']},indent=2))
