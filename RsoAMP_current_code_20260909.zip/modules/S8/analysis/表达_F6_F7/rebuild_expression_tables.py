from pathlib import Path
import csv,math,json,hashlib,subprocess,sys,collections,statistics,shutil,re
import openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;T=O/'tables';Q=O/'qa';S=O/'sources'
B=R/'Genes_lab_handoff_20260908/02_Workspace/9_2_major_revision';E=B/'revision_R1_20260902/06_expression_reanalysis';P=B/'Genes_expression_status_fix_20260904/04_Expression_Audit'
def read(p,d='\t'):return list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter=d))
def write(p,rows):
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
def finite(v):
    try:return math.isfinite(float(v))
    except:return False
def true(v):return str(v).upper() in ['TRUE','T','1','YES']
CAT=R/'成员判定收尾_20260909/统一目录/统一成员目录_主分析111.tsv'
cat=[r for r in read(CAT) if r['species']=='rso'];assert len(cat)==73
oldcat={r['protein_id']:r for r in read(B/'revision_R1_20260902/03_annotation_rescue/final_amp_primary_catalogue.tsv')}
tx={r['TXNAME']:r['GENEID'] for r in read(E/'transcript_to_gene.tsv')}
audit={r['gene_id']:r for r in read(P/'all_gene_prefilter_audit.tsv')};raw={r['gene_id']:r for r in read(P/'all_gene_prefilter_counts.tsv')}
allDE=read(E/'results/all_gene_DE_results.csv',',');de={(r['gene_id'],r['contrast']):r for r in allDE};assert len(de)==len(allDE)
matrices={name:{r['gene_id']:r for r in read(E/f'results/{fname}.csv',',')} for name,fname in [('TPM','gene_TPM'),('normalized_counts','gene_normalized_counts'),('VST','gene_VST')]}
samples=read(E/'rnaseq_sample_sheet.tsv');runs=[r['run'] for r in samples];contrasts=['S200_vs_CK','S400_vs_CK','S400_vs_S200']
live=json.loads((S/'live_expression_and_mappability.json').read_text())
maps={r['member_id']:r for r in live['mappability']};assert len(maps)==66
members=[]
for r in cat:
    present=r['protein_id'] in tx
    if present:assert tx[r['protein_id']]==r['original_gene_parent'] and r['original_gene_parent'] in audit
    else:assert r['source_branch']=='M6_new_supported_locus'
    old=oldcat.get(r['protein_id'],{})
    members.append(dict(member_id=r['member_id'],family=r['family'],protein_id=r['protein_id'],gene_id=r['original_gene_parent'],source_model_id=r['source_model_id'],source_candidate_id=r['source_candidate_id'],final_subclass=old.get('final_subclass','computational_nsLTP_candidate' if r['family']=='nsLTP' else 'computational_defensin_candidate'),final_subtype=r['gpi_evidence_category'] if r['family']=='nsLTP' else old.get('final_subtype',''),classification_confidence=old.get('classification_confidence','COMPUTATIONAL_RULE_SUPPORTED'),quantification_status='QUANTIFIED_IN_FROZEN_SALMON_REFERENCE' if present else 'NOT_IN_REFERENCE',reference_present=present,old63_member=r['protein_id'] in oldcat))
assert sum(r['reference_present'] for r in members)==66
write(T/'expression_catalogue_73.tsv',members);write(T/'expression_catalogue_66.tsv',[r for r in members if r['reference_present']])
maprows=[]
for m in members:
    mp=maps.get(m['member_id'])
    if mp:row=dict(mp)
    else:row={k:'' for k in next(iter(maps.values()))};row.update(member_id=m['member_id'],protein_id=m['protein_id'],gene_id=m['gene_id'],family=m['family'],transcript_id=m['source_model_id'],mappability_risk='NOT_ASSESSED_NOT_IN_REFERENCE',interpretation='New M6 model absent from the frozen Salmon target set; no assignment metrics or comparable transcriptome-wide screen available')
    maprows.append(row)
write(T/'S23_Mappability_73.tsv',maprows)
write(T/'mappability_66.tsv',list(maps.values()))
write(T/'Salmon_ambiguity_66_by_9_libraries.tsv',live['ambiguity_details'])
oldmp={r['member_id']:r for r in read(E/'results/key_gene_mappability.tsv')}
mapchanges=[]
for mid,mp in maps.items():
    if mid in oldmp:
        old=oldmp[mid]
        if mp['mappability_risk']!=old['mappability_risk'] or mp['near_identical_nonself_hits_95pct_80pct_coverage']!=int(old['near_identical_nonself_hits_95pct_80pct_coverage']):mapchanges.append(dict(member_id=mid,old_risk=old['mappability_risk'],new_risk=mp['mappability_risk'],old_near_hits=old['near_identical_nonself_hits_95pct_80pct_coverage'],new_near_hits=mp['near_identical_nonself_hits_95pct_80pct_coverage']))
(Q/'mappability_original63_comparison.json').write_text(json.dumps({'changed_risk_or_near_hit_counts':mapchanges,'coverage_definition':'Coordinate span / full query length; legacy HSP alignment-length counts retained in audit column'},indent=2))
pref=[];DE=[];eligibility=[]
for m in members:
    gid=m['gene_id'];present=m['reference_present'];a=audit.get(gid,{}) if present else {};retained=true(a.get('retained_for_DE',False))
    row={**{k:m[k] for k in ['member_id','family','gene_id','protein_id','quantification_status']},**{k:a.get(k,'') for k in next(iter(audit.values())) if k!='gene_id'}}
    row['prefilter_status']=a['prefilter_status'] if present else 'NOT_APPLICABLE_NOT_IN_REFERENCE'
    row['retained_for_DE']=retained if present else 'NA';pref.append(row)
    er={k:m[k] for k in ['member_id','family','gene_id','protein_id','source_model_id','source_candidate_id','old63_member','quantification_status']}
    er.update(reference_present=present,present_in_quant_sf_libraries=len(live['quant_sf_presence'].get(m['protein_id'],[])),prefilter_status=row['prefilter_status'],retained_for_DE=retained if present else 'NA',TPM_available=present,normalized_counts_available=retained,VST_available=retained,Figure6_included=retained,mappability_risk=maps[m['member_id']]['mappability_risk'] if present else 'NOT_ASSESSED_NOT_IN_REFERENCE')
    for contrast in contrasts:
        result=de.get((gid,contrast)) if present else None
        assert retained==bool(result)
        if not present:status='NOT_TESTED_NOT_IN_REFERENCE'
        elif not retained:status='NOT_TESTED_ALL_ZERO_COUNTS' if a['prefilter_status']=='FILTERED_ALL_ZERO_COUNTS' else 'NOT_TESTED_LOW_TOTAL_COUNT'
        elif not finite(result['pvalue']):status='P_VALUE_UNAVAILABLE'
        elif not finite(result['padj']):status='INDEPENDENTLY_FILTERED_PADJ_UNAVAILABLE'
        else:status='TESTED_WITH_ADJUSTED_P'
        sig=true(result['DE_call']) if result and status=='TESTED_WITH_ADJUSTED_P' else None
        if sig is not None:assert sig==(float(result['padj'])<.05 and abs(float(result['log2FoldChange']))>1)
        direction='UP' if sig and float(result['log2FoldChange'])>0 else 'DOWN' if sig else 'DOES_NOT_MEET_BOTH_CUTOFFS' if sig is False else 'NOT_EVALUABLE'
        dr={k:m[k] for k in ['member_id','family','final_subclass','final_subtype','gene_id','protein_id','quantification_status']}
        dr.update(contrast=contrast,prefilter_status=row['prefilter_status'],DE_test_status=status,**{k:result[k] if result else '' for k in ['baseMean','log2FoldChange','log2FC_apeglm','lfcSE','stat','pvalue']},padj_BH=result['padj'] if result else '',DE_call_FDR_lt_0_05_abs_log2FC_gt_1='TRUE' if sig else 'FALSE' if sig is False else 'NA',DE_direction=direction)
        # Preserve the original supplementary column spelling for safe replacement.
        dr['DE_call_FDR_lt_0.05_abs_log2FC_gt_1']=dr.pop('DE_call_FDR_lt_0_05_abs_log2FC_gt_1');DE.append(dr)
        er[contrast+'_DE_test_status']=status;er[contrast+'_DE_direction']=direction
        er[contrast+'_plottable']=bool(result and finite(result['log2FoldChange']) and finite(result['padj']))
    eligibility.append(er)
write(T/'S26_ExpressionFilter_73.tsv',pref);write(T/'expression_eligibility_73.tsv',eligibility);write(T/'S14_AMP_DE_73x3.tsv',DE)
normtables={}
for name,matrix in matrices.items():
    out=[]
    for m in members:
        gid=m['gene_id'];present=m['reference_present'];a=audit.get(gid,{}) if present else {};v=matrix.get(gid,{}) if present else {};expected=present if name=='TPM' else true(a.get('retained_for_DE',False))
        assert bool(v)==expected
        row={k:m[k] for k in ['member_id','family','final_subclass','gene_id','quantification_status']}
        row.update(prefilter_status=a.get('prefilter_status','NOT_APPLICABLE_NOT_IN_REFERENCE'),matrix_status='AVAILABLE' if v else 'NOT_AVAILABLE_PREFILTERED' if present else 'NOT_IN_REFERENCE',**{run:v.get(run,'') for run in runs});out.append(row)
    normtables[name]=out
    write(T/({'TPM':'S12_AMP_TPM_73.tsv','normalized_counts':'S13_AMP_NormCounts_73.tsv','VST':'AMP_VST_73.tsv'}[name]),out)
write(T/'AMP_rounded_counts_73.tsv',[{**{k:m[k] for k in ['member_id','gene_id','protein_id','quantification_status']},**{run:raw.get(m['gene_id'],{}).get(run,'') for run in runs}} for m in members])
summary=[]
for c in contrasts:
    for fam in ['ALL','Defensin','Snakin_GASA','nsLTP']:
        rr=[r for r in DE if r['contrast']==c and (fam=='ALL' or r['family']==fam)];sig=[r for r in rr if true(r['DE_call_FDR_lt_0.05_abs_log2FC_gt_1'])]
        summary.append(dict(contrast=c,family=fam,primary_catalogue_members=len(rr),quantified_members=sum(r['quantification_status']!='NOT_IN_REFERENCE' for r in rr),not_in_reference_members=sum(r['quantification_status']=='NOT_IN_REFERENCE' for r in rr),retained_for_DE_members=sum(r['prefilter_status']=='RETAINED_TOTAL_COUNT_GE_10' for r in rr),filtered_all_zero_members=sum(r['prefilter_status']=='FILTERED_ALL_ZERO_COUNTS' for r in rr),filtered_low_total_count_members=sum(r['prefilter_status']=='FILTERED_TOTAL_COUNT_LT_10' for r in rr),members_with_adjusted_P=sum(r['DE_test_status']=='TESTED_WITH_ADJUSTED_P' for r in rr),DE_members=len(sig),upregulated=sum(r['DE_direction']=='UP' for r in sig),downregulated=sum(r['DE_direction']=='DOWN' for r in sig),threshold='BH-adjusted P < 0.05 and abs(unshrunken MLE log2FC) > 1; original full-gene model and BH results retained'))
write(T/'S15_DE_Summary.tsv',summary)
priority=sorted([dict(r,candidate_evidence_label='salt-responsive transcriptome-supported candidate',functional_validation_status='NO_FUNCTIONAL_TEST_IN_THIS_ANALYSIS') for r in DE if r['contrast']=='S400_vs_CK' and r['DE_direction'] in ['UP','DOWN']],key=lambda r:(float(r['padj_BH']),-abs(float(r['log2FoldChange']))))
write(T/'S400_candidate_priority_18.tsv',priority)
# Reuse the original family-balanced candidate ranking and all-gene reference-gene screen.
write(T/'_candidate_DE_66.tsv',[dict(r,quantification_status='QUANTIFIED') for r in DE if r['quantification_status']!='NOT_IN_REFERENCE'])
write(T/'_candidate_TPM_66.tsv',[r for r in normtables['TPM'] if r['quantification_status']!='NOT_IN_REFERENCE'])
transcripts=S/'cohort66_transcripts.fasta';transcripts.write_text(''.join('>'+pid+'\n'+seq+'\n' for pid,seq in live['selected_transcripts'].items()),encoding='utf-8')
packet=O/'candidate_packet';packet.mkdir(exist_ok=True)
cmd=[sys.executable,str(E/'build_qpcr_candidate_packet.py'),'--catalogue',str(T/'expression_catalogue_66.tsv'),'--de-results',str(T/'_candidate_DE_66.tsv'),'--amp-tpm',str(T/'_candidate_TPM_66.tsv'),'--mappability',str(T/'mappability_66.tsv'),'--transcripts',str(transcripts),'--all-normalized-counts',str(E/'results/gene_normalized_counts.csv'),'--all-de-results',str(E/'results/all_gene_DE_results.csv'),'--output-dir',str(packet)]
subprocess.run(cmd,check=True)
s22=read(packet/'qPCR_candidate_packet.tsv');s24=read(packet/'reference_gene_candidates.tsv')
old24=read(E/'reference_gene_candidates.tsv')
assert s24==old24
for r in s22:r['validation_status']='COMPUTATIONAL_PRIORITY_ONLY; NO_INDEPENDENT_QRT_PCR_PERFORMED'
for r in s24:r['validation_status']='RNA_SEQ_SCREEN_ONLY; EXPERIMENTAL_STABILITY_NOT_VALIDATED'
write(T/'S22_qPCR_Candidates_8.tsv',s22);write(T/'S24_RefGenes_12.tsv',s24)
write(packet/'qPCR_candidate_packet.tsv',s22);write(packet/'reference_gene_candidates.tsv',s24)
for file in ['S12_AMP_TPM_73.tsv','S13_AMP_NormCounts_73.tsv','AMP_VST_73.tsv','AMP_rounded_counts_73.tsv','S14_AMP_DE_73x3.tsv','S26_ExpressionFilter_73.tsv']:
    rr=read(T/file);rr=[r for r in rr if r.get('quantification_status')!='NOT_IN_REFERENCE']
    write(T/file.replace('_73','_reference66'),rr)
old22={r['member_id'] for r in read(E/'qPCR_candidate_packet.tsv')};new22={r['member_id'] for r in s22}
oldDE={(r['member_id'],r['contrast']):r for r in read(P/'final_AMP_DE_results.tsv')}
oldvalues_unchanged=True
for r in DE:
    if (r['member_id'],r['contrast']) in oldDE:
        for k in ['log2FoldChange','log2FC_apeglm','pvalue','padj_BH','DE_test_status','prefilter_status','DE_call_FDR_lt_0.05_abs_log2FC_gt_1']:
            old=oldDE[(r['member_id'],r['contrast'])][k];newv=r[k]
            assert str(old).upper()==str(newv).upper(),(r['member_id'],r['contrast'],k,old,newv)
status={'primary_catalogue':73,'frozen_reference_present_in_tx2gene_and_all_9_quant_sf':66,'M6_not_in_reference':7,'retained_total_rounded_count_ge_10':52,'all_zero':11,'low_total_count':3,'Figure6_rows':52,'Figure7_points':{'S200_vs_CK':49,'S400_vs_CK':52},'DE_summary':[r for r in summary if r['family']=='ALL'],'old63_DE_numbers_and_statuses_unchanged':True,'S22_selected':list(r['member_id'] for r in s22),'S22_added':sorted(new22-old22),'S22_removed':sorted(old22-new22),'S24_original_12_rows_reproduced_exactly_before_label_update':True,'mappability_original63_classification_changes':mapchanges,'DESeq2_refitted':False,'Salmon_requantified':False,'BH_recomputed_on_AMP_subset':False,'formal_files_modified':False}
(Q/'table_rebuild_validation.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
versions={'python':sys.version,'openpyxl':openpyxl.__version__}
(Q/'software_versions.json').write_text(json.dumps(versions,indent=2))
sheets={'S12_AMP_TPM':normtables['TPM'],'S13_AMP_NormCounts':normtables['normalized_counts'],'S14_AMP_DE':DE,'S15_DE_Summary':summary,'S22_qPCR_Candidates':s22,'S23_Mappability':maprows,'S24_RefGenes':s24,'S26_ExpressionFilter':pref,'Eligibility73':eligibility,'VST73':normtables['VST'],'S400_Priority18':priority}
w=openpyxl.Workbook();w.remove(w.active)
for name,rs in sheets.items():
    ws=w.create_sheet(name);ws.append(list(rs[0]));
    for row in rs:
        vals=[]
        for value in row.values():
            if isinstance(value,str) and re.fullmatch(r'[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?',value):
                value=int(value) if re.fullmatch(r'[+-]?\d+',value) else float(value)
            vals.append(value)
        ws.append(vals)
    ws.freeze_panes='D2';ws.auto_filter.ref=ws.dimensions
    for cell in ws[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='24576D')
    for col in range(1,ws.max_column+1):ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width=23
    for row in ws:
        for cell in row:cell.alignment=Alignment(vertical='top')
w.save(T/'表达补表替换_S12_S15_S22_S24_S26.xlsx')
back=openpyxl.load_workbook(T/'表达补表替换_S12_S15_S22_S24_S26.xlsx',read_only=True,data_only=True)
assert all(back[k].max_row==len(v)+1 for k,v in sheets.items())
sources=[CAT,E/'transcript_to_gene.tsv',E/'results/all_gene_DE_results.csv',E/'results/gene_TPM.csv',E/'results/gene_normalized_counts.csv',E/'results/gene_VST.csv',P/'all_gene_prefilter_audit.tsv',P/'all_gene_prefilter_counts.tsv',P/'source_md5.tsv',E/'build_qpcr_candidate_packet.py',E/'audit_key_gene_mappability.py']
write(Q/'source_SHA256.tsv',[dict(relative_path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sources])
print(json.dumps(status,ensure_ascii=False,indent=2))
