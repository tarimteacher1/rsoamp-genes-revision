"""Final content/availability/preservation audit and package manifest."""
from pathlib import Path
import csv,json,hashlib,math,collections,xml.etree.ElementTree as ET
import openpyxl
O=Path(__file__).resolve().parent;R=O.parents[1];T=O/'tables';Q=O/'qa';F=O/'figures'
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def istrue(v):return str(v).upper() in ['TRUE','T','1']
def finite(v):
 try:return math.isfinite(float(v))
 except (TypeError,ValueError):return False
scope=[
 {'table':'S12','replacement':'S12_AMP_TPM_73.tsv','rows':73,'status':'REFILTERED_AND_EXPANDED_WITH_AVAILABILITY','scope':'66 measured members x 9 libraries; 7 NOT_IN_REFERENCE','change':'Original 63 plus RsLTP2/18/30 quantified; no zero imputation for M6'},
 {'table':'S13','replacement':'S13_AMP_NormCounts_73.tsv','rows':73,'status':'REFILTERED_AND_EXPANDED_WITH_AVAILABILITY','scope':'52 retained with normalized counts; 14 prefiltered; 7 NOT_IN_REFERENCE','change':'Original frozen-model normalized counts retained'},
 {'table':'S14','replacement':'S14_AMP_DE_73x3.tsv','rows':219,'status':'REFILTERED_ALL_THREE_CONTRASTS','scope':'73 members x 3 contrasts; original model and full-gene BH results','change':'RsLTP2 adds one UP call in each contrast; RsLTP18/30 retained but below abs(MLE) threshold'},
 {'table':'S15','replacement':'S15_DE_Summary.tsv','rows':12,'status':'RECOUNTED_WITH_EXPLICIT_DENOMINATORS','scope':'3 contrasts x ALL/Defensin/Snakin_GASA/nsLTP','change':'DE totals 8/18/13; up 6/12/9; down 2/6/4'},
 {'table':'S22','replacement':'S22_qPCR_Candidates_8.tsv','rows':8,'status':'COMPUTATIONAL_PRIORITY_REGENERATED','scope':'Original family-balanced selection rule; no independent qRT-PCR performed','change':'RsLTP2 replaces RsLTP35 in computational shortlist only; candidates lack independent experimental validation'},
 {'table':'S23','replacement':'S23_Mappability_73.tsv','rows':73,'status':'UNIFORM_66_TRANSCRIPT_SCREEN_COMPLETED','scope':'66 reference transcripts assessed; 7 not assessed because absent from reference','change':'Original 63 risk/near-hit classifications unchanged; RsLTP2/18/30 LOW under original rule'},
 {'table':'S24','replacement':'S24_RefGenes_12.tsv','rows':12,'status':'REPRODUCED_NUMERICALLY_UNCHANGED','scope':'Original all-gene stable-expression screen; no experimental stability validation','change':'Twelve members and numerical values unchanged; evidence label clarified'},
 {'table':'S26','replacement':'S26_ExpressionFilter_73.tsv','rows':73,'status':'REFILTERED_AND_REFERENCE_STATUS_ADDED','scope':'52 retained + 11 all zero + 3 low total count + 7 reference absent','change':'Original count-filter definition retained; M6 not assigned a count-filter failure'}
]
write(T/'supplementary_scope_status.tsv',scope)
elig=read(T/'expression_eligibility_73.tsv');assert len(elig)==73 and len({r['member_id'] for r in elig})==73
new=[r for r in elig if r['quantification_status']=='NOT_IN_REFERENCE']
assert {r['member_id'] for r in new}=={f'RsDEF{i}' for i in range(15,21)}|{'RsLTP41'}
assert sum(istrue(r['reference_present']) for r in elig)==66
assert sum(istrue(r['old63_member']) for r in elig)==63
assert sum(istrue(r['Figure6_included']) for r in elig)==52
for row in new:
 assert row['retained_for_DE']=='NA'
 for c in ['S200_vs_CK','S400_vs_CK','S400_vs_S200']:
  assert row[c+'_DE_test_status']=='NOT_TESTED_NOT_IN_REFERENCE' and not istrue(row[c+'_plottable'])
assert {r['member_id'] for r in elig if istrue(r['reference_present']) and not istrue(r['old63_member'])}=={'RsLTP2','RsLTP18','RsLTP30'}
expected_samples=['SRR27540881','SRR27540880','SRR27540879','SRR27540878','SRR27540877','SRR27540876','SRR27540875','SRR27540884','SRR27540883']
for file,n in [('S12_AMP_TPM_73.tsv',66),('S13_AMP_NormCounts_73.tsv',52),('AMP_VST_73.tsv',52),('AMP_rounded_counts_73.tsv',66)]:
 rr=read(T/file);assert len(rr)==73
 assert sum(all(finite(r[s]) for s in expected_samples) for r in rr)==n
 assert all(all(r[s]=='' for s in expected_samples) for r in rr if r['quantification_status']=='NOT_IN_REFERENCE')
de=read(T/'S14_AMP_DE_73x3.tsv');assert len(de)==219
for row in de:
 if row['quantification_status']=='NOT_IN_REFERENCE':
  assert all(row[s]=='' for s in ['baseMean','log2FoldChange','log2FC_apeglm','lfcSE','stat','pvalue','padj_BH'])
  assert row['DE_call_FDR_lt_0.05_abs_log2FC_gt_1']=='NA' and row['DE_direction']=='NOT_EVALUABLE'
assert all(len(read(T/r['replacement']))==r['rows'] for r in scope)
assert all(r['validation_status']=='COMPUTATIONAL_PRIORITY_ONLY; NO_INDEPENDENT_QRT_PCR_PERFORMED' for r in read(T/'S22_qPCR_Candidates_8.tsv'))
f7=json.loads((Q/'figure7_verification.json').read_text())
for c,n,p in [('S200_vs_CK',8,49),('S400_vs_CK',18,52)]:
 assert f7['panels'][c]['DE']==n and f7['panels'][c]['labels']==n and f7['panels'][c]['leader_lines']==n and f7['panels'][c]['plotted']==p
for k in ['overlapping_label_pairs','labels_outside_axes','labels_over_points']:
 assert not f7['layout_checks'][k] and not f7['apeglm_display_layout_checks'][k]
svg=ET.parse(F/'Figure7_expression_volcano_all_DE_labeled_66.svg')
ids={x.get('id') for x in svg.iter() if x.get('id')}
assert len([i for i in ids if i.startswith('point_')])==101 and len([i for i in ids if i.startswith('label_')])==26
for name,expected in f7['source_sha256'].items():assert sha(T/name)==expected
hash_checks=[]
for row in read(Q/'source_SHA256.tsv'):
 p=R/row['relative_path'];actual=sha(p);assert actual==row['sha256'];hash_checks.append({'relative_path':row['relative_path'],'sha256':actual,'unchanged':True})
author=json.loads((O.parent/'protected_author_figures.json').read_text(encoding='utf-8-sig'))
authorchecks=[]
for name,expected in author.items():
 p=Path(name);actual=sha(p);authorchecks.append({'path':name,'expected_sha256':expected,'actual_sha256':actual,'unchanged':actual==expected})
assert all(r['unchanged'] for r in authorchecks)
workbook=T/'表达补表替换_S12_S15_S22_S24_S26.xlsx'
w=openpyxl.load_workbook(workbook,data_only=True,read_only=True)
assert w['S12_AMP_TPM'].max_row==74 and w['S14_AMP_DE'].max_row==220
hdr=[c.value for c in next(w['S12_AMP_TPM'].iter_rows())];si=hdr.index(expected_samples[0]);qi=hdr.index('quantification_status')
measured=missing=0
for rr in list(w['S12_AMP_TPM'].values)[1:]:
 if rr[qi]=='NOT_IN_REFERENCE':assert rr[si] is None;missing+=1
 else:assert isinstance(rr[si],(int,float));measured+=1
assert (measured,missing)==(66,7)
qa={'delivery_scope':'Expression tables and Figure 6/7 for frozen 73-member primary catalogue, quantified cohort 66','primary73_reference66_retained52_verified':True,'new7_missing_numeric_fields_not_zero_or_NS_verified':True,'old63_source_numbers_unchanged':True,'new_reference_members':['RsLTP2','RsLTP18','RsLTP30'],'source_file_hash_checks':hash_checks,'protected_author_PDF_checks':authorchecks,'Figure6_visual_review':'PASS: all 52 labels readable; family strip clear; no color clipping or missing-data imputation','Figure7_visual_review':'PASS: all 8/18 labels and leaders visible; signs and up/down totals explicit; full y-range preserved','Figure7_SVG_point_and_label_ID_counts':[101,26],'Figure7_layout_checks_no_overlaps':True,'apeglm_sensitivity_visual_and_layout_review':'PASS; original DE calls retained; no shrunken fold-change cutoff','Excel_numeric_cells_and_missing_values_verified':True,'Salmon_requantified':False,'DESeq2_refitted':False,'BH_recomputed_on_AMP_subset':False,'formal_manuscript_and_old_workbook_written_by_this_task':False,'independent_qRT_PCR_performed':False,'S22_evidence_status':'COMPUTATIONAL_CANDIDATES_WITHOUT_INDEPENDENT_EXPERIMENTAL_VALIDATION','independent_output_only':True}
(Q/'final_delivery_validation.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
manifest=[]
for p in sorted(O.rglob('*')):
 if p.is_file() and p.name!='delivery_SHA256.tsv' and '__pycache__' not in p.parts:
  manifest.append({'relative_path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)})
write(Q/'delivery_SHA256.tsv',manifest)
assert all(sha(O/r['relative_path'])==r['sha256'] for r in read(Q/'delivery_SHA256.tsv'))
print(json.dumps({'files_hashed':len(manifest),'author_PDFs_unchanged':len(authorchecks),'all_checks':'PASS','DE_counts':[8,18,13],'reference_covered':66,'main':73,'retained':52},indent=2))
