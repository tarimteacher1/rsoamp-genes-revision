from pathlib import Path
import csv,json,hashlib,subprocess
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
B=ROOT/'Genes_lab_handoff_20260908/02_Workspace/9_2_major_revision'
E=B/'revision_R1_20260902/06_expression_reanalysis';P=B/'Genes_expression_status_fix_20260904/04_Expression_Audit'
def table(p,d='\t'):return list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter=d))
catalogue=[r for r in table(ROOT/'成员判定收尾_20260909/统一目录/统一成员目录_主分析111.tsv') if r['species']=='rso']
tx={r['TXNAME']:r['GENEID'] for r in table(E/'transcript_to_gene.tsv')}
members=[dict(member_id=r['member_id'],protein_id=r['protein_id'],gene_id=r['original_gene_parent'],family=r['family']) for r in catalogue if r['protein_id'] in tx]
assert len(members)==66
relative=['results/all_gene_DE_results.csv','results/gene_TPM.csv','results/gene_normalized_counts.csv','results/gene_VST.csv','transcript_to_gene.tsv','rnaseq_sample_sheet.tsv','results/key_gene_mappability.tsv','reference_gene_candidates.tsv']
expected={'/path/to/rso_project/revision_R1_20260902/06_expression_reanalysis/'+n:hashlib.sha256((E/n).read_bytes()).hexdigest() for n in relative}
md5=table(P/'source_md5.tsv')
script=r'''from pathlib import Path
import csv,json,hashlib,subprocess,statistics
members=__MEMBERS__
expected=__EXPECTED__
md5_expected=__MD5__
E=Path('/path/to/rso_project/revision_R1_20260902/06_expression_reanalysis')
O=Path('/path/to/rso_project/revision_sync_20260909/expression_F6_F7');O.mkdir(parents=True,exist_ok=True)
checks=[{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest(),'matches_local':hashlib.sha256(Path(p).read_bytes()).hexdigest()==h} for p,h in expected.items()]
assert all(x['matches_local'] for x in checks),checks
mdchecks=[{'path':r['file'],'md5':hashlib.md5(Path(r['file']).read_bytes()).hexdigest(),'matches_frozen_prefilter_input':hashlib.md5(Path(r['file']).read_bytes()).hexdigest()==r['md5']} for r in md5_expected]
assert all(x['matches_frozen_prefilter_input'] for x in mdchecks),mdchecks
fa=E/'rso_full_transcripts_from_gff.fa';seq={};k=None
for l in fa.open():
 if l.startswith('>'):k=l[1:].split()[0];seq[k]=''
 elif k:seq[k]+=l.strip()
ids={r['protein_id'] for r in members};assert ids<=set(seq)
q=O/'cohort66_transcripts.fasta';q.write_text(''.join('>'+r['protein_id']+'\n'+seq[r['protein_id']]+'\n' for r in members))
db=E/'results/full_transcriptome_blastdb'
command=['/usr/bin/blastn','-task','blastn','-query',str(q),'-db',str(db),'-evalue','1e-10','-dust','yes','-max_target_seqs','500','-num_threads','4','-outfmt','6 qseqid sseqid pident length qlen slen evalue bitscore qstart qend sstart send']
blast=subprocess.run(command,text=True,capture_output=True,check=True).stdout
(O/'cohort66_vs_full_transcriptome.blastn.tsv').write_text(blast)
hits={}
for l in blast.splitlines():
 f=l.split('\t');q,s,pi,n,ql,sl,ev,bs,qs,qe,ss,se=f
 if q==s:continue
 hits.setdefault(q,[]).append({'subject':s,'identity':float(pi),'alignment_length':int(n),'old_alignment_length_coverage':int(n)/int(ql),'query_coordinate_coverage':(abs(int(qe)-int(qs))+1)/int(ql),'subject_coordinate_coverage':(abs(int(se)-int(ss))+1)/int(sl),'bitscore':float(bs)})
ambiguity={k:[] for k in ids};details=[];quant_membership={k:[] for k in ids}
for run in list(csv.DictReader((E/'rnaseq_sample_sheet.tsv').open(),delimiter='\t')):
 run=run['run'];qp=E/'salmon_quant'/run/'quant.sf';ap=qp.parent/'aux_info/ambig_info.tsv'
 quant=list(csv.DictReader(qp.open(),delimiter='\t'));amb=list(csv.DictReader(ap.open(),delimiter='\t'));assert len(quant)==len(amb)
 for qr,ar in zip(quant,amb):
  name=ar.get('Name') or ar.get('Transcript') or qr['Name']
  assert name==qr['Name']
  if name not in ids:continue
  u=float(ar['UniqueCount']);a=float(ar['AmbigCount']);den=u+a
  fraction=a/den if den else 0.0
  ambiguity[name].append(fraction);quant_membership[name].append(run)
  details.append(dict(run=run,transcript_id=name,unique_count=u,ambiguous_count=a,assignment_denominator=den,ambiguous_fraction_with_legacy_zero_denominator_convention=fraction))
rows=[]
for m in members:
 pid=m['protein_id'];hh=sorted(hits.get(pid,[]),key=lambda h:-h['bitscore']);best=hh[0] if hh else None
 med=statistics.median(ambiguity[pid]);near=[h for h in hh if h['identity']>=95 and h['query_coordinate_coverage']>=.8]
 oldnear=[h for h in hh if h['identity']>=95 and h['old_alignment_length_coverage']>=.8]
 risk='HIGH' if near and med>=.5 else 'MODERATE' if near or med>=.2 else 'LOW'
 rows.append(dict(**m,transcript_id=pid,transcript_length_nt=len(seq[pid]),best_nonself_transcript=best['subject'] if best else '',best_nonself_identity_pct=f"{best['identity']:.3f}" if best else '',best_nonself_query_coverage=f"{best['query_coordinate_coverage']:.4f}" if best else '',near_identical_nonself_hits_95pct_80pct_coverage=len(near),legacy_alignment_length_near_identical_hit_count=len(oldnear),samples_with_salmon_ambiguity_metrics=len(ambiguity[pid]),median_salmon_ambiguous_fraction=f'{med:.4f}',mappability_risk=risk,interpretation='Transcript similarity and Salmon assignment diagnostic; not primer specificity or independent functional validation'))
assert all(len(x)==9 for x in quant_membership.values())
out={'source_checks':checks,'frozen_prefilter_inputs_md5_checks':mdchecks,'transcript_fasta':{'path':str(fa),'sha256':hashlib.sha256(fa.read_bytes()).hexdigest(),'records':len(seq)},'blast_command':command,'blast_version':subprocess.run(['/usr/bin/blastn','-version'],text=True,capture_output=True).stdout,'remote_output_dir':str(O),'mappability':rows,'ambiguity_details':details,'quant_sf_presence':quant_membership,'selected_transcripts':{k:seq[k] for k in ids},'blast_output':blast}
print(json.dumps(out))
'''.replace('__MEMBERS__',repr(members)).replace('__EXPECTED__',repr(expected)).replace('__MD5__',repr(md5))
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','dxy@example-host','python3 -'],input=script,text=True,encoding='utf-8',capture_output=True,timeout=120)
if p.returncode:raise RuntimeError(p.stderr)
d=json.loads(p.stdout);(OUT/'sources/live_expression_and_mappability.json').write_text(json.dumps(d,indent=2),encoding='utf-8')
print(json.dumps({'source_sha256_checks':len(d['source_checks']),'frozen_md5_checks':len(d['frozen_prefilter_inputs_md5_checks']),'mappability_members':len(d['mappability']),'new_three':[r for r in d['mappability'] if r['member_id'] in ['RsLTP2','RsLTP18','RsLTP30']]},indent=2))
