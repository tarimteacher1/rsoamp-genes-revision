"""Correct evidence-status text only; assert every other table value is unchanged."""
from pathlib import Path
import csv,json,hashlib
import openpyxl
O=Path(__file__).resolve().parent
STATUS='COMPUTATIONAL_PRIORITY_ONLY; NO_INDEPENDENT_QRT_PCR_PERFORMED'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
records=[]
for relative in ['tables/S22_qPCR_Candidates_8.tsv','candidate_packet/qPCR_candidate_packet.tsv']:
 p=O/relative;before=read(p);oldhash=sha(p)
 after=[dict(r,validation_status=STATUS) for r in before]
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(after[0]),delimiter='\t');w.writeheader();w.writerows(after)
 back=read(p)
 assert [{k:v for k,v in r.items() if k!='validation_status'} for r in back]==[{k:v for k,v in r.items() if k!='validation_status'} for r in before]
 assert len(back)==8 and all(r['validation_status']==STATUS for r in back)
 records.append({'path':relative,'before_sha256':oldhash,'after_sha256':sha(p),'all_non_status_cells_unchanged':True})
p=O/'tables/表达补表替换_S12_S15_S22_S24_S26.xlsx';oldhash=sha(p)
w=openpyxl.load_workbook(p);before={s.title:list(s.values) for s in w};ws=w['S22_qPCR_Candidates']
ci=[c.value for c in ws[1]].index('validation_status')+1
for ri in range(2,ws.max_row+1):ws.cell(ri,ci).value=STATUS
w.save(p)
back=openpyxl.load_workbook(p,data_only=True);after={s.title:list(s.values) for s in back}
changes=[]
for sheet,rows in before.items():
 assert len(rows)==len(after[sheet])
 for ri,(a,b) in enumerate(zip(rows,after[sheet])):
  for col,(va,vb) in enumerate(zip(a,b)):
   if va!=vb:
    assert sheet=='S22_qPCR_Candidates' and ri>0 and col==ci-1 and vb==STATUS
    changes.append([sheet,ri+1,col+1])
records.append({'path':str(p.relative_to(O)),'before_sha256':oldhash,'after_sha256':sha(p),'changed_cells':changes,'all_other_cells_including_all_numbers_unchanged':True})
manifest=read(O/'qa/delivery_SHA256.tsv')
figures=[r for r in manifest if Path(r['relative_path']).parts[0]=='figures']
assert all(sha(O/r['relative_path'])==r['sha256'] for r in figures)
audit={'scope':'Correction of independent-experiment evidence status only','independent_qRT_PCR_performed':False,'no_statistical_or_numeric_values_changed':True,'figure_files_unchanged':len(figures),'table_checks':records}
(O/'qa/independent_experiment_wording_correction.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(audit,ensure_ascii=False,indent=2))
