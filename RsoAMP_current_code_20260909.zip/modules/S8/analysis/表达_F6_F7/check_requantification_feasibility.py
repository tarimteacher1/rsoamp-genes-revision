"""Read-only existence/runtime inventory; does not launch Salmon or DESeq2."""
from pathlib import Path
import subprocess,json
OUT=Path(__file__).resolve().parent
code=r'''
from pathlib import Path
import csv,json
R=Path('/path/to/rso_project/revision_R1_20260902')
E=R/'06_expression_reanalysis'
runs=[x['run'] for x in csv.DictReader((E/'rnaseq_sample_sheet.tsv').open(),delimiter='\t')]
files=[]
for run in runs:
 for mate in [1,2]:
  p=R/'04_unmapped_reads/raw_fastq'/f'{run}_{mate}.fastq.gz'
  files.append({'run':run,'mate':mate,'path':str(p),'exists':p.is_file(),'bytes':p.stat().st_size if p.exists() else 0})
tools={}
for n,p in [('salmon','/path/to/user/tools/miniconda3/envs/salmon_env/bin/salmon'),('gffread','/path/to/user/tools/miniconda3/envs/starsolo/bin/gffread')]:tools[n]={'path':p,'exists':Path(p).is_file()}
meta=[]
for run in runs:
 p=E/'salmon_quant'/run/'aux_info/meta_info.json';d=json.loads(p.read_text())
 meta.append({'run':run,**{k:d.get(k) for k in ['salmon_version','num_targets','num_processed','num_mapped','percent_mapped','start_time','end_time']}})
print(json.dumps({'raw_fastq':files,'compressed_bytes_total':sum(x['bytes'] for x in files),'all18_fastq_present':all(x['exists'] and x['bytes']>0 for x in files),'tools':tools,'frozen_salmon_meta':meta,'assessment_only':True,'new_quantification_launched':False}))
'''
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','dxy@example-host','python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60)
if p.returncode:raise RuntimeError(p.stderr)
d=json.loads(p.stdout);(OUT/'sources/requantification_feasibility_live.json').write_text(json.dumps(d,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in d.items() if k not in ['raw_fastq','frozen_salmon_meta']},indent=2))
