#!/usr/bin/env bash
set -euo pipefail
TASK=/path/to/rso_project/r1_m6_deep_classification_20260908
cd "$TASK"
mkdir -p variant_sensitivity
exec >logs/variant_sensitivity.log 2>&1
trap 'code=$?; echo "$code" > variant_sensitivity.exitcode' EXIT
export DEEPSIG_ROOT=/path/to/user/tools/miniconda3/envs/deepsig_env/share/deepsig
/path/to/user/tools/miniconda3/envs/deepsig_env/bin/deepsig -f single_variant_sensitivity.faa -o variant_sensitivity/single.deepsig.gff3 -k euk -m gff3 -t 1
export PREDGPI_HOME=/path/to/rso_project/revision_R1_20260902/08_reproducibility/software/predgpi
python3 "$PREDGPI_HOME/predgpi.py" -f single_variant_sensitivity.faa -o variant_sensitivity/single.predgpi.json -m json
/path/to/user/tools/miniconda3/envs/cotton/bin/hmmsearch --cpu 1 --cut_ga --domtblout variant_sensitivity/AMP.cutga.domtbl \
 /path/to/rso_project/data/hmm/AMP_models.hmm single_variant_sensitivity.faa > variant_sensitivity/AMP.cutga.txt
/path/to/user/tools/miniconda3/envs/cotton/bin/hmmsearch --cpu 1 --max -E 100 --domE 100 --tblout variant_sensitivity/PF00304.relaxed.tbl \
 /path/to/rso_project/data/hmm/PF00304.hmm single_variant_sensitivity.faa > variant_sensitivity/PF00304.relaxed.txt
date -Iseconds > variant_sensitivity/COMPLETE
