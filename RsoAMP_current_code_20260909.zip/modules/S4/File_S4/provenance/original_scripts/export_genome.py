from pathlib import Path
import json,subprocess
OUT=Path(__file__).resolve().parent
DATA=json.loads((OUT/'candidate_manifest.json').read_text())
samtools='/path/to/user/tools/miniconda3/envs/as_splice/bin/samtools'
genome='/path/to/rso_project/data/genome.fa'
out={}
for r in DATA:
    m=r['model'];start=int(m['model_start'])-200;end=int(m['model_end'])+200
    region=f"{m['chrom']}:{start}-{end}"
    txt=subprocess.check_output([samtools,'faidx',genome,region],text=True)
    out[r['id']]={'chrom':m['chrom'],'start1':start,'end1':end,'sequence':''.join(txt.splitlines()[1:]).upper()}
(OUT/'genome_regions.json').write_text(json.dumps(out,indent=2))
print('exported',len(out),'regions')
