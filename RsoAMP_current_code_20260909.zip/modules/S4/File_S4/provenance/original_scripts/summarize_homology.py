from pathlib import Path
import csv,json,re
from collections import defaultdict
OUT=Path(__file__).resolve().parent
refs={r['Entry']:r for r in csv.DictReader((OUT/'reference/reviewed_plants_20_400aa.tsv').read_text(encoding='utf-8').splitlines(),delimiter='\t')}
hits=defaultdict(list)
for l in (OUT/'blast/queries_vs_reviewed_plants.tsv').read_text().splitlines():
    f=l.split('\t');q,s=f[:2];r=refs[s];name=r['Protein names'].lower()
    if 'PF00304;' in r['Pfam'] or 'IPR008176;' in r['InterPro']:label='DEFL_specific'
    elif 'defensin' in name or 'gamma-thionin' in name:label='DEFL_named'
    elif any(x+';' in r['InterPro'] for x in ['IPR000528','IPR033872','IPR039265']):label='LTP_specific'
    elif 'lipid transfer' in name or 'lipid-transfer' in name:label='LTP_named'
    elif 'IPR044741;' in r['InterPro']:label='LTP_like_domain'
    elif any(x in name for x in ['2s albumin','2s seed','2s storage','alpha-amylase inhibitor','trypsin inhibitor','protease inhibitor','prolamin','thionin','hevein']):label='OTHER_named'
    else:label='OTHER_or_uncharacterized'
    hits[q].append({'subject':s,'label':label,'name':r['Protein names'],'organism':r['Organism'],'identity':float(f[2]),'aligned_columns':int(f[3]),'qlen':int(f[4]),'slen':int(f[5]),'qstart':int(f[6]),'qend':int(f[7]),'sstart':int(f[8]),'send':int(f[9]),'qcovhsp':float(f[10]),'evalue':float(f[11]),'bitscore':float(f[12]),'qseq':f[13],'sseq':f[14],'interpro':r['InterPro'],'pfam':r['Pfam']})
for h in hits.values():h.sort(key=lambda x:-x['bitscore'])
(OUT/'homology_hits_annotated.json').write_text(json.dumps(dict(hits),indent=2))
for q,h in hits.items():
    if q.startswith('R1M6') or q.startswith('ALT'):
        print(q)
        for a in h[:4]:print(a['subject'],a['name'],a['bitscore'],a['identity'],a['qcovhsp'],a['evalue'],a['interpro'])
        print('best labelled alternatives:',[(cat,next(((a['subject'],a['bitscore']) for a in h if a['label']==cat),None)) for cat in ['DEFL_specific','DEFL_named','LTP_specific','LTP_named','OTHER_named','OTHER_or_uncharacterized']])
