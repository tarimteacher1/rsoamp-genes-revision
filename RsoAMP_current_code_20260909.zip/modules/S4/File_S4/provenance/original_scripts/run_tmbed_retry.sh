#!/usr/bin/env bash
set -euo pipefail
TASK=/path/to/rso_project/r1_m6_deep_classification_20260908
cd "$TASK"
exec >logs/tmbed_retry.log 2>&1
trap 'code=$?; echo "$code" > tmbed_retry.exitcode' EXIT
export TRANSFORMERS_OFFLINE=1 HF_HUB_OFFLINE=1
export HF_HOME=/path/to/rso_project/revision_R1_20260902/08_reproducibility/models/huggingface_cache
/path/to/rso_project/revision_R1_20260902/08_reproducibility/envs/tmbed/bin/python -m tmbed predict \
 --fasta alternative_starts.faa --predictions start_sensitivity/alternative.tmbed.pred \
 --out-format 0 --no-use-gpu --threads 2
date -Iseconds > start_sensitivity/COMPLETE
