#!/usr/bin/env bash
set -euo pipefail
TASK=/path/to/rso_project/r1_m6_deep_classification_20260908
cd "$TASK"
mkdir -p start_sensitivity
exec >logs/start_sensitivity.log 2>&1
trap 'code=$?; echo "$code" > start_sensitivity.exitcode' EXIT
export DEEPSIG_ROOT=/path/to/user/tools/miniconda3/envs/deepsig_env/share/deepsig
/path/to/user/tools/miniconda3/envs/deepsig_env/bin/deepsig -f alternative_starts.faa -o start_sensitivity/alternative.deepsig.gff3 -k euk -m gff3 -t 1
export TRANSFORMERS_OFFLINE=1 HF_HUB_OFFLINE=1
/path/to/rso_project/revision_R1_20260902/08_reproducibility/envs/tmbed/bin/python -m tmbed predict \
 --fasta alternative_starts.faa --predictions start_sensitivity/alternative.tmbed.pred \
 --out-format 0 --no-use-gpu --threads 2 \
 --model-dir /path/to/rso_project/revision_R1_20260902/08_reproducibility/models/prot_t5_xl_half_uniref50_enc
date -Iseconds > start_sensitivity/COMPLETE
