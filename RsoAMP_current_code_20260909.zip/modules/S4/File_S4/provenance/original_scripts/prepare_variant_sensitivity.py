from pathlib import Path
import csv,json
OUT=Path(__file__).resolve().parent
models={r['id']:r['model']['protein_sequence'] for r in json.loads((OUT/'candidate_manifest.json').read_text())}
seq={};meta=[]
for r in csv.DictReader((OUT/'variant_consequence_audit.tsv').read_text().splitlines(),delimiter='\t'):
    if r['effect']!='amino_acid_change':continue
    s=models[r['candidate']];idx=int(r['codon_index'])-1
    assert s[idx]==r['ref_aa']
    key=f"SENS_{r['candidate'][-6:]}_{r['ref_aa']}{idx+1}{r['alt_aa']}"
    seq[key]=s[:idx]+r['alt_aa']+s[idx+1:];meta.append({'sensitivity_id':key,**r})
seq.update({k:models[k] for k in ['R1M6_CAND01','R1M6_CAND02','R1M6_CAND03','R1M6_CAND05','R1M6_CAND06','R1M6_CAND07','R1M6_CAND08','R1M6_CAND10']})
(OUT/'single_variant_sensitivity.faa').write_text(''.join(f'>{k}\n{v}\n' for k,v in seq.items()))
(OUT/'single_variant_sensitivity_manifest.json').write_text(json.dumps({'scope':'Single-substitution in-silico sensitivity; not phased haplotypes or proof of translation. Each variant observed at fraction>=0.2 and depth>=10 after read/base filters.','variants':meta},indent=2))
print(len(seq),'sensitivity/control sequences')
