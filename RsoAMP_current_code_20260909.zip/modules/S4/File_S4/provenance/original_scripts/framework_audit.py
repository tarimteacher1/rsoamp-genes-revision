from pathlib import Path
import csv,json,re
OUT=Path(__file__).resolve().parent
old=json.loads((OUT.parent/'R1M6_候选审核_20260908/candidate_family_evidence.json').read_text())
models=json.loads((OUT/'candidate_manifest.json').read_text())
rows=[]
nsltp=re.compile(r'C[^C]*C[^C]*CC[^C]*C.C[^C]*C[^C]*C')
ps597=re.compile(r'[LIVM][PA].{2}C.{1,2}[LIVM].{1,2}[LIVMST].[LIVMFY].{1,2}[LIVMF][STRD].{3}[DN]C.{2}[LIVM]')
for m,f in zip(models,old):
    s=m['model']['protein_sequence']; ds=f['deepsig'];cut=ds[0][1] if ds else 0
    pos=[i+1 for i,c in enumerate(s) if c=='C' and i>=cut]
    pattern='C'+''.join('-X'+str(b-a-1)+'-C' for a,b in zip(pos,pos[1:]))
    eight=nsltp.search(s);site=ps597.search(s)
    rows.append([m['id'],len(s),cut,','.join(map(str,pos)),pattern,
        f'{eight.start()+1}-{eight.end()}' if eight else '',f'{site.start()+1}-{site.end()}' if site else ''])
with (OUT/'cysteine_framework.tsv').open('w',newline='') as f:
    w=csv.writer(f,delimiter='\t');w.writerow(['candidate','length','DeepSig_cut','mature_cysteine_positions_precursor','cysteine_spacing','nsLTP_8CM_span','PROSITE_PS00597_pattern_span']);w.writerows(rows)
for r in rows:print('\t'.join(map(str,r)))
