#!/usr/bin/env bash
set -euo pipefail
TASK=/path/to/rso_project/r1_m6_deep_classification_20260908
cd "$TASK"
mkdir -p interpro/tmp logs
exec >logs/interpro.log 2>&1
trap 'code=$?; echo "$code" > interpro.exitcode' EXIT
export PATH=/path/to/user/tools/miniconda3/lib/jvm/bin:/usr/bin:/bin
date -Iseconds
sha256sum queries_interpro.faa > interpro/inputs.sha256
/path/to/data/tools/software/interproscan-5.77-108.0/interproscan.sh \
 -i queries_interpro.faa -b "$TASK/interpro/queries" -f TSV,GFF3,XML \
 -cpu 4 -dp -iprlookup -goterms -T "$TASK/interpro/tmp"
sha256sum interpro/queries.* > interpro/outputs.sha256
date -Iseconds > interpro/COMPLETE
