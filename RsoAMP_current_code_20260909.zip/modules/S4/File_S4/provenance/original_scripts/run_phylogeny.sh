#!/usr/bin/env bash
set -euo pipefail
TASK=/path/to/rso_project/r1_m6_deep_classification_20260908
cd "$TASK"
exec >logs/phylogeny.log 2>&1
trap 'code=$?; echo "$code" > phylogeny.exitcode' EXIT
HMM=/path/to/user/tools/miniconda3/envs/cotton/bin/hmmalign
TRIMAL=/path/to/user/tools/miniconda3/envs/cotton/bin/trimal
IQ=/path/to/user/tools/miniconda3/envs/iqtree/bin/iqtree3
"$IQ" --version
for family in defensin nsltp; do
  model=PF00304
  [[ "$family" == nsltp ]] && model=PF00234
  /usr/bin/mafft --localpair --maxiterate 1000 --thread 2 "phylogeny/$family.full.faa" > "phylogeny/$family.full.aln.faa" 2> "logs/$family.mafft.log"
  "$HMM" --trim --outformat afa "/path/to/rso_project/data/hmm/$model.hmm" "phylogeny/$family.full.faa" > "phylogeny/$family.core.aln.faa"
  for scope in full core; do
    "$TRIMAL" -in "phylogeny/$family.$scope.aln.faa" -out "phylogeny/$family.$scope.gappyout.faa" -gappyout
    for mode in untrimmed gappyout; do
      aln="phylogeny/$family.$scope.aln.faa"
      [[ "$mode" == gappyout ]] && aln="phylogeny/$family.$scope.gappyout.faa"
      prefix="phylogeny/$family.$scope.$mode"
      "$IQ" -s "$aln" -st AA -m MFP -mset LG,WAG,JTT -nt 2 -bb 1000 -alrt 1000 -seed 260908 --prefix "$prefix" > "logs/$family.$scope.$mode.log" 2>&1
    done
  done
done
date -Iseconds > phylogeny/COMPLETE
