from pathlib import Path
import csv,json
from collections import defaultdict
OUT=Path(__file__).resolve().parent
new=json.loads((OUT/'homology_hits_annotated.json').read_text())
old=defaultdict(list)
for l in (OUT/'blast/queries_vs_original_panel.same_settings.tsv').read_text().splitlines():
    f=l.split('\t');cat,rid=f[1].split('|',1)
    old[f[0]].append({'subject':rid,'label':cat,'bitscore':float(f[12])})
def best(h,cond):
    a=[x for x in h if cond(x)]
    return max(a,key=lambda x:x['bitscore']) if a else None
rows=[]
for q in ['R1M6_CAND02','R1M6_CAND03','ALT_CAND02_M35','CTRL_RsLTP17','CTRL_RsLTP19','CTRL_RsLTP20']:
    for panel in ['original_76_same_BLAST_settings','expanded_24794_reviewed_plants']:
        hs=old[q] if panel.startswith('original') else new[q]
        if panel.startswith('original'):
            p=best(hs,lambda x:x['label']=='POS');n=best(hs,lambda x:x['label']=='NEG2S');a=best(hs,lambda x:x['label']=='AMBPRO')
        else:
            p=best(hs,lambda x:x['label'] in ['LTP_specific','LTP_named'])
            n=best(hs,lambda x:x['label']=='OTHER_named' and any(t in x['interpro'] or t in x['pfam'] for t in ['IPR000617','PF00234','PF14368']))
            a=best(hs,lambda x:x['label'] in ['OTHER_or_uncharacterized','LTP_like_domain'] and any(t in x['interpro'] or t in x['pfam'] for t in ['IPR043325','IPR016140','PF00234','PF14368']))
        competitors=[x for x in [n,a] if x]
        strongest=max(competitors,key=lambda x:x['bitscore']) if competitors else None
        delta=round(p['bitscore']-strongest['bitscore'],2) if p and strongest else None
        rows.append([q,panel,p['subject'] if p else '',p['bitscore'] if p else '',n['subject'] if n else '',n['bitscore'] if n else '',a['subject'] if a else '',a['bitscore'] if a else '',delta,
                     ';'.join(f'{cut}:{delta>=cut}' for cut in [30,40,50,60,70]) if delta is not None else 'not_computable'])
with (OUT/'reference_panel_threshold_sensitivity.tsv').open('w',newline='') as f:
    w=csv.writer(f,delimiter='\t');w.writerow(['query','panel','positive','positive_bits','explicit_alternative','alternative_bits','ambiguous','ambiguous_bits','positive_minus_strongest_competitor','threshold_grid_not_universal']);w.writerows(rows)
for r in rows:print('\t'.join(map(str,r)))
