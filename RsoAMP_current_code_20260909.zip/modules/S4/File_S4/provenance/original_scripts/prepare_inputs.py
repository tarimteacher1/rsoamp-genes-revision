from pathlib import Path
import json,csv,hashlib
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent/'Genes_lab_handoff_20260908'
OLD=OUT.parent/'R1M6_候选审核_20260908'
data=json.loads((OLD/'candidate_model_read_evidence.json').read_text(encoding='utf-8'))
def fasta(p):
    records={};name=None
    for l in p.read_text(encoding='utf-8').splitlines():
        if l.startswith('>'): name=l[1:].split()[0];records[name]=''
        elif name:records[name]+=l.strip()
    return records
seq={r['id']:r['model']['protein_sequence'] for r in data}
for k,v in fasta(ROOT/'02_Workspace/9_2_major_revision/revision_R1_20260902/05_comparative_genomics/predictions/rso_annotated_defensins.faa').items():seq[k]=v
pool=fasta(ROOT/'02_Workspace/9_2_major_revision/revision_R1_20260902/01_nslTP_curation/inputs/nsLTP_candidate_pool.faa')
controls={'STRG.4001.1.p1':'CTRL_RsLTP17','STRG.9437.1.p1':'CTRL_RsLTP19','gmmChr04G004380.1':'CTRL_RsLTP20'}
for k,v in pool.items():
    key=k.split('|')[0]
    if key in controls:seq[controls[key]]=v
assert len(seq)==22,(len(seq),list(seq))
alt={}
for r in data:
    if r['id']=='R1M6_CAND02':
        s=r['model']['protein_sequence']
        for i,c in enumerate(s[:55]):
            if c=='M' and i:alt[f'ALT_CAND02_M{i+1}']=s[i:]
(OUT/'candidate_manifest.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
for name,records in [('queries_controls.faa',seq),('alternative_starts.faa',alt),('candidates.faa',{r['id']:r['model']['protein_sequence'] for r in data})]:
    (OUT/name).write_text(''.join(f'>{k}\n{v}\n' for k,v in records.items()),encoding='utf-8')
(OUT/'queries_interpro.faa').write_text(''.join(f'>{k}\n{v}\n' for k,v in (seq|alt).items()),encoding='utf-8')
print(json.dumps({'queries':len(seq),'alternative_starts':alt,'sha256':hashlib.sha256((OUT/'queries_interpro.faa').read_bytes()).hexdigest()},ensure_ascii=False))
