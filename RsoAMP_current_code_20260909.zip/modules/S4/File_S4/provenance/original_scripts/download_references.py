from pathlib import Path
import urllib.request,urllib.parse,json,csv,hashlib,datetime
OUT=Path(__file__).resolve().parent
dest=OUT/'reference';dest.mkdir(exist_ok=True)
query='reviewed:true AND taxonomy_id:33090 AND length:[20 TO 400]'
fields='accession,id,protein_name,organism_name,length,ft_signal,ft_lipid,cc_function,xref_interpro,xref_pfam,sequence'
url='https://rest.uniprot.org/uniprotkb/stream?'+urllib.parse.urlencode({'query':query,'format':'tsv','fields':fields})
req=urllib.request.Request(url,headers={'User-Agent':'RsoAMP-candidate-curation/1.0'})
with urllib.request.urlopen(req,timeout=90) as response:
    data=response.read();headers=dict(response.headers)
(dest/'reviewed_plants_20_400aa.tsv').write_bytes(data)
rows=list(csv.DictReader(data.decode('utf-8').splitlines(),delimiter='\t'))
assert len(rows)>1000,(len(rows),data[:1000])
(dest/'reviewed_plants_20_400aa.faa').write_text(''.join('>'+r['Entry']+'\n'+r['Sequence']+'\n' for r in rows),encoding='utf-8')
meta={'url':url,'query':query,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'headers':headers,'count':len(rows),'sha256':hashlib.sha256(data).hexdigest(),'scope':'Reviewed Viridiplantae proteins 20-400 aa; broad short-protein comparison database, not a complete proteome or a functional truth set.'}
(dest/'download_provenance.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(meta,ensure_ascii=True))
