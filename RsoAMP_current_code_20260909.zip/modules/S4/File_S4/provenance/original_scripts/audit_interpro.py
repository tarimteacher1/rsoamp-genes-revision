from pathlib import Path
import json, csv, hashlib, xml.etree.ElementTree as ET
from collections import defaultdict

P=Path(__file__).resolve().parent
IP=P/'interpro'
assert (IP/'COMPLETE').exists(), 'InterPro run is not complete'
fields=['query','md5','length','analysis','signature','description','start','end','score','status','date','interpro','interpro_description','go','pathways']
rows=[]
for line in (IP/'queries.tsv').read_text().splitlines():
    f=line.split('\t')
    assert 11<=len(f)<=15, len(f)
    rows.append(dict(zip(fields,f+['-']*(15-len(f)))))
root=ET.parse(IP/'queries.xml').getroot()
local=lambda e:e.tag.rsplit('}',1)[-1]
xml_ids=set()
for e in root.iter():
    if local(e)=='xref':
        v=e.attrib.get('id','')
        if v.startswith(('R1M6_CAND','RSO_','CTRL_','ALT_CAND')):xml_ids.add(v)
seqs={}
for l in (P/'queries_interpro.faa').read_text().splitlines():
    if l.startswith('>'):q=l[1:].split()[0];seqs[q]=''
    else:seqs[q]+=l.strip()
assert set(seqs)==xml_ids,(set(seqs)-xml_ids,xml_ids-set(seqs))
by=defaultdict(list)
for r in rows:
    assert r['query'] in seqs
    assert int(r['length'])==len(seqs[r['query']])
    assert r['md5'].lower()==hashlib.md5(seqs[r['query']].encode()).hexdigest()
    by[r['query']].append(r)
result={'input_sequences':len(seqs),'xml_sequences':len(xml_ids),'tsv_rows':len(rows),
        'analyses_with_hits':sorted(set(r['analysis'] for r in rows)),
        'queries':{q:{'length':len(seq),'matches':by[q],
                    'interpro_entries':sorted(set((r['interpro'],r['interpro_description']) for r in by[q] if r['interpro']!='-'))}
                   for q,seq in seqs.items()}}
(IP/'audit.json').write_text(json.dumps(result,indent=2))
with (IP/'matches_annotated.tsv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=fields,delimiter='\t');w.writeheader();w.writerows(rows)
for q,v in result['queries'].items():
    print(q, v['interpro_entries'])
    for r in v['matches']:print(' ',r['analysis'],r['signature'],r['description'],r['start'],r['end'],r['score'])
