from pathlib import Path
import csv, json, re, hashlib, itertools, collections, shutil

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent
REMOTE = ROOT/'Genes_lab_handoff_20260908/03_Remote_Results_20260908'
REV = ROOT/'Genes_lab_handoff_20260908/02_Workspace/9_2_major_revision/revision_R1_20260902'
DEEP = ROOT/'R1M6_深入分类_20260908'
FULL = REMOTE/'r1_m6_full_read_validation_20260905'
M2 = ROOT/'nsLTP_统一审核_20260908'
SOURCES = {}

def register(p):
    p=Path(p); SOURCES[str(p.relative_to(ROOT))]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}; return p
def j(p): return json.loads(register(p).read_text(encoding='utf-8-sig'))
def t(p): return list(csv.DictReader(register(p).open(encoding='utf-8-sig'),delimiter='\t'))
def f(p):
    out={}
    for l in register(p).read_text(encoding='utf-8-sig').splitlines():
        if l.startswith('>'): key=l[1:].split()[0]; assert key not in out; out[key]=''
        elif l.strip():out[key]+=l.strip().upper()
    return out
def write_tsv(name, rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as h:
        w=csv.DictWriter(h,fieldnames=fields,delimiter='\t',lineterminator='\n'); w.writeheader(); w.writerows(rows)
def write_fasta(name, rows):
    with (OUT/name).open('w',encoding='ascii',newline='\n') as h:
        for q,s in rows:
            h.write('>'+q+'\n'+'\n'.join(s[i:i+70] for i in range(0,len(s),70))+'\n')
def sha(s):return hashlib.sha256(s.encode()).hexdigest() if s else ''
def revcomp(s):return s.translate(str.maketrans('ACGTN','TGCAN'))[::-1]
CODE={''.join(c):aa for c,aa in zip(itertools.product('TCAG',repeat=3),'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG')}
def translate(s):assert len(s)%3==0; return ''.join(CODE.get(s[i:i+3],'X') for i in range(0,len(s),3))
def interval(r):return r['chrom'],int(r['start']),int(r['end']),r['strand']
def overlaps(a,b):return a[0]==b[0] and a[1]<=b[2] and b[1]<=a[2]
def same_strand_overlap(a,b):return overlaps(a,b) and a[3]==b[3]

old=t(REV/'03_annotation_rescue/final_amp_primary_catalogue.tsv')
allold=t(REV/'03_annotation_rescue/final_amp_catalogue_all_audited_members.tsv')
oldprot=f(REV/'03_annotation_rescue/final_amp_primary_catalogue.faa')
m2=t(M2/'analysis/shared_candidate_evidence_matrix.tsv')
m2r=[x for x in m2 if x['species']=='rso']
m2a=[x for x in m2r if x['new_class'].startswith('A')]
m2by={x['protein_id']:x for x in m2r}
m2prot=f(M2/'analysis/rso_accepted_nsltp.faa')
m2_final_main=t(ROOT/'成员判定收尾_20260909/审核_M2/M2_primary_39_26.tsv')
m2_final_ext=t(ROOT/'成员判定收尾_20260909/审核_M2/M2_extended_40_27.tsv')
m2main_ids={x['protein_id'] for x in m2_final_main if x['species']=='rso'}
m2ext_ids={x['protein_id'] for x in m2_final_ext if x['species']=='rso'}
assert len(m2main_ids)==39 and len(m2ext_ids)==40
m2live=j(ROOT/'成员判定收尾_20260909/审核_M2/all99_live_source_extract.json')['rso']
m2cds=[]
for l in m2live['gff_rows']:
    z=l.split('\t')
    if z[2]!='CDS':continue
    at=dict(x.split('=',1) for x in z[8].split(';') if '=' in x)
    m2cds.append((at.get('Parent',''),(z[0],int(z[3]),int(z[4]),z[6])))
m5=t(ROOT/'R1M5_审查_20260908/六个位点_逐项审查.tsv')
m5coords=[]
for x in m5:
    q=re.fullmatch(r'(\w+):(\d+)-(\d+)\(([+-])\)',x['实际编码片段区间'])
    m5coords.append({'member_id':x['历史编号'],'chrom':q[1],'start':q[2],'end':q[3],'strand':q[4],'length_aa':x['片段长度aa']})

dec={x['id']:x for x in j(DEEP/'final_decisions.json')}
facts={x['id']:x for x in j(DEEP/'evidence_summary.json')}
gen=j(DEEP/'genome_regions.json')
manifest={x['id']:x for x in j(DEEP/'candidate_manifest.json')}
disc=t(REMOTE/'r1_m6_mapped_rescue_20260905/run_retry1/results/candidate_evidence.tsv')
ov=t(REMOTE/'r1_m6_overlap_model_audit_20260905_retry1/review/overlap_model_family_review.tsv')
rec=t(FULL/'recursive_genome_screen/recursive_genome_cluster_audit.tsv')
recm=t(REMOTE/'r1_m6_recursive_family_audit_20260905/prep/recursive_pf00234_manifest.tsv')
recprot=f(REMOTE/'r1_m6_recursive_family_audit_20260905/prep/recursive_pf00234_start_stop.faa')
fragprot=f(FULL/'prep/intergenic_stop_delimited_orfs.faa')
ovprot=f(REMOTE/'r1_m6_overlap_model_audit_20260905_retry1/prep/overlap_complete_start_stop_suborfs.faa')
ovall=f(REMOTE/'r1_m6_overlap_model_audit_20260905_retry1/prep/overlap_all_stop_delimited_orfs.faa')
assert len(old)==63 and len(m2a)==40 and len(m5coords)==6 and len(disc)==107

names={'R1M6_CAND03':'RsLTP41','R1M6_CAND04':'RsDEF15','R1M6_CAND05':'RsDEF16','R1M6_CAND06':'RsDEF17','R1M6_CAND07':'RsDEF18','R1M6_CAND09':'RsDEF19','R1M6_CAND10':'RsDEF20'}
assert not (set(names.values()) & {r['member_id'] for r in allold})
prot={}; cds={}
for slug in ['high_confidence','supplementary_candidates','connection_model']:
    prot.update(f(DEEP/'交付/候选序列与模型'/f'{slug}.protein.faa'))
    cds.update(f(DEEP/'交付/候选序列与模型'/f'{slug}.cds_with_stop.fna'))

validation=[]
for q in prot:
    fact=facts[q]; model=fact['model']; g=gen[q]; seq=''
    cum=0
    for a,b in (map(int,z.split('-')) for z in model['genomic_cds_segments_transcript_order'].split(';')):
        s=g['sequence'][a-g['start1']:b-g['start1']+1]
        if model['strand']=='-':s=revcomp(s)
        seq+=s
    assert seq==cds[q][:-3]==fact['cds_nt']
    assert translate(cds[q])==prot[q]+'*'
    assert prot[q]==model['protein_sequence']
    validation.append({'id':q,'cds_extraction_matches_final_fasta':True,'translation_matches_protein':True,'cds_nt_excluding_stop':len(seq),'protein_aa':len(prot[q]),'cds_with_stop_sha256':sha(cds[q]),'protein_sha256':sha(prot[q])})

def dedup_fields(chrom,start,end,strand,seq=''):
    a=(chrom,int(start),int(end),strand)
    m2iv=[dict(x,chrom=x['chromosome']) for x in m2a]
    oldmatch=[x['member_id'] for x in old if overlaps(a,interval(x))]
    oldsame=[x['member_id'] for x in old if same_strand_overlap(a,interval(x))]
    newmatch=[x['member_id'] or x['protein_id'] for x in m2iv if same_strand_overlap(a,interval(x))]
    historical=[x['member_id'] for x in m5coords if overlaps(a,interval(x))]
    peps=[key for key,s in oldprot.items() if seq and s==seq]
    peps2=[key for key,s in m2prot.items() if seq and s.rstrip('*')==seq]
    mainmatch=[x['member_id'] or x['protein_id'] for x in m2iv if x['protein_id'] in m2main_ids and same_strand_overlap(a,interval(x))]
    livepeps=[key for key,s in m2live['sequences'].items() if seq and s.rstrip('*')==seq]
    return {'old63_any_strand_interval_overlap':';'.join(oldmatch),'old63_same_strand_overlap':';'.join(oldsame),'M2_A40_same_strand_overlap':';'.join(newmatch),'M2_primary39_same_strand_overlap':';'.join(mainmatch),'M5_six_any_strand_interval_overlap':';'.join(historical),'old63_exact_protein_match':';'.join(peps),'M2_A40_exact_protein_match':';'.join(peps2),'M2_live54_exact_protein_match':';'.join(livepeps)}

rows=[]
for q,fact in facts.items():
    d=dec[q];m=fact['model'];reason=d['family_evidence']+' '+d['key_reason'];remaining=d['remaining']
    if q=='R1M6_CAND08':
        reason='共用CAND09第一段CDS和CAND07第二段CDS；79 aa前体与CAND07有第3位A/T差异（78/79一致），不能使用旧说明的“完全相同”。'+d['key_reason']
    row={'candidate_id':q,'original_model_id':m['transcript_id'],'original_orf_id':m['orf_id'],'suggested_stable_gene_name':names.get(q,''),'family':'nsLTP' if q in ['R1M6_CAND02','R1M6_CAND03'] else 'Defensin' if q!='R1M6_CAND01' else 'defensin-like','identity_tier':d['disposition'],'subtype':'LTPg_computational' if q=='R1M6_CAND03' else '', 'count_as_new_gene':int(q in names),'chrom':m['chrom'],'start':m['model_start'],'end':m['model_end'],'strand':m['strand'],'coordinate_basis':'transcript_span_1based_inclusive','cds_segments_transcript_order':m['genomic_cds_segments_transcript_order'],'protein_aa':len(prot[q]),'protein_sequence':prot[q],'protein_sha256':sha(prot[q]),'cds_with_stop_sequence':cds[q],'cds_with_stop_sha256':sha(cds[q]),'family_model_reason':reason,'short_complete_CDS_libraries_of9':fact['short_models_complete_cds_samples'],'exact_splice_fragments':';'.join(map(str,fact['junction_fragments'])),'qualified_local_long_reads':fact['long_local_structure_reads'],'branch':'mapped_intergenic_priority_deep_classification','remaining':remaining,'source':'R1M6_深入分类_20260908/evidence_summary.json;final_decisions.json;交付/候选序列与模型'}
    row.update(dedup_fields(m['chrom'],m['model_start'],m['model_end'],m['strand'],prot[q]));rows.append(row)
    assert not any(row[k] for k in ['old63_any_strand_interval_overlap','M2_A40_same_strand_overlap','M5_six_any_strand_interval_overlap','old63_exact_protein_match','M2_A40_exact_protein_match'])

# Four unprioritized ORFs represent three intergenic loci; two M6MERGE.16714 models share a locus.
for x in disc:
    if x['model_origin']!='INTERGENIC_CANDIDATE' or x['transcript_id'] in {f['transcript'] for f in facts.values()}:continue
    q=x['orf_id'];s=fragprot[q]
    row={'candidate_id':q,'original_model_id':x['transcript_id'],'original_orf_id':q,'suggested_stable_gene_name':'','family':'Defensin-like' if 'PF00304' in x['family_HMMs'] else 'nsLTP-like_similarity_only','identity_tier':'supplementary_incomplete_ORF','count_as_new_gene':0,'chrom':x['chrom'],'start':x['start'],'end':x['end'],'strand':x['strand'],'coordinate_basis':'transcript_span_1based_inclusive','protein_aa':len(s),'protein_sequence':s,'protein_sha256':sha(s),'cds_with_stop_sequence':'','family_model_reason':'发现阶段未形成完整起止ORF；保留片段/低支持状态，不据短片段相似性计基因。','branch':'mapped_intergenic_nonpriority','remaining':'尚未完成完整编码模型与独立reads审核。M6MERGE.16714.1/2属于同一坐标位点，并与REC015对应。','source':'r1_m6_mapped_rescue_20260905/run_retry1/results/candidate_evidence.tsv'}
    row.update(dedup_fields(x['chrom'],x['start'],x['end'],x['strand'],s));rows.append(row)

windows=f(FULL/'recursive_genome_screen/unannotated_cluster_windows_2kb.fasta')
win={k.split('|')[0]:(int(k.rsplit(':',1)[1].split('-')[0]),s) for k,s in windows.items()}
rec_by={x['recursive_cluster_id']:x for x in rec}
rec_m_by={x['recursive_cluster_id']:x for x in recm}
rec_seqs={};rec_nts={}
for q in ['R1M6_REC003','R1M6_REC020','R1M6_REC025','R1M6_REC029','R1M6_REC030','R1M6_REC031']:
    r=rec_by[q];m=rec_m_by.get(q);p='';nt='';a=int(r['start']);b=int(r['end'])
    if m:
        a=int(m['genomic_start']);b=int(m['genomic_end']);p=recprot[m['output_id']+'|start_stop'];start0,w=win[q]
        nt=w[a-start0-1:b-start0]
        if r['strand']=='-':nt=revcomp(nt);stop=revcomp(w[a-start0-4:a-start0-1])
        else:stop=w[b-start0:b-start0+3]
        assert translate(nt)==p and stop==m['downstream_stop_codon'];nt+=stop
        rec_seqs[q]=p;rec_nts[q]=nt
    if q in ['R1M6_REC003','R1M6_REC020','R1M6_REC029','R1M6_REC030']:
        family='nsLTP';tier='supplementary_genomic_ORF_family_supported'
        reason='IPR000528（PRINTS PR00382/PANTHER）与CDD cd01960支持nsLTP身份，局部基因组可重取完整起止ORF；尚未具备十优先模型同等级的完整转录模型/reads审核。'
        rem='未完成独立reads、模型起点及转录结构审核，暂不升级为主目录。'
        if q=='R1M6_REC003':rem+=' DeepSig未检出信号肽而TMbed标出1–33信号区，前体边界/分泌预测有分歧。'
    elif q=='R1M6_REC031':
        family='AAI_LTP_seed_storage_superfamily';tier='supplementary_short_genomic_ORF';reason='72 aa短ORF仅有PF14368/IPR016140/IPR043325等广义证据；不能把这些当nsLTP特异身份。';rem='缺完整8CM及nsLTP特异注释，缺逐位点reads与结构审核；不纳入。'
    else:
        family='defensin-like';tier='supplementary_genomic_homology_cluster';reason='与优先defensin同源的基因组簇，当前局部ORF筛查未给出可接受完整编码模型；不是额外完整基因。';rem='无可导出的合格完整模型；不能把tblastn簇或不完整miniprot模型计为基因。'
    row={'candidate_id':q,'original_model_id':m['output_id'] if m else 'homology_cluster_only','original_orf_id':m['source_orf_id'] if m else '', 'suggested_stable_gene_name':'','family':family,'identity_tier':tier,'count_as_new_gene':0,'chrom':r['chrom'],'start':a,'end':b,'strand':r['strand'],'coordinate_basis':'CDS_excluding_stop_1based_inclusive' if m else 'homology_cluster_1based_inclusive','cds_segments_transcript_order':f'{a}-{b}' if m else '', 'protein_aa':len(p) if p else '', 'protein_sequence':p,'protein_sha256':sha(p),'cds_with_stop_sequence':nt,'cds_with_stop_sha256':sha(nt),'family_model_reason':reason,'branch':'recursive_genome_screen_and_family_audit','remaining':rem,'source':'r1_m6_full_read_validation_20260905/recursive_genome_screen; r1_m6_recursive_family_audit_20260905'}
    row.update(dedup_fields(r['chrom'],a,b,r['strand'],p));rows.append(row)

write_tsv('M6_全部新增候选判定.tsv',rows)
write_tsv('M6_七个可合并成员.tsv',[r for r in rows if r['count_as_new_gene']])
write_tsv('M6_十个优先模型.tsv',rows[:10])
cross=[]
for q, fact in facts.items():
    m=fact['model'];segments=[(m['chrom'],int(a),int(b),m['strand']) for a,b in (z.split('-') for z in m['genomic_cds_segments_transcript_order'].split(';'))]
    hits=sorted({pid for pid,iv in m2cds if any(same_strand_overlap(s,iv) for s in segments)})
    assert not hits
    # Identical CDS implies identical translated peptide. All ten peptides differ from old63/M2,
    # and their lengths differ from all six M5 peptides, so no exact CDS duplicate is possible.
    assert all(len(prot[q])!=int(x['length_aa']) for x in m5coords)
    cross.append({'candidate_id':q,'M2_live54_same_strand_CDS_overlapping_protein_ids':';'.join(hits),'old63_exact_CDS_identity':'excluded_by_different_translated_protein','M2_extended40_exact_CDS_identity':'excluded_by_different_translated_protein','M5_six_exact_CDS_or_protein_identity':'excluded_by_different_protein_lengths','M5_six_interval_overlap':'none','M6_reference_CDS_vs_genome_and_protein':'exact_match','scope':'No nucleotide homology alignment was needed or performed; different CDS can still encode homologous proteins at independent loci.'})
write_tsv('M6_十优先模型_CDS与历史目录去重.tsv',cross)

overlap_rows=[]
for x in ov:
    r=dict(x);m=m2by.get(x['reference_id']);s=ovprot.get(x['orf_id']+'|start_stop',ovall.get(x['orf_id'],''))
    r.update({'current_M2_reference_class':m['new_class'] if m else 'not_in_M2_nsLTP_pool','current_M2_reference_member':m['member_id'] if m else '', 'count_as_new_gene':0,'protein_sequence':s,'protein_sha256':sha(s)})
    r['current_M2_tier_20260909']='primary_39' if x['reference_id'] in m2main_ids else 'extended_only' if x['reference_id'] in m2ext_ids else 'outside_nsLTP_roster'
    if m:
        r['current_disposition']='existing_locus_transcript_variant; use_current_M2_identity; no_new_gene'
        r['current_reason']='参考位点身份以M2新审核替换冻结旧标签；额外转录模型和短肽变体不另计独立位点，也不自动替换注释代表模型。'
    else:
        r['current_disposition']=x['family_review_status'];r['current_reason']=x['decision_reason']
    r.update(dedup_fields(x['chrom'],x['start'],x['end'],x['strand'],s));overlap_rows.append(r)
write_tsv('M6_32重叠模型_对照新M2.tsv',overlap_rows)

known=[]
oldby={r['protein_id']:r for r in old}
for x in disc:
    if x['model_origin']!='KNOWN_AMP_LOCUS':continue
    r=dict(x);m=m2by.get(x['reference_id']);oldr=oldby.get(x['reference_id'])
    r.update({'current_member_id':m['member_id'] if m else oldr['member_id'] if oldr else '', 'current_identity':m['new_class'] if m else oldr['family'] if oldr else 'requires_reference_crosswalk','count_as_new_gene':0,'current_disposition':'known_locus_expression_or_model_support_not_novel_gene'})
    known.append(r)
write_tsv('M6_61已知位点ORF支持.tsv',known)

rec_out=[]
for x in rec:
    r=dict(x);q=x['recursive_cluster_id'];match=[z for z in rows if z['candidate_id']==q]
    r['current_disposition']=match[0]['identity_tier'] if match else 'corresponds_to_priority_models' if x['overlapping_priority_models'] else 'existing_annotation_no_new_gene' if x['overlapping_frozen_transcripts'] else 'fragment_models_M6MERGE.16714.1_and_2_no_new_gene'
    r['current_M2_references']=';'.join(m2by[i]['member_id']+':'+m2by[i]['new_class'] for i in x['overlapping_frozen_transcripts'].split(';') if i in m2by)
    r['count_as_additional_gene']=0;rec_out.append(r)
write_tsv('M6_31递归同源簇_分支去重.tsv',rec_out)

# Export only seven accepted reference models as merge candidates; leave all source files intact.
write_fasta('M6_merge_ready.protein.faa',[(names[q]+' alias='+q+' original_model='+facts[q]['transcript'],prot[q]) for q in names])
write_fasta('M6_merge_ready.cds_with_stop.fna',[(names[q]+' alias='+q+' original_model='+facts[q]['transcript'],cds[q]) for q in names])
gff_source=register(DEEP/'交付/候选序列与模型/high_confidence.provisional_models.gff3')
gff_lines=[]
for l in gff_source.read_text().splitlines():
    if l.startswith('# Provisional'):l='# Stable proposed names; source model aliases retained. CDS excludes terminal stop codon. Prepared for catalogue merge.'
    if not l.startswith('#'):
        q=re.search(r'R1M6_CAND\d+',l)[0]
        l=l.replace(q,names[q])
        cols=l.split('\t')
        if cols[2]=='gene':l+=';Alias='+q+';family='+('nsLTP' if q=='R1M6_CAND03' else 'Defensin')
        if cols[2]=='CDS':
            # Verify GFF phase in transcription order below.
            pass
    gff_lines.append(l)
(OUT/'M6_merge_ready.gff3').write_text('\n'.join(gff_lines)+'\n',encoding='utf-8')
for q,name in names.items():
    entries=[l.split('\t') for l in gff_lines if not l.startswith('#') and ('Parent='+name+'.t1') in l and l.split('\t')[2]=='CDS']
    count=0;seq='';g=gen[q]
    for z in sorted(entries,key=lambda z:int(z[3]),reverse=facts[q]['model']['strand']=='-'):
        assert int(z[7])==(3-count%3)%3
        a,b=int(z[3]),int(z[4]);ss=g['sequence'][a-g['start1']:b-g['start1']+1]
        if z[6]=='-':ss=revcomp(ss)
        seq+=ss;count+=len(ss)
    assert seq==cds[q][:-3]
write_fasta('M6_supplementary_priority.protein.faa',[(q,prot[q]) for q in ['R1M6_CAND01','R1M6_CAND02']])
write_fasta('M6_supplementary_priority.cds_with_stop.fna',[(q,cds[q]) for q in ['R1M6_CAND01','R1M6_CAND02']])
write_fasta('M6_connection_not_a_gene.protein.faa',[('R1M6_CAND08',prot['R1M6_CAND08'])])
write_fasta('M6_connection_not_a_gene.cds_with_stop.fna',[('R1M6_CAND08',cds['R1M6_CAND08'])])
write_fasta('M6_recursive_supplementary_genomic_ORFs.protein.faa',list(rec_seqs.items()))
write_fasta('M6_recursive_supplementary_genomic_ORFs.cds_with_stop.fna',list(rec_nts.items()))
shutil.copy2(register(DEEP/'交付/候选序列与模型/CAND02_M35_sensitivity_only.faa'),OUT/'CAND02_M35_sensitivity_only.faa')

diff=[(i+1,a,b) for i,(a,b) in enumerate(zip(prot['R1M6_CAND07'],prot['R1M6_CAND08'])) if a!=b]
assert diff==[(3,'T','A')]
write_tsv('M6_旧结论纠正.tsv',[{'item':'CAND07_vs_CAND08_identity','old_claim':'蛋白完全相同','current_verified':'79 aa中第3位T/A不同，78/79一致；信号区后核心相同','evidence':'最终交付FASTA、evidence_summary、queries_interpro输入及本次CDS翻译均一致','impact':'CAND08连接CAND09第一CDS和CAND07第二CDS，不另计基因；七主成员不变'}, {'item':'32_overlap_frozen_nsLTP','old_claim':'旧M2边界或排除标签冻结不变','current_verified':'逐行链接20260908统一M2身份','evidence':'M6_32重叠模型_对照新M2.tsv','impact':'属于已有位点/转录变体，不新增独立基因'}])

residual=t(REV/'04_unmapped_reads/unmapped_amp_search_summary.tsv')
residual_hits=t(REV/'04_unmapped_reads/unmapped_amp_hits.tsv')
assert len(residual_hits)==23126
write_tsv('M6_分支范围与剩余事项.tsv',[
 {'branch':'genome_unmapped_residual_read_similarity','audited_units':23126,'unit':'read/mate_hit_rows','new_gene_additions':0,'closed_at_current_evidence':'read-level result only','remaining':'这些命中不是23126基因或完整ORF；未做residual转录组装/完整新基因判定，不能声称排尽遗漏。','source':'04_unmapped_reads/unmapped_amp_search_summary.tsv'},
 {'branch':'mapped_discovery_known','audited_units':61,'unit':'ORF_rows','new_gene_additions':0,'closed_at_current_evidence':'existing-locus support','remaining':'按已有注释/M2身份解释。','source':'M6_61已知位点ORF支持.tsv'},
 {'branch':'mapped_discovery_overlap','audited_units':32,'unit':'ORF/model_rows','new_gene_additions':0,'closed_at_current_evidence':'no_new_locus','remaining':'17条边界相关模型用新M2解释；各模型不自动替换参考编码模型。','source':'M6_32重叠模型_对照新M2.tsv'},
 {'branch':'mapped_intergenic_priority','audited_units':10,'unit':'models_at9_independent_loci_plus_connection','new_gene_additions':7,'closed_at_current_evidence':'7 main;2 supplementary;1 connection','remaining':'CAND01家族边界，CAND02起点，CAND08复杂连接；无活性验证。','source':'M6_十个优先模型.tsv'},
 {'branch':'mapped_intergenic_nonpriority','audited_units':4,'unit':'ORFs_at3_loci','new_gene_additions':0,'closed_at_current_evidence':'supplementary_fragments','remaining':'没有完整起止ORF；16714.1/2为同一位点且与REC015重复。','source':'M6_全部新增候选判定.tsv'},
 {'branch':'recursive_genome_screen','audited_units':31,'unit':'homology_clusters_not_genes','new_gene_additions':0,'closed_at_current_evidence':'10 priority matches;14 frozen annotation;1 fragment-model locus;6 supplementary clusters','remaining':'六簇未完成与十优先模型同等reads/完整模型审核；四簇有特异nsLTP身份但不自动纳入。','source':'M6_31递归同源簇_分支去重.tsv'}])

outsummary={'status':'M6_reconciliation_complete_with_explicit_supplementary_boundaries','main_new_genes':7,'main_new_Defensin':6,'main_new_nsLTP_LTPg':1,'priority_supplementary_candidates':2,'connection_model_not_gene':1,'nonpriority_intergenic_ORFs':4,'nonpriority_intergenic_loci':3,'recursive_supplementary_clusters':6,'recursive_family_supported_nsLTP_ORFs':4,'recursive_exported_start_stop_ORFs':5,'discovery_ORFs':107,'discovery_transcript_models':len({x['transcript_id'] for x in disc}),'known_locus_ORF_rows':61,'overlap_ORF_rows':32,'recursive_clusters':31,'old63_overlap_for_priority_models':0,'M2_A40_overlap_for_priority_models':0,'M5_six_overlap_for_priority_models':0,'priority_sequence_translation_checks':validation,'recursive_genomic_translation_checks':len(rec_seqs),'GFF_CDS_phase_and_extraction_checks':7,'CAND07_CAND08_difference':diff,'fresh_full_read_remapping_performed':False,'remote_calls_performed_by_this_script':False,'source_scope':'local source evidence only; input live genomic reference subsequences were already in the 20260908 deep audit','note':'The 20-row candidate table is 10 priority models +4 fragment ORFs +6 recursive clusters; these are not 20 independent genes.'}
outsummary.update({'M2_current_primary39_interval_overlap_for_priority_models':0,'M2_live54_CDS_same_strand_overlaps_for_priority_models':0,'M2_current_primary_size':39,'M2_current_extended_size':40,'M6_supplementary_locus_entries_excluding_connection':11,'M6_supplementary_locus_entries_note':'2 priority +3 fragmented-model loci +6 recursive clusters; not 11 confirmed genes'})
(OUT/'M6_核对计数与验证.json').write_text(json.dumps(outsummary,ensure_ascii=False,indent=2),encoding='utf-8')
write_tsv('M6_输入文件_SHA256.tsv',[{'path':p,**v} for p,v in sorted(SOURCES.items())])
print(json.dumps({k:v for k,v in outsummary.items() if k!='priority_sequence_translation_checks'},ensure_ascii=False,indent=2))
