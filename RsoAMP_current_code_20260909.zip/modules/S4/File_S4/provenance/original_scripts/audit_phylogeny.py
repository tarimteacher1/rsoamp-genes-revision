from pathlib import Path
import re,json,csv,hashlib
from collections import defaultdict
OUT=Path(__file__).resolve().parent
P=OUT/'phylogeny'
def parse_newick(s):
    tokens=re.findall(r"'[^']*'|[(),:;]|[^\s(),:;]+",s);i=0
    def node():
        nonlocal i
        n={'children':[],'name':'','length':0.0}
        if tokens[i]=='(':
            i+=1;n['children'].append(node())
            while tokens[i]==',':i+=1;n['children'].append(node())
            assert tokens[i]==')';i+=1
        if i<len(tokens) and tokens[i] not in ',():;':n['name']=tokens[i].strip("'");i+=1
        if tokens[i]==':':i+=1;n['length']=float(tokens[i]);i+=1
        n['leaves']=frozenset().union(*(x['leaves'] for x in n['children'])) if n['children'] else frozenset([n['name']])
        return n
    root=node();assert tokens[i]==';';return root
def walk(n):
    yield n
    for c in n['children']:yield from walk(c)
labels={r['tree_id']:r for r in csv.DictReader((P/'reference_manifest.tsv').read_text(encoding='utf-8').splitlines(),delimiter='\t')}
panels=json.loads((P/'panel_summary.json').read_text())
all_records=[];nearest=[];stable=[];stats=[]
for family,info in panels.items():
    paths=[p for p in P.glob(f'{family}.*.*.treefile')
           if p.with_suffix('.iqtree').exists() and p.with_suffix('.log').exists()
           and 'Date and Time:' in p.with_suffix('.log').read_text()]
    bysplit=defaultdict(dict)
    allsets=[]
    for p in paths:
        strategy=p.name[len(family)+1:-len('.treefile')]
        tree=parse_newick(p.read_text());universe=tree['leaves'];allsets.append(universe)
        assert len(universe)==info['total_sequences'],(p,len(universe),info)
        edges=[]
        for n in walk(tree):
            if n is tree or not n['children']:continue
            match=re.fullmatch(r'([\d.]+)/([\d.]+)',n['name'])
            sh,uf=map(float,match.groups()) if match else (None,None)
            a=n['leaves'];b=universe-a
            canonical=tuple(sorted(a)) if (len(a),sorted(a))<=(len(b),sorted(b)) else tuple(sorted(b))
            key='|'.join(canonical)
            rec={'family':family,'strategy':strategy,'split_key':key,'sh_alrt':sh,'ufboot':uf,'pass':sh is not None and sh>=80 and uf>=95,'side':sorted(a),'complement':sorted(b)}
            edges.append(rec);all_records.append(rec);bysplit[key][strategy]=rec
        for q in info['queries']:
            eligible=[]
            for e in edges:
                side=e['side'] if q in e['side'] else e['complement']
                reference_ids=[x for x in side if x.startswith('REF_')]
                if e['pass'] and reference_ids:
                    eligible.append((len(side),len(reference_ids),side,e,reference_ids))
            if eligible:
                _,_,side,e,rids=min(eligible,key=lambda x:(x[0],x[1],x[2]))
                nearest.append({'family':family,'strategy':strategy,'query':q,'size':len(side),'sh_alrt':e['sh_alrt'],'ufboot':e['ufboot'],'members':side,'reference_labels':{x:labels[x]['label'] for x in rids}})
            else:nearest.append({'family':family,'strategy':strategy,'query':q,'size':None,'members':[],'reference_labels':{}})
        stats.append({'family':family,'strategy':strategy,'taxa':len(universe),'jointly_supported_edges':sum(e['pass'] for e in edges),'internal_edges':len(edges)})
    assert all(x==allsets[0] for x in allsets)
    for key,es in bysplit.items():
        if len(es)==4 and all(e['pass'] for e in es.values()):
            first=next(iter(es.values()))
            stable.append({'family':family,'split_key':key,'side':first['side'],'complement':first['complement'],'support_by_strategy':{k:[v['sh_alrt'],v['ufboot']] for k,v in es.items()}})
(P/'split_audit.json').write_text(json.dumps({'method':'All-taxon unrooted bipartitions; joint SH-aLRT>=80 and UFBoot>=95; nearest supported side containing a query plus at least one reviewed reference is descriptive and may be broad. It is not a formal orthology, rooting, or subfamily call.','stats':stats,'nearest_supported_reference_neighborhood':nearest,'stable_4_of_4_splits':stable,'all_edges':all_records},indent=2))
with (P/'nearest_supported_neighborhood.tsv').open('w',newline='') as f:
    w=csv.writer(f,delimiter='\t');w.writerow(['family','strategy','query','size','SH_aLRT','UFBoot','reference_labels','members'])
    for n in nearest:w.writerow([n['family'],n['strategy'],n['query'],n['size'],n.get('sh_alrt'),n.get('ufboot'),json.dumps(n['reference_labels']),';'.join(n['members'])])
print(json.dumps({'trees':len(stats),'stable_splits':len(stable),'stats':stats},indent=2))
