#!/usr/bin/env bash
set -euo pipefail
TASK=/path/to/rso_project/r1_m6_deep_classification_20260908
cd "$TASK"
exec >logs/reference_sensitivity.log 2>&1
trap 'code=$?; echo "$code" > reference_sensitivity.exitcode' EXIT
BLAST=/path/to/user/tools/miniconda3/envs/blast/bin
OLD=/path/to/rso_project/revision_R1_20260902/01_nslTP_curation/reference/combined_labeled_reference.faa
"$BLAST/makeblastdb" -in "$OLD" -dbtype prot -out blast/original_curated_panel
"$BLAST/blastp" -query queries_interpro.faa -db blast/original_curated_panel \
 -evalue 10 -seg yes -soft_masking true -comp_based_stats 2 -matrix BLOSUM62 -max_target_seqs 5000 -num_threads 2 \
 -outfmt '6 qseqid sseqid pident length qlen slen qstart qend sstart send qcovhsp evalue bitscore qseq sseq' \
 -out blast/queries_vs_original_panel.same_settings.tsv
date -Iseconds > reference_sensitivity.COMPLETE
