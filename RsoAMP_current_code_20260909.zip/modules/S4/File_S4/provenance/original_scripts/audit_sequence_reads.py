from pathlib import Path
import sys,json,csv
from collections import defaultdict,Counter
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT.parent/'R1M6_候选审核_20260908/tools/pysam_linux'))
import pysam
DATA=json.loads((OUT/'candidate_manifest.json').read_text())
GENOME=json.loads((OUT/'genome_regions.json').read_text())
BASE=OUT.parent/'Genes_lab_handoff_20260908/03_Remote_Results_20260908/r1_m6_full_read_validation_20260905'
COMP=str.maketrans('ACGTN','TGCAN')
def strand(r):
    if r.is_read1:return '+' if r.is_reverse else '-'
    if r.is_read2:return '-' if r.is_reverse else '+'
    return r.get_tag('XS') if r.has_tag('XS') else None
def junctions(r):
    pos=r.reference_start;ops=r.cigartuples or []
    for i,(op,n) in enumerate(ops):
        if op==3:
            a=ops[i-1][1] if i and ops[i-1][0] in (0,7,8) else 0
            b=ops[i+1][1] if i+1<len(ops) and ops[i+1][0] in (0,7,8) else 0
            yield pos,pos+n,a,b
        if op in (0,2,3,7,8):pos+=n
summaries=[];sample_rows=[];junction_rows=[];base_rows=[]
for r in DATA:
    m=r['model'];g=GENOME[r['id']];exons=r['exons_0based_halfopen']
    txpos=[p for a,b in exons for p in range(a,b)]
    if m['strand']=='-':txpos=txpos[::-1]
    cdspos=txpos[int(m['cds_start_in_transcript_1based'])-1:int(m['cds_end_in_transcript_1based'])]
    stoppos=txpos[int(m['cds_end_in_transcript_1based']):int(m['cds_end_in_transcript_1based'])+3]
    target=set(cdspos+stoppos)
    ref={p:g['sequence'][p-(g['start1']-1)] for p in target}
    txseq=''.join(ref[p] for p in cdspos+stoppos)
    if m['strand']=='-':txseq=txseq.translate(COMP)
    assert txseq[:3]=='ATG' and txseq[-3:]==m['downstream_stop_codon']
    pooled=defaultdict(Counter);js_pooled=[set() for j in r['junctions_0based_halfopen']]
    for sample in sorted(r['short_read_metrics']):
        counts=defaultdict(dict);js=[set() for j in js_pooled];js_coords=[set() for j in js];stats=Counter()
        p=BASE/f'results/align/{sample}/{sample}.candidate_windows.bam'
        with pysam.AlignmentFile(str(p),'rb') as bam:
            for read in bam.fetch(m['chrom'],exons[0][0],exons[-1][1]):
                if read.is_unmapped or read.is_secondary or read.is_supplementary or read.is_qcfail:continue
                if strand(read)!=m['strand'] or not read.has_tag('NH') or read.get_tag('NH')!=1 or read.mapping_quality<20:continue
                stats['records']+=1
                stats['duplicate_flagged_records']+=read.is_duplicate
                for a,b,left,right in junctions(read):
                    if [a,b] not in r['junctions_0based_halfopen'] or min(left,right)<10:continue
                    idx=r['junctions_0based_halfopen'].index([a,b]);js[idx].add(read.query_name)
                    coord=tuple(sorted((read.reference_start,read.next_reference_start)))+(abs(read.template_length),)
                    js_coords[idx].add(coord);js_pooled[idx].add((sample,read.query_name))
                    if r['id']=='R1M6_CAND08':junction_rows.append([r['id'],sample,read.query_name,read.reference_start+1,read.next_reference_start+1,read.mapping_quality,read.get_tag('NM') if read.has_tag('NM') else '',left,right,read.cigarstring,read.query_sequence])
                qual=read.query_qualities
                if qual is None:continue
                for q,p0 in read.get_aligned_pairs(matches_only=True):
                    if p0 not in target or qual[q]<20:continue
                    v=(qual[q],read.query_sequence[q]);previous=counts[p0].get(read.query_name)
                    if previous is None or v[0]>previous[0]:counts[p0][read.query_name]=v
        cov={p:Counter(v[1] for v in counts[p].values()) for p in target}
        for p,c in cov.items():pooled[p].update(c)
        ref_supported=sum(cov[p][ref[p]]>0 for p in cdspos)
        sample_rows.append([r['id'],sample,len(cdspos),ref_supported,ref_supported/len(cdspos),min(sum(cov[p].values()) for p in cdspos),
            ';'.join(str(cov[p][ref[p]]) for p in cdspos[:3]),';'.join(str(cov[p][ref[p]]) for p in stoppos),
            ';'.join(str(len(x)) for x in js),';'.join(str(len(x)) for x in js_coords),stats['duplicate_flagged_records']])
    warnings=[]
    for p in cdspos+stoppos:
        c=pooled[p];depth=sum(c.values());rf=c[ref[p]]/depth if depth else None
        if depth>=10 and rf<.8:warnings.append({'position1':p+1,'ref':ref[p],'counts':dict(c),'reference_fraction':rf})
        base_rows.append([r['id'],m['chrom'],p+1,ref[p],depth,c['A'],c['C'],c['G'],c['T'],rf])
    summary={'id':r['id'],'cds_nt':txseq[:-3],'stop':txseq[-3:],'cds_bases':len(cdspos),
        'pooled_min_depth':min(sum(pooled[p].values()) for p in cdspos),'pooled_reference_supported_cds_bases':sum(pooled[p][ref[p]]>0 for p in cdspos),
        'pooled_start_reference_counts':[pooled[p][ref[p]] for p in cdspos[:3]],'pooled_stop_reference_counts':[pooled[p][ref[p]] for p in stoppos],
        'junction_fragments':[len(x) for x in js_pooled], 'reference_fraction_below_0_8_at_depth_ge_10':warnings}
    summaries.append(summary);print(json.dumps({k:v for k,v in summary.items() if k!='cds_nt'}),flush=True)
def tsv(name,headers,rows):
    with (OUT/name).open('w',newline='') as f:
        w=csv.writer(f,delimiter='\t');w.writerow(headers);w.writerows(rows)
tsv('read_sequence_per_sample.tsv',['candidate','sample','cds_bases','reference_supported_bases','fraction','minimum_depth','start_ref_counts','stop_ref_counts','junction_fragments','junction_endpoint_patterns','duplicate_flagged_records'],sample_rows)
tsv('CAND08_junction_records.tsv',['candidate','sample','read_id','start1','mate_start1','mapq','NM','left_anchor','right_anchor','cigar','read_sequence'],junction_rows)
tsv('pooled_cds_base_support.tsv',['candidate','chrom','position1','ref','depth','A','C','G','T','ref_fraction'],base_rows)
(OUT/'sequence_read_audit.json').write_text(json.dumps({'method':'NH=1 primary non-QC-fail transcript-strand concordant; MAPQ>=20, baseQ>=20; overlapping mates deduplicated per QNAME/position selecting highest-quality base. Depths are fragment support, not independent molecules; variation flags are descriptive, not genotype calls. Reference CDS and downstream stop extracted from original genome through transcript coordinates.','pysam':pysam.__version__,'candidates':summaries},indent=2))
