#!/usr/bin/env bash
set -euo pipefail
TASK=/path/to/rso_project/r1_m6_deep_classification_20260908
cd "$TASK"
mkdir -p blast hmm logs
exec >logs/homology.log 2>&1
trap 'code=$?; echo "$code" > homology.exitcode' EXIT
BLAST=/path/to/user/tools/miniconda3/envs/blast/bin
HMM=/path/to/user/tools/miniconda3/envs/cotton/bin
"$BLAST/blastp" -version
"$BLAST/makeblastdb" -in reviewed_plants_20_400aa.faa -dbtype prot -out blast/reviewed_plants
"$BLAST/blastp" -query queries_interpro.faa -db blast/reviewed_plants \
 -evalue 10 -seg yes -soft_masking true -comp_based_stats 2 -matrix BLOSUM62 \
 -max_target_seqs 5000 -num_threads 4 \
 -outfmt '6 qseqid sseqid pident length qlen slen qstart qend sstart send qcovhsp evalue bitscore qseq sseq' \
 -out blast/queries_vs_reviewed_plants.tsv
"$HMM/hmmsearch" --cpu 2 --max -E 100 --domE 100 --tblout hmm/PF00304.relaxed.tbl \
 --domtblout hmm/PF00304.relaxed.domtbl /path/to/rso_project/data/hmm/PF00304.hmm queries_interpro.faa > hmm/PF00304.relaxed.txt
"$HMM/hmmsearch" --cpu 2 --cut_ga --domtblout hmm/AMP.cutga.domtbl \
 /path/to/rso_project/data/hmm/AMP_models.hmm queries_interpro.faa > hmm/AMP.cutga.txt
"$HMM/hmmalign" --outformat afa /path/to/rso_project/data/hmm/PF00304.hmm queries_controls.faa > hmm/PF00304.aligned.faa
sha256sum reviewed_plants_20_400aa.faa queries_interpro.faa blast/queries_vs_reviewed_plants.tsv hmm/*.domtbl > homology.sha256
date -Iseconds > homology.COMPLETE
