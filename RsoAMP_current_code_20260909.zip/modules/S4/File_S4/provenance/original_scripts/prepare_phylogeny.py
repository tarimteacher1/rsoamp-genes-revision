from pathlib import Path
import csv,json,re,sys
from collections import defaultdict
OUT=Path(__file__).resolve().parent
DEST=OUT/(sys.argv[1] if len(sys.argv)>1 else 'phylogeny')
refs={r['Entry']:r for r in csv.DictReader((OUT/'reference/reviewed_plants_20_400aa.tsv').read_text(encoding='utf-8').splitlines(),delimiter='\t')}
hits=json.loads((OUT/'homology_hits_annotated.json').read_text())
def fasta(p):
    d={};k=None
    for l in p.read_text().splitlines():
        if l.startswith('>'):k=l[1:].split()[0];d[k]=''
        elif k:d[k]+=l.strip()
    return d
seq=fasta(OUT/'queries_interpro.faa')
panels={};manifest=[]
for family in ['defensin','nsltp']:
    qids=[q for q in seq if (q.startswith('RSO_') or (q.startswith('R1M6') and q[-2:] not in ['02','03']))] if family=='defensin' else [q for q in seq if q.startswith('CTRL_') or q.startswith('ALT_') or q[-2:] in ['02','03']]
    ids=set()
    for q in qids:
        # A broad-context panel is selected, then labels are audited separately.
        # IPR043325 is the AAI/LT/SS broad family, NOT nsLTP-specific evidence.
        allowed=[h for h in hits.get(q,[]) if h['label'].startswith('DEFL' if family=='defensin' else 'LTP') or (family=='nsltp' and 'IPR043325;' in h['interpro'])]
        ids.update(h['subject'] for h in allowed[:8])
        if family=='nsltp':
            ids.update(h['subject'] for h in hits.get(q,[]) if h['label']=='OTHER_named' and ('IPR000617;' in h['interpro'] or 'PF00234;' in h['pfam'] or 'PF14368;' in h['pfam']))
            ids.update(h['subject'] for h in hits.get(q,[]) if h['label']=='OTHER_or_uncharacterized' and ('PF00234;' in h['pfam'] or 'PF14368;' in h['pfam']))
    if family=='nsltp':
        ids.update(r['Entry'] for r in refs.values() if 'IPR000617;' in r['InterPro'])
    panel={q:seq[q] for q in qids}
    for rid in sorted(ids):
        r=refs[rid]
        label=next(h['label'] for hs in hits.values() for h in hs if h['subject']==rid) if any(h['subject']==rid for hs in hits.values() for h in hs) else 'OTHER_named'
        panel['REF_'+rid]=r['Sequence'];manifest.append([family,'REF_'+rid,rid,label,r['Protein names'],r['Organism'],r['InterPro'],r['Pfam']])
    dest=DEST;dest.mkdir(exist_ok=True)
    (dest/f'{family}.full.faa').write_text(''.join(f'>{k}\n{v}\n' for k,v in panel.items()))
    panels[family]={'queries':qids,'reference_count':len(ids),'total_sequences':len(panel)}
with (DEST/'reference_manifest.tsv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f,delimiter='\t');w.writerow(['family','tree_id','accession','label','name','organism','interpro','pfam']);w.writerows(manifest)
(DEST/'panel_summary.json').write_text(json.dumps(panels,indent=2))
print(json.dumps(panels,indent=2))
