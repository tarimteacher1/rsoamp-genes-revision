from pathlib import Path
import json,csv,re
from collections import defaultdict
P=Path(__file__).resolve().parent
v=json.loads((P/'single_variant_sensitivity_manifest.json').read_text(encoding='utf-8'))['variants']
hits=defaultdict(set);scores=defaultdict(dict)
for l in (P/'variant_sensitivity/AMP.cutga.domtbl').read_text().splitlines():
 if l and not l.startswith('#'):
  f=l.split();hits[f[0]].add(f[4]);scores[f[0]][f[4]]=float(f[7])
ds=defaultdict(list)
for l in (P/'variant_sensitivity/single.deepsig.gff3').read_text().splitlines():
 f=l.split('\t')
 if len(f)>4 and f[2]=='Signal peptide':ds[f[0]].append([int(f[3]),int(f[4])])
gpi={r['accession']:r['features'] for r in json.loads((P/'variant_sensitivity/single.predgpi.json').read_text())}
rows=[]
for r in v:
 q,s=r['candidate'],r['sensitivity_id']
 rows.append({'candidate':q,'single_variant':s,'HMM_original':sorted(hits[q]),'HMM_variant':sorted(hits[s]),
  'HMM_decision_unchanged':hits[q]==hits[s],'HMM_scores_original':scores[q],'HMM_scores_variant':scores[s],
  'DeepSig_original':ds[q],'DeepSig_variant':ds[s],'PredGPI_original':gpi[q],'PredGPI_variant':gpi[s],
  'cysteine_changed':r['ref_aa']=='C' or r['alt_aa']=='C'})
assert len(rows)==13 and all(r['HMM_decision_unchanged'] and not r['cysteine_changed'] for r in rows)
(P/'variant_sensitivity/summary.json').write_text(json.dumps(rows,indent=2))
qcs=[]
for log in (P/'phylogeny').glob('*.log'):
 txt=log.read_text(encoding='utf-8');rpt=log.with_suffix('.iqtree').read_text(encoding='utf-8')
 n,sites=map(int,re.search(r'Alignment has (\d+) sequences with (\d+) columns',txt).groups())
 m=re.search(r'TOTAL\s+([\d.]+)%\s+(\d+) sequences failed composition',txt)
 qcs.append({'tree':log.stem,'sequences':n,'columns':sites,'overall_gap_ambiguity_percent':float(m[1]),
  'composition_chi2_failed_sequences':int(m[2]),'composition_chi2_failed_fraction':int(m[2])/n,
  'model':re.search(r'Best-fit model according to BIC: (.+)',rpt)[1],
  'note':'Composition test is descriptive at p<0.05; these short heterogeneous alignments support only auxiliary topology interpretation.'})
(P/'phylogeny/model_and_composition_audit.json').write_text(json.dumps(qcs,indent=2))
with (P/'phylogeny/model_and_composition_audit.tsv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(qcs[0]),delimiter='\t');w.writeheader();w.writerows(qcs)
print('Validated',len(rows),'single-aa tests and',len(qcs),'tree QC records.')
