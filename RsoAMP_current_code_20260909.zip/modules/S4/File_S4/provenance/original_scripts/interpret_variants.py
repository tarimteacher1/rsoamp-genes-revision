from pathlib import Path
import csv,json,itertools
OUT=Path(__file__).resolve().parent
DATA=json.loads((OUT/'candidate_manifest.json').read_text())
AUD=json.loads((OUT/'sequence_read_audit.json').read_text())['candidates']
table={''.join(c):aa for c,aa in zip(itertools.product('TCAG',repeat=3),'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG')}
comp=str.maketrans('ACGT','TGCA')
base={}
for r in csv.DictReader((OUT/'pooled_cds_base_support.tsv').read_text().splitlines(),delimiter='\t'):
    base[r['candidate'],int(r['position1'])]=r
out=[]
for model,a in zip(DATA,AUD):
    m=model['model'];p=[i+1 for l,h in model['exons_0based_halfopen'] for i in range(l,h)]
    if m['strand']=='-':p=p[::-1]
    p=p[int(m['cds_start_in_transcript_1based'])-1:int(m['cds_end_in_transcript_1based'])+3]
    refseq=a['cds_nt']+a['stop'];assert len(p)==len(refseq)
    assert ''.join(table[refseq[i:i+3]] for i in range(0,len(refseq)-3,3))==m['protein_sequence']
    for j,pos in enumerate(p):
        b=base[m['provisional_locus_id'],pos];ref=b['ref'];depth=int(b['depth']);codstart=j//3*3
        for alt in 'ACGT':
            n=int(b[alt])
            if alt==ref or depth<10 or n/depth<.2:continue
            txalt=alt.translate(comp) if m['strand']=='-' else alt
            orig=refseq[codstart:codstart+3];new=orig[:j%3]+txalt+orig[j%3+1:]
            out.append([model['id'],pos,ref,alt,n,depth,round(n/depth,4),j//3+1,orig,new,table[orig],table[new],'synonymous_or_same_stop' if table[orig]==table[new] else 'amino_acid_change'])
with (OUT/'variant_consequence_audit.tsv').open('w',newline='') as f:
    w=csv.writer(f,delimiter='\t');w.writerow(['candidate','position1','ref','alt','alt_count','depth','alt_fraction','codon_index','ref_codon','alt_codon','ref_aa','alt_aa','effect']);w.writerows(out)
for r in DATA:
    o=[x for x in out if x[0]==r['id']];print(r['id'],'variant_sites',len(o),'nonsynonymous',[(x[1],str(x[10])+str(x[7])+str(x[11]),x[6]) for x in o if x[-1]!='synonymous_or_same_stop'])
