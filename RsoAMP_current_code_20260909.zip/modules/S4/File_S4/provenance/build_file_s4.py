"""Assemble a bounded English submission supplement from existing M6 evidence."""
from pathlib import Path
import csv, json, hashlib, shutil, re, zipfile

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
OUT = HERE / "File_S4"
DEEP = ROOT / "R1M6_深入分类_20260908"
REC = ROOT / "成员判定收尾_20260909/审核_M6"
OUT.mkdir(parents=True, exist_ok=True)
sources = []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source(path, output, operation="exact_copy"):
    sources.append(dict(source_relative_to_workspace=path.relative_to(ROOT).as_posix(),
                        source_bytes=path.stat().st_size, source_sha256=sha(path),
                        package_path=output, operation=operation))

def copy(path, output):
    target = OUT / output
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    source(path, output)

def read_tsv(path):
    return list(csv.DictReader(path.open(encoding="utf-8-sig", newline=""), delimiter="\t"))

def write_tsv(name, rows, fields=None):
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8", newline="") as h:
        writer = csv.DictWriter(h, fieldnames=fields or list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)

def write(name, text):
    target=OUT/name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding="utf-8")

priority = read_tsv(REC / "M6_十个优先模型.tsv")
all_rows = read_tsv(REC / "M6_全部新增候选判定.tsv")
evidence = {r["id"]: r for r in json.loads((DEEP/"evidence_summary.json").read_text("utf-8"))}
decisions = {
 "01": ("supplementary_family_uncertain",
        "Strong transcript-model support; no reportable InterProScan match. PF00304 full/domain scores 24.6/24.2 are below its unmodified 25.1 gathering threshold. Signal prediction, eight cysteines and a reviewed Fabatin-2 similarity provide clues, not sufficient family admission.",
        "Do not lower the gathering threshold to admit this model; defensin identity remains uncertain."),
 "02": ("supplementary_precursor_start_uncertain",
        "IPR000528/PR00382, cd01960 and PS00597 support nsLTP identity. The 149-aa reference model lacks a DeepSig signal; TMbed predicts a 1-56 signal region. The internal M35 version is sensitivity-only.",
        "Only 2/9 libraries contain the complete CDS model; minimum pooled CDS depth 2, with 445/447 reference CDS bases supported. The translation start remains unresolved."),
 "03": ("accepted_computational_family_model",
        "Multiple PR00382 matches integrate into nsLTP-specific IPR000528, with a compatible 28-101 eight-cysteine core, concordant DeepSig/TMbed 1-22 signal region and positive PredGPI prediction. Reviewed AtLTPG7 similarity: 86.7 bits, 34.1% identity and 90% precursor coverage.",
        "GPI attachment is predicted, not measured; P124A sensitivity retains a positive call but shifts the predicted site. No resolved new subfamily or antimicrobial activity claim."),
 "08": ("connection_model_not_an_additional_gene",
        "Shares the first CDS segment of CAND09 and the second CDS segment of CAND07. The 31,866-bp connecting intron has 18 fragments across seven libraries. CAND07 and CAND08 differ at precursor residue 3 (T and A); they are 78/79 identical, not identical full-length proteins.",
        "Retain the supported connection without counting a third gene. Long-intron length alone does not establish artifact; short-read support alone does not establish a separate gene.")
}
def_scores={"04":"31.0","05":"28.8","06":"31.9","07":"32.9","09":"32.6","10":"28.8"}
for ident, score in def_scores.items():
    decisions[ident]=("accepted_computational_family_model",
        f"PF00304 passes the unmodified gathering threshold (full-sequence score {score}); complete InterProScan also detects PF00304. A compatible eight-cysteine framework, secretion prediction and reviewed defensin similarities support the family assignment.",
        "A computational defensin-family model; antimicrobial activity and mature peptide processing have not been measured. Reference and RNA sequence differences remain separately recorded.")

fields=["candidate_id","original_model_id","original_orf_id","family","decision","count_as_independent_new_model",
        "chrom","start","end","strand","coordinate_basis","cds_segments_transcript_order","protein_aa",
        "complete_CDS_model_libraries_of9","exact_splice_fragment_counts","qualified_local_long_reads",
        "cds_bases","reference_supported_cds_bases","minimum_pooled_CDS_fragment_depth",
        "DeepSig_signal_intervals","TMbed_signal_end","PredGPI_call","family_and_model_evidence","remaining_limit",
        "protein_sha256","cds_with_stop_sha256","expression_analysis_scope"]
out_rows=[]
for row in priority:
    ev=evidence[row["candidate_id"]]
    decision, reason, limit=decisions[row["candidate_id"][-2:]]
    d={k:row[k] for k in ["candidate_id","original_model_id","original_orf_id","family","chrom","start","end","strand","coordinate_basis","cds_segments_transcript_order","protein_aa","protein_sha256","cds_with_stop_sha256"]}
    d.update(decision=decision,count_as_independent_new_model=row["count_as_new_gene"],
             complete_CDS_model_libraries_of9=row["short_complete_CDS_libraries_of9"],
             exact_splice_fragment_counts=row["exact_splice_fragments"],
             qualified_local_long_reads=row["qualified_local_long_reads"],
             cds_bases=ev["cds_bases"],reference_supported_cds_bases=ev["reference_supported_cds_bases"],
             minimum_pooled_CDS_fragment_depth=ev["cds_min_pooled_depth"],
             DeepSig_signal_intervals=json.dumps(ev["DeepSig_signal"]),TMbed_signal_end=ev["TMbed_signal_end"],
             PredGPI_call=json.dumps(ev["PredGPI"]),family_and_model_evidence=reason,remaining_limit=limit,
             expression_analysis_scope="Model/transcription support only; not included in the original Salmon DE reference or reference-proteome comparative cohort.")
    out_rows.append(d)
write_tsv("tables/ten_priority_candidate_evidence.tsv",out_rows,fields)
source(REC/"M6_十个优先模型.tsv","tables/ten_priority_candidate_evidence.tsv","English evidence synthesis; sequences and numeric observations preserved")
source(DEEP/"evidence_summary.json","tables/ten_priority_candidate_evidence.tsv","Numeric/model/predictor extraction")
write_tsv("tables/proposed_aliases_not_adopted.tsv",[
    dict(candidate_id=r["candidate_id"],original_model_id=r["original_model_id"],proposed_alias_not_adopted=r["suggested_stable_gene_name"],
         status="Proposed in reconciliation only; CAND identifier remains canonical in File S4.")
    for r in priority])
for name, rows in [
 ("ten_priority",priority),
 ("seven_accepted",[r for r in priority if r["count_as_new_gene"]=="1"]),
 ("two_supplementary",[r for r in priority if r["candidate_id"][-2:] in {"01","02"}]),
 ("connection_model",[r for r in priority if r["candidate_id"].endswith("08")])]:
    for suffix, column in [("protein.faa","protein_sequence"),("cds_with_stop.fna","cds_with_stop_sequence")]:
        write("models/"+name+"."+suffix,"".join(f">{r['candidate_id']} original_model={r['original_model_id']}\n{r[column]}\n"for r in rows))
        source(REC/"M6_十个优先模型.tsv","models/"+name+"."+suffix,"FASTA export with provisional identifiers; sequences unchanged")
model_src=DEEP/"交付/候选序列与模型"
copy(model_src/"high_confidence.provisional_models.gff3","models/seven_accepted.provisional_models.gff3")
copy(model_src/"CAND02_M35_sensitivity_only.faa","models/CAND02_M35_sensitivity_only.faa")
copy(REC/"M6_recursive_supplementary_genomic_ORFs.protein.faa","models/recursive_supplementary_genomic_ORFs.protein.faa")
copy(REC/"M6_recursive_supplementary_genomic_ORFs.cds_with_stop.fna","models/recursive_supplementary_genomic_ORFs.cds_with_stop.fna")

extra=[]
for row in all_rows[10:]:
    i=row["candidate_id"]
    if i.startswith("M6MERGE"):
        reason="Incomplete start-to-stop ORF; retained as a fragment, not a new gene. M6MERGE.16714.1 and .2 represent one locus, also overlapping REC015."
    elif i[-3:]in {"003","020","029","030"}:
        reason="Genomic start-to-stop ORF with nsLTP-specific IPR000528 and cd01960 support; lacks the priority-model level of per-locus reads and transcript-structure audit."
        if i.endswith("003"):reason+=" DeepSig and TMbed secretion predictions disagree."
    elif i.endswith("025"):
        reason="Defensin-like genomic homology cluster; no acceptable complete coding model is established."
    else:
        reason="Short 72-aa genomic ORF with broad superfamily evidence; lacks a complete eight-cysteine framework and specific nsLTP assignment."
    d={k:row[k]for k in ["candidate_id","original_model_id","original_orf_id","family","identity_tier","chrom","start","end","strand","coordinate_basis","protein_aa","branch"]}
    d.update(count_as_new_gene=0,interpretation=reason)
    extra.append(d)
write_tsv("tables/additional_supplementary_records.tsv",extra)
source(REC/"M6_全部新增候选判定.tsv","tables/additional_supplementary_records.tsv","English interpretation; only non-priority records")
branch_rows=[
 ["genome_unmapped_residual","23126","read_or_mate_similarity_hits","0","22845 hits to existing R. soongarica references; 281 to cross-species references. No complete new gene models; this branch is distinct from genome-mapped discovery."],
 ["mapped_discovery_known","61","ORF_records","0","Support for already represented loci; not additional genes."],
 ["mapped_discovery_overlap","32","model_ORF_records","0","Existing/overlapping loci; 17 prior nsLTP-boundary records interpreted against the later M2 audit. Do not count isoforms as additional loci."],
 ["mapped_intergenic_priority","10","models_at_nine_independent_loci_plus_connection","7","Seven accepted computational models, two supplementary candidates and one connecting model."],
 ["mapped_intergenic_nonpriority","4","ORFs_at_three_loci","0","Incomplete coding models; two M6MERGE.16714 records belong to one locus."],
 ["recursive_genome_screen","31","homology_clusters","0","Ten clusters overlap priority models, 14 overlap frozen annotation, one overlaps the 16714 fragment locus, six remain supplementary; no automatic additional gene count."]
]
write_tsv("tables/discovery_branch_scope.tsv",[dict(zip(["branch","audited_count","unit","additional_gene_count","scope_and_limit"],r))for r in branch_rows])
source(REC/"M6_分支范围与剩余事项.tsv","tables/discovery_branch_scope.tsv","English branch summary")
for src,name in [
 ("M6_十优先模型_CDS与历史目录去重.tsv","priority_CDS_and_legacy_nonredundancy.tsv"),
 ("M6_61已知位点ORF支持.tsv","known_locus_61_ORF_records.tsv"),
 ("M6_31递归同源簇_分支去重.tsv","recursive_31_cluster_reconciliation.tsv")]:
    copy(REC/src,"tables/"+name)
overlap=read_tsv(REC/"M6_32重叠模型_对照新M2.tsv")
cols=["audit_id","transcript_id","orf_id","chrom","start","end","strand","reference_id","existing_member_id",
      "current_M2_reference_class","current_M2_reference_member","current_M2_tier_20260909","current_disposition","count_as_new_gene"]
write_tsv("tables/overlapping_32_model_reconciliation.tsv",[{k:r.get(k,"")for k in cols}for r in overlap],cols)
source(REC/"M6_32重叠模型_对照新M2.tsv","tables/overlapping_32_model_reconciliation.tsv","Selected current-disposition fields; obsolete decision text omitted")
write_tsv("tables/correction_CAND07_CAND08.tsv",[dict(
    compared_models="R1M6_CAND07;R1M6_CAND08",protein_length_each=79,identical_positions=78,
    differing_precursor_position_1based=3,CAND07_residue="T",CAND08_residue="A",
    correction="Any archived statement of identical full-length proteins is superseded; mature-core identity does not justify an additional locus.",
    connection="CAND08 shares the first CDS of CAND09 and second CDS of CAND07; it is not counted as a third gene.")])

processed=["read_sequence_per_sample.tsv","pooled_cds_base_support.tsv","sequence_read_audit.json",
           "CAND08_junction_records.tsv","variant_consequence_audit.tsv","cysteine_framework.tsv",
           "reference_panel_threshold_sensitivity.tsv","homology_hits_annotated.json","homology_top_hits.txt",
           "queries_interpro.faa","queries_controls.faa","single_variant_sensitivity.faa","single_variant_sensitivity_manifest.json"]
for f in processed:copy(DEEP/f,"processed/"+f)
for dirname in ["interpro","hmm","start_sensitivity","variant_sensitivity","blast"]:
    for path in sorted((DEEP/dirname).iterdir()):
        if path.is_file() and path.name not in {"COMPLETE","inputs.sha256","outputs.sha256"}:
            copy(path,"processed/"+dirname+"/"+path.name)
for path in sorted((DEEP/"phylogeny").iterdir()):
    if path.suffix in {".faa",".treefile",".iqtree",".tsv",".json"}:
        copy(path,"processed/phylogeny/"+path.name)
copy(DEEP/"candidate_manifest.json","provenance/archived_candidate_manifest.json")
copy(DEEP/"genome_regions.json","provenance/priority_genome_windows.json")
copy(DEEP/"run_provenance.json","provenance/archived_run_provenance.json")
copy(DEEP/"reference/download_provenance.json","provenance/reviewed_reference_download.json")
copy(REC/"M6_输入文件_SHA256.tsv","provenance/reconciliation_input_hashes.tsv")
copy(REC/"M6_核对计数与验证.json","provenance/archived_reconciliation_validation.json")
copy(REC/"M6_旧结论纠正.tsv","provenance/archived_correction_record.tsv")
scripts=["prepare_inputs.py","prepare_phylogeny.py","audit_sequence_reads.py","audit_interpro.py",
         "audit_phylogeny.py","audit_sensitivity_results.py","framework_audit.py",
         "interpret_variants.py","prepare_variant_sensitivity.py","summarize_homology.py",
         "reference_sensitivity_audit.py","run_homology.sh","run_interpro.sh","run_phylogeny.sh",
         "run_reference_sensitivity.sh","run_alternative_start.sh","run_variant_sensitivity.sh",
         "run_tmbed_retry.sh","download_references.py","export_genome.py"]
for f in scripts:copy(DEEP/f,"provenance/original_scripts/"+f)
copy(REC/"build_m6_reconciliation.py","provenance/original_scripts/build_m6_reconciliation.py")
copy(Path(__file__),"provenance/build_file_s4.py")
write("README.md","""# File S4. Transcript-supported AMP-family candidate models and discovery boundaries

This supplement supports the separate genome-mapped transcript-discovery results and the biological interpretation in the revised manuscript. It is a bounded evidence package, not a replacement for the original 63-gene downstream cohort or the reference-proteome comparison in File S3.

## Read first

- `tables/ten_priority_candidate_evidence.tsv`: ten priority models, their per-candidate evidence, decisions and limitations.
- `models/seven_accepted.provisional_models.gff3`, protein FASTA and CDS FASTA: seven computational family models, comprising six defensins (CAND04-07 and CAND09-10) and one predicted nsLTP/LTPg (CAND03).
- `tables/discovery_branch_scope.tsv` and the accompanying reconciliation tables: the units, overlaps and unresolved boundaries of the other discovery branches.
- `tables/correction_CAND07_CAND08.tsv`: correction of an earlier reporting error. CAND07 and CAND08 are 78/79 identical and differ at precursor residue 3 (T/A). The first CDS segment of CAND08 is shared with CAND09, and its second with CAND07. This connecting model is not an additional gene.

The identifiers R1M6_CAND01-10 remain canonical here. Suggested later Rs names are supplied only in `proposed_aliases_not_adopted.tsv`; they are not adopted in the manuscript or used to silently renumber an analysis cohort.

## Model evidence and decision criteria

Gene-model support and family assignment were evaluated separately. Evidence includes a complete reference-genome ORF with a downstream stop, transcript-oriented genomic reconstruction, per-library complete-CDS models, exact splice support, filtered coding-base support and available local long reads. Coordinates are one-based inclusive where stated; GFF3 CDS features exclude the stop, which is represented separately. The CDS FASTA includes the terminal stop codon. The reference protein is not asserted to be the exact translated protein in every RNA sample.

For short-read base and splice auditing, primary, transcript-strand-concordant NH=1 alignments were used with MAPQ >= 20 and base quality >= 20. Overlapping mates were deduplicated by QNAME/position, selecting the higher-quality base. Pooled depth counts support fragments, not independent molecules. RNA/reference differences are descriptive, not phased genotypes. The prior per-sample transcript assemblies and local long-read measurements are retained in the archived candidate manifest.

Family admission combined family-specific annotations with compatible cysteine/secretion architecture and model support. HMMER 3.4 used the original curated Pfam gathering thresholds; PF00304.27 has a 25.1 full/domain threshold. Relaxed output was used only to inspect borderline hits, without relaxing admission. Complete InterProScan 5.77-108.0 analyzed 23 inputs (ten candidates, nine annotated defensin controls, three nsLTP boundary controls and a CAND02 internal-start sensitivity sequence). Its full output retained 18 available analyses; CAND01's absent reportable hit is not a missing run. Shared database models are not independent experiments.

CAND03 has PR00382 matches integrated into nsLTP-specific IPR000528, compatible eight-cysteine/secretion architecture and PredGPI support. This positive identity route does not depend on a universal 50-bit positive-minus-alternative cutoff. Broad PF00234/PF14368 or AAI/LTP/seed-storage evidence alone is insufficient. GPI anchoring remains a computational subtype prediction.

The reviewed short-plant-protein comparison used 24,794 UniProtKB/Swiss-Prot entries of 20-400 aa (2026_03), with BLAST+ 2.17.0, BLOSUM62, SEG and composition-based statistics 2. The complete reference database and raw alignments/BAMs are not duplicated here; accession and download provenance, source hashes, processed hits and commands are retained. The eight existing defensin/nsLTP phylogenies used full sequences or HMM-aligned cores, each untrimmed or trimAl-gappyout filtered, and IQ-TREE model selection with SH-aLRT/UFBoot support. These auxiliary trees are distinct from the original Figure 2 analyses and the two shared-audit trees in File S3. They do not resolve new subfamilies.

CAND01 has a well-supported model but uncertain defensin identity. CAND02 has specific nsLTP evidence but an unresolved precursor start; its internal M35 alternative is sensitivity-only. Single-substitution sensitivity does not define phased sample haplotypes or experimentally establish processing or GPI attachment.

## Discovery units and limits

The genome-unmapped residual screen produced 23,126 read/mate similarity records but no complete new gene models. This is a different branch from genome-mapped transcript reconstruction. The latter discovery contains 107 ORF records across 103 transcript models: 61 known-locus records, 32 overlapping/modified records, ten priority models and four other intergenic ORFs at three loci. Records, transcripts and loci must not be summed as equivalent gene counts.

The recursive screen comprises 31 homology clusters: ten corresponding to priority models, 14 to frozen annotation, one to the 16714 fragment locus and six retained as supplementary. Four of those six have nsLTP-specific family support and genomic start-to-stop ORFs, but lack the same complete transcript/read audit as the priority models. The 20-row source candidate compilation therefore does not represent 20 independent genes. Additional supplementary locus entries comprise two priority candidates, three fragment loci and six recursive clusters; they are not eleven established genes.

The seven accepted models were checked against the original 63-gene catalogue, later M2 nsLTP sets and six historical backfill fragments; they do not overlap these loci or duplicate their complete reference proteins. This reconciliation does not establish that all omitted genes have been recovered. Their sequences are outside the original Salmon quantification reference: model/read support is not differential-expression evidence and has not been appended to the original DE matrix. They are also outside the two-reference-proteome comparison in File S3. No independent qRT-PCR, peptide activity assay or causal salt-tolerance experiment was performed.

## Provenance and validation

This package was assembled from existing 2026-09-08 deep-classification evidence and the 2026-09-09 reconciliation. No new read alignment, family search, phylogeny or biological experiment was run during packaging. `SOURCE_PROVENANCE.tsv` records the input path relative to the working archive, its size and SHA-256, and any export/translation operation. Archived paths in scripts are provenance, not an assertion that the complete external environment or large input data are included. Some archived manifests retain provisional status or earlier neighborhood annotations; the current English decision table and explicit CAND07/CAND08 correction take precedence over those archived narrative fields.

`FILE_MANIFEST_SHA256.tsv` inventories package content except the manifest itself. Run `python verify_file_s4.py` from any directory to validate hashes, candidate counts, protein/CDS translations, genomic CDS reconstruction, GFF phases and the CAND07/CAND08 correction. Verification uses the Python standard library and local retained genomic windows. It verifies the packaged evidence, not independent biological replication.
""")
write_tsv("SOURCE_PROVENANCE.tsv",sources)
print(json.dumps({"package":str(OUT),"files_before_manifest":len(list(OUT.rglob("*"))),"sources":len(sources)},ensure_ascii=False))
