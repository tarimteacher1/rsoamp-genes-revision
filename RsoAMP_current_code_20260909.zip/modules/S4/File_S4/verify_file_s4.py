"""Portable, read-only validation of File S4; Python standard library only."""
from pathlib import Path
import csv, hashlib, itertools, json

ROOT=Path(__file__).resolve().parent
def rows(name):
    return list(csv.DictReader((ROOT/name).open(encoding="utf-8-sig",newline=""),delimiter="\t"))
def fasta(name):
    result={}
    key=None
    for line in (ROOT/name).read_text("utf-8").splitlines():
        if line.startswith(">"):
            key=line[1:].split()[0]
            assert key not in result,("duplicate FASTA ID",key)
            result[key]=""
        elif line.strip():
            result[key]+=line.strip()
    return result
def digest(data):return hashlib.sha256(data).hexdigest()
def rc(s):return s.translate(str.maketrans("ACGT","TGCA"))[::-1]
def translate(s):
    chars="FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
    code=dict(zip(("".join(x) for x in itertools.product("TCAG",repeat=3)),chars))
    assert len(s)%3==0
    return "".join(code[s[i:i+3]]for i in range(0,len(s),3))

manifest=rows("FILE_MANIFEST_SHA256.tsv")
for r in manifest:
    path=ROOT/r["relative_path"]
    assert path.is_file(),("missing",r["relative_path"])
    assert path.stat().st_size==int(r["bytes"]),("size",r["relative_path"])
    assert digest(path.read_bytes())==r["sha256"],("hash",r["relative_path"])
actual={p.relative_to(ROOT).as_posix()for p in ROOT.rglob("*")if p.is_file() and p.name!="FILE_MANIFEST_SHA256.tsv"}
assert actual=={r["relative_path"]for r in manifest},"unlisted or missing package file"

table=rows("tables/ten_priority_candidate_evidence.tsv")
assert len(table)==10
assert len({r["candidate_id"]for r in table})==10
accepted=[r for r in table if r["count_as_independent_new_model"]=="1"]
assert len(accepted)==7
assert sum(r["family"]=="Defensin"for r in accepted)==6
assert sum(r["family"]=="nsLTP"for r in accepted)==1
assert sum(r["decision"].startswith("supplementary")for r in table)==2
assert sum(r["decision"]=="connection_model_not_an_additional_gene"for r in table)==1

proteins=fasta("models/ten_priority.protein.faa")
cds=fasta("models/ten_priority.cds_with_stop.fna")
windows=json.loads((ROOT/"provenance/priority_genome_windows.json").read_text("utf-8"))
by_id={r["candidate_id"]:r for r in table}
def extract(ident,start,end,strand):
    win=windows[ident]
    assert win["start1"]<=start<=end<=win["end1"]
    seq=win["sequence"][start-win["start1"]:end-win["start1"]+1]
    return rc(seq)if strand=="-"else seq
for r in table:
    ident=r["candidate_id"]
    assert len(proteins[ident])==int(r["protein_aa"])
    assert digest(proteins[ident].encode())==r["protein_sha256"]
    assert digest(cds[ident].encode())==r["cds_with_stop_sha256"]
    assert translate(cds[ident])==proteins[ident]+"*"
    assert cds[ident].startswith("ATG")
    segments=[tuple(map(int,x.split("-")))for x in r["cds_segments_transcript_order"].split(";")]
    extracted="".join(extract(ident,a,b,r["strand"])for a,b in segments)
    assert extracted==cds[ident][:-3],("genomic CDS",ident)
    a,b=segments[-1]
    stop=extract(ident,a-3,a-1,r["strand"])if r["strand"]=="-"else extract(ident,b+1,b+3,r["strand"])
    assert stop==cds[ident][-3:],("stop codon",ident)
assert [i+1 for i,(a,b)in enumerate(zip(proteins["R1M6_CAND07"],proteins["R1M6_CAND08"]))if a!=b]==[3]
assert proteins["R1M6_CAND07"][2]=="T" and proteins["R1M6_CAND08"][2]=="A"
assert len(proteins["R1M6_CAND07"])==len(proteins["R1M6_CAND08"])==79
assert by_id["R1M6_CAND08"]["cds_segments_transcript_order"].split(";")[0]==by_id["R1M6_CAND09"]["cds_segments_transcript_order"].split(";")[0]
assert by_id["R1M6_CAND08"]["cds_segments_transcript_order"].split(";")[1]==by_id["R1M6_CAND07"]["cds_segments_transcript_order"].split(";")[1]
gff={}
genes=set()
for line in (ROOT/"models/seven_accepted.provisional_models.gff3").read_text("utf-8").splitlines():
    if not line or line.startswith("#"):continue
    fields=line.split("\t")
    attrs=dict(x.split("=",1)for x in fields[8].split(";")if "="in x)
    if fields[2]=="gene":genes.add(attrs["ID"])
    if fields[2]not in {"CDS","stop_codon"}:continue
    ident=attrs["Parent"].split(".t")[0]
    gff.setdefault(ident,{"CDS":[],"stop_codon":[]})[fields[2]].append(fields)
assert genes=={r["candidate_id"]for r in accepted}
for ident,features in gff.items():
    strand=by_id[ident]["strand"]
    ordered=sorted(features["CDS"],key=lambda f:int(f[3]),reverse=strand=="-")
    total=0
    sequence=""
    for f in ordered:
        assert int(f[7])==(-total)%3,("GFF phase",ident)
        part=extract(ident,int(f[3]),int(f[4]),strand)
        total+=len(part)
        sequence+=part
    assert sequence==cds[ident][:-3],("GFF sequence",ident)
    stops=sorted(features["stop_codon"],key=lambda f:int(f[3]),reverse=strand=="-")
    assert "".join(extract(ident,int(f[3]),int(f[4]),strand)for f in stops)==cds[ident][-3:]
for prefix,count in [("seven_accepted",7),("two_supplementary",2),("connection_model",1)]:
    p=fasta("models/"+prefix+".protein.faa")
    d=fasta("models/"+prefix+".cds_with_stop.fna")
    assert len(p)==len(d)==count
    for ident in p:assert p[ident]==proteins[ident] and d[ident]==cds[ident]
assert len(rows("tables/known_locus_61_ORF_records.tsv"))==61
assert len(rows("tables/overlapping_32_model_reconciliation.tsv"))==32
assert len(rows("tables/recursive_31_cluster_reconciliation.tsv"))==31
assert len(rows("tables/additional_supplementary_records.tsv"))==10
trees=list((ROOT/"processed/phylogeny").glob("*.treefile"))
assert len(trees)==8
for path in trees:assert path.read_text("utf-8").strip().endswith(";")
print(json.dumps(dict(status="PASS",manifest_files=len(manifest),priority_models=10,
 accepted_models=7,accepted_defensins=6,accepted_nsLTP_LTPg=1,supplementary_priority=2,
 connecting_models=1,sequence_translation_and_genomic_checks=10,
 GFF_phase_sequence_stop_checks=7,CAND07_CAND08_difference="position 3: T/A; 78/79 identity",
 known_ORF_records=61,overlapping_model_records=32,recursive_clusters=31,
 retained_phylogenies=8,scope="Package consistency only; no independent biological validation"),indent=2))
