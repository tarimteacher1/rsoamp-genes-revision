from pathlib import Path
from collections import Counter,defaultdict
import csv,json,hashlib

HERE=Path(__file__).resolve().parent
results=json.loads((HERE/'results/new_rooting_results.json').read_text())
assert len(results)==16, f'Expected all 16 completed inferences, found {len(results)}'
patterns={};output=[]
for row in results:
    root=row['conditional_root'];a=row['alignment_stats']
    family='nsLTP' if row['dataset'].startswith('LTP') else ('Defensin' if row['dataset'].startswith('DEF') else 'Snakin_GASA')
    pid=''
    if root:
        signature=(family,root['root_signature_sha256'])
        if signature not in patterns:patterns[signature]=family+'_R'+str(1+sum(k[0]==family for k in patterns))
        pid=patterns[signature]
    output.append({'family':family,'dataset':row['dataset'],'region':row['region'],'trimming':row['trimming'],'taxa':a['taxa'],'alignment_columns':a['columns'],'informative_columns':a['informative_columns'],'gap_percent':round(a['gap_percent'],2),'model':row['model'],'outgroup_exact_split':bool(root),'outgroup_split_support':root['split_support'] if root else '', 'outgroup_split_joint_threshold':root['split_joint_support'] if root else False,'conditional_root_placement':pid,'ingroup_root_child_sizes':'/'.join(map(str,sorted(map(len,root['ingroup_root_children'])))) if root else '', 'PID2_median_percent':round(a['outgroup_to_ingroup_PID2_median'],2),'paired_residues_median':a['paired_residue_count_median'],'non_C_identical_same_denominator_median_percent':round(a['non_C_identity_same_denominator_median'],2),'outgroup_composition_fail_count':sum('failed' in x for x in row['outgroup_composition_tests']),'conditional_rooted_file':root['conditional_rooted_file'] if root else '', 'unrooted_tree':row['tree']})
with (HERE/'定根试验结果_16次.tsv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(output[0]),delimiter='\t');w.writeheader();w.writerows(output)
partition_rows=[]
seen=set()
for row,out in zip(results,output):
    if not row['conditional_root']:continue
    identifier=out['conditional_root_placement']
    if identifier in seen:continue
    seen.add(identifier)
    root=row['conditional_root']
    for side,taxa in enumerate(root['ingroup_root_children'],1):
        for taxon in taxa:partition_rows.append({'root_placement':identifier,'side':side,'taxon':taxon})
with (HERE/'根位置对应成员.tsv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['root_placement','side','taxon'],delimiter='\t');w.writeheader();w.writerows(partition_rows)
summary=[]
for fam in ['nsLTP','Snakin_GASA','Defensin']:
    rows=[x for x in output if x['family']==fam]
    summary.append({'family':fam,'analyses':len(rows),'exact_outgroup_splits':sum(x['outgroup_exact_split'] for x in rows),'joint_supported_outgroup_splits':sum(x['outgroup_split_joint_threshold'] for x in rows),'distinct_conditional_root_placements':len({x['conditional_root_placement'] for x in rows if x['conditional_root_placement']}),'placements':dict(Counter(x['conditional_root_placement'] or 'NO_SEPARATING_SPLIT' for x in rows))})
(HERE/'summary_statistics.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'summary':summary,'runs':output},ensure_ascii=False,indent=2))
