"""Gymnosperm candidate sensitivity, queued after the initial jobs to retain the 8-thread cap."""
from pathlib import Path
import json,time,hashlib,os
from concurrent.futures import ThreadPoolExecutor
from run_assessment import HERE,PHY,fasta,core,write_fasta,run_dataset

def main():
    while not os.environ.get('ROOTING_START_NOW'):
        p=HERE/'status.json'
        if p.exists():
            try:
                if json.loads(p.read_text()).get('state') in ['complete','failed']:break
            except json.JSONDecodeError:pass
        time.sleep(20)
    candidates=json.loads((HERE/'gymnosperm_config.json').read_text())
    base=fasta(PHY/'Defensin/Defensin.full.faa')
    out={}
    for row in candidates:
        existing=[k for k,v in base.items() if v==row['Sequence']]
        assert len(existing)<=1
        name=existing[0] if existing else 'GYM_'+row['Entry']
        out[name]=row['Sequence']
    assert len(out)==10
    combined={**base,**out};ingroup=sorted(set(combined)-set(out));assert len(ingroup)==102
    rows=[]
    for region in ['full','core']:
        seqs={k:core(v) if region=='core' else v for k,v in combined.items()}
        inp=HERE/'inputs'/('DEF_Gymnosperms10.'+region+'.faa');write_fasta(inp,seqs)
        rows.append({'name':'DEF_Gymnosperms10','region':region,'input':str(inp),'outgroup':sorted(out),'ingroup':ingroup,'trims':['untrimmed','gappyout']})
    (HERE/'defensin_datasets.json').write_text(json.dumps(rows,indent=2))
    (HERE/'defensin_status.json').write_text(json.dumps({'state':'running'}))
    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            completed=list(pool.map(run_dataset,rows))
        (HERE/'defensin_status.json').write_text(json.dumps({'state':'complete','completed_analyses':sum(map(len,completed))}))
    except Exception as e:
        (HERE/'defensin_status.json').write_text(json.dumps({'state':'failed','error':repr(e)}));raise

if __name__=='__main__':main()
