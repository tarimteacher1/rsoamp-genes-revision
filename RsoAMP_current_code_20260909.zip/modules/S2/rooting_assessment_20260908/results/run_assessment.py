"""Independent outgroup sensitivity experiment. Run with the existing cotton Python.
Original revision files are read only. No constraints or -o are used during inference.
Outgroup membership must form an exact split before a conditional root is exported.
"""
from pathlib import Path
import csv, json, hashlib, subprocess, time, os
from concurrent.futures import ThreadPoolExecutor, as_completed
from Bio import SeqIO
import Bio, numpy

HERE=Path(__file__).resolve().parent
SOURCE=Path('/path/to/rso_project/revision_R1_20260902')
PHY=SOURCE/'02_phylogeny'
MAFFT='/path/to/user/tools/miniconda3/envs/busco1/bin/mafft'
TRIMAL='/path/to/user/tools/miniconda3/envs/cotton/bin/trimal'
IQ='/path/to/user/tools/miniconda3/envs/cotton/bin/iqtree3'
CONF=json.loads((HERE/'config.json').read_text())
THREADS=int(os.environ.get('ROOTING_THREADS','4'))

def table(p):
    return list(csv.DictReader(p.open(), delimiter='\t'))

def fasta(p):
    return {r.id:str(r.seq) for r in SeqIO.parse(p,'fasta')}

def core(s):
    a,b=s.find('C'),s.rfind('C')
    return s[a:b+1] if a>=0 and b-a+1>=25 else ''

def write_fasta(p, seqs):
    p.write_text(''.join('>'+k+'\n'+v+'\n' for k,v in seqs.items()))

def command(cmd, log, stdout=None):
    with log.open('w') as err:
        if stdout:
            with stdout.open('w') as out:
                subprocess.run(cmd,stdout=out,stderr=err,check=True)
        else:
            subprocess.run(cmd,stdout=err,stderr=subprocess.STDOUT,check=True)

def prepare():
    d=HERE/'inputs';d.mkdir(exist_ok=True)
    sources=[]
    for fam in ['Defensin','Snakin_GASA','nsLTP']:
        p=PHY/fam/(fam+'.full.faa')
        sources.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    full=fasta(PHY/'nsLTP/nsLTP.full.faa')
    man=table(PHY/'nsLTP/nsLTP.taxon_manifest.tsv')
    ingroup={r['taxon_id']:full[r['taxon_id']] for r in man if r['source_group'] in ['Tamarix_austromongolica','reviewed_nsLTP_positive'] or r['taxon_id'] in CONF['canonical_rso_ltp']}
    assert len(ingroup)==108, len(ingroup)
    neg={r['taxon_id']:full[r['taxon_id']] for r in man if r['source_group']=='reviewed_2S_negative'}
    assert len(neg)==8
    # Two pre-specified accession groups of 2S controls: three G7 entries and five Arabidopsis entries.
    groups={'LTP_2S_all8':neg,'LTP_2S_G7_3':{k:v for k,v in neg.items() if '_G7' in k},'LTP_2S_Arabidopsis5':{k:v for k,v in neg.items() if '_G7' not in k}}
    datasets=[]
    for name,out in groups.items():
        dataset={**ingroup,**out}
        regions=['full','core']
        for region in regions:
            s={k:(core(v) if region=='core' else v) for k,v in dataset.items()}
            assert all(s.values())
            inp=d/(name+'.'+region+'.faa');write_fasta(inp,s)
            datasets.append({'name':name,'region':region,'input':str(inp),'outgroup':sorted(out),'ingroup':sorted(ingroup),'trims':['untrimmed','gappyout'] if name=='LTP_2S_all8' else ['gappyout']})
    base=fasta(PHY/'Snakin_GASA/Snakin_GASA.full.faa')
    out={x['id']:x['sequence'] for x in CONF['selaginella_gasa_selected']}
    for region in ['full','core']:
        dataset={**base,**out}
        s={k:(core(v) if region=='core' else v) for k,v in dataset.items()}
        inp=d/('GASA_Selaginella3.'+region+'.faa');write_fasta(inp,s)
        datasets.append({'name':'GASA_Selaginella3','region':region,'input':str(inp),'outgroup':sorted(out),'ingroup':sorted(base),'trims':['untrimmed','gappyout']})
    (HERE/'datasets.json').write_text(json.dumps(datasets,indent=2))
    (HERE/'source_hashes.json').write_text(json.dumps(sources,indent=2))
    return datasets

def run_dataset(row):
    t=time.time();d=HERE/'runs'/row['name']/row['region'];d.mkdir(parents=True,exist_ok=True)
    aln=d/'aligned.faa'
    cmd=[MAFFT,'--localpair','--maxiterate','1000','--thread',str(THREADS),row['input']]
    (d/'mafft_command.json').write_text(json.dumps(cmd));command(cmd,d/'mafft.log',aln)
    trimmed=d/'gappyout.faa'
    cmd=[TRIMAL,'-in',str(aln),'-out',str(trimmed),'-gappyout']
    (d/'trimal_command.json').write_text(json.dumps(cmd));command(cmd,d/'trimal.log')
    results=[]
    for trim in row['trims']:
        inp=aln if trim=='untrimmed' else trimmed
        pre=d/trim
        cmd=[IQ,'-s',str(inp),'-m','MFP','-mset','LG,WAG,JTT,VT,DAYHOFF','-mrate','E,I,G4,R4','-alrt','1000','-bb','1000','-bnni','-seed','20260908','-nt',str(THREADS),'-pre',str(pre)]
        (d/(trim+'.command.json')).write_text(json.dumps(cmd))
        command(cmd,d/(trim+'.stdout.log'))
        results.append({**row,'trim':trim,'prefix':str(pre),'alignment':str(inp),'seconds_since_dataset_start':time.time()-t})
        (d/(trim+'.completed.json')).write_text(json.dumps(results[-1],indent=2))
    return results

def main():
    meta={'started':time.strftime('%Y-%m-%d %H:%M:%S %z'),'pid':os.getpid(),'Bio':Bio.__version__,'numpy':numpy.__version__,'max_concurrent_jobs':2,'threads_per_job':THREADS,'total_max_threads':2*THREADS,'rooting':'post-inference conditional, exact split required','original_outputs_modified':False}
    (HERE/'run_metadata.json').write_text(json.dumps(meta,indent=2))
    datasets=prepare();results=[];failures=[]
    with ThreadPoolExecutor(max_workers=2) as pool:
        pending={pool.submit(run_dataset,row):row for row in datasets}
        for f in as_completed(pending):
            try:results.extend(f.result())
            except Exception as e:failures.append({'dataset':pending[f],'error':repr(e)})
            state={'state':'running','completed_analyses':len(results),'failures':failures}
            (HERE/'status.json').write_text(json.dumps(state,indent=2))
            print(json.dumps(state),flush=True)
    (HERE/'completed_runs.json').write_text(json.dumps(results,indent=2))
    (HERE/'status.json').write_text(json.dumps({'state':'complete' if not failures else 'failed','completed_analyses':len(results),'failures':failures,'finished':time.strftime('%Y-%m-%d %H:%M:%S %z')},indent=2))

if __name__=='__main__': main()
