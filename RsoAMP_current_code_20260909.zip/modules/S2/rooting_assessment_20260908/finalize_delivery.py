from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import unquote, urlsplit
import hashlib, json, subprocess, zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((HERE/'synced_file_manifest.json').read_text())
for item in manifest:
    p = HERE/'results'/item['path']
    assert p.stat().st_size == item['bytes'] and digest(p) == item['sha256'], str(p)
results = json.loads((HERE/'results/new_rooting_results.json').read_text())
assert len(results) == 16
rooted = [r['conditional_root'] for r in results if r['conditional_root']]
assert len(rooted) == 9
assert all(r['edge_support_preserved_after_serialization'] for r in rooted)
assert all(r['max_pairwise_distance_change_after_serialization'] < 1e-7 for r in rooted)
assert len(list((HERE/'results/runs').rglob('*.treefile'))) == 16

source_expected = json.loads((HERE/'results/source_hashes.json').read_text())
snapshot = ROOT/'revision_reading/outgroup_audit/server_snapshot/revision_R1_20260902/02_phylogeny'
original_trees = sorted(snapshot.rglob('*.treefile'))
assert len(original_trees) == 12
expected = source_expected + [{'file':'/path/to/rso_project/revision_R1_20260902/02_phylogeny/'+p.relative_to(snapshot).as_posix(),'sha256':digest(p)} for p in original_trees]
code = "from pathlib import Path\nimport json,hashlib\nexpected="+repr(expected)+"\nprint(json.dumps([{'file':r['file'],'sha256':hashlib.sha256(Path(r['file']).read_bytes()).hexdigest(),'unchanged':hashlib.sha256(Path(r['file']).read_bytes()).hexdigest()==r['sha256']} for r in expected]))\n"
r = subprocess.run(['ssh','-T','-o','BatchMode=yes','-o','ConnectTimeout=15','dxy@example-host','python3 -'],input=code.encode(),capture_output=True,timeout=45)
r.check_returncode()
source_check = json.loads(r.stdout)
assert len(source_check)==15 and all(x['unchanged'] for x in source_check)

class LinkCheck(HTMLParser):
    def __init__(self): super().__init__(); self.links=[]; self.tr=0; self.details=0
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if tag=='a' and 'href' in a:self.links.append(a['href'])
        if tag=='tr':self.tr+=1
        if tag=='details':self.details+=1
page=ROOT/'外群定根_先看这一页.html'
parser=LinkCheck(); parser.feed(page.read_text(encoding='utf-8'))
assert parser.tr==17 and parser.details==3
local_links=[x for x in parser.links if not urlsplit(x).scheme and not x.startswith('#')]
assert all((ROOT/unquote(urlsplit(x).path)).exists() for x in local_links)
validation={'new_completed_analyses':16,'new_conditionally_rooted_trees':9,'rooted_tree_label_topology_distance_and_support_checks':'PASS',
 'downloaded_files_verified':len(manifest),'original_3_source_fastas_and_12_trees_unchanged':True,'source_checks':source_check,
 'html_static_checks':{'data_rows':parser.tr-1,'details_panels':parser.details,'all_local_links_exist':True},
 'visual_preview':'Not performed: local file URL access was blocked by browser policy; no workaround attempted.',
 'scope':'Original 12 analyses support sequence groups; 16 new analyses assess candidate rooting. Original manuscript and response not edited for these new findings.'}
(HERE/'final_validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')

deliverables = [ROOT/'外群定根_先看这一页.html',ROOT/'外群定根评估报告_20260908.md',ROOT/'R1.M4_外群定根补充回复_中英.md']
files=sorted(p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='delivery_manifest.json')+deliverables
rows=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)} for p in files]
delivery_manifest=HERE/'delivery_manifest.json'
delivery_manifest.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
archive=ROOT/'外群定根_结果与补充回复_20260908.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[delivery_manifest]: z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in rows:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
archive_hash=digest(archive)
(ROOT/(archive.name+'.sha256')).write_text(archive_hash+'  '+archive.name+'\n',encoding='utf-8')
print(json.dumps({'validation':'PASS','downloaded_files':len(manifest),'unchanged_originals':len(source_check),'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':archive_hash,'archived_files':len(files)+1},ensure_ascii=False,indent=2))
