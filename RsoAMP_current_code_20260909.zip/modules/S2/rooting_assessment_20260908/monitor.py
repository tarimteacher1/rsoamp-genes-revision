from pathlib import Path
import subprocess,sys
code=r'''
from pathlib import Path
import json,time
p=Path('/path/to/rso_project/rooting_assessment_20260908')
done=[json.loads(f.read_text()) for f in (p/'runs').rglob('*.completed.json')]
active=[]
for f in sorted((p/'runs').rglob('*.stdout.log')):
    if not f.with_name(f.name.replace('.stdout.log','.completed.json')).exists():
        lines=f.read_text().splitlines()
        active.append({'run':str(f.relative_to(p)),'last_output':lines[-3:]})
status={}
for name in ['status.json','defensin_status.json']:
    if (p/name).exists():status[name]=json.loads((p/name).read_text())
print(json.dumps({'time':time.strftime('%H:%M:%S'),'completed':len(done),'expected':16,'active':active,'status':status},indent=2))
'''
r=subprocess.run(['ssh','-T','-o','BatchMode=yes','dxy@example-host','python3 -'],input=code.encode(),capture_output=True,timeout=30)
print(r.stdout.decode());print(r.stderr.decode());r.check_returncode()
