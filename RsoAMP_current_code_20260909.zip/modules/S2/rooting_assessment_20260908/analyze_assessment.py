"""Exact unrooted split audit and conditional rooting, preserving edge support values."""
from pathlib import Path
from itertools import combinations
from collections import Counter
import csv, json, copy, hashlib, re
from Bio import Phylo, SeqIO
import numpy as np

HERE=Path(__file__).resolve().parent
SOURCE=Path('/path/to/rso_project/revision_R1_20260902')
PHY=SOURCE/'02_phylogeny'
STRATEGIES=['full.untrimmed','full.gappyout','core.untrimmed','core.gappyout']

def table(p): return list(csv.DictReader(p.open(),delimiter='\t'))
def names(clade): return frozenset(t.name for t in clade.get_terminals())
def key(side, universe):
    a,b=tuple(sorted(side)),tuple(sorted(universe-side))
    return min((a,b),key=lambda x:(len(x),x))
def edges(tree):
    universe=names(tree)
    return {key(names(c),universe):{'label':c.name if not c.is_terminal() else None,'length':c.branch_length,'size':len(names(c))} for c in tree.find_clades() if c is not tree.root}
def supported(value):
    if not value:return False
    try:a,b=map(float,str(value).split('/'));return a>=80 and b>=95
    except ValueError:return False

def all_leaf_distances(tree):
    graph={c:[] for c in tree.find_clades()}
    for parent in tree.find_clades():
        for child in parent.clades:
            length=child.branch_length or 0.0
            graph[parent].append((child,length));graph[child].append((parent,length))
    leaves=tree.get_terminals();result={}
    for start in leaves:
        stack=[(start,None,0.0)]
        while stack:
            node,previous,distance=stack.pop()
            if node.is_terminal() and node.name>start.name:result[(start.name,node.name)]=distance
            stack.extend((n,node,distance+w) for n,w in graph[node] if n is not previous)
    return result

def rooted(tree,outgroup,target):
    outgroup=frozenset(outgroup);alltaxa=names(tree);initial=edges(tree)
    assert outgroup<alltaxa
    if key(outgroup,alltaxa) not in initial:return None
    result=copy.deepcopy(tree)
    # Root first on an ingroup terminal so the requested outgroup is a descendant clade.
    inside=sorted(alltaxa-outgroup)[0]
    result.root_with_outgroup(next(t for t in result.get_terminals() if t.name==inside))
    outs=[t for t in result.get_terminals() if t.name in outgroup]
    node=result.common_ancestor(outs)
    assert names(node)==outgroup
    result.root_with_outgroup(node,outgroup_branch_length=(node.branch_length or 0.0)/2)
    assert len(result.root.clades)==2
    outchild=next(c for c in result.root.clades if names(c)==outgroup)
    inchild=next(c for c in result.root.clades if names(c)==alltaxa-outgroup)
    # Biopython stores support on nodes. Reassign by exact edge split after rerooting.
    for c in result.get_nonterminals():
        c.name=None;c.confidence=None
        if c is not result.root and c is not outchild:
            c.name=initial.get(key(names(c),alltaxa),{}).get('label')
    assert names(result)==alltaxa
    assert set(edges(result))==set(initial)
    # Complete pairwise distance check is inexpensive for these small trees.
    before_dist=all_leaf_distances(tree);after_dist=all_leaf_distances(result)
    assert before_dist.keys()==after_dist.keys()
    maximum_error=max(abs(before_dist[pair]-after_dist[pair]) for pair in before_dist)
    assert maximum_error<1e-8, maximum_error
    target.parent.mkdir(parents=True,exist_ok=True)
    Phylo.write(result,str(target),'newick',format_branch_length='%1.10f')
    written=Phylo.read(str(target),'newick')
    assert names(written)==alltaxa and set(edges(written))==set(initial)
    def support_map(t):
        return {key(names(c),alltaxa):c.name for c in t.get_nonterminals() if c is not t.root and c.name}
    assert support_map(written)==support_map(tree), 'Support labels changed during reroot/write'
    written_dist=all_leaf_distances(written)
    serialized_error=max(abs(before_dist[pair]-written_dist[pair]) for pair in before_dist)
    assert serialized_error<1e-7
    # The joining edge supports the outgroup split, not a statistical confidence in the root.
    basal=sorted([sorted(names(c)) for c in inchild.clades])
    info={'outgroup':sorted(outgroup),'split_support':initial[key(outgroup,alltaxa)]['label'],'split_joint_support':supported(initial[key(outgroup,alltaxa)]['label']),
          'ingroup_root_children':basal,'ingroup_basal_branch_support':[{'taxa':sorted(names(c)),'support':initial.get(key(names(c),alltaxa),{}).get('label')} for c in inchild.clades],
          'root_signature_sha256':hashlib.sha256(json.dumps(basal,sort_keys=True).encode()).hexdigest(),
          'conditional_rooted_file':str(target.relative_to(HERE)),'max_pairwise_distance_change':maximum_error,
          'max_pairwise_distance_change_after_serialization':serialized_error,'edge_support_preserved_after_serialization':True,
          'root_reliability':'conditional on outgroup validity; split support is NOT root confidence'}
    return info

def alignment_stats(path,outgroup):
    records={x.id:str(x.seq) for x in SeqIO.parse(path,'fasta')}
    seqs=list(records.values());l=len(seqs[0]);assert all(len(x)==l for x in seqs)
    pi=sum(sum(v>=2 for v in Counter(x[i] for x in seqs if x[i] not in '-?X').values())>=2 for i in range(l))
    overlaps=[];pids=[];nons_cys=[]
    for o in outgroup:
        for k,s in records.items():
            if k in outgroup:continue
            pairs=[(a,b) for a,b in zip(records[o],s) if a not in '-?X' and b not in '-?X']
            overlaps.append(len(pairs));pids.append(sum(a==b for a,b in pairs)/max(1,len(pairs))*100)
            nons_cys.append(sum(a==b and a!='C' for a,b in pairs)/max(1,len(pairs))*100)
    return {'taxa':len(seqs),'columns':l,'informative_columns':pi,'gap_percent':sum(x.count('-') for x in seqs)/(len(seqs)*l)*100,
            'outgroup_to_ingroup_PID2_median':float(np.median(pids)),'PID2_denominator':'paired unambiguous non-gap residues, separately for each pair',
            'paired_residue_count_median':float(np.median(overlaps)),'non_C_identity_same_denominator_median':float(np.median(nons_cys))}

def baseline():
    result={'Tamarix_whole_family':[],'Tamarix_local_candidates':[],'original_2S_conditional_roots':[],'original_Pinus_conditional_roots':[]}
    rbh=table(SOURCE/'05_comparative_genomics/orthogroups.tsv')
    syn=table(SOURCE/'05_comparative_genomics/rso_tamarix_amp_synteny.tsv')
    candidates=json.loads((HERE/'Tamarix_local_candidate_splits.json').read_text())
    for fam in ['Defensin','Snakin_GASA','nsLTP']:
        for strategy in STRATEGIES:
            tree=Phylo.read(PHY/fam/(fam+'.'+strategy+'.treefile'),'newick')
            universe=names(tree);ed=edges(tree);tau={x for x in universe if x.startswith('TAU_')}
            result['Tamarix_whole_family'].append({'family':fam,'strategy':strategy,'Tamarix_count':len(tau),'all_Tamarix_is_exact_split':key(tau,universe) in ed})
            if fam=='Defensin':
                og={'UNI_A4L7R7','UNI_A4L7R8'}
                info=rooted(tree,og,HERE/'conditional_roots/original_Pinus'/(fam+'.'+strategy+'.nwk'))
                result['original_Pinus_conditional_roots'].append({'family':fam,'strategy':strategy,'candidate_outgroup_monophyletic':info is not None,'conditional_root':info})
            if fam=='nsLTP':
                og={x for x in universe if x.startswith('NEG2S_')}
                info=rooted(tree,og,HERE/'conditional_roots/original_2S'/(fam+'.'+strategy+'.nwk'))
                result['original_2S_conditional_roots'].append({'family':fam,'strategy':strategy,**info})
            for n,c in enumerate(candidates,1):
                if c['family']!=fam:continue
                group=set(c['taxa']);tau1=next(x for x in group if x.startswith('TAU_'));rso={x for x in group if x.startswith('RSO_')}
                within=ed.get(key(rso,universe),{})
                subset=copy.deepcopy(tree)
                # Pruning can merge edges and support labels: export topology and lengths only.
                for node in subset.get_nonterminals():node.name=None;node.confidence=None
                for t in list(subset.get_terminals()):
                    if t.name not in group:subset.prune(t)
                conditional=rooted(subset,{tau1},HERE/'conditional_roots/Tamarix_local'/('candidate'+str(n)+'.'+strategy+'.nwk'))
                matches=[x['orthogroup_id'] for x in rbh if 'TAU_'+x['tamarix_display_id']==tau1 and 'RSO_'+x['rso_display_id'] in rso and x['amp_family_concordant']=='YES']
                sy=[x['mcscanx_block'] for x in syn if 'TAU_'+x['tamarix_gene'].removeprefix('TAU__')==tau1 and 'RSO_'+x['rso_amp_id'] in rso and x['direct_amp_to_amp_anchor']=='YES']
                result['Tamarix_local_candidates'].append({'candidate':n,'family':fam,'strategy':strategy,'taxa':sorted(group),'rso_only_split_present':bool(within),'rso_only_split_support':within.get('label'),'rso_only_joint_support':supported(within.get('label')),'RBH_pairs':matches,'direct_synteny_blocks':sy,'pruned_root_note':'Topology-only exploratory root; pruning a three-tip group makes the rooted sister pair tautological and is not duplication evidence.',**conditional})
    (HERE/'baseline_rooting_audit.json').write_text(json.dumps(result,indent=2))
    return result

def new_runs():
    completed=[json.loads(p.read_text()) for p in (HERE/'runs').rglob('*.completed.json')]
    result=[]
    for row in sorted(completed,key=lambda x:(x['name'],x['region'],x['trim'])):
        pre=Path(row['prefix']);tree=Phylo.read(str(pre)+'.treefile','newick')
        expected=frozenset(row['ingroup'])|frozenset(row['outgroup'])
        assert names(tree)==expected, 'Inference output lost or gained taxa'
        assert frozenset(x.id for x in SeqIO.parse(row['alignment'],'fasta'))==expected
        info=rooted(tree,row['outgroup'],HERE/'conditional_roots/new_runs'/(row['name']+'.'+row['region']+'.'+row['trim']+'.nwk'))
        log=Path(str(pre)+'.log').read_text();report=Path(str(pre)+'.iqtree').read_text()
        composition=[x.strip() for x in log.splitlines() if any(o in x for o in row['outgroup']) and re.search(r'\s(?:passed|failed)\s',x)]
        model=re.search(r'Best-fit model according to BIC: (.+)',report)
        result.append({'dataset':row['name'],'region':row['region'],'trimming':row['trim'],'alignment':str(Path(row['alignment']).relative_to(HERE)),'tree':str(pre.relative_to(HERE))+'.treefile','candidate_outgroup_monophyletic':info is not None,'conditional_root':info,'alignment_stats':alignment_stats(row['alignment'],row['outgroup']),'model':model.group(1).strip() if model else None,'outgroup_composition_tests':composition,'saturation_warning':any('saturat' in x.lower() for x in log.splitlines())})
    (HERE/'new_rooting_results.json').write_text(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    b=baseline();n=new_runs()
    print(json.dumps({'original_Tamarix_whole_family_splits':sum(x['all_Tamarix_is_exact_split'] for x in b['Tamarix_whole_family']),'baseline_local_roots':len(b['Tamarix_local_candidates']),'new_completed':len(n),'new_results':[{k:r[k] for k in ['dataset','region','trimming','candidate_outgroup_monophyletic']}|{'split_support':r['conditional_root']['split_support'] if r['conditional_root'] else None,'root_signature':r['conditional_root']['root_signature_sha256'][:12] if r['conditional_root'] else None} for r in n]},indent=2))
