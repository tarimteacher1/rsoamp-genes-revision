from pathlib import Path
import subprocess,json,base64,hashlib,zlib

HERE=Path(__file__).resolve().parent
CODE=r'''
from pathlib import Path
import json,base64,hashlib,zlib,sys
p=Path('/path/to/rso_project/rooting_assessment_20260908')
files=[];inventory=[]
for f in sorted(p.rglob('*')):
    if not f.is_file() or '__pycache__' in f.parts:continue
    data=f.read_bytes()
    row={'path':str(f.relative_to(p)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    inventory.append(row)
    if f.suffix in ['.py','.json','.tsv','.txt','.md','.faa','.nwk','.treefile','.iqtree','.log','.contree','.pdf','.png']:
        files.append({**row,'data':base64.b64encode(data).decode()})
payload=json.dumps({'files':files,'remote_inventory':inventory}).encode()
sys.stdout.buffer.write(zlib.compress(payload,6))
'''
r=subprocess.run(['ssh','-T','-o','BatchMode=yes','-o','ConnectTimeout=15','dxy@example-host','python3 -'],input=CODE.encode(),capture_output=True,timeout=60)
r.check_returncode();result=json.loads(zlib.decompress(r.stdout));n=0
for row in result['files']:
    target=(HERE/'results'/row['path']).resolve()
    assert target.is_relative_to((HERE/'results').resolve())
    data=base64.b64decode(row['data']);assert hashlib.sha256(data).hexdigest()==row['sha256']
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);n+=1
(HERE/'synced_file_manifest.json').write_text(json.dumps([{k:r[k] for k in ['path','bytes','sha256']} for r in result['files']],indent=2))
(HERE/'remote_full_inventory.json').write_text(json.dumps(result['remote_inventory'],indent=2))
print(json.dumps({'synced_files':n,'compressed_transfer_bytes':len(r.stdout),'all_downloaded_hashes_verified':True}))
