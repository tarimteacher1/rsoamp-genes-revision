from pathlib import Path
from collections import Counter
import json,html

HERE=Path(__file__).resolve().parent
data=json.loads((HERE/'results/new_rooting_results.json').read_text())
assert len(data)==16, 'Build the final reading page only after all 16 analyses finish.'
esc=html.escape
groups=[('nsLTP','LTP','2S 蛋白'),('Snakin/GASA','GASA','卷柏 GASA'),('Defensin','DEF','裸子植物 defensin')]
cards=[];rows=[]
dataset_names={'LTP_2S_all8':'nsLTP：8 条 2S','LTP_2S_Arabidopsis5':'nsLTP：拟南芥 5 条 2S','LTP_2S_G7_3':'nsLTP：Medicago 3 条 2S','DEF_Gymnosperms10':'Defensin：10 条裸子植物序列','GASA_Selaginella3':'GASA：3 条卷柏序列'}
for title,prefix,candidate in groups:
    selected=[r for r in data if r['dataset'].startswith(prefix)]
    roots=[r['conditional_root'] for r in selected if r['conditional_root']]
    variants=len({r['root_signature_sha256'] for r in roots})
    if not roots: verdict='未形成可统一分离的候选外群'
    elif len(roots)<len(selected):verdict='候选外群未在所有策略中成立'
    elif variants>1:verdict='可以画出条件性定根树，但根位置不一致'
    elif not all(r['split_joint_support'] for r in roots):verdict='根位置一致，但部分分支未通过支持度门槛'
    else:verdict='本次测试根位置一致；仍须审查外群的进化依据'
    cards.append(f'<article><span class="label">{title}</span><h3>{verdict}</h3><p>候选：{candidate}。完成 {len(selected)} 次分析；{len(roots)} 次能分离候选外群，得到 {variants} 种内群根部划分。</p></article>')
    for r in selected:
        root=r['conditional_root'];a=r['alignment_stats']
        region={'full':'全长','core':'首末 C 区域'}[r['region']]
        trimming={'untrimmed':'未修剪','gappyout':'gappyout 修剪'}[r['trimming']]
        rows.append(f'<tr><td>{dataset_names[r["dataset"]]}</td><td>{region} / {trimming}</td><td>{a["taxa"]} / {a["columns"]}</td><td>{root["split_support"] if root else "没有对应分支"}</td><td>{" / ".join(str(len(s)) for s in root["ingroup_root_children"]) if root else "—"}</td></tr>')
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>外群定根：先看这一页</title>
<style>
:root{color-scheme:light}*{box-sizing:border-box}body{margin:0;background:#f6f5f1;color:#23343a;font:17px/1.8 "Microsoft YaHei","PingFang SC",sans-serif}main{max-width:1050px;margin:auto;padding:48px 26px 70px}.eyebrow{font-size:14px;color:#526f73;letter-spacing:2px}h1{font-size:34px;line-height:1.4;margin:8px 0 18px}h2{font-size:23px;margin:0 0 18px}h3{font-size:19px;line-height:1.6;margin:10px 0}p{margin:10px 0 16px}.lead{font-size:21px;max-width:850px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:26px 0}article{border:1px solid #d7e0df;border-radius:14px;background:#fff;padding:23px}.label{color:#27696d;font-weight:bold}article p{font-size:15px;margin-bottom:0}.note{background:#e7efec;border-left:4px solid #448175;border-radius:4px;padding:18px 22px;margin:28px 0}.note p{margin:0}details{border-top:1px solid #d7deda;padding:22px 0}summary{cursor:pointer;font-size:22px;font-weight:bold;margin-bottom:12px}details>div{padding:10px 0 0}a{color:#23676d}svg{display:block;background:white;border:1px solid #d7e0df;border-radius:12px;width:100%;height:auto;margin:20px 0}.caption{font-size:14px;color:#53656c}table{width:100%;border-collapse:collapse;font-size:14px}th,td{padding:12px 10px;border-bottom:1px solid #dce3df;text-align:left}th{background:#eaf0ed}.scroll{overflow:auto}footer{font-size:13px;color:#5e6a70;margin-top:26px}@media(max-width:760px){.cards{grid-template-columns:1fr}main{padding:28px 18px}h1{font-size:28px}.lead{font-size:18px}summary{font-size:20px}}
</style><main><div class="eyebrow">GENES 修订 · 2026 年 9 月 8 日 · 分层阅读</div><h1>外群定根：先看这一页</h1><p class="lead">近缘种比较提供了值得检验的同源序列。能否把它们当作外群，要看基因家族中的位置和复制关系。</p><p>本次已重新运行 16 次分析，并检查原有 12 棵树。下面按家族区分结果。</p><section class="cards">'''+''.join(cards)+'''</section>
<div class="note"><p><strong>现有稳定分组分析仍有价值。</strong>分组回答“哪些成员稳定聚在一起”；定根回答“从哪里开始分化”。根未解决时，仍可如实报告有支持的分组，保留未解决关系。</p></div>
<details><summary>第一层：Tamarix 比较到底帮了什么？</summary><div><p>归一化数量用于比较成员数量；双向最佳匹配用于筛选可能对应的拷贝；共线性用于核对基因所在区段的关系。它们不能直接给出整个家族的树根。</p><p>已有 28 对家族一致的最佳匹配，其中 <strong>12 对在全部四种策略下形成高支持分支</strong>。这是有用的同源关系证据。不过，在全部 12 棵原树中，所有 Tamarix 成员都不能被一条枝与其余成员整体分开。</p><p>因此可以保留并使用这项比较；目前不能把全部 Tamarix 序列直接指定为三个家族的统一外群。</p></div></details>
<details><summary>第二层：用一个真实例子理解</summary><div><p>RsLTP39、RsLTP40 和一条 Tamarix 序列在四种策略下都聚成稳定的三成员组。但组内最稳定的一对是 <strong>RsLTP40 与 Tamarix</strong>。</p>
<svg viewBox="0 0 900 335" role="img" aria-label="未定根连接关系：其余150条序列和RsLTP39连接在一侧，RsLTP40与Tamarix连接在另一侧"><g fill="none" stroke="#677f83" stroke-width="3"><path d="M185 95 L345 165 L185 255 M345 165 L565 165 M565 165 L720 95 M565 165 L720 255"/></g><g font-family="Microsoft YaHei,sans-serif" font-size="20" fill="#263d46"><text x="35" y="80">其余 150 条序列</text><text x="35" y="285" fill="#246d83">红砂 RsLTP39</text><text x="672" y="80" fill="#246d83">红砂 RsLTP40</text><text x="675" y="285" fill="#a36827">Tamarix</text><text x="390" y="146" font-size="19">99.6 / 100</text><text x="260" y="320" font-size="14" fill="#667a7d">无箭头：未指定根；枝长未按比例绘制</text></g><circle cx="345" cy="165" r="5" fill="#677f83"/><circle cx="565" cy="165" r="5" fill="#677f83"/></svg>
<p class="caption">连接与支持度来自原全长 + gappyout 树。Tamarix 序列为 novel_model_206_643946eb；与 RsLTP40 对应 RBH_0013。99.6/100 是分支支持度，不是树根正确率。</p><p>截出这三条序列后，软件确实能把 Tamarix 放在一侧、两个红砂成员放在另一侧。但这取决于人为指定的根，不能用来证明红砂成员的复制先后。</p></div></details>
<details><summary>第三层：查看 16 次分析的具体结果</summary><div><p class="caption">“序列/位点”为输入数量与比对长度；“分支支持”为 SH-aLRT/UFBoot；“内群两侧数量”描述条件性根部的划分。相同数量不保证成员相同，精确成员对应保存在 TSV 表中。首末 C 区域沿用项目定义，不等同于经实验确认的成熟肽。</p><div class="scroll"><table><thead><tr><th>候选集合</th><th>策略</th><th>序列 / 位点</th><th>外群分支支持</th><th>内群两侧数量</th></tr></thead><tbody>'''+''.join(rows)+'''</tbody></table></div></div></details>
<footer>所有新结果保存在独立的 rooting_assessment_20260908 目录；原论文图件和原始树未覆盖。<a href="rooting_assessment_20260908/实验设计与判定标准.md">实验设计</a> · <a href="rooting_assessment_20260908/定根试验结果_16次.tsv">完整指标</a> · <a href="rooting_assessment_20260908/根位置对应成员.tsv">根位置成员表</a> · <a href="https://iqtree.github.io/doc/Rootstrap">IQ-TREE 定根说明</a></footer></main></html>'''
target=HERE.parent/'外群定根_先看这一页.html'
target.write_text(page,encoding='utf-8')
print(target)
