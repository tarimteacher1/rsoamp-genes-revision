from pathlib import Path
import csv,json,hashlib
from collections import Counter
P=Path(__file__).resolve().parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=list(csv.DictReader((P/'SHA256SUMS.tsv').open(encoding='utf-8-sig'),delimiter='\t'))
for r in manifest:
 p=P/r['relative_path'];assert p.is_file(),p
 assert p.stat().st_size==int(r['bytes']) and sha(p.read_bytes())==r['sha256'],p
seqs={};key=None
for line in (P/'inputs/union_full_proteins.faa').read_text().splitlines():
 if line.startswith('>'):
  key=line[1:].split()[0];assert key not in seqs;seqs[key]=''
 else:seqs[key]+=line.strip()
assert len(seqs)==98 and len(set(seqs.values()))==98
assert all(set(s)<=set('ACDEFGHIKLMNPQRSTVWY') for s in seqs.values())
pred=json.loads((P/'evidence/predictions_by_sequence.json').read_text())
assert len(pred)==98
for r in pred:
 assert sha(seqs[r['union_id']].encode())==r['sequence_sha256']
 parts=[(a,float(b)) for a,b in (v.strip().split() for v in r['wolfpsort_profile'].split(','))]
 maximum=max(b for a,b in parts);top=[a for a,b in parts if b==maximum]
 assert set(top)==set(r['wolfpsort_top_labels'].split(';'))
 assert bool(r['wolfpsort_top_tie'])==(len(top)>1)
rows=json.loads((P/'evidence/localization_rows.json').read_text())
summary=json.loads((P/'evidence/localization_summary.json').read_text())
assert len(rows)==len({r['sequence_sha256'] for r in rows})==98
for name,stats in summary['cohorts'].items():
 subset=[r for r in rows if r[name]]
 assert len(subset)==stats['n'],name
 counts=Counter('TOP_TIE' if r['wolfpsort_top_tie'] else r['wolfpsort_top_labels'] for r in subset)
 assert dict(counts)==stats['unique_highest_or_tie'],name
 assert sum(r['deepsig_positive'] for r in subset)==stats['DeepSig_positive'],name
print(json.dumps({'status':'PASS','files_verified':len(manifest),'unique_sequences':98,'cohorts_verified':len(summary['cohorts'])}))
