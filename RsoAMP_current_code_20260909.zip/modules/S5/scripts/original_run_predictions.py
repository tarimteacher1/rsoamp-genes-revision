
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,os,hashlib,shutil,traceback,tarfile
R=Path(__file__).resolve().parent
W=R/'software/WoLFPSort'; D=Path('/path/to/user/tools/miniconda3/envs/deepsig_env')
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
status={'state':'running','started_utc':now(),'commands':[]}
def save():(R/'run_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2))
def run(name,args,cwd,env,stdin=None):
    entry={'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'stdin':str(stdin) if stdin else None,'started_utc':now()}
    status['commands'].append(entry);save()
    with (R/(name+'.stdout.txt')).open('wb') as out,(R/(name+'.stderr.txt')).open('wb') as err:
        inp=stdin.open('rb') if stdin else None
        try:p=subprocess.run(args,cwd=cwd,env=env,stdin=inp,stdout=out,stderr=err,timeout=1200)
        finally:
            if inp:inp.close()
    entry.update(returncode=p.returncode,completed_utc=now());save()
    if p.returncode:raise RuntimeError(name+' returncode '+str(p.returncode))
try:
    for src in (W/'bin/binByPlatform/binary-i386').iterdir():
        if src.is_file():shutil.copy2(src,W/'bin'/src.name)
    env=os.environ.copy();env.update(LANG='C',LC_ALL='C',CUDA_VISIBLE_DEVICES='-1',TF_CPP_MIN_LOG_LEVEL='3',OMP_NUM_THREADS='4',TF_NUM_INTRAOP_THREADS='4',TF_NUM_INTEROP_THREADS='1',DEEPSIG_ROOT=str(D/'share/deepsig'))
    run('wolfpsort',['/usr/bin/perl',str(W/'bin/runWolfPsortSummary'),'plant'],W,env,R/'union_full_proteins.faa')
    run('deepsig',[str(D/'bin/deepsig'),'-f',str(R/'union_full_proteins.faa'),'-o',str(R/'union.deepsig.gff3'),'-k','euk','-m','gff3','-t','4'],R,env)
    manifest={'wolfpsort_version':'0.2','wolfpsort_repository':'https://github.com/fmaguire/WoLFPSort','wolfpsort_commit':subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip(),'deepsig_version':subprocess.check_output([str(D/'bin/deepsig'),'--version'],env=env,text=True).strip(),'deepsig_repository':'https://github.com/BolognaBiocomp/deepsig','environment':{k:env[k] for k in ['LANG','LC_ALL','CUDA_VISIBLE_DEVICES','TF_CPP_MIN_LOG_LEVEL','OMP_NUM_THREADS','TF_NUM_INTRAOP_THREADS','TF_NUM_INTEROP_THREADS','DEEPSIG_ROOT']},'perl':subprocess.check_output(['/usr/bin/perl','-e','print "$^V"'],text=True),'uname':subprocess.check_output(['uname','-a'],text=True).strip(),'files':[]}
    files=[p for p in W.rglob('*') if p.is_file() and '.git' not in p.parts]
    for p in files:manifest['files'].append({'group':'WoLFPSort','relative':str(p.relative_to(W)),'size':p.stat().st_size,'sha256':sha(p)})
    dsp=[p for p in (D/'share/deepsig').rglob('*') if p.is_file() and ('euk' in p.parts or 'tools' in p.parts)]
    dsp += [p for p in (D/'lib/python3.8/site-packages/deepsig').rglob('*.py')]
    dsp += [D/'bin/deepsig']
    for p in dsp:manifest['files'].append({'group':'DeepSig','relative':str(p.relative_to(D)),'size':p.stat().st_size,'sha256':sha(p)})
    metas=[json.loads(p.read_text()) for p in (D/'conda-meta').glob('*.json')]
    (R/'deepsig_conda_metadata.json').write_text(json.dumps(metas,indent=2))
    (R/'deepsig_environment_explicit.txt').write_text('@EXPLICIT\n'+'\n'.join(m['url'] for m in sorted(metas,key=lambda x:x['name']) if m.get('url'))+'\n')
    (R/'software_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    with tarfile.open(R/'software_snapshot.tar.gz','w:gz') as tf:
        for p in files:tf.add(p,arcname='WoLFPSort/'+str(p.relative_to(W)),recursive=False)
        for p in dsp:tf.add(p,arcname='DeepSig_1.2.5/'+str(p.relative_to(D)),recursive=False)
    status.update(state='complete',completed_utc=now(),output_hashes={p.name:sha(p) for p in [R/'wolfpsort.stdout.txt',R/'wolfpsort.stderr.txt',R/'union.deepsig.gff3',R/'software_manifest.json',R/'software_snapshot.tar.gz']})
except Exception:
    status.update(state='error',error=traceback.format_exc(),completed_utc=now())
save()
