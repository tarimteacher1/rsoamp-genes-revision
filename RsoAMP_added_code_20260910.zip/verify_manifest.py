from pathlib import Path
import csv,hashlib
root=Path(__file__).resolve().parent
rows=list(csv.DictReader((root/'MANIFEST_SHA256.tsv').open(encoding='utf8'),delimiter='\t'))
for r in rows:
 p=root/r['path']
 assert p.is_file(),r['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],r['path']
print('PASS',len(rows),'distributed files')
