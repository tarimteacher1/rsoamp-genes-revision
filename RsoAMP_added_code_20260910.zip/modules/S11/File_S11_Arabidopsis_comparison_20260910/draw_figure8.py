from pathlib import Path
from collections import Counter
import json,copy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch,FancyBboxPatch,Polygon,Patch
from matplotlib.lines import Line2D
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np

W=Path(__file__).resolve().parent;OUT=W/'figures';OUT.mkdir(exist_ok=True)
T=json.loads((W/'sources/Tamarix_plot_data.json').read_text(encoding='utf-8'))
A=json.loads((W/'analysis/Arabidopsis_plot_data.json').read_text(encoding='utf-8'))
G=T['genes']|A['genes']
# Keep the curated Tamarix/Rso model annotations, including reconstructed models.
G.update(T['genes'])
FC={'Defensin':'#C43D3D','Snakin_GASA':'#2E6F9E','nsLTP':'#2F7D4A'}
FN={'Defensin':'Defensin','Snakin_GASA':'Snakin/GASA','nsLTP':'nsLTP'}
SC={'RSO':'#4D758B','TAU':'#AD8358','ATH':'#78875D'}
SN={'RSO':'R. soongarica','TAU':'T. austromongolica','ATH':'A. thaliana'}
plt.rcParams.update({'font.family':'Arial','font.size':8,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.linewidth':.55,'text.color':'#24323B','axes.labelcolor':'#24323B','savefig.facecolor':'white'})
LABELS=[]

def curve(ax,x1,y1,x2,y2,col,lw=1,alpha=1,ls='-',z=2):
 dy=(y2-y1)*.42
 pa=MPath([(x1,y1),(x1,y1+dy),(x2,y2-dy),(x2,y2)],[1,4,4,4])
 ax.add_patch(PathPatch(pa,fill=False,ec=col,lw=lw,alpha=alpha,ls=ls,zorder=z))

def ribbon(ax,a,b,c,d,y1,y2,col,alpha=.1):
 m1=y1+(y2-y1)*.4;m2=y2-(y2-y1)*.4
 v=[(a,y1),(a,m1),(c,m2),(c,y2),(d,y2),(d,m2),(b,m1),(b,y1),(a,y1)]
 ax.add_patch(PathPatch(MPath(v,[1,4,4,4,2,4,4,4,79]),fc=col,ec='none',alpha=alpha,zorder=1))

def title(fig,label,text,y):
 fig.text(.035,y,label,fontweight='bold',fontsize=12,va='top')
 fig.text(.087,y-.001,text,fontweight='bold',fontsize=10,va='top')

def inventory(fig):
 title(fig,'A','Family inventories',.975)
 ax=fig.add_axes([.13,.846,.82,.090]);x=np.arange(3)
 for i,sp in enumerate(['RSO','TAU']):
  for j,f in enumerate(FC):
   r=next(r for r in T['counts'] if r['family']==f and r['species'].startswith('Reaumuria' if sp=='RSO' else 'Tamarix'))
   n=int(r['annotated_catalogue_members']);m=int(r['additional_homology_models']);xx=j+(-.17 if i==0 else .17)
   ax.bar(xx,n,width=.29,color=SC[sp],lw=0,zorder=3)
   if m:ax.bar(xx,m,width=.29,bottom=n,facecolor='#F6F2ED',edgecolor=SC[sp],hatch='////',lw=.6,zorder=3)
   ax.text(xx,n+m+1,str(n+m),ha='center',fontsize=8.5)
 ax.set_ylim(0,46);ax.set_yticks([0,20,40]);ax.set_ylabel('Candidate members',fontsize=8)
 ax.set_xticks(x,[FN[f] for f in FC]);ax.tick_params(labelsize=8,length=2.5,pad=3)
 ax.spines[['top','right']].set_visible(False);ax.spines[['left','bottom']].set_color('#819198');ax.grid(axis='y',lw=.35,color='#E4E9EC',zorder=0)
 fig.legend(handles=[Patch(fc=SC[s],label=SN[s]) for s in ['RSO','TAU']],loc='upper right',bbox_to_anchor=(.96,.966),frameon=False,ncol=2,prop={'style':'italic','size':7.7},handlelength=1.4,columnspacing=1.4)
 fig.text(.13,.816,'Hatching: reconstructed or homology-derived models.',fontsize=7.2,color='#61717B')

def macro(fig):
 title(fig,'B','Chromosome-scale collinearity with two comparator species',.783)
 ax=fig.add_axes([.067,.463,.89,.291]);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
 chromosomes=T['chromosomes']|{'ATH':A['chromosomes']['ATH']};span={}
 for sp,cs in chromosomes.items():
  gap=.009;space=.96-gap*(len(cs)-1);total=sum(c['length'] for c in cs);at=.02
  for c in cs:
   width=space*c['length']/total;span[(sp,c['chrom'])]=(at,width,c['length']);at+=width+gap
 def xp(gid,pos):
  g=G[gid];x,w,n=span[(g['species'],g['chrom'])];return x+w*pos/n
 yy={'TAU':.84,'RSO':.50,'ATH':.16}
 def draw_blocks(dataset,partner):
  for b in dataset['blocks']:
   aa=[p['gene1'] for p in b['pairs']];bb=[p['gene2'] for p in b['pairs']]
   assert all((G[k]['species'],G[k]['chrom']) in span for k in aa+bb)
   a=xp(aa[0],min(G[k]['start'] for k in aa));c=xp(aa[0],max(G[k]['end'] for k in aa))
   h=xp(bb[0],min(G[k]['start'] for k in bb));j=xp(bb[0],max(G[k]['end'] for k in bb))
   if b['orientation']=='minus':h,j=j,h
   ribbon(ax,a,c,h,j,yy['RSO'],yy[partner],'#A5AEB5',.075)
 draw_blocks(T,'TAU');draw_blocks(A,'ATH')
 for r in T['amp_pairs']:
  a,h=r['rso_gene'],r['tamarix_gene'];direct=r['direct_amp_to_amp_anchor']=='YES';fam=r['rso_amp_family'] or r['tamarix_amp_family']
  col=FC[fam] if direct else '#7B8186'
  curve(ax,xp(a,(G[a]['start']+G[a]['end'])/2),yy['RSO'],xp(h,(G[h]['start']+G[h]['end'])/2),yy['TAU'],col,1 if direct else .75,.85,'-' if direct else (0,(3,2)),3)
 for r in A['amp_pairs']:
  a,h=r['rso_id'],r['ath_id'];col=FC[r['rso_family']]
  curve(ax,xp(a,(G[a]['start']+G[a]['end'])/2),yy['RSO'],xp(h,(G[h]['start']+G[h]['end'])/2),yy['ATH'],col,1,.85,z=3)
 for sp in ['TAU','RSO','ATH']:
  y=yy[sp]
  for c in chromosomes[sp]:
   x,w,n=span[(sp,c['chrom'])]
   ax.add_patch(FancyBboxPatch((x,y-.012),w,.024,boxstyle='round,pad=0,rounding_size=0.004',fc=SC[sp],ec=SC[sp],lw=.35,zorder=5))
   ax.text(x+w/2,y+.040,str(int(c['chrom'][3:])),ha='center',va='center',fontsize=7.5,color=SC[sp],bbox={'fc':'white','ec':'none','pad':.25,'alpha':.9})
  ax.text(.02,y+.101,SN[sp],fontstyle='italic',fontsize=9,color=SC[sp],va='center',bbox={'fc':'white','ec':'none','pad':1,'alpha':.95})
 ax.text(.98,.945,'588 blocks; 25 catalogue pairs + 5 other anchors',ha='right',va='center',fontsize=7.3,color='#61717B')
 ax.text(.98,.053,'819 blocks; 26 Rso-candidate anchors',ha='right',va='center',fontsize=7.3,color='#61717B')
 fig.legend(handles=[Line2D([0],[0],color=FC[f],lw=1.4,label=FN[f]) for f in FC],loc='lower left',bbox_to_anchor=(.077,.449),frameon=False,ncol=3,fontsize=7.5,handlelength=1.9,columnspacing=1.8)
 fig.text(.087,.436,'Chromosome lengths are scaled within each genome; grey ribbons show background blocks.',fontsize=7.1,color='#61717B')

def select_context(member):
 t=next(c for c in T['all_pair_contexts'] if any(r['rso_amp_id']==member and r['direct_amp_to_amp_anchor']=='YES' for r in c['focus_pairs']))
 aa=[c for c in A['all_pair_contexts'] if any(r['rso_member']==member for r in c['focus_pairs'])]
 a=aa[0] if aa else None
 tracks=[copy.deepcopy(t['tracks'][1]),copy.deepcopy(t['tracks'][0])]
 if a:
  tracks.append(copy.deepcopy(a['tracks'][1]));r=tracks[1];other=a['tracks'][0]
  r['start']=min(r['start'],other['start']);r['end']=max(r['end'],other['end'])
  r['genes']=sorted([k for k,g in G.items() if g['species']=='RSO' and g['chrom']==r['chrom'] and g['start']>=r['start'] and g['end']<=r['end'] and g.get('model_source')!='reconstructed_transcript_model'],key=lambda k:G[k]['start'])
 pairs=[];focus=[]
 for p in t['pairs']:pairs.append(p|{'partner':'TAU'})
 for r in t['focus_pairs']:
  if r['rso_amp_id']==member:focus.append({'gene1':r['rso_gene'],'gene2':r['tamarix_gene'],'family':r['rso_amp_family']})
 if a:
  for p in a['pairs']:pairs.append(p|{'partner':'ATH'})
  for r in a['focus_pairs']:
   if r['rso_member']==member:focus.append({'gene1':r['rso_id'],'gene2':r['ath_id'],'family':r['rso_family']})
 return {'member':member,'tracks':tracks,'pairs':pairs,'focus':focus,'family':focus[0]['family'],'tau_block':t['block'],'ath_block':a['block'] if a else None}

def arrow(ax,x1,x2,y,strand,col,extra=False):
 half=.022;head=min((x2-x1)*.4,.006)
 if strand=='+':v=[(x1,y-half),(x2-head,y-half),(x2,y),(x2-head,y+half),(x1,y+half)]
 else:v=[(x2,y-half),(x1+head,y-half),(x1,y),(x1+head,y+half),(x2,y+half)]
 ax.add_patch(Polygon(v,closed=True,fc='#FFF3F0' if extra else col,ec=col,lw=.6 if extra else .2,hatch='////' if extra else None,zorder=5))

def label(k):
 g=G[k]
 if g['species']=='ATH':return g['locus_tag']
 s=g.get('amp',{}).get('display_id',g['source_id'])
 return s.removeprefix('evm.model.').removeprefix('TAU_')

def local(ax,c,header=True):
 ax.set(xlim=(0,1),ylim=(-.04,1.14));ax.axis('off');three=len(c['tracks'])==3
 ys=[.84,.50,.16] if three else [.75,.30];points={};left=.205;right=.975
 focal={k for p in c['focus'] for k in (p['gene1'],p['gene2'])};fp={(p['gene1'],p['gene2']):p for p in c['focus']}
 for t,y in zip(c['tracks'],ys):
  def xp(p):
   z=(p-t['start'])/(t['end']-t['start']);z=1-z if t['reverse'] else z;return left+(right-left)*z
  for k in t['genes']:
   g=G[k];u,v=sorted([xp(g['start']),xp(g['end'])]);points[k]=(u,v,y)
 for p in c['pairs']:
  a,b=p['gene1'],p['gene2'];assert a in points and b in points,(c['member'],a,b)
  u,v,y1=points[a];w,z,y2=points[b];f=fp.get((a,b));col=FC[f['family']] if f else '#A5AEB5'
  ribbon(ax,u,v,w,z,y1,y2,col,.24 if f else .27)
  curve(ax,(u+v)/2,y1,(w+z)/2,y2,col,1 if f else .45,.85 if f else .35,z=3 if f else 1)
 for t,y in zip(c['tracks'],ys):
  sp=t['species'];ax.plot([left,right],[y,y],color='#88969F',lw=.5,zorder=3)
  ax.text(.003,y,SN[sp],color=SC[sp],fontstyle='italic',fontsize=7.2,va='center')
  lo,hi=(t['end'],t['start']) if t['reverse'] else (t['start'],t['end'])
  coords=f"{t['chrom']}  {lo/1e6:.3f}–{hi/1e6:.3f} Mb"+(' (reversed)' if t['reverse'] else '')
  ax.text(right,y-.095,coords,ha='right',va='center',fontsize=6.3,color='#61717B')
  for k in t['genes']:
   g=G[k];u,v,_=points[k];selected=k in focal;col=FC[c['family']] if selected else '#7F8B93';strand=g['strand']
   if t['reverse']:strand='-' if strand=='+' else '+'
   extra=g.get('model_source')=='additional_homology_model'
   arrow(ax,u,v,y,strand,col,extra)
   if selected:
    x=(u+v)/2;lx=min(.88,max(.29,x));ly=y+.104
    ax.plot([x,lx],[y+.029,ly-.035],color=col,lw=.45,zorder=6)
    ax.plot(x,y,marker='D' if extra else 'o',ms=2.8 if extra else 2.4,mfc='white' if extra else col,mec=col,mew=.5,zorder=7)
    ob=ax.text(lx,ly,label(k),ha='center',va='center',fontsize=7.3,color=col,zorder=7);LABELS.append((ax,ob,k))
 if header:ax.text(.003,1.09,FN[c['family']],fontweight='bold',fontsize=8.5,va='center')

def main():
 fig=plt.figure(figsize=(7.5,10.1));inventory(fig);macro(fig)
 title(fig,'C','Local genomic contexts',.410)
 contexts=[select_context(m) for m in ['RsDEF6','RsSNA8','RsLTP13']]
 for rect,c in zip([[.07,.301,.89,.088],[.07,.153,.89,.127],[.07,.012,.89,.127]],contexts):local(fig.add_axes(rect),c)
 fig.canvas.draw();ren=fig.canvas.get_renderer();overlap=[]
 for i,(ax,o,k) in enumerate(LABELS):
  for bx,p,h in LABELS[i+1:]:
   if ax is bx and o.get_window_extent(ren).overlaps(p.get_window_extent(ren)):overlap.append((k,h))
 assert not overlap,overlap
 for ext in ['pdf','svg','png']:fig.savefig(OUT/f'Figure8_Rso_Tamarix_Arabidopsis_20260910.{ext}',dpi=600)
 fig.savefig(OUT/'Figure8_preview.png',dpi=170);plt.close(fig)
 (W/'analysis/main_local_contexts.json').write_text(json.dumps(contexts,ensure_ascii=False,indent=2),encoding='utf-8')
 # Retain each Arabidopsis anchor neighbourhood, not only the chosen examples.
 with PdfPages(OUT/'Arabidopsis_all_26_anchor_contexts.pdf') as pdf:
  for offset in range(0,len(A['amp_pairs']),4):
   page=plt.figure(figsize=(8.27,11.69));page.text(.07,.976,'R. soongarica–A. thaliana: all candidate-anchor contexts',fontsize=12,fontweight='bold')
   page.text(.07,.952,'Independent local coordinate scales; colours follow the R. soongarica candidate family.',fontsize=8,color='#61717B')
   for j,(r,a) in enumerate(zip(A['amp_pairs'][offset:offset+4],A['all_pair_contexts'][offset:offset+4])):
    c={'member':r['rso_member'],'family':r['rso_family'],'tracks':a['tracks'],'pairs':a['pairs'],'focus':[{'gene1':r['rso_id'],'gene2':r['ath_id'],'family':r['rso_family']}]}
    ax=page.add_axes([.067,.719-j*.222,.89,.183]);local(ax,c,False)
    ax.text(.003,1.10,f"{offset+j+1:02d}  {r['rso_member']} — {r['ath_locus_tag']}   |   Block {r['block_id']}",fontsize=9,fontweight='bold')
   page.text(.07,.013,'Complete pair, scope and reference records are provided in Tables S55, S57–S59 and File S11.',fontsize=8,color='#61717B')
   pdf.savefig(page);plt.close(page)
 (OUT/'figure_QA.json').write_text(json.dumps({'matplotlib_version':matplotlib.__version__,'figure_inches':[7.5,10.1],'main_label_overlaps':overlap,'all_819_Arabidopsis_blocks_displayed':True,'main_local_members':['RsDEF6','RsSNA8','RsLTP13'],'main_local_pairs':sum(len(c['focus']) for c in contexts),'arabidopsis_all_contexts':len(A['amp_pairs']),'original_author_figure_unchanged':True},indent=2),encoding='utf-8')
 print('Figure 8 and 26-context atlas written.')
if __name__=='__main__':main()
