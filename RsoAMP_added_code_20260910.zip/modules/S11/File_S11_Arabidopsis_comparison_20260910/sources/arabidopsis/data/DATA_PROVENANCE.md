# 数据溯源记录 (Gate 0)

> 下载与核验日期：2026-07-02。所有数据均为公共数据。

## 1. 基因组组装 + 结构注释
- **物种**：*Reaumuria soongarica*（红砂，柽柳科 Tamaricaceae）
- **来源**：Figshare `10.6084/m9.figshare.25533064.v2`（随 Nature *Scientific Data* 11:812 (2024) 释出）
  - 论文：Chromosome-level genome assembly and annotation of xerophyte secretohalophyte *Reaumuria soongarica*. *Sci Data* 11, 812 (2024). https://doi.org/10.1038/s41597-024-03644-y (PMC11263558)
- **GenBank 组装号**：JBEBFM000000000
- **下载文件**：`Chromosome-level genome assembly and annotation of Reaumuria soongarica.rar`
  - MD5 = `4b9367aa70216a48839e38f0693f877e`（Figshare 官方 = 一致 ✓）
  - 解包内容：`hs.chrom.genome.final.fa`（基因组）、`hs.chrom.genome.gff`（注释）
- **蛋白 / CDS**：随附归档未提供 pep/cds，故由 `gffread` 从 genome.fa + genome.gff 提取（`protein.fa`, `cds.fa`；21,791 条；无内部终止子）。

### 组装统计核验（与已发表一致）
| 指标 | 已发表 | 本地核验 | 结论 |
|---|---|---|---|
| 组装大小 | 1.28 Gb | 1,281,161,807 bp | ✓ |
| Scaffold N50 | 116.15 Mb | 116,152,396 bp | ✓ |
| 染色体数 | 11 | Chr01–Chr11 (+ UnChr scaffolds) | ✓ |
| 基因数 | 21,791 | 21,791 (gene = mRNA) | ✓ |
| BUSCO | 97.5% | 未重跑（三项硬指标已互证） | — |

## 2. 盐胁迫 RNA-seq（Gate 0 可下载性核验通过）
- **来源**：NCBI SRA / ENA。测序平台 DNBSEQ-G50，双端。
- **实验设计**：3 处理 × 3 生物学重复（幼苗期）
  | 条件 | 样本 | Run |
  |---|---|---|
  | CK（对照） | CK-1/2/3 | SRR27540881 / SRR27540880 / SRR27540879 |
  | S200（200 mM NaCl） | S200-1/2/3 | SRR27540878 / SRR27540877 / SRR27540876 |
  | S400（400 mM NaCl） | S400-1/2/3 | SRR27540875 / SRR27540884 / SRR27540883 |
- 每 run ≈ 2.7×10⁷ read pairs，经 ENA `filereport` 逐一确认真实且可下载（read_count + fastq_bytes 非空）。
- **诚实约束**：本数据集为**盐胁迫剂量梯度**，无干旱、无病原挑战数据。表达分析仅框定盐胁迫剂量响应。

## 3. 参考与模型
- **Pfam HMM**（InterPro/EBI，`annotation=hmm`）：PF00304（Gamma-thionin/defensin）、PF00321（Thionin）、PF02704（GASA/Snakin）、PF00234（nsLTP/Tryp_alpha_amyl）、PF00187（Chitin_bind_1/Hevein）、PF03784（Cyclotide）
- **AMP 参考种子序列**（UniProt，按 Pfam 交叉引用）：*Arabidopsis thaliana* (3702) + *Medicago truncatula* (3880)；Defensin 63、Thionin 5、Snakin/GASA 60、nsLTP 116、Hevein 22。
- **InterProScan** 5.77-108.0（18 库：Pfam, SMART, CDD, PANTHER, SUPERFAMILY, Gene3D, ProSite…）

## 4. 新颖性预检（Gate 0 决定性步骤）
- 检索红砂已发表家族文献：仅存在**基因组文**与 **AP2/ERF 家族文**（后者即本项目盐胁迫 RNA-seq 来源），二者均出自内蒙古大学 Dang Z 组，完整引用如下：
  - 基因组：Song M, Gong W, Tian Y, Meng Y, Huo T, Liu Y, Zhang Y, Dang Z (2024). Chromosome-level genome assembly and annotation of xerophyte secretohalophyte *Reaumuria soongarica*. *Scientific Data* 11, 812. doi:10.1038/s41597-024-03644-y（勘误 doi:10.1038/s41597-024-03935-4）。
  - RNA-seq：Zhu M, Liu Y, Zhao H, Sun Z, Gong W, Dang Z (2025). Genome-wide Identification of the *AP2*/*ERF* Gene Family and Its Expression Patterns under Salt Stress in the Desert Plant *Reaumuria soongarica*. *Chinese Bulletin of Botany*（植物学报）. doi:10.11983/CBB25066. Reads: NCBI SRA SRR27540875–884。
- **未发现**任何红砂 AMP / defensin / nsLTP / snakin 家族全基因组鉴定文；基因组文补充材料仅做全局 Pfam 批注，未单独汇总 AMP 家族、无系统发育/表达分析。
- 结论：**描述性新颖性成立 → GO**。
