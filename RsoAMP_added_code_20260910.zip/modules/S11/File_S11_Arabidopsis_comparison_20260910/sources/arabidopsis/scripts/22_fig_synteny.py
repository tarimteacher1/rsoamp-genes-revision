#!/usr/bin/env python3
"""
F8 — 红砂 (Reaumuria soongarica) vs Arabidopsis thaliana 种间共线性图.
上排 Arabidopsis (at1-at5),下排红砂 (rs01-rs11).
灰色缎带 = 全部 819 个种间共线块(宏观共线背景);
彩色缎带 = 27 对 AMP 成员↔拟南芥同源基因的共线关系(按家族着色),红砂侧标出 AMP 位点.
数据: intermediate/synteny/{rso_ath.gff,rso_ath.collinearity} + tables/{T1,T11}.
输出: figures/F8_synteny.{svg,pdf,png}
"""
import os, re, csv, sys
sys.path.insert(0, os.path.dirname(__file__))
from plot_style import plt, savefig_three
import numpy as np
from matplotlib.path import Path
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SYN  = f"{ROOT}/intermediate/synteny"
FAI  = f"{ROOT}/data/genome.fa.fai"

# ---------- 1. gene -> (chrom, start, end) from combined MCScanX gff ----------
gene_pos = {}
for line in open(f"{SYN}/rso_ath.gff"):
    ch, gid, s, e = line.rstrip("\n").split("\t")[:4]
    gene_pos[gid] = (ch, int(s), int(e))

# ---------- 2. chromosome lengths ----------
ath_len = {}
for gid, (ch, s, e) in gene_pos.items():
    if ch.startswith("at"):
        ath_len[ch] = max(ath_len.get(ch, 0), e)
rso_len = {}
for line in open(FAI):
    name, length = line.split("\t")[:2]
    if re.fullmatch(r"Chr\d+", name):                 # Chr01..Chr11 -> rs01..rs11
        rso_len["rs" + name[3:]] = int(length)

ath_chroms = [f"at{i}" for i in range(1, 6)]
rso_chroms = [f"rs{i:02d}" for i in range(1, 12)]

# ---------- 3. parse inter-species collinear blocks -> spans on each side ----------
blocks = []          # (rso_chrom, rso_x0, rso_x1, ath_chrom, ath_x0, ath_x1)
cur = None
def flush(cur):
    if not cur or not cur["ath"] or not cur["rso"]:
        return
    a_ch = cur["ath_ch"]; r_ch = cur["rso_ch"]
    if a_ch not in ath_len or r_ch not in rso_len:
        return
    blocks.append((r_ch, min(cur["rso"]), max(cur["rso"]),
                   a_ch, min(cur["ath"]), max(cur["ath"])))
for line in open(f"{SYN}/rso_ath.collinearity"):
    if line.startswith("## Alignment"):
        flush(cur)
        m = re.search(r'(\S+)&(\S+)\s', line)
        a, b = m.group(1), m.group(2)
        ath_ch = a if a.startswith("at") else b
        rso_ch = b if a.startswith("at") else a
        cur = {"ath_ch": ath_ch, "rso_ch": rso_ch, "ath": [], "rso": []}
    elif line.startswith("#") or not line.strip():
        continue
    else:                                              #  "  0-  0:\tg1\tg2\te"
        parts = line.rstrip("\n").split("\t")
        if len(parts) < 3:
            continue
        for g in (parts[1], parts[2]):
            if g in gene_pos:
                ch, s, e = gene_pos[g]
                mid = (s + e) / 2
                if ch.startswith("at"): cur["ath"].append(mid)
                else:                   cur["rso"].append(mid)
flush(cur)

# ---------- 4. karyotype layout: each row normalised to [0, W] ----------
W, GAP = 100.0, 2.0
def layout(chroms, lengths):
    tot = sum(lengths[c] for c in chroms)
    usable = W - GAP * (len(chroms) - 1)
    x, off = {}, 0.0
    for c in chroms:
        w = usable * lengths[c] / tot
        x[c] = (off, off + w)                          # (x_start, x_end) for coord 0..len
        off += w + GAP
    return x
ath_x = layout(ath_chroms, ath_len)
rso_x = layout(rso_chroms, rso_len)
def xpos(row_x, lengths, ch, coord):
    x0, x1 = row_x[ch]
    return x0 + (x1 - x0) * coord / lengths[ch]

Y_ATH, Y_RSO, BAR = 6.0, 0.0, 0.55
top_of_rso, bot_of_ath = Y_RSO + BAR, Y_ATH

# ---------- 5. draw ----------
fig, ax = plt.subplots(figsize=(11, 4.6))

def ribbon(rx0, rx1, ax0, ax1, color, alpha, lw=0, z=1, ec="none"):
    """填充缎带: 红砂侧 [rx0,rx1] (下) 连到拟南芥侧 [ax0,ax1] (上)."""
    y0, y1 = top_of_rso, bot_of_ath
    ym = (y0 + y1) / 2
    verts = [(rx0, y0), (rx0, ym), (ax0, ym), (ax0, y1),          # left edge up
             (ax1, y1), (ax1, ym), (rx1, ym), (rx1, y0), (rx0, y0)]
    codes = [Path.MOVETO, Path.CURVE4, Path.CURVE4, Path.CURVE4,
             Path.LINETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.CLOSEPOLY]
    ax.add_patch(mpatches.PathPatch(Path(verts, codes), fc=color, ec=ec,
                                    lw=lw, alpha=alpha, zorder=z))

def link(rx, axx, color, lw, alpha, z):
    """单基因连线(AMP 位点)."""
    y0, y1 = top_of_rso, bot_of_ath
    ym = (y0 + y1) / 2
    verts = [(rx, y0), (rx, ym), (axx, ym), (axx, y1)]
    codes = [Path.MOVETO, Path.CURVE4, Path.CURVE4, Path.CURVE4]
    ax.add_patch(mpatches.PathPatch(Path(verts, codes), fc="none", ec=color,
                                    lw=lw, alpha=alpha, zorder=z))

# 5a. background ribbons — all 819 inter-species blocks
for r_ch, rs0, rs1, a_ch, as0, as1 in blocks:
    rx0 = xpos(rso_x, rso_len, r_ch, rs0); rx1 = xpos(rso_x, rso_len, r_ch, rs1)
    ax0 = xpos(ath_x, ath_len, a_ch, as0); ax1 = xpos(ath_x, ath_len, a_ch, as1)
    ribbon(rx0, rx1, ax0, ax1, color="#c9ccd1", alpha=0.28, z=1)

# 5b. AMP-anchored inter-species pairs (from T11 + coords from T1 / ath.gff)
FAM_COLOR = {"nsLTP": "#1f77b4", "Snakin_GASA": "#d62728", "Defensin": "#2ca02c"}
t1 = {}
with open(f"{ROOT}/tables/T1_AMP_members.csv") as fh:
    for row in csv.DictReader(fh):
        t1[row["member_id"]] = row
amp_loci = {}            # member -> (rso_ch, x)  for marker/label (dedup)
n_amp_links = 0
with open(f"{ROOT}/tables/T11_synteny.csv") as fh:
    for row in csv.DictReader(fh):
        if row["synteny_type"] != "inter_Athaliana":
            continue
        mem, fam, partner = row["member_id"], row["family"], row["partner"]
        if mem not in t1 or partner not in gene_pos:
            continue
        m = t1[mem]
        r_ch = "rs" + m["chrom"][3:]                    # Chr04 -> rs04
        if r_ch not in rso_len:
            continue
        r_mid = (int(m["start"]) + int(m["end"])) / 2
        a_ch, as_, ae = gene_pos[partner]
        rx  = xpos(rso_x, rso_len, r_ch, r_mid)
        axx = xpos(ath_x, ath_len, a_ch, (as_ + ae) / 2)
        col = FAM_COLOR.get(fam, "#7f7f7f")
        link(rx, axx, col, lw=1.1, alpha=0.85, z=4)
        amp_loci[mem] = (r_ch, rx, col)
        n_amp_links += 1

# 5c. chromosome bars
def draw_bars(row_x, chroms, y, labels):
    for c in chroms:
        x0, x1 = row_x[c]
        ax.add_patch(mpatches.FancyBboxPatch(
            (x0, y), x1 - x0, BAR, boxstyle="round,pad=0,rounding_size=0.12",
            fc="#4a4a4a", ec="none", zorder=6))
        ax.text((x0 + x1) / 2, y + BAR + 0.18 if labels == "top" else y - 0.22,
                c.upper(), ha="center",
                va="bottom" if labels == "top" else "top", fontsize=7.5)
draw_bars(ath_x, ath_chroms, Y_ATH, "top")
draw_bars(rso_x, rso_chroms, Y_RSO, "bottom")

# 5d. AMP locus markers + labels on red-sand bar (fan clustered labels horizontally)
loci = sorted(amp_loci.items(), key=lambda kv: kv[1][1])     # by true x
SPACING, LABEL_Y = 1.7, -1.25
clusters, cur_cl = [], []
for mem, v in loci:
    if cur_cl and v[1] - cur_cl[-1][1][1] > SPACING:
        clusters.append(cur_cl); cur_cl = []
    cur_cl.append((mem, v))
if cur_cl:
    clusters.append(cur_cl)
for cl in clusters:
    k = len(cl)
    mean_x = sum(v[1] for _, v in cl) / k
    for i, (mem, (r_ch, rx, col)) in enumerate(cl):
        lx = mean_x + (i - (k - 1) / 2) * SPACING           # fanned label x
        ax.plot([rx], [top_of_rso], marker="v", ms=4.5, color=col,
                mec="white", mew=0.4, zorder=7, clip_on=False)
        ax.annotate(mem, xy=(rx, top_of_rso), xytext=(lx, LABEL_Y),
                    ha="center", va="top", fontsize=4.8, color=col, rotation=90,
                    arrowprops=dict(arrowstyle="-", color=col, lw=0.3, alpha=0.55))

# 5e. genome labels + legend
ax.text(-3.5, Y_ATH + BAR / 2, "A. thaliana", ha="right", va="center",
        fontsize=9, style="italic", fontweight="bold")
ax.text(-3.5, Y_RSO + BAR / 2, "R. soongarica", ha="right", va="center",
        fontsize=9, style="italic", fontweight="bold")
handles = [mpatches.Patch(fc="#c9ccd1", ec="none",
                          label=f"All inter-species blocks (n={len(blocks)})")]
handles += [Line2D([0], [0], color=FAM_COLOR[f], lw=1.6,
                   label={"nsLTP": "nsLTP", "Snakin_GASA": "Snakin/GASA",
                          "Defensin": "Defensin"}[f])
            for f in ["nsLTP", "Snakin_GASA", "Defensin"]
            if any(v[2] == FAM_COLOR[f] for v in amp_loci.values())]
leg = ax.legend(handles=handles, loc="center", bbox_to_anchor=(0.5, 0.5),
                ncol=len(handles), frameon=True, fontsize=7.5,
                handlelength=1.6, columnspacing=1.4)
leg.get_frame().set_facecolor("white")
leg.get_frame().set_edgecolor("#cccccc")
leg.get_frame().set_alpha(0.9)
leg.get_frame().set_linewidth(0.5)

ax.set_xlim(-13, W + 1)
ax.set_ylim(-4.2, Y_ATH + BAR + 0.8)
ax.axis("off")
ax.set_title(f"Inter-species synteny: {n_amp_links} AMP-anchored syntenic pairs "
             f"(R. soongarica – A. thaliana)", fontsize=10, pad=6)

os.makedirs(f"{ROOT}/figures", exist_ok=True)
savefig_three(fig, f"{ROOT}/figures/F8_synteny")
print(f"F8_synteny written | background blocks={len(blocks)} | AMP inter-species links={n_amp_links} "
      f"| unique AMP loci={len(amp_loci)}")
