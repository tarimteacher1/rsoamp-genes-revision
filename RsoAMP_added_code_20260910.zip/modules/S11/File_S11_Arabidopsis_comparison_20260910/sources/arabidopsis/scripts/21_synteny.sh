#!/usr/bin/env bash
# Gate 2 extension — inter-species synteny (Reaumuria soongarica vs Arabidopsis thaliana)
# via MCScanX, + reuse intra-species rso.collinearity. Highlights AMP gene syntenic pairs.
set -uo pipefail
source "$(dirname "$0")/00_paths.sh"
SYN=$INTER/synteny; MC=$INTER/mcscanx; ATH=$DATA/ext/ath/ncbi_dataset/data/GCF_000001735.4
DIAMOND=$(command -v diamond || echo /home/USER/tools/miniconda3/envs/busco1/bin/diamond)
MCSCANX=$MCSCANX_BIN/MCScanX
mkdir -p $SYN; LOG=$SYN/run.log; : > $LOG
log(){ echo "[$(date '+%F %T')] $*" | tee -a $LOG; }

# ---- 1. Arabidopsis: longest-isoform protein per gene + MCScanX gff ----
log "prep Arabidopsis (longest isoform, chrom->at1..at5)"
python3 - "$ATH/genomic.gff" "$ATH/protein.faa" "$SYN" <<'PY'
import sys,re
gff,pep,out=sys.argv[1:4]
# NC_003070.9..NC_003076.8 -> Chr1..Chr5 ; skip organelles
chrmap={"NC_003070.9":"at1","NC_003071.7":"at2","NC_003074.8":"at3","NC_003075.7":"at4","NC_003076.8":"at5"}
mrna={}   # rna_id -> (chrom,start,end,gene)
prot={}   # rna_id -> protein_acc (from CDS)
for line in open(gff):
    if line.startswith("#"): continue
    c=line.rstrip("\n").split("\t")
    if len(c)<9: continue
    ch=chrmap.get(c[0])
    if not ch: continue
    attr=dict(kv.split("=",1) for kv in c[8].split(";") if "=" in kv)
    if c[2]=="mRNA":
        rid=attr.get("ID","")
        mrna[rid]=(ch,int(c[3]),int(c[4]),attr.get("Parent",""))
    elif c[2]=="CDS":
        par=attr.get("Parent","")
        if par and "protein_id" in attr and par not in prot:
            prot[par]=attr["protein_id"]
# longest mRNA per gene
best={}   # gene -> (len,rna,ch,s,e)
for rid,(ch,s,e,gene) in mrna.items():
    if rid not in prot: continue
    L=e-s
    if gene not in best or L>best[gene][0]:
        best[gene]=(L,rid,ch,s,e)
keep_prot={}   # protein_acc -> (ch,s,e)  (the ID used in gff/pep)
for gene,(L,rid,ch,s,e) in best.items():
    keep_prot[prot[rid]]=(ch,s,e)
with open(f"{out}/ath.gff","w") as fh:
    for pa,(ch,s,e) in sorted(keep_prot.items(),key=lambda x:(x[1][0],x[1][1])):
        fh.write(f"{ch}\t{pa}\t{s}\t{e}\n")
# extract those proteins
keep=set(keep_prot); wrote=0
with open(f"{out}/ath.pep","w") as fo:
    w=False
    for line in open(pep):
        if line.startswith(">"):
            acc=line[1:].split()[0]; w=acc in keep
            if w: wrote+=1
        if w: fo.write(line)
print(f"ath genes kept (longest isoform, chr1-5): {len(keep_prot)} | proteins written: {wrote}")
PY

# ---- 2. red-sand pep (reuse) : extract the pep matching rso.gff ids ----
log "prep red-sand pep (ids from rso.gff)"
cut -f2 $MC/rso.gff > $SYN/rso.ids
$SEQKIT_BIN/seqkit grep -f $SYN/rso.ids $DATA/protein.fa -o $SYN/rso.pep 2>>$LOG
log "rso pep: $(grep -c '>' $SYN/rso.pep) | ath pep: $(grep -c '>' $SYN/ath.pep)"

# ---- 3. combined gff + cross-species DIAMOND (rso vs ath both directions) ----
cat $MC/rso.gff $SYN/ath.gff > $SYN/rso_ath.gff
log "combined gff: $(wc -l <$SYN/rso_ath.gff) genes"
$DIAMOND makedb --in $SYN/ath.pep -d $SYN/ath --quiet 2>>$LOG
$DIAMOND makedb --in $SYN/rso.pep -d $SYN/rso --quiet 2>>$LOG
log "DIAMOND rso->ath + ath->rso (e<1e-5, top5)"
$DIAMOND blastp -q $SYN/rso.pep -d $SYN/ath -o $SYN/r2a.tsv -e 1e-5 -k 5 -p 16 --quiet 2>>$LOG
$DIAMOND blastp -q $SYN/ath.pep -d $SYN/rso -o $SYN/a2r.tsv -e 1e-5 -k 5 -p 16 --quiet 2>>$LOG
cat $SYN/r2a.tsv $SYN/a2r.tsv > $SYN/rso_ath.blast
log "cross blast rows: $(wc -l <$SYN/rso_ath.blast)"

# ---- 4. MCScanX (inter+intra) ----
log "MCScanX on rso_ath"
( cd $SYN && $MCSCANX rso_ath >>$LOG 2>&1 )
if [ -f $SYN/rso_ath.collinearity ]; then
  # Only cross-species (rso<->ath) BLAST was fed to MCScanX, so every block is inter-species
  # by construction. Classify from the block-header chrom pair ("atX&rsY"), NOT the gene-id
  # columns (those hold STRG.*/gmm*/NP_* ids, so grepping them for chrom prefixes miscounts).
  blocks=$(grep -c "## Alignment" $SYN/rso_ath.collinearity)
  same=$(grep "## Alignment" $SYN/rso_ath.collinearity | grep -cE '(at[0-9]+&at[0-9]+)|((rs|us)[0-9]+&(rs|us)[0-9]+)' || true)
  log "collinearity blocks: $blocks ; inter-species (rso-ath): $((blocks - same)) ; same-genome: $same"
else
  log "MCScanX produced no collinearity — check log"
fi

# ---- 5. extract AMP-anchored syntenic pairs -> T11 ----
#   inter_Athaliana : rso_ath.collinearity anchors where one gene is Arabidopsis (NP_/at*)
#                     and the other is an AMP member protein_id  -> (member, ath-partner, chrom-pair)
#   intra_segmental : rso.collinearity anchors where BOTH genes are AMP member protein_ids
log "extract AMP-anchored syntenic pairs -> T11_synteny.csv"
python3 - "$TAB/T1_AMP_members.csv" "$SYN/rso_ath.collinearity" "$MC/rso.collinearity" "$TAB/T11_synteny.csv" <<'PY'
import sys, csv, re
t1, inter_col, intra_col, out = sys.argv[1:5]
pid2mem, fam = {}, {}
for r in csv.DictReader(open(t1)):
    pid2mem[r["protein_id"]] = r["member_id"]; fam[r["member_id"]] = r["family"]
amp = set(pid2mem)
is_ath = lambda g: g.startswith("NP_") or g.startswith("at")
def natkey(m):                       # RsLTP5 before RsLTP10
    n = re.search(r'(\d+)$', m)
    return (re.sub(r'\d+$', '', m), int(n.group(1)) if n else 0)

inter = []
cur = None
for line in open(inter_col):
    if line.startswith("## Alignment"):
        a, b = re.search(r'(\S+)&(\S+)\s', line).groups()
        cur = (a, b) if a.startswith("at") else (b, a)      # (ath_chrom, rso_chrom)
    elif line.startswith("#") or not line.strip():
        continue
    else:
        p = line.rstrip("\n").split("\t")
        if len(p) < 3: continue
        g1, g2 = p[1].strip(), p[2].strip()
        rso_g = g2 if is_ath(g1) else (g1 if is_ath(g2) else None)
        ath_g = g1 if is_ath(g1) else (g2 if is_ath(g2) else None)
        if rso_g is None or ath_g is None: continue
        if rso_g in amp:
            m = pid2mem[rso_g]
            inter.append((m, fam[m], "inter_Athaliana", ath_g, f"{cur[0]}&{cur[1]}"))

intra = []
for line in open(intra_col):
    if line.startswith("#") or not line.strip(): continue
    p = line.rstrip("\n").split("\t")
    if len(p) < 3: continue
    g1, g2 = p[1].strip(), p[2].strip()
    if g1 in amp and g2 in amp:
        m1 = pid2mem[g1]
        intra.append((m1, fam[m1], "intra_segmental", pid2mem[g2], ""))

inter.sort(key=lambda r: (r[1], natkey(r[0]), r[4], r[3]))
intra.sort(key=lambda r: (r[1], natkey(r[0])))
with open(out, "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["member_id", "family", "synteny_type", "partner", "block"])
    w.writerows(inter + intra)
print(f"T11: inter_Athaliana={len(inter)} pairs "
      f"({len({r[0] for r in inter})} loci) ; intra_segmental={len(intra)} pairs")
PY
log "SYNTENY PIPE DONE"
