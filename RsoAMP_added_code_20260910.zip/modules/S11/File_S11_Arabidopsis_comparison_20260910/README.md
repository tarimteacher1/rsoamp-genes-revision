# File S11: Arabidopsis and intraspecific collinearity; revised Figure 8

This supplement restores the Arabidopsis comparison alongside the existing
Tamarix austromongolica comparison. The current R. soongarica primary catalogue
contains 73 members. Sixty-six reference-annotated members occur in the genomic
anchor references; seven reconstructed models were not assessed by these anchors.

## Contents and results

- `analysis/S57_Arabidopsis_anchors.tsv`: 26 primary-candidate anchor pairs, involving
  22 R. soongarica members (17 nsLTP and 5 Snakin/GASA) and 22 Arabidopsis loci.
  Pair counts are 20 nsLTP-associated and 6 Snakin/GASA-associated.
- `analysis/Intraspecies_archived_crosscheck.tsv`: seven previously reported intraspecific
  candidate pairs, all retained under the current catalogue.
- `analysis/S58_Arabidopsis_scope.tsv`: all 73 members, distinguishing absence from
  the anchor reference (NOT_ASSESSED) from no recovered anchor among eligible genes.
- `analysis/S59_Comparative_member_links.tsv`: member-level coverage in both
  comparisons; 13 R. soongarica members have candidate-associated links to both.
  Tamarix candidate-involving and direct catalogue-to-catalogue pair counts are
  recorded separately. Correspondence is not a one-to-one orthology claim.
- `analysis/Arabidopsis_extended_and_primary.tsv`: all 27 original candidate pairs,
  preserving RsLTP20 as EXTENDED_ONLY; this pair is excluded from the 26 primary pairs.
- `figures/`: revised Figure 8 in PDF, SVG and 600-dpi PNG, plus a seven-page atlas
  displaying all 26 primary Arabidopsis pair neighborhoods.
- `sources/arabidopsis/`: archived MCScanX blocks, DIAMOND hits, scripts, original
  execution log, original candidate table and original figures, retained as evidence.
  `REMOTE_SOURCE_MANIFEST.json` gives source paths and SHA-256 hashes.
- `sources/arabidopsis/ath_selected_annotation.json`: selected mRNA/gene/CDS metadata
  extracted from the original official GFF, including source GFF hash and coordinates.
  The whole official GFF and genome FASTA are not duplicated in this supplement.
- `sources/Tamarix_plot_data.json`: the existing curated Tamarix comparison used by
  Figure 8A and the upper half of Figure 8B. Its numerical results are unchanged.
- `sources/Supplementary_Tables.xlsx`: the pre-addition S1–S50/historical workbook,
  used here only to read the current primary and extended catalogues. The submission
  workbook supplied separately contains S1–S59: S51–S56 are in File S10, and S57–S59 are in this File S11.

## Reference and method

Arabidopsis: NCBI RefSeq GCF_000001735.4, TAIR10.1, TAIR/Araport annotation.
The original comparison used 27,444 representatives from five nuclear chromosomes;
one mRNA was selected per annotated locus by its greatest genomic span (not longest
protein length). The red-sand reference contained 21,791 proteins. The original
DIAMOND 2.1.18 searches were bidirectional, E <= 1e-5, maximum 5 hits per query,
16 threads; MCScanX then used default parameters. The recorded result contains
819 interspecies blocks and 10,098 genome-wide anchor rows.

For this update the archived genome-wide blocks were parsed and joined to the
current candidate catalogue. DIAMOND and MCScanX were NOT rerun. Original 27
Arabidopsis pairs and seven intraspecific pairs were reproduced against the archived
candidate table before the current-catalogue filter was applied. Coordinates were
checked against the reference GFF and the existing red-sand/Tamarix plot data.

This is a genomic-position comparison. Arabidopsis partners have not undergone a
matched complete family inventory. Figure 8A therefore shows only the independently
curated red-sand and Tamarix inventories. The Arabidopsis colors in Figure 8B/C
follow red-sand family assignments. No Arabidopsis expression analysis is included.

## Reproduce the current tables and figures (no network required after dependencies)

Python 3.9 or newer. Tested using Python 3.13, matplotlib 3.10.8, numpy and openpyxl.
The plotting script uses Arial when available; matplotlib uses a fallback font if
Arial is absent, so typography can differ across computers.

```sh
python -m pip install -r requirements.txt
python reproduce.py
```

`reproduce.py` first runs `recover_analysis.py`, then `draw_figure8.py`. This
reproduces the catalogue-filtered records and plotting from the archived inputs.
It does not claim to rerun the original genome-wide inference from raw genomes.
PDF metadata and font availability may change output file hashes across runs.
Use the TSV values and `analysis/summary.json` for numerical comparison.

The complete local-neighborhood atlas uses up to four neighboring anchors on each
side of the focal pair within the same block. Chromosome lengths are proportional
within each genome, with each genome independently normalized in the overview.
Local windows also have independent scales; reversed coordinates are labeled.

SHA256SUMS.txt covers the supplied files before any reproduction run.


## Consolidated manuscript numbering
The independent characterization/duplication supplement retains File S10 and Tables S51–S56. This Arabidopsis add-on is File S11: current Arabidopsis anchors are Table S57, reference coverage S58, and comparator links S59. The seven intraspecific pairs are represented once in formal Table S55 from File S10; this archive retains an independent cross-check under Intraspecies_archived_crosscheck.tsv. The source workbook in this archive is historical and is used only for catalogue inputs. The current formal workbook is S1–S59. Figure8_current_author.pdf preserves the latest author-edited figure; the plotting scripts reproduce the preceding computational layout, with unchanged scientific data.


Publication note (2026-09-10): the workbook under sources/ is a retained analysis input. The authoritative current workbook is tables/Supplementary_Tables_S1-S59.xlsx in the parent update bundle. Original source manifests describe the pre-publication bytes; use the update bundle MANIFEST_SHA256.tsv for distributed-byte verification.
