from pathlib import Path
from collections import Counter,defaultdict
import csv,json,re,hashlib,shutil
import openpyxl

W=Path(__file__).resolve().parent
S=W/'sources/arabidopsis'; OUT=W/'analysis';OUT.mkdir(exist_ok=True)
TAU_SOURCE=W/'sources/Tamarix_plot_data.json'
tau=json.loads(TAU_SOURCE.read_text(encoding='utf-8'))
wb=openpyxl.load_workbook(W/'sources/Supplementary_Tables.xlsx',read_only=True,data_only=True)
def records(sheet):
 a=list(wb[sheet].values);return [dict(zip(a[0],v)) for v in a[1:]]
primary={r['protein_id']:r for r in records('S1_Catalogue')}
extended={r['protein_id']:r for r in records('S31_ExtendedCatalogue') if r.get('species')=='rso'}
old={r['protein_id']:r for r in csv.DictReader((S/'tables/T1_AMP_members.csv').open())}
ath=json.loads((S/'ath_selected_annotation.json').read_text())
seqchr={'NC_003070.9':'Chr01','NC_003071.7':'Chr02','NC_003074.8':'Chr03','NC_003075.7':'Chr04','NC_003076.8':'Chr05'}
G={};raw_to_id={};chromosomes={'RSO':tau['chromosomes']['RSO'],'ATH':[]}
for seq,ch in seqchr.items():chromosomes['ATH'].append({'chrom':ch,'length':ath['regions'][seq]['end']})
for l in (S/'intermediate/synteny/rso_ath.gff').read_text().splitlines():
 c,pid,start,end=l.split();sp='ATH' if c.startswith('at') else 'RSO';gid=sp+'__'+pid
 raw_to_id[pid]=gid
 ch='Chr'+c[2:].zfill(2) if c.startswith(('at','rs')) else 'UnChr'+c[2:]
 g={'combined_id':gid,'source_id':pid,'species':sp,'chrom':ch,'start':int(start),'end':int(end),'model_source':'reference_annotation'}
 if sp=='ATH':
  a=ath['proteins'][pid];ga=a['gene']['attrs'];ra=a['mrna']['attrs'];ca=a['cds']['attrs']
  g.update({'strand':a['mrna']['strand'],'locus_tag':ga.get('locus_tag',ga.get('Name','')),'gene_symbol':ga.get('gene',''),'annotation_product':ca.get('product',''),'gene_feature_id':ga.get('ID',''),'rna_feature_id':ra.get('ID','')})
  assert (int(start),int(end))==(a['mrna']['start'],a['mrna']['end'])
 else:
  g['strand']=tau['genes'][gid]['strand']
  tg=tau['genes'][gid]
  assert (g['chrom'],g['start'],g['end'])==(tg['chrom'],tg['start'],tg['end']),(gid,g,tg)
  if pid in primary:g['amp']={'display_id':primary[pid]['member_id'],'family':primary[pid]['family'],'source_tier':'annotated_catalogue'}
 G[gid]=g

def parse(p):
 blocks=[]
 for line in p.read_text().splitlines():
  if line.startswith('## Alignment'):
   m=re.match(r'## Alignment (\d+): score=([\d.]+) e_value=(\S+) N=(\d+) (\S+)&(\S+) (plus|minus)',line)
   assert m,line
   i,score,ev,n,c1,c2,ori=m.groups();blocks.append({'id':int(i),'score':float(score),'evalue':ev,'N':int(n),'chrom1_raw':c1,'chrom2_raw':c2,'orientation':ori,'pairs':[]})
  elif line.strip() and not line.startswith('#'):
   # Strip the index field before parsing identifiers, including padded MCScanX rows.
   fields=line.split('\t');assert len(fields)==4,(p,line)
   a,b,ev=[f.strip() for f in fields[1:]]
   # An independent whitespace parse must yield the same three scientific fields.
   assert [a,b,ev]==line.split()[-3:]
   blocks[-1]['pairs'].append({'gene1_raw':a,'gene2_raw':b,'evalue':ev})
 assert all(len(b['pairs'])==b['N'] for b in blocks)
 return blocks
rawblocks=parse(S/'intermediate/synteny/rso_ath.collinearity')
blocks=[];links=[];old_links=[];extended_links=[]
poskeys={(sp,c['chrom']) for sp,cc in chromosomes.items() for c in cc}
for b in rawblocks:
 z={k:v for k,v in b.items() if k!='pairs'};z['pairs']=[]
 for p in b['pairs']:
  a,h=(raw_to_id[p[x]] for x in ['gene1_raw','gene2_raw'])
  if G[a]['species']=='ATH':a,h=h,a
  assert G[a]['species']=='RSO' and G[h]['species']=='ATH'
  z['pairs'].append({'gene1':a,'gene2':h,'evalue':p['evalue']})
  pid=G[a]['source_id'];pa=G[h]
  if pid in old:old_links.append((old[pid]['member_id'],pa['source_id']))
  if pid in primary or pid in extended:
   r=primary.get(pid,extended.get(pid));mem=r['member_id'];fam=r['family']
   row={'block_id':b['id'],'rso_member':mem,'rso_family':fam,'rso_protein':pid,'rso_chrom':G[a]['chrom'],'rso_start':G[a]['start'],'rso_end':G[a]['end'],'ath_protein':pa['source_id'],'ath_locus_tag':pa['locus_tag'],'ath_gene_symbol':pa['gene_symbol'],'ath_annotation_product':pa['annotation_product'],'ath_chrom':pa['chrom'],'ath_start':pa['start'],'ath_end':pa['end'],'evalue':p['evalue'],'block_orientation':b['orientation'],'rso_catalogue_status':'PRIMARY' if pid in primary else 'EXTENDED_ONLY','ath_family_status':'reference_annotation; not assessed by the shared family-catalogue rules','rso_id':a,'ath_id':h}
   extended_links.append(row)
   if pid in primary:links.append(row)
 blocks.append(z)

oldtable=list(csv.DictReader((S/'tables/T11_synteny.csv').open()))
assert Counter(old_links)==Counter((r['member_id'],r['partner']) for r in oldtable if r['synteny_type']=='inter_Athaliana')
intraraw=parse(S/'intermediate/mcscanx/rso.collinearity');intralinks=[]
for b in intraraw:
 for p in b['pairs']:
  a,h=p['gene1_raw'],p['gene2_raw']
  if a in primary and h in primary:
   x,y=primary[a],primary[h]
   intralinks.append({'block_id':b['id'],'member_a':x['member_id'],'member_b':y['member_id'],'family_a':x['family'],'family_b':y['family'],'protein_a':a,'protein_b':h,'evalue':p['evalue'],'chrom_a':x['chrom'],'chrom_b':y['chrom'],'scope':'reference-annotated primary candidates'})
assert Counter(tuple(sorted((r['member_a'],r['member_b']))) for r in intralinks)==Counter(tuple(sorted((r['member_id'],r['partner']))) for r in oldtable if r['synteny_type']=='intra_segmental')

def context(link,flank=4):
 b=blocks[link['block_id']];assert b['id']==link['block_id']
 pairs=b['pairs'];ix=next(i for i,p in enumerate(pairs) if (p['gene1'],p['gene2'])==(link['rso_id'],link['ath_id']))
 pp=pairs[max(0,ix-flank):ix+flank+1];tracks=[]
 for sp,key in [('RSO','gene1'),('ATH','gene2')]:
  kk=[p[key] for p in pp];ch=G[kk[0]]['chrom'];assert all(G[k]['chrom']==ch for k in kk)
  lo=min(G[k]['start'] for k in kk);hi=max(G[k]['end'] for k in kk);pad=max(500,int((hi-lo)*.04));lo=max(1,lo-pad);hi+=pad
  genes=sorted([k for k,g in G.items() if g['species']==sp and g['chrom']==ch and g['start']>=lo and g['end']<=hi],key=lambda k:G[k]['start'])
  assert set(kk)<=set(genes)
  tracks.append({'species':sp,'chrom':ch,'start':lo,'end':hi,'reverse':sp=='ATH' and b['orientation']=='minus','genes':genes})
 focal=[r for r in links if r['block_id']==b['id'] and any((p['gene1'],p['gene2'])==(r['rso_id'],r['ath_id']) for p in pp)]
 return {'block':b['id'],'tracks':tracks,'pairs':pp,'focus_pairs':focal,'family':link['rso_family'],'selection':'focal anchor plus up to four adjacent anchors on each side, within the same block'}

allctx=[context(r) for r in links]
eligible=Counter(r['family'] for p,r in primary.items() if p in raw_to_id)
plotted=[b for b in blocks if all((G[p[k]]['species'],G[p[k]]['chrom']) in poskeys for p in b['pairs'] for k in ['gene1','gene2'])]
summary={'total_inter_species_blocks':len(blocks),'plotted_chromosome_blocks':len(plotted),'unplaced_rso_blocks':len(blocks)-len(plotted),'total_anchor_rows':sum(len(b['pairs']) for b in blocks),'primary_anchor_pairs':len(links),'unique_primary_rso_members':len({r['rso_member'] for r in links}),'unique_ath_loci':len({r['ath_locus_tag'] for r in links}),'unique_ath_proteins':len({r['ath_protein'] for r in links}),'pairs_by_rso_family':dict(Counter(r['rso_family'] for r in links)),'members_by_rso_family':dict(Counter({r['rso_member']:r['rso_family'] for r in links}.values())),'eligible_reference_members_by_family':dict(eligible),'not_in_reference':sorted(r['member_id'] for p,r in primary.items() if p not in raw_to_id),'historical_pairs':len(old_links),'extended_pairs':len(extended_links),'intra_primary_pairs':len(intralinks),'intra_pair_families':dict(Counter(r['family_a'] for r in intralinks)),'original_inference_rerun':False,'method':'Reparse and filter archived genome-wide MCScanX anchors using the current catalogue; no new homolog discovery or family-wide Arabidopsis curation.'}
tau_rso={r['rso_amp_id'] for r in tau['amp_pairs'] if r['rso_amp_id']};common=sorted(tau_rso&{r['rso_member'] for r in links})
summary['rso_members_anchored_to_both_comparators']=common
summary['rso_members_anchored_to_both_count']=len(common)

def tsv(name,rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');writer.writeheader();writer.writerows(rows)
tsv('S57_Arabidopsis_anchors.tsv',links)
tsv('Intraspecies_archived_crosscheck.tsv',intralinks)
tsv('S58_Arabidopsis_scope.tsv',[{'member_id':r['member_id'],'family':r['family'],'protein_id':p,'anchor_reference':'PRESENT' if p in raw_to_id else 'ABSENT','anchor_pairs':sum(z['rso_protein']==p for z in links) if p in raw_to_id else 'NOT_ASSESSED','interpretation':'No recovered anchor is not evidence of gene absence or loss.'} for p,r in primary.items()])
tsv('S59_Comparative_member_links.tsv',[{'member_id':r['member_id'],'family':r['family'],'protein_id':p,'anchor_reference':'PRESENT' if p in raw_to_id else 'ABSENT','Tamarix_candidate_involving_pairs':sum(z['rso_amp_id']==r['member_id'] for z in tau['amp_pairs']) if p in raw_to_id else 'NOT_ASSESSED','Tamarix_direct_catalogue_pairs':sum(z['rso_amp_id']==r['member_id'] and z['direct_amp_to_amp_anchor']=='YES' for z in tau['amp_pairs']) if p in raw_to_id else 'NOT_ASSESSED','Arabidopsis_anchor_pairs':sum(z['rso_protein']==p for z in links) if p in raw_to_id else 'NOT_ASSESSED','links_to_both_comparators':'YES' if r['member_id'] in common else 'NO' if p in raw_to_id else 'NOT_ASSESSED','scope':'Pairwise genomic correspondence; not a three-species orthology or family-conservation test.'} for p,r in primary.items()])
tsv('Arabidopsis_extended_and_primary.tsv',extended_links)
tsv('Arabidopsis_blocks.tsv',[{k:v for k,v in b.items() if k!='pairs'}|{'plotted':b in plotted} for b in blocks])
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'Arabidopsis_plot_data.json').write_text(json.dumps({'summary':summary,'genes':G,'chromosomes':chromosomes,'blocks':blocks,'amp_pairs':links,'all_pair_contexts':allctx},ensure_ascii=False),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
print('TARGET_GENE_LABELS',[(r['rso_member'],r['ath_locus_tag'],r['ath_gene_symbol'],r['ath_annotation_product']) for r in links])
