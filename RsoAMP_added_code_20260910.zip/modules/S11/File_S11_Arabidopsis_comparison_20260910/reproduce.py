from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for script in ['recover_analysis.py','draw_figure8.py']:
    subprocess.run([sys.executable,'-X','utf8',str(root/script)],cwd=root,check=True)
print('Finished. Tables: analysis/; figures: figures/.')
