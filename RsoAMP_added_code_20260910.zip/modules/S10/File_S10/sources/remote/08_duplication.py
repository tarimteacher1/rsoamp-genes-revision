#!/usr/bin/env python3
"""Gate 2 — duplication analysis from MCScanX.
Outputs T3_duplication.csv (per-member dup type) and pairs for Ka/Ks."""
import csv
from collections import defaultdict
PROJ="/path/to/rsoamp_original"; INTER=f"{PROJ}/intermediate"; TAB=f"{PROJ}/tables"
MC=f"{INTER}/mcscanx"

members={r["protein_id"]:r for r in csv.DictReader(open(f"{TAB}/T1_AMP_members.csv")) if r["source"]!="tblastn_backfill"}
pid2mid={p:members[p]["member_id"] for p in members}

# gene_type: gene\tcode  (0 singleton,1 dispersed,2 proximal,3 tandem,4 WGD/segmental)
TYPE={"0":"singleton","1":"dispersed","2":"proximal","3":"tandem","4":"WGD_segmental"}
gtype={}
for line in open(f"{MC}/rso.gene_type"):
    c=line.rstrip("\n").split("\t")
    if len(c)>=2: gtype[c[0]]=TYPE.get(c[1],c[1])

# tandem pairs (both members)
tandem_pairs=[]
for line in open(f"{MC}/rso.tandem"):
    a,b=line.strip().split(",")
    if a in members and b in members: tandem_pairs.append((a,b))

# segmental (collinearity) pairs among members
seg_pairs=[]
for line in open(f"{MC}/rso.collinearity"):
    if line.startswith("#") or "\t" not in line: continue
    parts=line.split("\t")
    if len(parts)>=3:
        a=parts[1].strip(); b=parts[2].strip()
        if a in members and b in members: seg_pairs.append((a,b))

# write per-member table
rows=[]
for p,m in members.items():
    rows.append({"member_id":m["member_id"],"family":m["family"],"protein_id":p,
                 "chrom":m["chrom"],"start":m["start"],
                 "duplication_type":gtype.get(p,"NA")})
def k(r):
    order=["Defensin","Snakin_GASA","nsLTP"]; import re
    return (order.index(r["family"]) if r["family"] in order else 9, int(re.sub(r"\D","",r["member_id"]) or 0))
rows.sort(key=k)
with open(f"{TAB}/T3_duplication.csv","w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=["member_id","family","protein_id","chrom","start","duplication_type"]);w.writeheader();w.writerows(rows)

# write pairs (member_id) for Ka/Ks
allpairs=[("tandem",a,b) for a,b in tandem_pairs]+[("segmental",a,b) for a,b in set(map(tuple,map(sorted,seg_pairs)))]
with open(f"{INTER}/dup_pairs.tsv","w") as f:
    f.write("mode\tmember_a\tmember_b\tpid_a\tpid_b\n")
    for mode,a,b in allpairs:
        f.write(f"{mode}\t{pid2mid[a]}\t{pid2mid[b]}\t{a}\t{b}\n")

from collections import Counter
print("=== per-member duplication type ===")
print(dict(Counter(r["duplication_type"] for r in rows)))
print("by family x type:")
ft=Counter((r["family"],r["duplication_type"]) for r in rows)
for (f_,t),n in sorted(ft.items()): print(f"   {f_:12} {t:14} {n}")
print(f"\ntandem member-pairs: {len(tandem_pairs)}")
print(f"segmental member-pairs: {len(set(map(tuple,map(sorted,seg_pairs))))}")
print(f"wrote {TAB}/T3_duplication.csv, {INTER}/dup_pairs.tsv ({len(allpairs)} pairs)")
