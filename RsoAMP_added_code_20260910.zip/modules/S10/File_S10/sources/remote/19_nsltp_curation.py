#!/usr/bin/env python3
"""nsLTP boundary check (task B): classify the 40 nsLTP-family members as
canonical nsLTP vs non-canonical 'nsLTP-like' (8CM/HyPRP-grade), using orthogonal
evidence already produced (InterProScan, BLAST-vs-seeds, phylogeny, Cys/length).
Writes audit table T10 and stamps a `subclass` column into T1/T7/T8; recomputes T9.
NOTE: `family` is left = 'nsLTP' for all 40 (all are LTP-fold, kept together for
structural/phylo analyses); the canonical/nsLTP-like split lives in `subclass`.
"""
import csv, os, re
from collections import defaultdict
PROJ = os.environ.get("PROJ_ROOT") or os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TAB = f"{PROJ}/tables"; INT = f"{PROJ}/intermediate"

NSLTP_SPEC_IPR = {"IPR000528": "Plant nsLTP/Par allergen",
                  "IPR033872": "nsLTP type 2",
                  "IPR044741": "nsLTP-like",
                  "IPR039265": "DIR1-like nsLTP"}

t1 = list(csv.DictReader(open(f"{TAB}/T1_AMP_members.csv")))
nsltp = {r["protein_id"]: r["member_id"] for r in t1 if r["family"] == "nsLTP"}

# --- InterProScan evidence ---
ips_ipr = defaultdict(set)
for line in open(f"{INT}/ips/candidates_ips.tsv"):
    c = line.rstrip("\n").split("\t")
    if len(c) < 13 or c[0] not in nsltp:
        continue
    if c[11] and c[11] != "-":
        ips_ipr[c[0]].add(c[11])

# --- BLAST-vs-seed evidence ---
blast = {}
for r in csv.DictReader(open(f"{INT}/candidates_union.tsv"), delimiter="\t"):
    if r["protein_id"] in nsltp:
        blast[r["protein_id"]] = (r["blast_fam"], r["blast_seed"], r["blast_pident"])

# --- length / Cys ---
phys = {r["member_id"]: r for r in csv.DictReader(open(f"{TAB}/T2_physicochemical.csv"))}

# --- phylogeny: nearest reference-nsLTP patristic distance ---
from Bio import Phylo
tr = Phylo.read(f"{INT}/phylo/nsLTP_tree.treefile", "newick")
tr.root_at_midpoint()
tips = {l.name: l for l in tr.get_terminals()}
refs = [n for n in tips if n and n.startswith("REF_")]
def nearest_ref(mid):
    if mid not in tips:
        return ("", None)
    best, bd = "", 1e9
    for o in refs:
        d = tr.distance(tips[mid], tips[o])
        if d < bd:
            bd, best = d, o
    return (best, round(bd, 3))

# --- classify ---
audit = []
subclass = {}   # member_id -> canonical / nsLTP-like
for pid, mid in sorted(nsltp.items(), key=lambda x: int(re.sub(r"\D", "", x[1]) or 0)):
    spec = ips_ipr[pid] & set(NSLTP_SPEC_IPR)
    bfam, bseed, bpid = blast.get(pid, ("", "", ""))
    blast_ns = (bfam == "nsLTP")
    nr, nrd = nearest_ref(mid)
    canonical = bool(spec) or blast_ns          # nsLTP-specific IPR OR nsLTP-seed BLAST
    subclass[mid] = "canonical" if canonical else "nsLTP-like"
    reasons = []
    if spec: reasons.append("nsLTP-specific IPR:" + "+".join(sorted(spec)))
    if blast_ns: reasons.append(f"BLAST nsLTP seed {bseed} {bpid}%")
    if not canonical:
        reasons.append("broad PF00234/AAI-2S umbrella only; no nsLTP-seed BLAST; "
                       f"far from ref (d={nrd})")
    audit.append({
        "member_id": mid, "protein_id": pid, "subclass": subclass[mid],
        "length_aa": phys[mid]["length_aa"], "cysteine_count": phys[mid]["cysteine_count"],
        "nsLTP_specific_IPR": "+".join(sorted(spec)) if spec else "",
        "blast_family": bfam, "blast_pident": bpid,
        "nearest_ref": nr, "nearest_ref_dist": nrd,
        "evidence": "; ".join(reasons)})

with open(f"{TAB}/T10_nsLTP_curation.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(audit[0].keys())); w.writeheader()
    w.writerows(audit)

canon = [a["member_id"] for a in audit if a["subclass"] == "canonical"]
like = [a["member_id"] for a in audit if a["subclass"] == "nsLTP-like"]
print(f"wrote T10_nsLTP_curation.csv | canonical nsLTP: {len(canon)} | nsLTP-like: {len(like)}")
print("nsLTP-like (downgraded):", like)

# --- stamp subclass into T1 (all rows; non-nsLTP -> '') ---
def add_subclass(path, key="member_id"):
    rows = list(csv.DictReader(open(path)))
    fn = list(rows[0].keys())
    if "subclass" not in fn:
        fn = fn[:fn.index("family") + 1] + ["subclass"] + fn[fn.index("family") + 1:]
    for r in rows:
        r["subclass"] = subclass.get(r[key], "") if r.get("family", "").startswith("nsLTP") else ""
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fn); w.writeheader(); w.writerows(rows)
    return len(rows)

for p in ("T1_AMP_members.csv", "T7_expression_TPM.csv", "T8_DE_results.csv"):
    n = add_subclass(f"{TAB}/{p}")
    print(f"stamped subclass -> {p} ({n} rows)")
