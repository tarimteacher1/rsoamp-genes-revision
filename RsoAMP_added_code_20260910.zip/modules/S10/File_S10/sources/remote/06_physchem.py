#!/usr/bin/env python3
"""Gate 1 — physicochemical property table (AMP-tailored). tables/T2_physicochemical.csv
Columns emphasise AMP-relevant features: net charge (cationicity), cysteine count
(disulfide scaffold), signal peptide (secretion), plus standard ProtParam metrics."""
import csv
from Bio import SeqIO
from Bio.SeqUtils.ProtParam import ProteinAnalysis
PROJ="/path/to/rsoamp_original"; INTER=f"{PROJ}/intermediate"; TAB=f"{PROJ}/tables"

# signal peptides from deepsig
sp={}
for line in open(f"{INTER}/members_deepsig.tsv"):
    c=line.rstrip("\n").split("\t")
    if len(c)>4 and c[2]=="Signal peptide":
        sp[c[0]]=(int(c[3]),int(c[4]))   # start,end (cleavage)

meta={r["member_id"]:r for r in csv.DictReader(open(f"{TAB}/T1_AMP_members.csv"))}

rows=[]
for rec in SeqIO.parse(f"{INTER}/members_final.faa","fasta"):
    mid=rec.id; seq=str(rec.seq).replace("*","").replace("X","")
    if not seq: continue
    pa=ProteinAnalysis(seq)
    aa=pa.amino_acids_percent
    ali=(aa.get('A',0)*100 + 2.9*aa.get('V',0)*100 + 3.9*(aa.get('I',0)+aa.get('L',0))*100)
    m=meta.get(mid,{})
    has_sp=mid in sp
    rows.append({
        "member_id":mid,"family":m.get("family",""),"subtype":m.get("subtype",""),
        "source":m.get("source",""),"chrom":m.get("chrom",""),
        "length_aa":len(seq),
        "MW_Da":f"{pa.molecular_weight():.1f}",
        "pI":f"{pa.isoelectric_point():.2f}",
        "net_charge_pH7":f"{pa.charge_at_pH(7.0):.2f}",
        "cysteine_count":seq.count("C"),
        "gravy":f"{pa.gravy():.3f}",
        "instability_index":f"{pa.instability_index():.2f}",
        "aliphatic_index":f"{ali:.1f}",
        "signal_peptide":"Y" if has_sp else "N",
        "sp_cleavage_pos":sp[mid][1] if has_sp else "",
    })
# order by member_id family index
def k(r):
    fam=r["family"]; import re
    n=int(re.sub(r"\D","",r["member_id"]) or 0); order=["Defensin","Snakin_GASA","nsLTP","Thionin"]
    return (order.index(fam) if fam in order else 9, n)
rows.sort(key=k)
cols=["member_id","family","subtype","source","chrom","length_aa","MW_Da","pI","net_charge_pH7",
      "cysteine_count","gravy","instability_index","aliphatic_index","signal_peptide","sp_cleavage_pos"]
with open(f"{TAB}/T2_physicochemical.csv","w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)

# summary stats per family
from statistics import mean
print(f"wrote {TAB}/T2_physicochemical.csv ({len(rows)} rows)")
print(f"\n{'family':12} {'n':>3} {'SP+':>4} {'meanLen':>8} {'meanpI':>7} {'mean_charge':>11} {'meanCys':>8}")
for fam in ["Defensin","Snakin_GASA","nsLTP"]:
    fr=[r for r in rows if r["family"]==fam]
    if not fr: continue
    print(f"{fam:12} {len(fr):>3} {sum(r['signal_peptide']=='Y' for r in fr):>4} "
          f"{mean(r['length_aa'] for r in fr):>8.1f} {mean(float(r['pI']) for r in fr):>7.2f} "
          f"{mean(float(r['net_charge_pH7']) for r in fr):>11.2f} {mean(r['cysteine_count'] for r in fr):>8.1f}")
