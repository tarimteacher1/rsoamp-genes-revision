#!/usr/bin/env python3
"""
Gate 1 final member table builder.
- Annotated members: validated by InterProScan domain evidence (see 04_finalize_members.py rules),
  with corrected nsLTP definition (type1 PF00234/IPR000528 + type2 PF14368).
- Backfilled members: 6 gene-model-unannotated loci recovered by tblastn + confirmed as intact
  Cys-rich ORFs (5 defensins tandem on Chr04, 1 snakin on Chr09).
- Assigns publication IDs (RsDEF/RsSNA/RsLTP) ordered by chromosome then position.
Outputs tables/T1_AMP_members.csv and intermediate/members_final.faa
"""
import csv, subprocess
from collections import defaultdict
PROJ="/path/to/rsoamp_original"; INTER=f"{PROJ}/intermediate"; TAB=f"{PROJ}/tables"
SAM="/path/to/user-home/tools/miniconda3/envs/as_splice/bin/samtools"

# ---- parse IPS domain evidence ----
pf=defaultdict(set); ipr=defaultdict(set); plen={}
for line in open(f"{INTER}/ips/candidates_ips.tsv"):
    c=line.rstrip("\n").split("\t")
    plen[c[0]]=int(c[2])
    if c[3]=="Pfam": pf[c[0]].add(c[4])
    if c[11] and c[11]!="-": ipr[c[0]].add(c[11])

prior={r["protein_id"]:r["family"] for r in csv.DictReader(open(f"{INTER}/candidates_union.tsv"),delimiter="\t")}

def classify(p):
    P,I=pf.get(p,set()),ipr.get(p,set())
    if "IPR008176" in I or "PF00304" in P:
        return "Defensin","CSab_knottin" if (I&{"IPR003614","IPR036574"}) else "plant_defensin"
    if "PF00321" in P: return "Thionin","thionin"
    if "IPR003854" in I or "PF02704" in P: return "Snakin_GASA","GASA"
    if "IPR000528" in I or "PF00234" in P: return "nsLTP","type1"
    if "PF14368" in P or "IPR033872" in I: return "nsLTP","type2"
    if "IPR044741" in I or "IPR039265" in I: return "nsLTP","nsLTP_like"
    return None,None

members=[]
for p in prior:
    fam,sub=classify(p)
    if fam:
        members.append({"protein_id":p,"family":fam,"subtype":sub,"length_aa":plen.get(p,""),
                        "source":"annotated","peptide":None})

# ---- coordinates from GFF (mRNA line, ID=protein_id) ----
coord={}
for line in open(f"{PROJ}/data/genome.gff"):
    if line.startswith("#"): continue
    c=line.rstrip("\n").split("\t")
    if len(c)<9 or c[2]!="mRNA": continue
    mid=None
    for kv in c[8].split(";"):
        if kv.startswith("ID="): mid=kv[3:]
    if mid: coord[mid]=(c[0],int(c[3]),int(c[4]),c[6])
for m in members:
    ch,s,e,st=coord.get(m["protein_id"],("NA",0,0,"."))
    m.update(chrom=ch,start=s,end=e,strand=st)

# ---- backfilled members (confirmed intact Cys-rich ORFs) ----
backfill=[
 ("Chr04",5686329,5686577,"-","Defensin","WEDPVLSNGEGGPSGQSEPGGAPTCHAESKLYRGLCWGKTNCATICVVEGYKDGYCSTFIRRCMCDKNCMTG"),
 ("Chr04",5836502,5836660,"-","Defensin","PVLSKGEGGLNGAVSLGRSNGPPEVEQECDTTSRLFRGLCWSRFNCATICVAEGYHDGHCSTVLRRCKCTKPCKKEK"),
 ("Chr04",7432080,7432337,"-","Defensin","CEDPVLSKGKGGLGVEARPSGLDGYHMPCDAESKLFRGHCWSNYNCANLCVSEEYEVGQCDVWSRLCTCFKPCRKDE"),
 ("Chr04",25700872,25701021,"-","Defensin","WSNGEGELGGEASSSGSDGLPNSMTCESKSRLFKGPCWSSFKCKNLCVTEGYQSGLCETSGRICNCEKLC"),
 ("Chr04",120255368,120255571,"+","Defensin","QNTSIWFLCFLASSSCNFFLFFFKSCVEDDVASPVHAEKICGSLSQFMGICVSSTNCAQICQTEGFSSGHCQGSEYRCFCTKPCSS"),
 ("Chr09",136142526,136142712,"+","Snakin_GASA","ITLKNARANVIGGAAIHNTAMLCVLFFCQKCYRKCLCVPQDTYGNSQACLRYKNWKTQGGGPKCP"),
]
for i,(ch,s,e,st,fam,pep) in enumerate(backfill,1):
    members.append({"protein_id":f"{ch}_{s}_backfill","family":fam,
        "subtype":"backfill_defensin" if fam=="Defensin" else "backfill_GASA",
        "length_aa":len(pep),"source":"tblastn_backfill","peptide":pep,
        "chrom":ch,"start":s,"end":e,"strand":st})

# ---- assign publication IDs, ordered by chrom then start ----
PREFIX={"Defensin":"RsDEF","Thionin":"RsTHI","Snakin_GASA":"RsSNA","nsLTP":"RsLTP"}
def chrkey(ch):
    import re
    m=re.match(r"Chr(\d+)",ch); return (0,int(m.group(1))) if m else (1,ch)
for fam in PREFIX:
    fam_m=[m for m in members if m["family"]==fam]
    fam_m.sort(key=lambda m:(chrkey(m["chrom"]),m["start"]))
    for i,m in enumerate(fam_m,1):
        m["member_id"]=f"{PREFIX[fam]}{i}"

members=[m for m in members if m["family"] in PREFIX]
members.sort(key=lambda m:(list(PREFIX).index(m["family"]),chrkey(m["chrom"]),m["start"]))

from collections import Counter
print("=== FINAL member counts ===")
print(dict(Counter(m["family"] for m in members)))
print("by source:",dict(Counter(m["source"] for m in members)))
print("total:",len(members))

cols=["member_id","family","subtype","source","protein_id","chrom","start","end","strand","length_aa"]
with open(f"{TAB}/T1_AMP_members.csv","w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=cols,extrasaction="ignore");w.writeheader();w.writerows(members)

# ---- final peptide fasta (annotated pulled from protein.fa; backfilled from stored ORF) ----
from Bio import SeqIO
prot={r.id:str(r.seq) for r in SeqIO.parse(f"{PROJ}/data/protein.fa","fasta")}
with open(f"{INTER}/members_final.faa","w") as f:
    for m in members:
        seq=m["peptide"] if m["peptide"] else prot[m["protein_id"]]
        f.write(f">{m['member_id']} {m['family']}|{m['subtype']}|{m['source']}|{m['chrom']}:{m['start']}-{m['end']}\n{seq}\n")
print(f"\nwrote {TAB}/T1_AMP_members.csv and {INTER}/members_final.faa ({len(members)} seqs)")
