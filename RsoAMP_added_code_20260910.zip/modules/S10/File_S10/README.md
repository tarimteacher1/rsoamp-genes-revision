# File S10: restored characterization and duplication evidence

This supplement provides Tables S51–S56 for the current 73-member R. soongarica primary catalogue. It supplements Files S1–S9; it does not replace their historical or current datasets.

## Reproduce

Use Python 3.13 and the versions in requirements.txt. From this folder run:

```text
python -m pip install -r requirements.txt
python analyze_restoration.py
```

Outputs appear in analysis/. The script checks all 73 protein hashes against the catalogue, computes precursor physicochemical properties, extracts the existing MCScanX gene-type assignments, verifies sequences and coordinates for 66 annotation-derived members, matches seven segmental pairs to collinearity anchors, and validates the core-cysteine coordinates of 40 nsLTPs.

## Results and interpretation

- S51: 73 complete precursor sequences; molecular weight, pI, charge at pH 7, GRAVY, instability index, aliphatic index and cysteine counts.
- S52: family-specific minimum, median and maximum for these properties.
- S53/S54: 66 assessed members (19 tandem, 2 proximal, 14 whole-genome/segmental, 23 dispersed and 8 singleton); seven reconstructed models are not assessed, not classified as singletons.
- S55: all seven candidate segmental pairs match original within-genome anchors in five blocks. The archive contains 161 within-genome blocks overall; S55 is the candidate-pair subset.
- S56: sequence-checked 8-cysteine positions and seven gap lengths for 40 primary nsLTPs; 13 positive GPI predictions. The seven gap lengths count residues strictly between successive core cysteines, using 1-based full-precursor coordinates. RsLTP41 uses the core 28–101 and signal region 1–22 recorded in S33; its predicted attachment site is not fixed. A type 1/type 2 classification is not inferred from these descriptors alone.

## Corrections and provenance

The original 06_physchem.py used Biopython 1.87 amino_acids_percent and multiplied its already-percentage values by 100. Consequently the aliphatic-index column in the archived T2 table is approximately 100-fold too large (allowing for rounding). This archived column is DEPRECATED and must not be used as a result. The corrected formula is 100*[n(A)+2.9*n(V)+3.9*(n(I)+n(L))]/L. All other compared original theoretical metrics agree within their original rounding for the 66 identical annotation-derived sequences. Current S51 is authoritative.

The original 05_build_final_members.py assigned type1/type2 labels from domain identifiers (including broad PF00234); 19_nsltp_curation.py assessed family boundaries and did not establish an independent 8-cysteine-spacing structural classification. Archived scripts are supplied for provenance only and should not be used to regenerate the current catalogue. Table S56 preserves observed structural features, independently of the supported phylogenetic groups.

MCScanX is not rerun by this supplement. The original gene_type, gff, tandem and collinearity files are retained with checksums. The original reference contains 21,791 proteins; all 66 retained members have exact matching sequences and coordinates. Gene-type codes are 0 singleton, 1 dispersed, 2 proximal, 3 tandem, 4 whole-genome/segmental. These are software assignments; code 4 alone is not evidence for a particular whole-genome duplication event. The archived block header records MATCH_SCORE=50, MATCH_SIZE=5, GAP_PENALTY=-1, OVERLAP_WINDOW=5, E_VALUE=1e-05, MAX GAPS=25. The exact original duplicate_gene_classifier command/version printout was not recovered for this run; no additional unrecorded parameters are claimed. The original software inventory identifies an MCScanX build in the cotton environment. This is distinct from the later two-species comparison runs.

The retained 23 candidate-pair Ka/Ks dataset (16 tandem, 7 segmental pairs) is separate from the complete member-level duplication classification. All 16 tandem pairs were also checked against the archived tandem file. The seven reconstructed models are absent from the old genomic classifier reference and receive no inferred gene_type.

Full sequences, source tables and scripts allow reproduction of the added calculations and retained-output checks. They do not constitute a new rerun of the upstream genome-wide MCScanX search or experimental confirmation of protein properties.

## Method sources

- Biopython ProteinAnalysis: https://biopython.org/docs/latest/api/Bio.SeqUtils.ProtParam.html
- ExPASy ProtParam equations and scope: https://web.expasy.org/protparam/protparam-doc.html
- Ikai (1980), aliphatic index: https://pubmed.ncbi.nlm.nih.gov/7462208/
- MCScanX official source and gene classification: https://github.com/wyp1125/MCScanX

No new public-repository upload is claimed for File S10. It accompanies the current revision locally.
