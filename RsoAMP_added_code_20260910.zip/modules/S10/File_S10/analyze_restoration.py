import csv, hashlib, json, re, statistics
from pathlib import Path
from collections import Counter
from Bio import SeqIO, __version__ as bioversion
from Bio.SeqUtils.ProtParam import ProteinAnalysis
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'sources'
OUT = ROOT / 'analysis'
OUT.mkdir(exist_ok=True)
w = load_workbook(SRC/'supplement.xlsx', data_only=True)
def sheet(name):
    vals=list(w[name].values)
    return [dict(zip(vals[0],r)) for r in vals[1:]]
def write(name,rows):
    with (OUT/(name+'.tsv')).open('w',encoding='utf-8-sig',newline='') as f:
        cw=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');cw.writeheader();cw.writerows(rows)
    return rows
cat=sheet('S1_Catalogue'); bymid={r['member_id']:r for r in cat}
fa={r.id.removeprefix('RSO__'):str(r.seq) for r in SeqIO.parse(SRC/'primary73.faa','fasta')}
oldfa={r.id:str(r.seq) for r in SeqIO.parse(SRC/'remote/members_final.faa','fasta')}
oldphys={r['member_id']:r for r in csv.DictReader((SRC/'remote/T2_physicochemical.csv').open())}
phys=[]; oldaudit=[]
for r in cat:
    s=fa[r['protein_id']]; assert set(s)<=set('ACDEFGHIKLMNPQRSTVWY')
    assert hashlib.sha256(s.encode()).hexdigest()==r['protein_sha256']
    assert len(s)==r['length_aa']
    pa=ProteinAnalysis(s);c=Counter(s)
    row=dict(member_id=r['member_id'],family=r['family'],protein_id=r['protein_id'],length_aa=len(s),molecular_weight_Da=pa.molecular_weight(),theoretical_pI=pa.isoelectric_point(),net_charge_pH7=pa.charge_at_pH(7.0),GRAVY=pa.gravy(),instability_index=pa.instability_index(),aliphatic_index=100*(c['A']+2.9*c['V']+3.9*(c['I']+c['L']))/len(s),cysteine_count=c['C'],protein_sha256=r['protein_sha256'],sequence_scope='complete untrimmed precursor; theoretical unmodified sequence')
    phys.append(row)
    if r['member_id'] in oldfa:
        same=s==oldfa[r['member_id']]
        old=oldphys[r['member_id']]
        oldaudit.append(dict(member_id=r['member_id'],exact_sequence_match=same,old_aliphatic_index=old['aliphatic_index'],corrected_aliphatic_index=row['aliphatic_index'],old_over_corrected=float(old['aliphatic_index'])/row['aliphatic_index'] if row['aliphatic_index'] else None))
write('S51_Physicochemical',phys);write('old_physchem_comparison',oldaudit)
summary=[]
for fam in ['Defensin','Snakin_GASA','nsLTP','All_primary']:
    rows=[r for r in phys if fam=='All_primary' or r['family']==fam]
    for metric in ['length_aa','molecular_weight_Da','theoretical_pI','net_charge_pH7','GRAVY','instability_index','aliphatic_index','cysteine_count']:
        v=[r[metric] for r in rows]
        summary.append(dict(family=fam,n=len(rows),metric=metric,min=min(v),median=statistics.median(v),max=max(v)))
write('S52_PhyschemSummary',summary)
gt=dict(line.split() for line in (SRC/'remote/rso.gene_type').read_text().splitlines() if line.strip())
coords={t[1]:(t[0],int(t[2]),int(t[3])) for line in (SRC/'remote/rso.gff').read_text().splitlines() if (t:=line.split())}
olddup={r['protein_id']:r for r in csv.DictReader((SRC/'remote/T3_duplication.csv').open())}
codes={'0':'singleton','1':'dispersed','2':'proximal','3':'tandem','4':'WGD_segmental'}
dups=[]
for r in cat:
    pid=r['protein_id']; inref=pid in gt
    if inref:
        assert pid in coords and oldfa[r['member_id']]==fa[pid]
        chrom,start,end=coords[pid]
        assert chrom=='rs'+r['chrom'].removeprefix('Chr') and start==r['start'] and end==r['end'],(pid,coords[pid],r)
        assert codes[gt[pid]]==olddup[pid]['duplication_type']
    else: assert r['member_id'] in ['RsDEF15','RsDEF16','RsDEF17','RsDEF18','RsDEF19','RsDEF20','RsLTP41']
    dups.append(dict(member_id=r['member_id'],family=r['family'],protein_id=pid,chrom=r['chrom'],start=r['start'],end=r['end'],gene_type_code=gt.get(pid),duplication_type=codes[gt[pid]] if inref else 'not_assessed',reference_status='present in archived genome-wide classification' if inref else 'reconstructed model absent from classification reference',coordinate_and_sequence_match='YES' if inref else 'NOT_APPLICABLE',protein_sha256=r['protein_sha256']))
write('S53_DuplicationModes',dups)
dsummary=[]
for fam in ['Defensin','Snakin_GASA','nsLTP','All_primary']:
    rr=[r for r in dups if fam=='All_primary' or r['family']==fam];cc=Counter(r['duplication_type'] for r in rr)
    for c in list(codes.values())+['not_assessed']:
        dsummary.append(dict(family=fam,mode=c,n=cc[c],family_total=len(rr),classified_total=sum(r['gene_type_code'] is not None for r in rr)))
write('S54_DuplicationSummary',dsummary)
blocks=[]; anchors={}; current=None
for line in (SRC/'remote/rso.collinearity').read_text().splitlines():
    m=re.match(r'## Alignment (\d+): score=(\S+) e_value=(\S+) N=(\d+) (\S+) (\S+)',line)
    if m:
        current=dict(block_id=int(m[1]),block_score=float(m[2]),block_evalue=m[3],block_anchor_count=int(m[4]),block_chromosomes=m[5],block_orientation=m[6]);blocks.append(current)
    elif line.strip() and not line.startswith('#'):
        p=line.split('\t'); assert len(p)==4
        a,b=p[1:3]; key=tuple(sorted([a,b]));anchors.setdefault(key,[]).append(dict(**current,anchor_index=p[0].strip(),anchor_evalue=p[3].strip()))
segs=[r for r in sheet('S11_KaKsAudit') if 'segmental' in str(r['duplication_mode']).lower()]
evidence=[]
for r in segs:
    a,b=r['member_a'],r['member_b'];pa,pb=bymid[a]['protein_id'],bymid[b]['protein_id']; matches=anchors.get(tuple(sorted([pa,pb])),[]); assert matches,(a,b)
    for m in matches:
        evidence.append(dict(member_a=a,member_b=b,protein_a=pa,protein_b=pb,family=r['family'],**m,coordinates_match_current_catalogue=True,source='rso.collinearity; rso.gff'))
write('S55_IntraspeciesAnchors',evidence)
# Preserve existing, sequence-verified framework coordinates, including the reconstructed LTPg model.
ns={r['member_id']:r for r in sheet('S3_nsLTP_Evidence') if r['species']=='rso'}
frames=[]
for r in cat:
    if r['family']!='nsLTP':continue
    s=fa[r['protein_id']]
    if r['member_id']=='RsLTP41':
        n=dict(core_cysteine_positions='28;35;49;50;63;65;91;101',core_start=28,core_end=101,core_spacing='6-13-0-12-1-25-9',signal_present='YES',signal_cut=22,gpi_present='True',gpi_omega=None,specific_ipr='IPR000528',full_sequence=s)
        source='S33: sequence-verified core 28-101; DeepSig/TMbed signal 1-22; PredGPI-positive; attachment site not fixed'
    else:n=ns[r['member_id']];source='S3: exact protein sequence and core coordinates rechecked'
    assert n['full_sequence']==s
    cp=[int(x) for x in n['core_cysteine_positions'].split(';')]; assert len(cp)==8 and all(s[x-1]=='C' for x in cp)
    gaps=[b-a-1 for a,b in zip(cp,cp[1:])];assert '-'.join(map(str,gaps))==n['core_spacing']
    frames.append(dict(member_id=r['member_id'],protein_id=r['protein_id'],precursor_length_aa=len(s),full_precursor_cysteines=s.count('C'),core_start_1based=cp[0],core_end_1based=cp[-1],core_cysteine_positions=';'.join(map(str,cp)),C1_C2_gap=gaps[0],C2_C3_gap=gaps[1],C3_C4_gap=gaps[2],C4_C5_gap=gaps[3],C5_C6_gap=gaps[4],C6_C7_gap=gaps[5],C7_C8_gap=gaps[6],signal_peptide=n['signal_present'],signal_end=n['signal_cut'],GPI_predicted=n['gpi_present'],predicted_omega=n['gpi_omega'],specific_InterPro=n['specific_ipr'],current_subtype=r['final_subtype'],structural_type_assignment='not assigned; core spacing and GPI architecture reported separately',evidence_source=source,protein_sha256=r['protein_sha256']))
write('S56_nsLTP_Framework',frames)
assert len(phys)==73 and len(dups)==73 and len(frames)==40 and len(segs)==7
report=dict(biopython_version=bioversion,primary_sequence_hashes_verified=73,old_sequence_matches=sum(r['exact_sequence_match'] for r in oldaudit),old_aliphatic_ratio_range=[min(r['old_over_corrected'] for r in oldaudit),max(r['old_over_corrected'] for r in oldaudit)],genome_classifier_genes=len(gt),genome_collinearity_blocks=len(blocks),classified_current_members=66,reconstructed_not_assessed=7,duplication_counts=dict(Counter(r['duplication_type'] for r in dups)),segmental_pairs_verified=len(segs),segmental_anchor_rows=len(evidence),segmental_distinct_blocks=len({r['block_id'] for r in evidence}),nsLTP_core_verified=40,GPI_positive=sum(str(r['GPI_predicted']).lower()=='true' for r in frames),physchem_summary=summary)
(OUT/'restoration_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
