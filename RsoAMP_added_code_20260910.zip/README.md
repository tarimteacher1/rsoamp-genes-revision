# RsoAMP revision additions, 10 September 2026

This update complements the fixed `revision-20260909` release, the reader-label update and the 14-pattern promoter amendment. Download those earlier records for Files S1–S9. This bundle adds Files S10–S11 and the authoritative current Tables S1–S59 and figure PDFs. No manuscript or reviewer correspondence is included.

## Run order

1. Verify distributed bytes: `python verify_manifest.py` from this bundle directory.
2. Install dependencies recorded in each module's requirements.txt, preferably in separate environments. The checks here used Python 3.13, Biopython 1.87, openpyxl 3.1.5, matplotlib 3.10.8 and numpy 2.4.3; source requirements retain the module-specific ranges.
3. File S10: `python -X utf8 modules/S10/File_S10/analyze_restoration.py`. Outputs: S51–S56 under that module's analysis/.
4. File S11: `python -X utf8 modules/S11/File_S11_Arabidopsis_comparison_20260910/reproduce.py`. Outputs: S57–S59 and the regenerated Figure 8/Arabidopsis atlas under that module. Original DIAMOND/MCScanX outputs are re-parsed; no new genome-wide search is performed by this command.
5. Compare the results with tables/Supplementary_Tables_S1-S59.xlsx. The source workbooks inside modules are preserved inputs; their historical sheet coverage does not supersede the final workbook.

## Scope

- Primary catalogue: 73 members (15 defensin, 18 Snakin/GASA, 40 nsLTP). RsLTP20 remains extended-only.
- File S10: theoretical properties of all 73 complete precursors; 66 classified duplicates (19 tandem, 2 proximal, 14 WGD/segmental, 23 dispersed, 8 singleton); seven reconstructed models unassessed. Seven within-species candidate anchor pairs occur in five blocks. Structural cysteine spacing does not reinstate unverified type 1/type 2 labels.
- File S11: 26 primary Rso-candidate Arabidopsis anchors, involving 22 Rso members and 22 Arabidopsis loci; 13 Rso members link to both genomic comparators. Arabidopsis partners are not a matched curated family inventory.
- Tamarix collinearity used 21,791 Rso reference records plus 22,374 Tamarix reference records and five homology-derived Tamarix defensin models: 44,170 records. Seven newly reconstructed Rso models were not in that anchor input. The 44,177-record sequence-comparison database additionally includes those seven Rso models; these two counts describe different inputs.
- S21's input-scope field is clarified; anchor values and other scientific numbers are unchanged by publication. The final promoter panel remains 14 patterns and 42 joint tests, with no significant enrichment.
- The official-CDS-based T. chinensis candidate-pair comparison remains in S9; its limited subset does not establish a species effect or conserved function. No independent qRT-PCR or peptide-function experiment is added here.

## Provenance

`SOURCE_TO_PUBLIC.tsv` maps supplied S10/S11 entries to public entries and gives both SHA-256 values. Private execution prefixes use illustrative paths; this does not change numerical evidence or current analysis logic. Original source scripts are historical records where indicated, not interchangeable with current reproduction entry points. `MANIFEST_SHA256.tsv` verifies distributed bytes; pre-publication/source manifests inside modules identify their source bytes and may differ after path normalization.

Author-edited PDFs under figures/ are copied exactly from the current review set. The source mappings distinguish analytical reproduction from manual typography; regenerating a plot need not reproduce author PDF bytes. The existing repository license notice continues to apply; no new license is asserted for third-party sources.
