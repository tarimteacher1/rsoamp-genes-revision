"""Layout-only split heatmaps from frozen tables; no expression re-normalization."""
from pathlib import Path
import csv,json,hashlib,re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.text import Text
import fitz
O=Path(__file__).resolve().parent; R=O.parent
P=R/'启动子_F5'; E=R/'表达_F6_F7'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','text.color':'#27323B'})
COLORS={'Defensin':'#C43D3D','Snakin_GASA':'#2E6F9E','nsLTP':'#2F7D4A'}
def read(p):
 with p.open(encoding='utf-8-sig') as f:return list(csv.DictReader(f,delimiter='\t'))
def write(p,rr):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]),delimiter='\t');w.writeheader();w.writerows(rr)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def base_axes(fig,pos,ids,family,fontsize=9):
 ax=fig.add_axes(pos);ax.set_xlim(0,1);ax.set_ylim(len(ids),0)
 ax.set_yticks(np.arange(len(ids))+.5,labels=ids,fontsize=fontsize,fontstyle='italic')
 for t,n in zip(ax.get_yticklabels(),ids):t.set_color(COLORS[family[n]])
 ax.tick_params(length=0,pad=4)
 for s in ax.spines.values():s.set_visible(False)
 for j in range(1,len(ids)):
  if family[ids[j]]!=family[ids[j-1]]:ax.axhline(j,color='white',lw=2,zorder=4)
 return ax
def mesh(ax,matrix,cmap,lo,hi):
 nr,nc=matrix.shape
 h=ax.pcolormesh(np.arange(nc+1),np.arange(nr+1),matrix,cmap=cmap,vmin=lo,vmax=hi,edgecolors='white',linewidth=.20,rasterized=False)
 ax.set_xlim(0,nc);ax.set_ylim(nr,0)
 assert np.array_equal(np.asarray(h.get_array()),matrix)
 xy=h.get_coordinates();assert xy.shape==(nr+1,nc+1,2)
 assert np.array_equal(xy[:,:,0],np.tile(np.arange(nc+1),(nr+1,1)))
 assert np.array_equal(xy[:,:,1],np.tile(np.arange(nr+1)[:,None],(1,nc+1)))
 return h
def finish(fig,name,ids,extra,cells):
 fig.canvas.draw();ren=fig.canvas.get_renderer();tt=[];outside=[];overlap=[]
 for t in fig.findobj(Text):
  if not t.get_visible() or not t.get_text().strip():continue
  b=t.get_window_extent(ren)
  if b.width<=0 or b.height<=0:continue
  tt.append((t.get_text(),b))
  if b.x0<-.25 or b.y0<-.25 or b.x1>fig.bbox.width+.25 or b.y1>fig.bbox.height+.25:outside.append(t.get_text())
 for i,(t,b) in enumerate(tt):
  for u,c in tt[i+1:]:
   if b.overlaps(c):overlap.append([t,u])
 assert not outside,(name,'outside',outside)
 assert not overlap,(name,'text overlap',overlap)
 for ext in ['pdf','svg','png']:fig.savefig(O/(name+'.'+ext),dpi=600,facecolor='white')
 fig.savefig(O/(name+'_preview.png'),dpi=160,facecolor='white')
 pdf=fitz.open(O/(name+'.pdf'));text=pdf[0].get_text()
 assert len(pdf)==1 and all(re.search(r'\b'+n+r'\b',text) for n in ids)
 assert not any('Type3' in str(f) for f in pdf[0].get_fonts(full=True))
 q={'status':'PASS','figure_inches':fig.get_size_inches().tolist(),'member_label_font_pt':9,'all_other_labels_at_least_8pt':True,'members':len(ids),'all_member_labels_in_PDF':True,'text_overlap':overlap,'text_outside_canvas':outside,'all_cell_values_and_unit_coordinates_verified':True,'cell_count':len(cells),'clustering':False,'source_row_order_preserved_within_columns':True,'PDF_TrueType_fonts':True,'SVG_editable_text':'<text' in (O/(name+'.svg')).read_text(encoding='utf-8'),'PNG_dpi':600,**extra}
 write(O/(name+'_cell_coordinates.tsv'),cells)
 (O/(name+'_QA.json')).write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 plt.close(fig);return q
def figure5():
 old=json.loads((P/'figures/figure5_qa.json').read_text(encoding='utf-8'));ids=old['row_order'];names=old['column_order']
 rows=read(P/'results/cis_element_full_results.tsv');lookup={(r['member_id'],r['element']):int(r['nonredundant_genomic_site_count']) for r in rows}
 fam={r['member_id']:r['family'] for r in rows};audit={r['member_id']:r for r in read(P/'results/promoter_extraction_audit.tsv')}
 assert len(ids)==73 and len(names)==15 and len(lookup)==1095
 counts=np.array([[lookup[n,c] for c in names] for n in ids]);full=np.log1p(counts);assert float(full.max())==old['scale_max']
 labels={'MYB_core':'MYB core','E_box':'E-box','TGACG_CGTCA_core':'TGACG/CGTCA core','P_box':'P-box','ACGTG_flank_B':'BACGTG (custom)','STRE_like':'STRE-like'}
 fig=plt.figure(figsize=(7.2,8.5),dpi=140)
 fig.text(.028,.983,'Sequence motifs in upstream proxies',fontsize=12,va='top')
 fig.text(.028,.946,'73 primary genes · 2,000 bp · 15 double-stranded patterns',fontsize=9)
 fig.text(.028,.904,'Colour: ln(1 + nonredundant site count)',fontsize=8)
 cells=[];drawn=[];flagcells=[]
 for isright in [False,True]:
  rr=[n for n in ids if (fam[n]=='nsLTP')==isright];nr=len(rr);height=.61*nr/40;bottom=.84-height
  x=.606 if isright else .107
  ax=base_axes(fig,[x,bottom,.302,height],rr,fam)
  m=np.array([[np.log1p(lookup[n,c]) for c in names] for n in rr]);im=mesh(ax,m,'cividis',0,old['scale_max'])
  ax.set_xticks(np.arange(15)+.5,labels=[labels.get(c,c) for c in names],rotation=90,fontsize=8)
  for i,n in enumerate(rr):
   drawn.append(n)
   for j,c in enumerate(names):cells.append({'member_id':n,'family':fam[n],'column':c,'panel':'B' if isright else 'A','row_0based':i,'column_0based':j,'x0':j,'x1':j+1,'y0':i,'y1':i+1,'raw_count':lookup[n,c],'plotted_value_ln1p':repr(float(m[i,j]))})
  flags=np.array([[int(audit[n]['overlapping_other_gene_count'])>0,int(audit[n]['annotated_five_prime_utr_features'])==0] for n in rr],dtype=int)
  qc=fig.add_axes([x+.311,bottom,.032,height]);mesh(qc,flags,ListedColormap(['#f2f4f5','#a04d23']),0,1)
  qc.set_yticks([]);qc.set_xticks([.5,1.5],labels=['O','U'],fontsize=8);qc.tick_params(length=0,pad=4)
  for s in qc.spines.values():s.set_visible(False)
  for i,n in enumerate(rr):
   for j,c in enumerate(['Gene_overlap','No_5prime_UTR_annotation']):flagcells.append({'member_id':n,'flag':c,'panel':'B' if isright else 'A','row_0based':i,'column_0based':j,'x0':j,'x1':j+1,'y0':i,'y1':i+1,'flag_value':int(flags[i,j])})
  label='B  nsLTP (n = 40)' if isright else 'A  Defensin (15) + Snakin/GASA (18)'
  fig.text(.528 if isright else .028,.863,label,fontsize=9,weight='bold')
 cax=fig.add_axes([.61,.899,.302,.013]);cb=fig.colorbar(im,cax=cax,orientation='horizontal',ticks=[0,1,2,3,old['scale_max']]);cb.ax.set_xticklabels(['0','1','2','3','3.56']);cb.ax.tick_params(labelsize=8,length=2,pad=2)
 fig.text(.028,.125,'Brown flags: O, overlap with another gene; U, no annotated 5′UTR.',fontsize=8)
 fig.text(.028,.096,'Cells are sequence matches; binding and regulatory activity were not tested.',fontsize=8)
 fig.text(.028,.068,'Proxies use 66 annotated and 7 new-model boundaries; no independently mapped TSSs.',fontsize=8)
 assert drawn==ids and len(cells)==1095 and len(flagcells)==146
 write(O/'Figure5_primary73_compact_flag_coordinates.tsv',flagcells)
 return finish(fig,'Figure5_primary73_compact',ids,{'columns':names,'family_counts':{'Defensin':15,'Snakin_GASA':18,'nsLTP':40},'scale':[0,old['scale_max']],'colormap':'cividis','transformation':'natural log(1 + original integer count)','flag_cells_verified':146,'positive_overlap_flags':sum(int(r['flag_value']) for r in flagcells if r['flag']=='Gene_overlap'),'positive_no_UTR_flags':sum(int(r['flag_value']) for r in flagcells if r['flag']=='No_5prime_UTR_annotation'),'no_statistical_recalculation':True},cells)
def figure6():
 old=json.loads((E/'qa/figure6_verification.json').read_text(encoding='utf-8'));rr=read(E/'tables/Figure6_VST_row_zscore_52.tsv');ids=[r['member_id'] for r in rr];samples=old['samples'];fam={r['member_id']:r['family'] for r in rr};d={r['member_id']:r for r in rr}
 assert ids==old['row_order'] and len(ids)==52 and old['symmetric_color_limits']==[-3,3]
 fig=plt.figure(figsize=(7.2,7.8),dpi=140)
 fig.text(.028,.983,'Expression profiles of reference-covered AMP genes',fontsize=11.5,va='top')
 fig.text(.028,.945,'52 count-filtered members · nine RNA-seq libraries',fontsize=9)
 fig.text(.028,.90,'Colour: frozen row-wise VST z score',fontsize=8)
 cells=[];drawn=[]
 for right in [False,True]:
  mm=[n for n in ids if (fam[n]=='nsLTP')==right];nr=len(mm);height=.59*nr/30;bottom=.78-height;x=.606 if right else .107
  ax=base_axes(fig,[x,bottom,.363,height],mm,fam)
  m=np.array([[float(d[n][s]) for s in samples] for n in mm]);im=mesh(ax,m,'RdBu_r',-3,3)
  ax.set_xticks(np.arange(9)+.5,labels=['Rep. 1','Rep. 2','Rep. 3']*3,rotation=90,fontsize=8)
  for v in [3,6]:ax.axvline(v,color='white',lw=1.8,zorder=4)
  for xval,label,col in [(1.5,'CK','#63768D'),(4.5,'200 mM','#C49A47'),(7.5,'400 mM','#8B647C')]:
   ax.text(xval,1.027,label,transform=ax.get_xaxis_transform(),ha='center',va='bottom',fontsize=8,weight='bold',color=col)
   ax.plot([xval-1.4,xval+1.4],[1.012,1.012],transform=ax.get_xaxis_transform(),lw=3,color=col,clip_on=False)
  for i,n in enumerate(mm):
   drawn.append(n)
   for j,s in enumerate(samples):cells.append({'member_id':n,'family':fam[n],'sample':s,'condition':['CK','S200','S400'][j//3],'replicate':j%3+1,'panel':'B' if right else 'A','row_0based':i,'column_0based':j,'x0':j,'x1':j+1,'y0':i,'y1':i+1,'source_zscore_string':d[n][s],'plotted_zscore':repr(float(m[i,j]))})
  fig.text(.528 if right else .028,.845,'B  nsLTP (n = 30)' if right else 'A  Defensin (7) + Snakin/GASA (15)',fontsize=9,weight='bold')
 cax=fig.add_axes([.606,.895,.363,.015]);cb=fig.colorbar(im,cax=cax,orientation='horizontal',ticks=[-3,-2,-1,0,1,2,3]);cb.ax.tick_params(labelsize=8,length=2,pad=2)
 fig.text(.028,.101,'73 primary members: 66 in the original reference; 52 passed the count filter.',fontsize=8)
 fig.text(.028,.073,'Seven new models were not quantified. No missing values were imputed.',fontsize=8)
 fig.text(.028,.045,'Frozen row-wise VST z scores and sample order are retained; no clustering was applied.',fontsize=8)
 assert drawn==ids and len(cells)==468
 return finish(fig,'Figure6_expression52_compact',ids,{'samples':samples,'family_counts':old['family_counts'],'scale':[-3,3],'colormap':'RdBu_r','z_scores_read_directly_from_frozen_TSV':True,'z_score_recalculated':False,'sample_order_unchanged':True,'imputed_values':0,'no_statistical_recalculation':True},cells)
if __name__=='__main__':
 sources=[P/'results/cis_element_full_results.tsv',P/'results/promoter_extraction_audit.tsv',P/'figures/figure5_qa.json',P/'plot_promoters_primary73.py',E/'tables/Figure6_VST_row_zscore_52.tsv',E/'qa/figure6_verification.json',E/'draw_expression_figures.py']
 before={str(p.relative_to(R)):sha(p) for p in sources}
 report={'Figure5':figure5(),'Figure6':figure6()}
 assert before=={str(p.relative_to(R)):sha(p) for p in sources}
 (O/'source_hashes_unchanged.json').write_text(json.dumps({'original_sources_and_scripts_unchanged':True,'SHA256':before},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
