"""Minimal PDF text-operator edits preserving the author's A4 Figure 3 layout.

No figure reconstruction, sequence analysis or scientific data change occurs.
The SVG export outlines text to preserve the appearance of the authoritative PDF.
"""
from pathlib import Path
import hashlib,json,re
import fitz
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
STAGE=ROOT/'output'
AUTHOR=ROOT/'inputs'/'figure3'/'Figure3_author_input.pdf'
LOCAL=AUTHOR
BASE='Figure3_reader_labels_20260909'
OLD_LINE='Source: A, annotation; M6, reconstructed. UTR: S, source; M, model-derived; NR, not recorded.'
NEW_LINE='Source: A, reference annotation; R, reconstructed model. UTR: S, source; M, model-derived; NR, not recorded.'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def spans(page):
    return [s for b in page.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
def plain(x):
    if isinstance(x,(fitz.Rect,fitz.Point)):return list(x)
    if isinstance(x,dict):return {k:plain(v) for k,v in x.items() if k!='seqno'}
    if isinstance(x,(tuple,list)):return [plain(v) for v in x]
    return x

def main():
    # The author's embedded font has generous ascent/descent metrics whose
    # default extraction boxes overlap adjacent rows despite separated glyphs.
    # Use font-size-height extraction boxes for text-overlap and pixel masks.
    # This controls inspection only and does not alter any PDF content.
    fitz.TOOLS.set_small_glyph_heights(True)
    STAGE.mkdir(parents=True,exist_ok=True)
    assert sha(LOCAL)=='d0252a200f9f6d893e3eee4f4acc72a1485422aeff6a76f1f99535e62dc61db6', 'Unexpected author input PDF'
    source_hash=sha(AUTHOR)
    doc=fitz.open(LOCAL);page=doc[0]
    assert len(doc)==1 and len(page.get_contents())==1
    old_spans=spans(page)
    targets=[s for s in old_spans if s['text']=='M6' or s['text']==OLD_LINE]
    assert len(targets)==8 and sum(s['text']=='M6' for s in targets)==7
    table_size=next(s['size'] for s in targets if s['text']=='M6')
    xref=next(f[0] for f in page.get_fonts() if f[4]=='TT0')
    char_widths=doc.get_char_widths(xref,limit=128)
    assert all(char_widths[ord(c)][0]>0 for c in NEW_LINE if c!=' ')
    # Font size is carried by the 8.8063-scaled text matrix, with Tf=1.
    # TJ kerning centres the shorter R while leaving the text-line matrix,
    # and therefore the subsequent UTR-column positioning, untouched.
    shift=(char_widths[ord('M')][1]+char_widths[ord('6')][1]-char_widths[ord('R')][1])/2
    old_token=b'(M6)Tj'
    new_token=f'[-{shift*1000:.8f} (R)]TJ'.encode('ascii')
    stream=page.read_contents();assert stream.count(old_token)==7
    pattern=rb'8\.8063 0 0 8\.8063 25\.9248 766\.5479 Tm\n\(Sou\)Tj.*?\(ded\.\)Tj'
    match=re.search(pattern,stream,re.S);assert match
    old_block=match.group(0)
    new_block=('8.8063 0 0 8.8063 25.9248 766.5479 Tm\n('+NEW_LINE+')Tj').encode('ascii')
    updated=stream.replace(old_token,new_token).replace(old_block,new_block)
    assert updated.replace(new_token,old_token).replace(new_block,old_block)==stream
    doc.update_stream(page.get_contents()[0],updated)
    newpdf=STAGE/(BASE+'.pdf')
    doc.save(newpdf,deflate=True);doc.close()

    with fitz.open(LOCAL) as old,fitz.open(newpdf) as new:
        a,b=old[0],new[0]
        assert a.rect==b.rect
        new_spans=spans(b)
        new_targets=[s for s in new_spans if s['text']=='R' or s['text']==NEW_LINE]
        assert len(new_targets)==8 and sum(s['text']=='R' for s in new_targets)==7
        assert not re.search(r'\bM[1-9]\b',b.get_text())
        other_old=[s for s in old_spans if s not in targets]
        other_new=[s for s in new_spans if s not in new_targets]
        assert other_old==other_new,'Non-target text or its position/style changed'
        assert plain(a.get_drawings())==plain(b.get_drawings()),'Non-text vector geometry changed'
        assert a.get_images(full=True)==b.get_images(full=True)
        assert a.get_fonts(full=True)==b.get_fonts(full=True),'Original font resources changed'
        line=next(s for s in new_targets if s['text']==NEW_LINE)
        assert line['bbox'][2]<b.rect.width-20,'Source explanation exceeds existing page margin'
        for s in new_targets:
            r=fitz.Rect(s['bbox'])
            for other in other_new:
                assert not r.intersects(fitz.Rect(other['bbox'])),(s['text'],other['text'])
        # The exact visual comparison covers every pixel outside the eight
        # edited text bounding regions, expanded by 1 point for antialiasing.
        zoom=2
        pa=a.get_pixmap(matrix=fitz.Matrix(zoom,zoom),alpha=False)
        pb=b.get_pixmap(matrix=fitz.Matrix(zoom,zoom),alpha=False)
        aa=np.frombuffer(pa.samples,dtype=np.uint8).reshape(pa.height,pa.width,pa.n)
        bb=np.frombuffer(pb.samples,dtype=np.uint8).reshape(pb.height,pb.width,pb.n)
        mask=np.zeros((pa.height,pa.width),dtype=bool)
        edited_boxes=[]
        for s in targets+new_targets:
            r=fitz.Rect(s['bbox'])+(-1,-1,1,1);edited_boxes.append(list(r))
            mask[max(0,int(r.y0*zoom)):min(pa.height,int(np.ceil(r.y1*zoom))),max(0,int(r.x0*zoom)):min(pa.width,int(np.ceil(r.x1*zoom)))]=True
        difference=np.any(aa!=bb,axis=2)
        external=int(np.count_nonzero(difference & ~mask))
        assert external==0,f'{external} changed pixels outside the intended text areas'
        pix=b.get_pixmap(dpi=600,alpha=False);pix.save(STAGE/(BASE+'.png'))
        b.get_pixmap(dpi=140,alpha=False).save(STAGE/(BASE+'_preview.png'))
        (STAGE/(BASE+'.svg')).write_text(b.get_svg_image(text_as_path=True),encoding='utf-8')
        qa={'status':'PASS','method':'eight bounded edits in the original author PDF content stream; no Matplotlib reconstruction',
            'author_source':AUTHOR.relative_to(ROOT).as_posix(),'archived_author_source':LOCAL.relative_to(ROOT).as_posix(),'author_source_SHA256':source_hash,
            'page_size_points':list(b.rect),'PDF_pages':1,'row_source_label_mapping':{'A':'A','M6':'R'},
            'row_M6_to_R_replacements':7,'old_explanation':OLD_LINE,'new_explanation':NEW_LINE,
            'UTR_evidence_codes_S_M_NR_unchanged':True,'original_model_identifiers_and_all_scientific_numerics_unchanged':True,
            'all_other_content_stream_bytes_unchanged':True,'non_target_text_spans_exactly_equal_including_positions_and_fonts':True,
            'non_text_vector_drawings_exactly_equal':True,'font_resources_exactly_equal':True,'images_unchanged':True,
            'pixel_comparison_dpi':144,'changed_pixels_outside_target_text_regions':external,
            'target_region_changed_pixels':int(np.count_nonzero(difference)),
            'original_author_removed_footer_not_restored':True,'PNG_dpi':600,'PNG_dimensions':[pix.width,pix.height],
            'SVG_export':'vector PDF conversion; all text outlined as paths for appearance fidelity; not editable text',
            'text_overlap_with_non_target_text':False,'internal_M1_to_M9_labels_remaining':False,
            'output_SHA256':{p.name:sha(p) for p in STAGE.glob(BASE+'.*')}}
    assert sha(AUTHOR)==source_hash
    (STAGE/(BASE+'_QA.json')).write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(qa,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
