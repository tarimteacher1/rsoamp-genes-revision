"""Change only reader-visible wording in Figure 6; reuse every plotted value."""
from pathlib import Path
import hashlib, json
import fitz
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
STAGE=ROOT/'output'
INPUT_ROOT=ROOT/'inputs'/'figure6'
FILES=['source/plot_compact_F5_F6.py','tables/Figure6_VST_row_zscore_52.tsv','qa/figure6_verification.json']
REPLACEMENTS={
    'Colour: frozen row-wise VST z score':'Colour: row-wise VST z score',
    'Frozen row-wise VST z scores and sample order are retained; no clustering was applied.':
    'Row-wise VST z scores are shown in CK, 200 mM, 400 mM sample order; no clustering was applied.',
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def plain(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,(fitz.Rect,fitz.Point)):return list(v)
    if isinstance(v,dict):return {k:plain(x) for k,x in v.items() if k!='seqno'}
    if isinstance(v,(tuple,list)):return [plain(x) for x in v]
    if isinstance(v,np.generic):return v.item()
    return v
def drawings(p):
    with fitz.open(p) as d:return plain(d[0].get_drawings())
def axes_geometry(fig):
    fig.canvas.draw()
    records=[]
    for ax in fig.axes:
        r={'position':ax.get_position().bounds,'xlim':ax.get_xlim(),'ylim':ax.get_ylim(),
           'lines':[{'xy':l.get_xydata(),'colour':l.get_color(),'lw':l.get_linewidth()} for l in ax.lines],
           'collections':[{'array':c.get_array(),'coordinates':c.get_coordinates() if hasattr(c,'get_coordinates') else None,
                           'facecolours':c.get_facecolors(),'clim':c.get_clim()} for c in ax.collections]}
        records.append(plain(r))
    return records

def main():
    STAGE.mkdir(parents=True,exist_ok=True)
    manifest=[]
    for name in FILES:
        src=INPUT_ROOT/name
        manifest.append({'source':src.relative_to(ROOT).as_posix(),'SHA256':sha(src)})
    original=INPUT_ROOT/FILES[0]
    ns={'__file__':str(original),'__name__':'reader_figure6_source'}
    exec(compile(original.read_text(encoding='utf-8'),str(original),'exec'),ns)
    # Relocate only the expression input root; the archived plotting script
    # remains byte-identical. Figure 5 is not executed or included here.
    ns['E']=INPUT_ROOT
    finish=ns['finish'];ns['finish']=lambda *a:a
    fig,oldname,ids,extra,cells=ns['figure6']()
    before=axes_geometry(fig)
    from matplotlib.text import Text
    changed=[]
    for obj in fig.findobj(Text):
        if obj.get_text() in REPLACEMENTS:
            old=obj.get_text();obj.set_text(REPLACEMENTS[old]);changed.append({'old':old,'new':obj.get_text()})
    assert len(changed)==len(REPLACEMENTS)
    assert before==axes_geometry(fig)
    ns['O']=STAGE
    q=finish(fig,'Figure6_reader_labels_20260909',ids,extra,cells)
    oldpdf=INPUT_ROOT/'Figure6_before_label_revision.pdf'
    newpdf=STAGE/'Figure6_reader_labels_20260909.pdf'
    vector_same=drawings(oldpdf)==drawings(newpdf)
    assert vector_same,'Non-text PDF drawing geometry changed'
    with fitz.open(oldpdf) as a,fitz.open(newpdf) as b:
        assert a[0].rect==b[0].rect
        clip=fitz.Rect(0,110,a[0].rect.width,490)
        pa=a[0].get_pixmap(matrix=fitz.Matrix(2,2),clip=clip,alpha=False)
        pb=b[0].get_pixmap(matrix=fitz.Matrix(2,2),clip=clip,alpha=False)
        pixels_same=pa.samples==pb.samples
        assert pixels_same,'Heatmap-area rendering changed'
        text=b[0].get_text()
        assert 'frozen' not in text.lower() and 'retained' not in text.lower()
    assert all(sha(ROOT/r['source'])==r['SHA256'] for r in manifest)
    q.update({'visible_text_replacements':changed,'axes_and_all_468_cell_values_and_coordinates_unchanged':True,
              'source_PDF_nontext_drawings_identical':vector_same,'source_PDF_heatmap_area_pixels_identical_at_144dpi':pixels_same,
              'source_files_unchanged':True,'source_manifest':manifest,
              'source_PDF_SHA256':sha(oldpdf),
              'outputs':{p.name:sha(p) for p in STAGE.glob('Figure6_reader_labels_20260909.*')}})
    (STAGE/'Figure6_reader_labels_20260909_QA.json').write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(q,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
