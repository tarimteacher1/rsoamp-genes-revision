# Figure 3 and Figure 6 reader-label patch

This small supplement contains the final vector/raster figures and only the inputs needed to reproduce their label changes. It does not rerun sequence searches, gene-model reconstruction, expression normalization, statistical tests, or clustering.

## Reproduce

The package was tested with Python 3.13. The scripts locate all inputs relative to this package and write only to `output/`; no workstation paths or network access are needed.

```sh
python -m pip install -r requirements.txt
python scripts/build_reader_figure3_author_pdf.py
python scripts/build_reader_figure6.py
```

The scripts can also be invoked by their absolute script paths from another working directory. Installation of the listed Python packages is required only if they are not already present. DejaVu Sans is supplied by Matplotlib and embedded in the author PDF; no separately installed fonts are required.

## Scientific meaning of the labels

- In Figure 3, source **A** denotes a model from the reference annotation; source **R** denotes a reconstructed transcript model. Seven previously displayed source values are mapped to R without changing the model or member identifiers.
- **UTR** means untranslated region. The distinct evidence labels **S**, **M**, and **NR** remain: S, explicitly recorded in the source annotation; M, model-derived noncoding exonic portions; NR, UTR features not recorded. M is a defined evidence category, not a task number; NR does not establish biological absence of a UTR.
- The legacy raw value **M6**, retained in the archived input and replacement key, serves only compatibility/provenance. It does not create an additional scientific class or change the plotted membership.
- Span is the selected transcript model's inclusive genomic end minus start plus one, including introns. Each row is independently normalized to 0–1 and displayed 5′ to 3′, with minus-strand models reversed. Horizontal widths are proportional within a row but cannot be compared as absolute lengths across rows. Coding blocks include the terminal stop codon; a complete exon can contain both coding and noncoding portions.
- Model-derived noncoding exonic portions are the exon intervals remaining after subtraction of CDS and terminal-stop intervals; they are not independently annotated UTR or transcription-start-site boundaries.

Figure 3 preserves the author's A4 layout, all non-target text, fonts and vector shapes. It changes seven source labels and the source explanation in the original PDF content stream. It does not reconstruct the figure with Matplotlib or restore the footer removed during layout editing. Its SVG is a vector conversion with text outlined as paths for appearance fidelity; it is not an editable-text SVG. The PDF keeps its original embedded fonts and searchable text.

Figure 6 removes two workflow-state phrases from reader-visible text while retaining the meaning of row-wise VST z scores, CK/200 mM/400 mM sample order, and no clustering. The 52 × 9 matrix, numerical precision, geometry, colour scale and sample/member order are unchanged. Its SVG retains editable text.

## Contents and validation

- `inputs/figure3/Figure3_author_input.pdf`: the author-layout PDF before the bounded label replacement.
- `inputs/figure6/`: the previous Figure 6 PDF used to verify unchanged non-text graphics, the byte-preserved original plotting script, the 52-gene expression table, and its necessary QA metadata. Only the Figure 6 function is executed; unused Figure 5 dependencies are intentionally excluded.
- `scripts/`: the two portable plotting/label-patch scripts.
- `output/`: final PDF, SVG, 600 dpi PNG, low-resolution previews, numerical cell-coordinate table, and per-figure QA.
- `VALIDATION.json`: regeneration compared with the approved figure outputs, including full-page rendered-pixel and geometry checks. Binary PDF or SVG hashes may differ because of PDF identifiers, timestamps or SVG IDs while visible content is identical.
- `MANIFEST_SHA256.tsv`: package inventory at preparation time; regeneration may update output metadata hashes.

No manuscript, response letter, chat transcript, analysis database, credential, or machine-specific path is included. The source inputs and all model identifiers are retained. This is a reproducible presentation patch rather than a new biological analysis.
