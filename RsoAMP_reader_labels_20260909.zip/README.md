# Reader-facing labels and author figure layouts, 9 September 2026

This presentation amendment accompanies the fixed scientific release `revision-20260909` (commit `7593467f6fc8a81fe3c7440ecc857f7677ac1991`). It does not rerun biological analyses or alter candidate membership, coordinates, expression values, statistical results, tree topology or support.

## Current display terminology

Figure 3 uses **A = reference annotation** and **R = reconstructed model**. All models refer to the same study reference genome; R distinguishes a reconstructed transcript model from an entry in its original annotation. The seven reconstructed members formerly displayed with the internal task key M6 now use R. Stable original model identifiers remain unchanged.

UTR evidence classes S (source-annotated), M (model-derived) and NR (not recorded) retain their defined scientific meanings. Here M is an evidence category, not a numbered task. The complete caption explains independent 0–1 genomic-span scaling including introns, shared exon portions, and the limits of inferred UTRs.

Other reader-facing task labels in current table explanations were replaced with descriptions of family-evidence curation and gene-model reconstruction. `Reader_Guide` explains provenance and the preserved legacy worksheet/model keys. Raw historical source-label M6 and identifiers such as R1M6_CAND or M6MERGE remain valid compatibility keys in the scientific source archive; they are not the current figure display labels.

## Included material

- `current_figures/`: current author-layout Figures 1, 2 and 4, Figure 3 with bounded source-label edits on the author PDF, Figure 6 with internal workflow-status wording removed, and the complete current captions. Other figures retain the fixed scientific-release versions.
- `current_tables/`: the complete current S1–S50 workbook with reader guidance, and R/A structure-table views. Scientific values, stable IDs and decision states are unchanged. The workbook retains its historical sheets for traceability.
- `plotting/`: portable Figure 3/6 presentation scripts, their required inputs and verification. Figure 3 edits the author PDF content stream and preserves all non-target objects; it is not a regeneration of the author's layout from the initial Matplotlib source. Figure 6 uses unchanged prepared expression inputs.

SVGs converted from author PDFs retain vector outlines; their text is outlined rather than editable as text. Original PDFs retain their appearance and searchable text. Manuscript embedding may trim blank canvas margins without changing diagram content. Scientific inputs and the earlier plotting alternatives remain available in the base release.

Paths inside this public copy are normalized to illustrative paths. `SOURCE_MAP.json` records source/public hashes; original submission ZIP files have their own manifests. This amendment is an addition to, not a silent replacement of, the fixed base release.

Run `python verify_reader_update.py` to verify the package manifest. Follow `plotting/README.md` for the two portable display updates. No raw FASTQ/BAM or third-party software installations are bundled. Independent qRT-PCR and functional experiments remain unperformed.
